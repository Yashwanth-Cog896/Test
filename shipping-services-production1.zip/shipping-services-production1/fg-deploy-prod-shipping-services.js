const { execSync } = require('child_process')


const gitCommand = 'git rev-parse HEAD'
const gitCommitHash = execSync(gitCommand).toString().trim()

module.exports = {
  appParameters: {
    Cpu: '4096',
    Memory: '12GB',
    AppName: 'shipping-services',
    InstanceCount: 4,
    HealthCheckPath: '/shipping-services/',
    TaskRoleName: 'fargateappexecrole',
    environmentVars: {
      IS_FARGATE: true,
      FARGATE_ENV: 'prod',
     // VCAP_SERVICES: ''
    },
    port: 8080,
	    timeoutInSeconds: 500
  },
  aws: {
     accountId: '421144339100',
     fargateStackName: 'SC-421144339100-pp-cjvomptoudozo',
     region: 'us-east-1'
   },
  docker: {
      image: '421144339100.dkr.ecr.us-east-1.amazonaws.com/shipping-service:prod'
    
  },
  'autoScaling': {
    'enabled': true,
    'maxInstances': 6,
    'scalingPolicies': [
      {
        'scaleBy': 'CPU',
        'targetValue': 75,
        'scaleInCooldown': 600,
        'scaleOutCooldown': 60
      },
      {
        'scaleBy': 'Memory',
        'targetValue': 75,
        'scaleInCooldown': 600,
        'scaleOutCooldown': 60
      },
      {
        'scaleBy': 'RequestCount',
        'targetValue': 200,
        'scaleInCooldown': 600,
        'scaleOutCooldown': 60
      }
    ]
  }
}
