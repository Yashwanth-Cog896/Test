package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.PrintOptions;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.util.Map;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/printing")
public interface PrintingService {
    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/packing-list-container/{container-id}/print/{printer-Id}")
    void printContainmentLabels(@PathParam("container-id") Long shipmentContainerId, @PathParam("printer-Id") Long printerId, PrintOptions printOptions);

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/packing-list/{packing-list-id}/print/{printer-Id}")
    void printAllContainmentLabels(@PathParam("packing-list-id") Long packingListId, @PathParam("printer-Id") Long printerId, PrintOptions printOptions);

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/shipment-container/{container-id}/print/{printer-Id}")
    void printCarrierLabel(@PathParam("container-id") Long shipmentContainerId, @PathParam("printer-Id") Long printerId);

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/shipment/{shipment-id}/print/{printer-Id}")
    void printAllCarrierLabels(@PathParam("shipment-id") Long shipmentId, @PathParam("printer-Id") Long printerId);

    @GET
    @Produces(APPLICATION_JSON)
    @Path("/view-label")
    Map<String, String> viewLabel(@QueryParam("packing-list-id") Long packingListId, @QueryParam("container-layer") String containmentLayer, @QueryParam("box-num") Integer boxNumber, @QueryParam("print-total-boxes") Boolean printTotalBoxes);
}
