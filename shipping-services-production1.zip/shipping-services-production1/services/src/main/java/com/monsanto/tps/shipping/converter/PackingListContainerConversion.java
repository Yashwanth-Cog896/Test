package com.monsanto.tps.shipping.converter;

import com.google.common.base.Function;
import com.monsanto.tps.shipping.dao.ShipmentStatusDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.util.DtoConverter;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;

@Service
public class PackingListContainerConversion implements DtoConverter<PackingListContainer, ShipmentContainerEntity> {

    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;

    @Autowired
    private ShipmentStatusDao shipmentStatusDao;

    public ShipmentContainerEntity toEntity(PackingListContainer dto, ShipmentContainerEntity entity) {
        entity.setGrossWeight(dto.getGrossWeight());
        entity.setNetWeight(dto.getNetWeight());
        entity.setUomId(unitOfMeasureDao.getInventoryMgtUomIdFromAbbreviation(dto.getUom()));
        if (dto.getShippingStatus() != null) {
            entity.setStatus(shipmentStatusDao.getByName(dto.getShippingStatus()));
        }
        return entity;
    }

    @Override
    public PackingListContainer toDto(ShipmentContainerEntity entity, PackingListContainer dto) {
        if (entity == null) {
            return null;
        }

        createBaseDto(entity, dto);

        dto.setGrossWeight(entity.getGrossWeight());
        dto.setNetWeight(entity.getNetWeight());
        dto.setUom(StringUtils.lowerCase(unitOfMeasureDao.getAbbreviationFromInventoryMgtUomId(entity.getUomId())));
        if (entity.getStatus() != null) {
            dto.setShippingStatus(entity.getStatus().getName());
        }

        return dto;
    }

    private PackingListContainer createBaseDto(ShipmentContainerEntity entity, PackingListContainer dto) {
        if (entity == null) {
            return null;
        }
        dto.setId(entity.getShipmentContainerId());
        StorageContainerEntity storageContainer = entity.getStorageContainer();
        dto.setName(storageContainer.getName());
        dto.setStagingContainer(!storageContainer.getStorageContainerType().getName().equals("Box"));
        dto.setBarcode(storageContainer.getBarcode());
        dto.setStorageContainerId(storageContainer.getStorageContainerId());

        return dto;
    }

    public Function<ShipmentContainerEntity, PackingListContainer> toDto() {
        return new Function<ShipmentContainerEntity, PackingListContainer>() {
            @Override
            public PackingListContainer apply(@Nullable ShipmentContainerEntity input) {
                return toDto(input, new PackingListContainer());
            }
        };
    }

    public Function<ShipmentContainerEntity, PackingListContainer> toBaseDto() {
        return new Function<ShipmentContainerEntity, PackingListContainer>() {
            @Override
            public PackingListContainer apply(@Nullable ShipmentContainerEntity input) {
                return createBaseDto(input, new PackingListContainer());
            }
        };
    }
}
