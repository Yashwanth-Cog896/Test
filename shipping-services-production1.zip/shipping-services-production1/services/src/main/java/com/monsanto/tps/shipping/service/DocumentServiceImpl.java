package com.monsanto.tps.shipping.service;

import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.AttachmentUtil;
import com.monsanto.tps.shipping.business.DocumentBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Document;
import com.monsanto.tps.shipping.service.model.FileResponse;
import com.monsanto.tps.shipping.service.model.enums.DocumentEnum;
import com.monsanto.tps.shipping.service.validation.PackingListValidatorImpl;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import software.amazon.awssdk.services.s3.model.S3Object;

import javax.activation.DataHandler;
import javax.annotation.Nullable;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;

@Component("documentService")
public class DocumentServiceImpl implements DocumentService {

    private static final Logger log = LogManager.getLogger(DocumentServiceImpl.class);

    @Autowired
    private ShipmentPackingListBusiness packingListBusiness;
    @Autowired
    private PackingListValidatorImpl packingListValidator;
    @Autowired
    private DocumentBusiness documentBusiness;

    @Override
    public List<Document> getDocumentList(String scope, @Nullable Long id) {
        DocumentEnum documentEnum = DocumentEnum.getByScope(scope);
        List<String> fileNames = documentBusiness.retrieveFileNames(documentEnum, id);
        return generateDocumentsFromFileNames(fileNames);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<Document> uploadDocument(String scope, Long id, MultipartBody multipartBody) {
        DocumentEnum documentEnum = DocumentEnum.getByScope(scope);
        List<Attachment> allAttachments = multipartBody.getAllAttachments();
        return filterAttachmentsToSave(id, documentEnum, allAttachments);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public FileResponse downloadDocument(String scope, Long id, String base64EncodedFileName) {
        DocumentEnum documentEnum = DocumentEnum.getByScope(scope);
        if (!DocumentEnum.PACKING_LIST.equals(documentEnum)) {
            throw new UnsupportedOperationException("Only packing-list is supported at this time.");
        }
        ShipmentPackingListEntity packingList = packingListBusiness.getShipmentPackingList(id);
        String barcode = packingList.getBarcode();
        String fileName = decodeFileName(base64EncodedFileName);

        if ("uploaded-docs-all".equals(fileName)) {
            return createFileResponseOfAllFiles(id, documentEnum, barcode);
        }
        return createFileResponseForFile(id, fileName, documentEnum, barcode);
    }

    private String decodeFileName(String base64EncodedFileName){
        byte[] decoded = Base64.decodeBase64(base64EncodedFileName);
        String fileName = null;
        try {
            fileName = new String(decoded, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new ShippingWebException("unable to decode the fileName", e);
        }
        return fileName;
    }

    @Override
    public void deleteDocument(String scope, Long id, String base64EncodedFileName) {
        DocumentEnum documentEnum = DocumentEnum.getByScope(scope);
        if (documentEnum == null) {
            throw new ShippingWebException("Invalid scope provided: " + scope);
        }
        String fileName = decodeFileName(base64EncodedFileName);
        documentBusiness.delete(documentEnum, id, fileName);
    }

    @Override
    public void deleteAll(String scope, Long id) {
        DocumentEnum documentEnum = DocumentEnum.getByScope(scope);
        if (documentEnum == null) {
            throw new ShippingWebException("Invalid scope provided: " + scope);
        }
        documentBusiness.deleteAsync(documentEnum, id);
    }

    @Override
    public boolean pathExists(Long id){
        return documentBusiness.pathExists(DocumentEnum.PACKING_LIST, id);
    }

    private List<Document> filterAttachmentsToSave(Long id, DocumentEnum documentEnum, List<Attachment> allAttachments) {
        Set<String> duplicateFileNames = new HashSet<String>();
        List<String> fileNames = saveFilteredAttachments(id, documentEnum, allAttachments, duplicateFileNames);
        List<Document> documents = generateDocumentsFromFileNames(fileNames);
        checkForDuplicatesAndUpdateDocument(documents, duplicateFileNames);
        return documents;
    }

    private List<String> saveFilteredAttachments(Long id, DocumentEnum documentEnum, List<Attachment> allAttachments, Set<String> duplicateFileNames) {
        List<Attachment> attachmentsToSave = new ArrayList<Attachment>();
        if (DocumentEnum.PACKING_LIST.equals(documentEnum)) {
            ShipmentPackingListEntity shipmentPackingList = packingListBusiness.getShipmentPackingList(id);
            boolean isEditable = packingListValidator.isEditable(shipmentPackingList);
            if (!isEditable) {
                Set<String> existingFileNames = retrieveExistingFileNames(id, documentEnum);
                for (Attachment attachment : allAttachments) {
                    String fileName = AttachmentUtil.getFileName(attachment);
                    if (existingFileNames.contains(fileName)) {
                        duplicateFileNames.add(fileName);
                    } else {
                        attachmentsToSave.add(attachment);
                    }
                }
                if(CollectionUtils.isEmpty(attachmentsToSave)){
                    return new ArrayList<String>(existingFileNames);
                }
            } else {
                attachmentsToSave.addAll(allAttachments);
            }
        } else {
            attachmentsToSave.addAll(allAttachments);
        }

        return documentBusiness.saveAttachments(documentEnum, id, attachmentsToSave);
    }

    private Set<String> retrieveExistingFileNames(Long id, DocumentEnum documentEnum) {
        List<String> fileNames = documentBusiness.retrieveFileNames(documentEnum, id);
        return new HashSet<String>(fileNames);
    }

    private void checkForDuplicatesAndUpdateDocument(List<Document> finalDocuments, Set<String> duplicateFileNames) {
        for (Document document : finalDocuments) {
            if (duplicateFileNames.contains(document.getFileName())) {
                document.setDuplicate(true);
            }
        }
    }

    private FileResponse createFileResponseForFile(Long id, String fileName, DocumentEnum documentEnum, String barcode) {
        byte[] obj = documentBusiness.retrieveAttachment(documentEnum, id, fileName);
        if (obj == null) {
            log.error("file not found for " + fileName);
            return null;
        }
        try {
            ByteArrayOutputStream os = generateByteArrayOutputStreamFromByteArray(obj);
            return new FileResponse(barcode + "_" + fileName, os);
        } catch (IOException e) {
            log.error("An error occurred while trying to convert the file to a responseEntity.", e);
            return null;
        }
    }

    private FileResponse createFileResponseOfAllFiles(Long id, DocumentEnum documentEnum, String barcode) {
        List<String> fileNames = documentBusiness.retrieveFileNames(documentEnum, id);

        Map<String, Future<byte[]>> docsMap = Maps.newHashMapWithExpectedSize(fileNames.size());
        for (String fileName : fileNames) {
            docsMap.put(fileName, documentBusiness.retrieveAttachmentAsync(documentEnum, id, fileName));
        }

        Map<String, ByteArrayOutputStream> zipFilesMap = getZipFilesMap(barcode, docsMap);
        return new FileResponse(barcode + "_uploaded-documents.zip", zipFilesMap);
    }

    private Map<String, ByteArrayOutputStream> getZipFilesMap(String barcode, Map<String, Future<byte[]>> docsMap) {
        Map<String, ByteArrayOutputStream> zipFilesMap = Maps.newHashMap();
        for (Map.Entry<String, Future<byte[]>> entry : docsMap.entrySet()) {
            String filePath = entry.getKey();
            Future<byte[]> fobj = entry.getValue();
            String fileName = barcode + "_" + filePath;
            try {
                byte[] obj = fobj.get();
                zipFilesMap.put(fileName, generateByteArrayOutputStreamFromByteArray(obj));
            } catch (Exception e) {
                addErrorTextFileToZip(zipFilesMap, fileName, e);
            }
        }
        return zipFilesMap;
    }

    private ByteArrayOutputStream generateByteArrayOutputStreamFromByteArray(byte[] obj) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(obj.length);
        baos.write(obj, 0, obj.length);
        return baos;
    }

    private void addErrorTextFileToZip(Map<String, ByteArrayOutputStream> zipFilesMap, String fileName, Exception e) {
        ByteArrayOutputStream errorOutput = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(errorOutput);
        e.printStackTrace(printStream);
        zipFilesMap.put(fileName + "_Error.txt", errorOutput);
    }

    private List<Document> generateDocumentsFromFileNames(List<String> fileNames) {
        if (CollectionUtils.isEmpty(fileNames)) {
            return Collections.<Document>emptyList();
        }

        List<Document> documents = new ArrayList<Document>();
        for (String fileName : fileNames) {
            Document document = new Document();
            document.setFileName(fileName);
            documents.add(document);
        }

        Collections.sort(documents);
        return documents;
    }
}
