package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.tps.shipping.business.ContactBusiness;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MTFDetailsDocumentBuilderImpl extends AbstractMTFDetailsDocumentBuilder {

    @Autowired
    private ContactBusiness contactBusiness;

    @Override
    public void buildDocument(PdfWriter writer, Document document, ShipmentPackingListEntity packingList) throws DocumentException {
        Font boldFont = buildBoldFont(9);
        Font defaultFont = buildDefaultFont(9);
        Font boldUnderlineFont = buildBoldUnderlineFont(9);

        addStringAtCoordinates("Ship From", 20, 50, writer, boldFont);
        addStringAtCoordinates(getShipFromString(packingList), 30, 65, writer, defaultFont);

        addStringAtCoordinates("Ship To", 240, 50, writer, boldFont);
        addStringAtCoordinates(getShipToString(packingList), 250, 65, writer, defaultFont);

        addStringAtCoordinates("Shipment Tracking Information", 560, 50, writer, boldFont);
        addBoxesWithTextVerticallyAtCoordinates(new String[]{getCarrierAndTrackingIdString(packingList), getBoxSummaryString(packingList)}, 560, 70, 212, writer, defaultFont);

        addStringCenteredAtY("NOTE: It is the receiver's responsibility to fully check the notification numbers and events prior to release.", 190, writer, defaultFont);

        addStringAtCoordinates("SHIPPER Information", 22, 250, writer, boldUnderlineFont);
        addStringAtCoordinates("RECEIVER Information", 399, 250, writer, boldUnderlineFont);
        addBoxesWithTextCenteredHorizontallyAtY(new String[]{getShipperInformationString(), getReceiverInformationString()}, 250, 300, writer, defaultFont);
    }

    public String getShipFromString(ShipmentPackingListEntity packingList) {
        AbstractContact fromContact = getFromContact(packingList);

        StringBuilder shipFromStringBuilder = new StringBuilder();
        shipFromStringBuilder.append(packingList.getCreatedBy().getFirstName()).append(" ").append(packingList.getCreatedBy().getLastName()).append("\n");
        appendContact(fromContact, shipFromStringBuilder);

        return shipFromStringBuilder.toString();
    }

    public String getShipToString(ShipmentPackingListEntity packingList) {
        AbstractContact toContact = getToContact(packingList);

        StringBuilder shipToStringBuilder = new StringBuilder();
        shipToStringBuilder.append(packingList.getShipToAttn()).append("\n");
        appendContact(toContact, shipToStringBuilder);
        return shipToStringBuilder.toString();
    }

    private AbstractContact getToContact(ShipmentPackingListEntity packingList) {
        return contactBusiness.getContact(packingList.getToContactId());
    }

    private AbstractContact getFromContact(ShipmentPackingListEntity packingList) {
        return contactBusiness.getContact(packingList.getFromContactId());
    }
}
