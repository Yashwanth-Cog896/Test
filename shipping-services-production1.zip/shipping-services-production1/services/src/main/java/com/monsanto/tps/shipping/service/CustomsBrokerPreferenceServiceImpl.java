package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.CustomsBrokerPreferenceBusiness;
import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;
import com.monsanto.tps.shipping.service.model.CustomsBrokerPreference;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Component("customsBrokerPreferenceService")
public class CustomsBrokerPreferenceServiceImpl implements CustomsBrokerPreferenceService {

    @Autowired
    private CustomsBrokerPreferenceBusiness customsBrokerPreferenceBusiness;

    @Trace
    @Override
    @Transactional(readOnly = true)
    public Collection<CustomsBrokerPreference> getBrokerPreferences() {

        Collection<CustomsBrokerPreference> customsBrokerPreferences = Lists.newArrayList();

        Collection<CustomsBrokerPreferenceEntity> customsBrokerPreferenceEntities = customsBrokerPreferenceBusiness.loadAll();

        for (CustomsBrokerPreferenceEntity customsBrokerPreferenceEntity : customsBrokerPreferenceEntities) {

            CustomsBrokerPreference customsBrokerPreference = new CustomsBrokerPreference();
            customsBrokerPreference.setId(customsBrokerPreferenceEntity.getCustomsBrokerPreferenceId());
            customsBrokerPreference.setCountryISOCode(customsBrokerPreferenceEntity.getCountryName());
            customsBrokerPreference.setCustomsBrokerId(customsBrokerPreferenceEntity.getCustomsBroker().getCustomsBrokerId());
            customsBrokerPreference.setFromAccountId(customsBrokerPreferenceEntity.getAccountId());

            customsBrokerPreferences.add(customsBrokerPreference);
        }

        return customsBrokerPreferences;
    }

    @Trace
    @Override
    @Transactional
    public CustomsBrokerPreference edit(CustomsBrokerPreference customsBrokerPreference) {
        return null;
    }

    @Trace
    @Override
    @Transactional
    public CustomsBrokerPreference create(CustomsBrokerPreference customsBrokerPreference) {
        return null;
    }
}
