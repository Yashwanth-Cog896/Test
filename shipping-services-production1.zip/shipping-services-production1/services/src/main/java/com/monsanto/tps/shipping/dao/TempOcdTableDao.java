package com.monsanto.tps.shipping.dao;

import java.util.Collection;
import java.util.List;

/*
* User: pgadi
*/
public interface TempOcdTableDao {
    long insertStrings(List<String> strings);
    long insertLongs(Collection<Long> longs);
    long getNextRequestId();
}
