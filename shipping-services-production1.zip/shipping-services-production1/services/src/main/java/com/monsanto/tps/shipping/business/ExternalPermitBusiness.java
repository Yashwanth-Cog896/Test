package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ExternalPermit;

import java.util.Collection;

public interface ExternalPermitBusiness {

    ExternalPermitEntity save(ExternalPermit externalPermit);
    void delete(Long externalPermitId);
    Collection<ExternalPermitEntity> getExternalPermitsForPackingList(ShipmentPackingListEntity packingList);
}
