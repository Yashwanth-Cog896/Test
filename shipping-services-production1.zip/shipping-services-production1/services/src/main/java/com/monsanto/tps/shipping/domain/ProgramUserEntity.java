package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "BR_PROG_USER", schema = "MIDAS")
public class ProgramUserEntity {

    @Id
    @Column(name = "BR_PROG_USER_ID", nullable = false)
    private Long programUserId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BR_PROG_ID")
    private ProgramEntity program;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MIDAS_USER_ID")
    private MidasUserEntity user;

    @Type(type = "true_false")
    @Column(name = "ref_active")
    private boolean refActive;

    public Long getProgramUserId() {
        return programUserId;
    }

    public void setProgramUserId(Long programUserId) {
        this.programUserId = programUserId;
    }

    public ProgramEntity getProgram() {
        return program;
    }

    public void setProgram(ProgramEntity program) {
        this.program = program;
    }

    public MidasUserEntity getUser() {
        return user;
    }

    public void setUser(MidasUserEntity user) {
        this.user = user;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
