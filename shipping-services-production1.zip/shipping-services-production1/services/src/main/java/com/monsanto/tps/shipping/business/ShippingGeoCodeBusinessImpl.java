package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.AgencyRequestResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Created by pthad on 12/8/15.
 */

@Service
public class ShippingGeoCodeBusinessImpl implements ShippingGeoCodeBusiness{

    private static final Log LOG = LogFactory.getLog(ShippingGeoCodeBusinessImpl.class);

    @Value("${geocode-services.url}")
    private String SHIPPING_GEOCODE_BASE_URL;

    @Value("${geocode-services.arids-url}")
    private String AR_IDS_BY_CONTACTS_URL;

    @Resource(name = "restOperation")
    private RestTemplate restTemplate;

    @Override
    public AgencyRequestResponse getAgencyRequestResponseByContactIds(Long fromContactId, Long toContactId) {
        checkArgument(fromContactId != null, "fromContactId cannot be null.");
        checkArgument(toContactId != null, "toContactId cannot be null.");

        String url = UriComponentsBuilder.fromUriString(SHIPPING_GEOCODE_BASE_URL + AR_IDS_BY_CONTACTS_URL).buildAndExpand(fromContactId, toContactId).toUriString();
        AgencyRequestResponse agencyRequestResponse;
        try {
            agencyRequestResponse = restTemplate.getForObject(url, AgencyRequestResponse.class);
        } catch (RestClientException e) {
            LOG.error("Exception occurred while getting AgencyRequestResponse by FromContactId : " + fromContactId + " and ToContactId: " + toContactId);
            agencyRequestResponse = new AgencyRequestResponse();
            agencyRequestResponse.setValidateByAddress(false);
        }
        return agencyRequestResponse;
    }

}
