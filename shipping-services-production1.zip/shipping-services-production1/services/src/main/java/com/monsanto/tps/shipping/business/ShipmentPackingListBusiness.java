package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;

import java.util.Date;
import java.util.List;

/**
 * User: DCENGL
 */
public interface ShipmentPackingListBusiness {

    List<ShipmentPackingListEntity> getShipmentPackingListsByProgramAfterDate(Long accountId, Date date);

    List<ShipmentPackingListEntity> getShipmentPackingListsByCountry(String isoCountryCode, Date date);

    ShipmentPackingListEntity getShipmentPackingList(Long shipmentPackingListId);

    ShipmentPackingListEntity getShipmentPackingListForBoxBarcode(String suBarcode);

    ShipmentPackingListEntity getShipmentPackingListForShipmentBarcode(String shBarcode);

    ShipmentPackingListEntity getShipmentPackingListForSapOrderShipmentId(Long sapOrderShipmentId);

    ShipmentPackingListEntity savePackingList(ShipmentPackingList shipmentPackingList, String username);

    ShipmentPackingListEntity editPackingList(ShipmentPackingList shipmentPackingList, String username);

    void removeEmptyContainers(ShipmentPackingListEntity packingList);

    void deletePackingList(Long packingListId);

    ShipmentPackingListEntity savePackingListWithoutContents(ShipmentPackingList shipmentPackingList, String username);

    void editUom(Long packingListId, String uom);

    Boolean validateShipToMatch(Long packingListId, Long contactId);

    void save(ShipmentPackingListEntity packingList);

}
