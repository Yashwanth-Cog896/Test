package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.EventConstructEntity;
import com.monsanto.tps.shipping.domain.GeneticMaterialEntity;
import com.monsanto.tps.shipping.domain.GermplasmEntity;
import com.monsanto.tps.shipping.domain.HDTrayEntity;
import com.monsanto.tps.shipping.domain.InventoryEntity;
import com.monsanto.tps.shipping.domain.MultiContentContainerEntity;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.TissuePlateContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateEntity;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * User: DCENGL
 */
@Service
public class CropBusinessImpl implements CropBusiness {

    @Autowired
    private ProgramBusiness programBusiness;
    @Autowired
    private ContactBusiness contactBusiness;

    @Trace
    @Override
    public CropEntity getCropByPackingList(ShipmentPackingListEntity shipmentPackingListEntity) {
        CropEntity cropEntity = null;

        //First try to get from the type of content
        if (shipmentPackingListEntity.getFromContactId() != null) {
            shipmentPackingListEntity.getFromContactId();

            ShipmentContact contact = contactBusiness.getContact(shipmentPackingListEntity.getFromContactId());

            cropEntity = programBusiness.getProgramByAccount(contact.getAccountId()).getCrop();
        } else if (!CollectionUtils.isEmpty(shipmentPackingListEntity.getShipmentContainers())) {
            cropEntity = getCropEntityByPackingListWithContainers(shipmentPackingListEntity);
        }
        return cropEntity;
    }

    @Trace
    @Override
    public CropEntity getCropEntityByPackingListWithContainers(ShipmentPackingListEntity shipmentPackingListEntity) {
        CropEntity cropEntity = null;
        for (ShipmentContainerEntity shipmentContainerEntity : shipmentPackingListEntity.getShipmentContainers()) {
            if (!CollectionUtils.isEmpty(shipmentContainerEntity.getStorageContainer().getContainers())) {
                ScannedContainerEntity contentContainerEntity = shipmentContainerEntity.getStorageContainer().getContainers().get(0);
                if (contentContainerEntity instanceof MultiContentContainerEntity) {
                    for (ScannedContainerEntity containerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
                        cropEntity = ((MultiContentContainerEntity) containerEntity).getCrop();
                        if (cropEntity != null) {
                            break;
                        }
                    }
                } else if (contentContainerEntity instanceof TissuePlateContainerEntity) {
                    cropEntity = getCropEntityForTissue(cropEntity, shipmentContainerEntity);
                } else {
                    ContentEntity contentEntity = contentContainerEntity.getContent();
                    if(contentEntity instanceof EventConstructEntity ){
                        cropEntity = ((EventConstructEntity) contentEntity).getCrop();
                    } else if (contentEntity instanceof HDTrayEntity){
                        cropEntity = getCropEntityForHdTray(cropEntity, (HDTrayEntity) contentEntity);
                    } else {
                        GeneticMaterialEntity geneticMaterialEntity = contentEntity.getGeneticMaterial();
                        if (geneticMaterialEntity == null) {
                            return null;
                        }
                        cropEntity = geneticMaterialEntity.getGermplasm().getCrop();
                    }
                }
                if (cropEntity != null) {
                    break;
                }
            }
        }
        return cropEntity;
    }

    private CropEntity getCropEntityForTissue(CropEntity cropEntity, ShipmentContainerEntity shipmentContainerEntity) {
        for (ScannedContainerEntity containerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
            if (containerEntity instanceof OtherContainerEntity) {
                continue;
            }
            TissuePlateContainerEntity tissuePlateContainerEntity = (TissuePlateContainerEntity) containerEntity;
            TissuePlateEntity tissuePlateEntity = tissuePlateContainerEntity.getContent();
            PlotEntity plot = tissuePlateEntity.getPlot();
            if (plot == null) {
                continue;
            }
            GeneticMaterialEntity geneticMaterial = plot.getGeneticMaterial();
            if (geneticMaterial == null) {
                continue;
            }
            GermplasmEntity germplasm = geneticMaterial.getGermplasm();
            if (germplasm == null) {
                continue;
            }
            cropEntity = germplasm.getCrop();
            break;
        }
        return cropEntity;
    }

    private CropEntity getCropEntityForHdTray(CropEntity cropEntity, HDTrayEntity contentEntity) {
        HDTrayEntity hdTrayEntity = contentEntity;
        List<InventoryEntity> inventoryEntityList = hdTrayEntity.getInventoryEntityList();
        for (InventoryEntity inventoryEntity : inventoryEntityList) {
            if(inventoryEntity.getGeneticMaterial() != null
                    && inventoryEntity.getGeneticMaterial().getGermplasm() != null
                    && inventoryEntity.getGeneticMaterial().getGermplasm().getCrop() != null) {
                cropEntity = inventoryEntity.getGeneticMaterial().getGermplasm().getCrop();
                break;
            }
        }
        return cropEntity;
    }
}
