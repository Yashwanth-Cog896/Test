package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collection;

@Repository
public class RegulatedMovementDaoImpl implements RegulatedMovementDao {

    public static final String REQUEST_ID = "requestId";
    public static final String AGENCY_ID = "agencyId";
    @Resource
    private TempOcdTableDao tempOcdTableDao;
    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<RegulatedInventoryMovementEntity> find(Long agencyId, Collection<Long> ids) {
        long requestId = tempOcdTableDao.insertLongs(ids);

        Collection<RegulatedInventoryMovementEntity> regulatedMovementEntities = Lists.newArrayList();

        regulatedMovementEntities.addAll(sessionFactory.getCurrentSession()
                .createQuery("select reg from RegulatedInventoryMovementEntity reg  where reg.id in (" +
                        "select tempOcdNumber from TempOcdTable tempTable where tempTable.sessionId = :requestId)  and reg.agency.id = :agencyId ")
                .setParameter(REQUEST_ID, requestId)
                .setParameter(AGENCY_ID, agencyId)
                .list());

        return regulatedMovementEntities;
    }

    @Trace
    @Override
    public void save(RegulatedInventoryMovementEntity regulatedMovement) {
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(regulatedMovement);
    }

    @Trace
    @Override
    public int deleteRegulatedMovementsForContent(ScannedContainerEntity<?> contentContainerEntity) {
       return deleteRegulatedMovementsForContent(contentContainerEntity, true);
    }

    private int deleteRegulatedMovementsForContent(ScannedContainerEntity<?> contentContainerEntity, boolean singleDelete) {
        Session session = sessionFactory.getCurrentSession();
        int count = 0;

        if (!CollectionUtils.isEmpty(contentContainerEntity.getRegulatedMovements())) {
            for (RegulatedInventoryMovementEntity entity : contentContainerEntity.getRegulatedMovements()) {
                session.delete(entity);
                count++;
            }
            if (singleDelete) {
                sessionFactory.getCurrentSession().flush();
                if (contentContainerEntity.getRegulatedMovements() != null) {
                    contentContainerEntity.getRegulatedMovements().clear();
                }
            }
        }
        return count;
    }

    @Trace
    @Override
    public int deleteRegulatedMovementsForPackingList(ShipmentPackingListEntity packingList) {
        int count = 0;

        if (CollectionUtils.isEmpty(packingList.getShipmentContainers())) {
            return count;
        }

        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            for (ScannedContainerEntity contentContainerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
                count += deleteRegulatedMovementsForContent(contentContainerEntity, false);
            }
        }
        sessionFactory.getCurrentSession().flush();
        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            for (ScannedContainerEntity<?> contentContainerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
                if (contentContainerEntity != null && contentContainerEntity.getRegulatedMovements() != null) {
                    contentContainerEntity.getRegulatedMovements().clear();
                }
            }
        }
        sessionFactory.getCurrentSession().flush();

        return count;
    }

    @Trace
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RegulatedInventoryMovementEntity> load(Collection<Long> regulatedMovementIds) {
        long requestId = tempOcdTableDao.insertLongs(regulatedMovementIds);

        Collection<RegulatedInventoryMovementEntity> regulatedMovementEntities = Lists.newArrayList();

        String queryString = "from RegulatedInventoryMovementEntity where id in (select tempOcdNumber from TempOcdTable tempTable where tempTable.sessionId = :requestId) ";
        regulatedMovementEntities.addAll((Collection<RegulatedInventoryMovementEntity>)
                sessionFactory.getCurrentSession()
                        .createQuery(queryString)
                        .setLong(REQUEST_ID, requestId)
                        .list());

        return regulatedMovementEntities;
    }
}
