package com.monsanto.tps.shipping.business.reports.checklist;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.monsanto.tps.shipping.business.RegulatedEventBusiness;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import static com.itextpdf.text.Font.FontFamily.HELVETICA;

/**
 * Created by DCENGL
 */
@Service
public class ChecklistReportImpl implements ChecklistReport {

    private static final String FIRST_PARAGRAPH = "The shipper, shipment verifier, and receiver are responsible for ensuring that proper containment, documentation, and labeling " +
            "are used for movement of seed and/or viable plant material. This checklist must be completed by the shipper, shipment " +
            "verifier, and receiver and maintained with the Transfer Form for this shipment. If a shipment doesn't arrive at its intended " +
            "destination or arrives damaged to the extent that material may have been lost, a Bayer Compliance Specialist must be " +
            "notified immediately. Please follow crop function specific requirements.";

    public static final Font HEADER_FONT = new Font(HELVETICA, 8, Font.BOLD);
    public static final Font SIGNATURE_FONT = new Font(HELVETICA, 8, Font.BOLD);
    public static final Font SECTION_TEXT_FONT = new Font(HELVETICA, 8);

    @Autowired
    private DefaultSection defaultSection;
    @Autowired
    private EpaSection epaSection;
    @Autowired
    private UsdaSection usdaSection;
    @Autowired
    private StewardshipSection stewardshipSection;
    @Autowired
    private SeedTreatmentShippingSection seedTreatmentShippingSection;
    @Autowired
    private SeedTreatmentNonPPQSection seedTreatmentNonPPQSection;
    @Autowired
    private SeedTreatmentPPQSection seedTreatmentPPQSection;
    @Autowired
    private RegulatedEventBusiness regulatedEventBusiness;

    @Trace(showReturn = false)
    @Override
    public ByteArrayOutputStream getPdfReport(ShipmentPackingListEntity packingListEntity) throws IOException {
        Document document = new Document(PageSize.LETTER);
        document.setMargins(20, 20, 20, 20);
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        try {
            Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingListEntity);

            PdfWriter writer = PdfWriter.getInstance(document, os);

            Rectangle pageRect = document.getPageSize();
            writer.setPageEvent(new HeaderFooter(packingListEntity, regulatedEvents.keySet(), pageRect));

            document.open();
            Paragraph firstParagraph = new Paragraph(FIRST_PARAGRAPH, SECTION_TEXT_FONT);
            firstParagraph.setAlignment(Element.ALIGN_JUSTIFIED);
            document.add(firstParagraph);

            float currentY = writer.getVerticalPosition(true) - 10;
            currentY = defaultSection.writeSection(document, writer, currentY);


            if (!CollectionUtils.isEmpty(regulatedEvents.keySet())) {

                    currentY = usdaSection.writeSection(document, writer, currentY);
                    currentY = epaSection.writeSection(document, writer, currentY);
                    currentY = stewardshipSection.writeSection(document, writer, currentY);
            }

            currentY = seedTreatmentShippingSection.writeSection(document, writer, currentY);
            currentY = seedTreatmentNonPPQSection.writeSection(document, writer, currentY);
            currentY = seedTreatmentPPQSection.writeSection(document, writer, currentY);

            currentY = addSignatureLine(writer, currentY, "Shipper: ");
            currentY = addSignatureLine(writer, currentY, "Verifier: ");
            addSignatureLine(writer, currentY, "Receiver: ");

            document.close();

            return os;
        } catch (DocumentException e) {
            throw new ShippingWebException(e.getMessage(), e, true);
        }
    }

    private float addSignatureLine(PdfWriter writer, float currentY, String text) throws DocumentException {
        currentY -= 10;

        ColumnText columnText = new ColumnText(writer.getDirectContent());
        Paragraph signParagraph = new Paragraph(text, SIGNATURE_FONT);
        signParagraph.setAlignment(Element.ALIGN_RIGHT);
        columnText.addElement(signParagraph);
        columnText.setSimpleColumn(20, 0, 80, currentY);
        columnText.go();

        ColumnText signLine = new ColumnText(writer.getDirectContent());
        signLine.addElement(new LineSeparator(1, 100, BaseColor.BLACK, Element.ALIGN_JUSTIFIED, 0));
        signLine.setSimpleColumn(83, 0, writer.getPageSize().getRight() - 300, currentY - 15.5f);
        signLine.go();

        ColumnText dateText = new ColumnText(writer.getDirectContent());
        Paragraph dateParagraph = new Paragraph("Date: ", SIGNATURE_FONT);
        dateParagraph.setAlignment(Element.ALIGN_RIGHT);
        dateText.addElement(dateParagraph);
        dateText.setSimpleColumn(writer.getPageSize().getRight() - 300, 0, writer.getPageSize().getRight() - 250, currentY);
        dateText.go();

        ColumnText dateLine = new ColumnText(writer.getDirectContent());
        dateLine.addElement(new LineSeparator(1, 100, BaseColor.BLACK, Element.ALIGN_JUSTIFIED, 0));
        dateLine.setSimpleColumn(writer.getPageSize().getRight() - 247, 0, writer.getPageSize().getRight() - 50, currentY - 15.5f);
        dateLine.go();

        return columnText.getYLine();
    }

    protected class HeaderFooter extends PdfPageEventHelper {
        private Phrase rightHeader;
        private Phrase leftHeader;
        private Phrase leftFooter;
        private Phrase regulatedFooter;
        private Rectangle pageRect;

        public HeaderFooter(ShipmentPackingListEntity packingList, Set<AgencyEnum> agencyEnums, Rectangle pageRect) {
            this.pageRect = pageRect;

            Font headerFont = new Font();
            headerFont.setSize(12);
            headerFont.setStyle(Font.BOLD);
            Font footerFont = new Font();
            footerFont.setSize(8);

            rightHeader = new Phrase("Ship ID: " + packingList.getBarcode(), headerFont);
            leftHeader = new Phrase("Shipment/Movement Checklist", headerFont);

            if (requiresRegulatedFooter(agencyEnums)) {
                regulatedFooter = new Phrase("This shipment contains Genetically Modified Plant Material which is Regulated.", footerFont);
            } else {
                regulatedFooter = new Phrase("");
            }

            leftFooter = new Phrase(packingList.getDescription(), footerFont);
        }

        private boolean requiresRegulatedFooter(Set<AgencyEnum> agencyEnums) {
            return !CollectionUtils.isEmpty(agencyEnums) && (agencyEnums.contains(AgencyEnum.EPA) || agencyEnums.contains(AgencyEnum.USDA));
        }

        public void onStartPage(PdfWriter writer, Document document) {

            try {
                ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
                        leftHeader, pageRect.getLeft(20), pageRect.getTop(20), 0);

                ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT,
                        rightHeader, pageRect.getRight(20), pageRect.getTop(20), 0);

                ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
                        leftFooter, pageRect.getLeft(20), pageRect.getBottom(30), 0);

                ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER,
                        regulatedFooter, pageRect.getRight() / 2, pageRect.getBottom(10), 0);

            } catch (Exception e) {
                throw new ShippingWebException("Error writing Header/Footer", e, true);
            }
        }
    }

}
