package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateWellEntity;

import java.util.Collection;

/**
 * Created by DCENGL
 */
public interface TissuePlateWellDao {

    Collection<TissuePlateWellEntity> getTissuePlateWells(Collection<ScannedContainerEntity> scannedContainers);

}
