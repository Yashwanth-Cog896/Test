package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.TissuePlateEntity;

import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
public interface TissuePlateDao {
    List<TissuePlateEntity> findByBarcode(Set<String> barcodes);

    List<TissuePlateEntity> findByBarcode(String barcode);
}
