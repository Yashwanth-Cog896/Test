package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.IrdContactXref;

import java.util.Collection;
import java.util.List;

/**
 * Created by SLAKS on 2/27/14.
 */
public interface IrdContactXrefDao {

    List<IrdContactXref> findContactsXrefs(Long contactId);

    List<IrdContactXref> findContactsXrefs(Collection<Long> fcmContactIds);
}
