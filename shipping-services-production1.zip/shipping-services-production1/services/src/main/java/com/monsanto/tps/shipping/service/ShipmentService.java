package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Shipment;
import com.monsanto.tps.shipping.service.model.ShipmentAcknowledgement;
import com.monsanto.tps.shipping.service.model.ShipmentType;

import javax.ws.rs.*;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/shipment")
public interface ShipmentService {

    @POST
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    public Shipment createShipment(Shipment shipment);

    @GET
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    @Path("/type")
    public List<ShipmentType> getShipmentTypes();

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/barcode/{sh-barcode}/acknowledge/")
    public void acknowledge(@PathParam("sh-barcode") String shBarcode, ShipmentAcknowledgement acknowledgement);

    @GET
    @Produces(APPLICATION_JSON)
    @Path("/barcode/{sh-barcode}")
    public Shipment getShipment(@PathParam("sh-barcode") String shBarcode);

    @GET
    @Path("/type/{shipmentTypeId}")
    @Produces(APPLICATION_JSON)
    public ShipmentType getShipmentType(@PathParam("shipmentTypeId") Long shipmentTypeId);

    @GET
    @Produces(APPLICATION_JSON)
    public List<Shipment> getShipments(@QueryParam("account-id") Long accountId,
                                       @QueryParam("modified-number-of-days") Long modifiedNumberOfDays,
                                       @QueryParam("shipment-direction") String shipmentDirection);

    @GET
    @Path("/international")
    @Produces(APPLICATION_JSON)
    public List<Shipment> getInternationalShipments(@QueryParam("countryCode") String countryCode,
                                       @QueryParam("modified-number-of-days") Long modifiedNumberOfDays,
                                       @QueryParam("shipment-direction") String shipmentDirection);

    @DELETE
    @Path("/{shipmentId}")
    public void cancelShipment(@PathParam("shipmentId") Long shipmentId);

    @POST
    @Path("/status-update")
    @Produces(APPLICATION_JSON)
    void updateUndeliveredShipmentStatuses();

}
