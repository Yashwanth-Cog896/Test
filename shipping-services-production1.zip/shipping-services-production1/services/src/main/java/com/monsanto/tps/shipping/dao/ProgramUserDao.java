package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ProgramUserEntity;

import java.util.List;

/**
 * User: DCENGL
 */
public interface ProgramUserDao {

    List<ProgramUserEntity> findByLoginId(String userName);

}
