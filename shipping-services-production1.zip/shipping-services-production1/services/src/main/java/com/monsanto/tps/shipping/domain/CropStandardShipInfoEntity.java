package com.monsanto.tps.shipping.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CROP_STD_SHIP_INFO", schema = "MIDAS")
public class CropStandardShipInfoEntity implements Serializable {
    @Id
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID")
    private CropEntity crop;

    @Column(name = "PER_SEED_CNT_STD_WGT", nullable = false)
    private Double perSeedCountStandardWeight;

    @OneToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "WGT_UOM_ID", referencedColumnName = "UOM_ID")
    private UnitOfMeasureEntity weightUnitOfMeasure;

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public Double getPerSeedCountStandardWeight() {
        return perSeedCountStandardWeight;
    }

    public void setPerSeedCountStandardWeight(Double perSeedCountStandardWeight) {
        this.perSeedCountStandardWeight = perSeedCountStandardWeight;
    }

    public UnitOfMeasureEntity getWeightUnitOfMeasure() {
        return weightUnitOfMeasure;
    }

    public void setWeightUnitOfMeasure(UnitOfMeasureEntity weightUnitOfMeasure) {
        this.weightUnitOfMeasure = weightUnitOfMeasure;
    }

    @Override
    public int hashCode() {
        return crop.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CropStandardShipInfoEntity that = (CropStandardShipInfoEntity) o;
        return that.getCrop().getCropId().equals(this.getCrop().getCropId());

    }
}