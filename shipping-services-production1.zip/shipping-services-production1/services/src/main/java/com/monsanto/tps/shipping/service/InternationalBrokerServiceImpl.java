package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.InternationalCompositesBusiness;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * User: pgadi
 */
@Component("internationalBrokerService")
public class InternationalBrokerServiceImpl implements InternationalBrokerService {
    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    @Override
    public InternationalCustomer getInternationalBroker(String id) {
        return internationalCompositesBusiness.getBroker(id);
    }

    @Override
    public List<InternationalCustomer> getInternationalBrokers() {
        return internationalCompositesBusiness.getBrokers();
    }
}
