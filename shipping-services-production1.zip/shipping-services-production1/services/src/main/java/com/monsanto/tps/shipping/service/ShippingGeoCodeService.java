package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.AgencyRequestResponse;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by pthad on 12/16/15.
 */

@Path("/geocode")
public interface ShippingGeoCodeService {

    // TODO This is to aid testing
    @GET
    @Produces(APPLICATION_JSON)
    @Path("/agency-request-ids/from-contact/{fromContactId}/to-contact/{toContactId}")
    AgencyRequestResponse getAgencyRequestResponseByContactIds(@PathParam("fromContactId") Long fromContactId, @PathParam("toContactId") Long toContactId);

}
