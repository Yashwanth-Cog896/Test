package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.service.model.Epc;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.apache.commons.lang3.StringUtils.isNumeric;

/**
 * Created by DCENGL
 */
@Service
public class EpcBusinessImpl implements EpcBusiness {

    private String epcServicesUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${epc-services.url}")
    public void setEpcServicesUrl(String epcServicesUrl) {
        this.epcServicesUrl = epcServicesUrl;
    }

    @Override
    public void associateBarcodesFromEpc(ShipmentPackingList shipmentPackingList) {
        if (shipmentPackingList.getStagingContainer() != null) {
            associateBarcodesForContents(shipmentPackingList.getStagingContainer());
        }
        for (PackingListContainer packingListContainer : shipmentPackingList.getPackingListContainers()) {
            associateBarcodesForContents(packingListContainer);
        }
    }

    private void associateBarcodesForContents(PackingListContainer packingListContainer) {
        for (PackingListContent packingListContent : packingListContainer.getPackingListContents()) {
            if (packingListContent.getEpc() != null && isNumeric(packingListContent.getEpc())) {
                try {
                    ResponseEntity<Epc> response = restTemplate.getForEntity(epcServicesUrl + "/epc/" + packingListContent.getEpc(), Epc.class);
                    packingListContent.setBarcode(response.getBody().getBarcode());
                } catch (HttpClientErrorException e) {
                    if (!e.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                        throw new RuntimeException("Error calling epc services", e);
                    }
                }
            }
        }
    }

    public void createEpcForContent(ScannedContainerEntity scannedContainer) {
        String barcode = scannedContainer.getContent().getBarcode();
        if (scannedContainer.getContentType() != ContentType.INVENTORY) {
            throw new IllegalArgumentException("Only Inventory content type supported for generating EPCs. [" + scannedContainer.getContentType() + "] is not a valid Inventory barcode");
        }

        ResponseEntity<Epc[]> response = restTemplate.postForEntity(epcServicesUrl + "/epc/barcode/" + barcode + "/type/INVENTORY", null, Epc[].class);

        Epc epc = response.getBody()[0];
        scannedContainer.setElectronicProductCode(String.valueOf(epc.getId()));
    }
}
