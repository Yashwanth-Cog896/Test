package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static javax.persistence.FetchType.LAZY;

/**
 * Created by DCENGL
 */
@Entity
@Table(name = "STORAGE_CONTAINER", schema = "INVENTORY_MGT")
public class CassetteEntity implements ContentEntity, Serializable {

    @Id
    @Column(name = "STORAGE_CONTAINER_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    private Long storageContainerId;
    @Column(name = "NAME", nullable = false)
    private String name;
    @Column(name = "DESCRIPTION", nullable = false)
    private String description;
    @Column(name = "BARCODE", nullable = false)
    private String barcode;
    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;
    @Column(name = "STORAGE_CONTAINER_TYPE_ID", nullable = false)
    private Long storageContainerTypeId;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "STORAGE_CONTAINER_TYPE_ID", nullable = false, insertable = false, updatable = false)
    private StorageContainerTypeEntity storageContainerType;
    @OneToMany(mappedBy = "storageContainer", cascade = {CascadeType.DETACH, CascadeType.REFRESH})
    private List<SeedTrayCellEntity> seedTrayCells = new ArrayList<SeedTrayCellEntity>();

    public Long getStorageContainerId() {
        return storageContainerId;
    }

    public void setStorageContainerId(Long storageContainerId) {
        this.storageContainerId = storageContainerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getStorageContainerTypeId() {
        return storageContainerTypeId;
    }

    public void setStorageContainerTypeId(Long storageContainerTypeId) {
        this.storageContainerTypeId = storageContainerTypeId;
    }

    public StorageContainerTypeEntity getStorageContainerType() {
        return storageContainerType;
    }

    public void setStorageContainerType(StorageContainerTypeEntity storageContainerType) {
        this.storageContainerType = storageContainerType;
    }

    public List<SeedTrayCellEntity> getSeedTrayCells() {
        return seedTrayCells;
    }

    public void setSeedTrayCells(List<SeedTrayCellEntity> seedTrayCells) {
        this.seedTrayCells = seedTrayCells;
    }

    @Override
    public Long getContentId() {
        return storageContainerId;
    }

    @Override
    public String getBarcode() {
        return barcode;
    }

    @Override
    public GeneticMaterialEntity getGeneticMaterial() {
        return null;
    }

    @Override
    public InventoryEntity getInventory() {
        return null;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.CASSETTE;
    }

}
