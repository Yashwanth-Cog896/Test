package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by brthie1
 */
@Component
public class PackingListExportImpl implements PackingListExport {

    @Autowired
    private PackingListDetailsSheetBuilder packingListDetailsSheetBuilder;
    
    @Autowired
    private InternationalComplianceSheetBuilder internationalComplianceSheetBuilder;

    @Autowired
    private PackingListItemsSheetBuilderFactory packingListItemsSheetBuilderFactory;

    @Trace(showReturn = false)
    @Override
    public ByteArrayOutputStream getXlsxReport(ShipmentPackingListEntity packingListEntity) throws IOException {
        Workbook workbook = new SXSSFWorkbook(100);

        packingListDetailsSheetBuilder.buildSheet(workbook, packingListEntity);

        packingListItemsSheetBuilderFactory.getSheetBuilder(packingListEntity).buildSheet(workbook, packingListEntity);

        if (packingListEntity.isInternational()) {
            internationalComplianceSheetBuilder.buildSheet(workbook, packingListEntity);
        }

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream, 10*1024);

        workbook.write(bufferedOutputStream);

        bufferedOutputStream.close();
        return byteArrayOutputStream;
    }
}
