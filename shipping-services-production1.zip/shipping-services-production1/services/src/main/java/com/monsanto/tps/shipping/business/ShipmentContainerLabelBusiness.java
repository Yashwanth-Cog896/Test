package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;

/**
 * User: SDCHIL
 */
public interface ShipmentContainerLabelBusiness {
    void save(ShipmentContainerLabelEntity shipmentContainerLabelEntity);

    void delete(ShipmentContainerLabelEntity shipmentContainerLabelEntity);
}
