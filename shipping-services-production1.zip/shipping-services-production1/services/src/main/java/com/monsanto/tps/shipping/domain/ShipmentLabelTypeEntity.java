package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: SDCHIL
 */
@Entity
@Table(name = "SHPMT_LBL_TYP", schema = "INVENTORY_MGT")
public class ShipmentLabelTypeEntity {
    @Id
    @Column(name = "SHPMT_LBL_TYP_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    private Long shipmentLabelTypeId;
    @Column(name= "SHPMT_LBL_TYP_NM", nullable = false)
    private String name;
    @Column(name= "SHPMT_LBL_TYP_DSC", nullable = false)
    private String description;


    public Long getShipmentLabelTypeId() {
        return shipmentLabelTypeId;
    }

    public void setShipmentLabelTypeId(Long shipmentLabelTypeId) {
        this.shipmentLabelTypeId = shipmentLabelTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
