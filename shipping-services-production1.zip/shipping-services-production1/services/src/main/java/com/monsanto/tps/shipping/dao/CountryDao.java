package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CountryEntity;

/**
 * User: pgadi
 */
public interface CountryDao {

    public CountryEntity getCountry(String countryAbbr);
}
