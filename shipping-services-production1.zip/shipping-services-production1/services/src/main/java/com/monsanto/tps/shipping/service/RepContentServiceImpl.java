package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.PlotComparator;
import com.monsanto.tps.shipping.business.ProgramBusiness;
import com.monsanto.tps.shipping.business.RepBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.RepContent;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("repContentService")
public class RepContentServiceImpl implements RepContentService {
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private ContactService contactService;
    @Autowired
    private ProgramBusiness programBusiness;
    @Autowired
    private RepBusiness repBusiness;

    @Override
    @Trace
    @Transactional
    public RepContent getRepContent(Long packingListId, String barcode, Long cropId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        Long programId = null;
        if (packingList.getToContactId() != null) {
            programId = getShipToProgram(packingList).getProgramId();
        }

        return repBusiness.getRepContent(barcode, cropId, programId, packingList.getShipmentType());
    }

    @Override
    @Trace
    @Transactional
    public RepContent getRepContent(Long packingListId, String barcode) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        return repBusiness.getRepContent(barcode, null, null, packingList.getShipmentType());
    }



    @Override
    @Trace
    @Transactional
    public List<RepContent> save(Long packingListId, Integer plotsPerBox, Boolean continueLastBox, String order, List<RepContent> repContents) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        if(plotsPerBox!=null){
            return repBusiness.save(packingList,plotsPerBox, continueLastBox, order, repContents);
        }
        else {
            return repBusiness.save(packingList,order!=null? order: PlotComparator.PLOT , repContents);
        }
    }

    private ProgramEntity getShipToProgram(ShipmentPackingListEntity packingList) {
        ShipmentContact toContact = contactService.getContact(packingList.getToContactId());
        return programBusiness.getProgramByAccount(toContact.getAccountId());
    }
}
