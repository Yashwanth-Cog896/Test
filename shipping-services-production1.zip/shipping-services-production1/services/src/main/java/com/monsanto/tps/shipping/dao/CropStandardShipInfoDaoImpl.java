package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.CropStandardShipInfoEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CropStandardShipInfoDaoImpl implements CropStandardShipInfoDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public CropStandardShipInfoEntity getCropStandardShipInfoByCrop(CropEntity crop) {
        return (CropStandardShipInfoEntity) sessionFactory.getCurrentSession().createQuery(
            "from CropStandardShipInfoEntity where crop = :crop").setParameter("crop", crop).uniqueResult();
    }
}