package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "OPERATION_OPERATION_TYPE", schema = "MIDAS")
public class OperationOperationTypeEntity implements Serializable {

    @Id
    @Column(name = "OPERATION_OPERATION_TYPE_ID")
    private Long id;
    @Column(name = "OPERATION_ID")
    private Long operationId;
    @OneToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "OPERATION_TYPE_ID", insertable = false, updatable = false)
    private OperationTypeEntity operationType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOperationId() {
        return operationId;
    }

    public void setOperationId(Long operationId) {
        this.operationId = operationId;
    }

    public OperationTypeEntity getOperationType() {
        return operationType;
    }

    public void setOperationType(OperationTypeEntity operationType) {
        this.operationType = operationType;
    }
}
