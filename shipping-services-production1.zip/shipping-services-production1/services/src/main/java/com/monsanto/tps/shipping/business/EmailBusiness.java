package com.monsanto.tps.shipping.business;

import com.monsanto.tps.observation.transfer.ShippingPlotObservationValue;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.List;

/**
 * User: DCENGL
 */
public interface EmailBusiness {

    void sendShipmentDeliveredMessage(ShipmentEntity shipmentEntity);

    void sendShipmentCreatedMessage(ShipmentEntity shipmentEntity);

    void sendShipmentCancelledMessage(ShipmentEntity shipmentEntity);

    void sendShipmentAcknowledgedMessage(String toAddresses, ShipmentEntity shipmentEntity, ShipmentPackingListEntity packingList);

    void sendHarvestWtUpdateFailureNotificationMessage(ShipmentEntity shipmentEntity, String message);

    void sendHwtUpdateFailureNotificationWithAttachment(ShipmentEntity shipmentEntity, String message,
                                                        List<ShippingPlotObservationValue> failedPlotObsList) throws MessagingException, IOException;

}
