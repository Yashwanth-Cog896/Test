package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.SapOrderItem;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/sap-order-item")
public interface SapOrderItemService {

    @PUT
    @Consumes(APPLICATION_JSON)
    @Path("/{order-item-id}")
    public void saveSapOrderItem(SapOrderItem orderItem);

}
