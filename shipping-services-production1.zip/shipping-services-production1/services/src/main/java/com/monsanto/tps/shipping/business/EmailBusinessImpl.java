package com.monsanto.tps.shipping.business;

import com.google.common.collect.Iterables;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.tps.observation.transfer.ShippingPlotObservationValue;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.*;
import javax.mail.util.ByteArrayDataSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import static javax.mail.Message.RecipientType.TO;

/**
 * User: DCENGL
 */
@Service
public class EmailBusinessImpl implements EmailBusiness {
   // private static final Log LOG = LogFactory.getLog(EmailBusinessImpl.class);

    private static final String NEW_LINE = System.getProperty("line.separator");
    private static final String TAB = "\t";
    private static final String DELIVERED_STATUS = "Delivered";
    private static final String CANCELLED_STATUS = "Cancelled";
    private static final String ACKNOWLEDGED_STATUS = "Completed";
    public static final String TRACKING_EMAIL_SUBJECT = "Tracking Shipment: (%1$s) on %2$tb %2$te, %2$tY %2$tI:%2$tM %2$Tp moved to %3$s";
    public static final String SHIPMENT_CREATED_EMAIL_SUBJECT = "Tracking Shipment: (%1$s) on %2$tb %2$te, %2$tY %2$tI:%2$tM %2$Tp has been created and status set to %3$s";
    public static final String HWT_UPDATE_FAILURE_NOTIFICATION_SUBJECT = "HWT/EARWT update failed for shipment: (%1$s)";
    public static final String HWT_UPDATE_FAILURE_EXCEPTION_MSG_SUBJECT = "Exception occurred while updating HWT/EARWT for shipment: (%1$s)";
    public static final String DL_NITRO_TEAM = "DL-TPSNitroScrumTeam@monsanto.com";

    public static final String DESCRIPTION = "Description: ";
    public static final String SHIPMENT_BID = "Shipment BID: ";
    public static final String SHIP_FROM = "Ship From: ";
    public static final String SHIP_TO_ATTN = "Ship To Attn: ";
    public static final String SHIP_TO = "Ship To: ";
    public static final String SPACE = " ";

    @Autowired
    private JavaMailSender mailSender;
    @Value("#{emailSystemXmlProperties.FROM_ADDRESS}")
    private String fromAddresses;
    @Value("#{emailSystemXmlProperties.STATUS_ADDRESS}")
    private String nonProdToAddress;
    @Value("#{emailSystemXmlProperties.SHIPPING_CONFIRMATION_BASE_URL}")
    private String confirmationBaseUrl;

    @Trace
    @Override
    public void sendShipmentDeliveredMessage(ShipmentEntity shipmentEntity) {
        String subject = buildSubject(shipmentEntity.getShipmentBarcode(), DELIVERED_STATUS);
        sendStatusEmail(shipmentEntity, subject, true);
    }

    @Trace
    @Override
    public void sendShipmentCreatedMessage(ShipmentEntity shipmentEntity) {
        String subject = buildShipmentCreatedSubject(shipmentEntity);
        sendStatusEmail(shipmentEntity, subject, true);
    }

    @Trace
    @Override
    public void sendShipmentCancelledMessage(ShipmentEntity shipmentEntity) {
        String subject = buildSubject(shipmentEntity.getShipmentBarcode(), CANCELLED_STATUS);
        sendStatusEmail(shipmentEntity, subject, false);
    }

    @Trace
    @Override
    public void sendHarvestWtUpdateFailureNotificationMessage(ShipmentEntity shipmentEntity, String message) {
        String subject = buildHWTUpdateFailureNotificationSubject(shipmentEntity);
        sendTextEmail(shipmentEntity.getNotificationEmails(), subject, buildWtUpdateFailureNotificationMessage(shipmentEntity));

        String exceptionMsgSubject = buildHWTUpdateFailureExceptionMsgSubject(shipmentEntity);
        sendTextEmail(DL_NITRO_TEAM, exceptionMsgSubject, buildWtUpdateFailureExceptionMessage(shipmentEntity, message));
    }

    @Trace
    @Override
    public void sendHwtUpdateFailureNotificationWithAttachment(ShipmentEntity shipmentEntity, String message,
                                                               List<ShippingPlotObservationValue> failedPlotObsList) throws MessagingException, IOException {
        String subject = buildHWTUpdateFailureNotificationSubject(shipmentEntity);
        StringBuilder messageBuilder = new StringBuilder("Failed to automatically update HWT/EARWT for the below shipment. The shipment is still successful. ")
                .append("Please find attached document with the failed plot BIDs and weights. ").append(NEW_LINE);
        appendShipmentBidAndContactsInfo(shipmentEntity, messageBuilder, false);
        sendMimeMessage(shipmentEntity.getNotificationEmails(), subject, messageBuilder.toString(), shipmentEntity.getShipmentBarcode(), failedPlotObsList);

        String exceptionMsgSubject = buildHWTUpdateFailureExceptionMsgSubject(shipmentEntity);
        StringBuilder messageBuilder1 = new StringBuilder(messageBuilder).append("Exception details: ").append(NEW_LINE).append(message);
        sendMimeMessage(DL_NITRO_TEAM, exceptionMsgSubject, messageBuilder1.toString(), shipmentEntity.getShipmentBarcode(), failedPlotObsList);
    }

    @Trace
    @Override
    public void sendShipmentAcknowledgedMessage(String toAddresses, ShipmentEntity shipmentEntity, ShipmentPackingListEntity packingList) {
        String subject = buildSubject(shipmentEntity.getShipmentBarcode(), ACKNOWLEDGED_STATUS);
        int boxesVerified = 0;
        int totalContents = 0;
        int verifiedContents = 0;
        for (ShipmentContainerEntity container : packingList.getShipmentContainers()) {
            if (container.getStatus() != null && ShippingStatus.ACKNOWLEDGED.equals(container.getStatus().getName())) {
                boxesVerified++;
            }
            for (ScannedContainerEntity scannedContainerEntity : container.getStorageContainer().getContainers()) {
                totalContents++;
                if (scannedContainerEntity.getReceiveVerificationDate() != null) {
                    verifiedContents++;
                }
            }
        }

        StringBuilder messageBuilder = new StringBuilder("\n");
        if (Boolean.TRUE.equals(shipmentEntity.getReceivedInGoodCondition())) {
            messageBuilder.append("Shipment was received in good condition");
        } else {
            messageBuilder.append("Shipment was not received in good condition");
        }
        messageBuilder.append('\n').append('\n');
        messageBuilder.append(boxesVerified);
        messageBuilder.append(" of ");
        messageBuilder.append(packingList.getShipmentContainers().size());
        messageBuilder.append(" Boxes Verified ");
        messageBuilder.append('\n');
        messageBuilder.append(verifiedContents);
        messageBuilder.append(" of ");
        messageBuilder.append(totalContents);
        messageBuilder.append(" Contents Verified ");
        messageBuilder.append('\n');

        sendTextEmail(toAddresses, subject, buildMessage(shipmentEntity, true) + messageBuilder.toString());
    }

    private void sendStatusEmail(ShipmentEntity shipmentEntity, String subject, boolean showStatus) {
        sendTextEmail(shipmentEntity.getNotificationEmails(), subject, buildMessage(shipmentEntity, showStatus));
    }

    private void sendTextEmail(String toAddresses, String subject, String body) {
        if (StringUtils.isNotEmpty(toAddresses)) {
            SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
            simpleMailMessage.setSubject(subject);
            simpleMailMessage.setFrom(fromAddresses);
            if (isProduction()) {
               // LOG.info(toAddresses.split(","));
                simpleMailMessage.setTo(toAddresses.split(","));
            } else {
                String nonProdToAddressOverride = System.getProperty("nonProdToAddress");
                if (StringUtils.isNotEmpty(nonProdToAddressOverride)) {
                    simpleMailMessage.setTo(nonProdToAddressOverride.trim());
                } else {
                    simpleMailMessage.setTo(nonProdToAddress);
                }
            }
            String finalBody = body;
            if (!isProduction()) {
                finalBody += "\n***Non Production Email*** Email would have been sent to: " + toAddresses;
            }

            simpleMailMessage.setText(finalBody);
            mailSender.send(simpleMailMessage);
        }
    }

    private String buildMessage(ShipmentEntity shipmentEntity, boolean showStatus) {
        StringBuilder messageBuilder = new StringBuilder();
        appendShipmentBidAndContactsInfo(shipmentEntity, messageBuilder, showStatus);

        if (showStatus) {
            messageBuilder.append("Shipment Status moved to: ");
            messageBuilder.append(shipmentEntity.getStatus().getName());
            messageBuilder.append(NEW_LINE);
        }

        messageBuilder.append("Carrier: ");
        messageBuilder.append(shipmentEntity.getCarrier() != null ? shipmentEntity.getCarrier().getName() : "");
        messageBuilder.append(NEW_LINE);

        messageBuilder.append("Tracking Number: ");
        messageBuilder.append(shipmentEntity.getTrackingNumber());
        messageBuilder.append(NEW_LINE);

        if (!StringUtils.isEmpty(shipmentEntity.getCarrier().getTrackingUrl())) {
            messageBuilder.append("Carrier Tracking: ");
            messageBuilder.append(shipmentEntity.getCarrier().getTrackingUrl()).append(shipmentEntity.getTrackingNumber());
            messageBuilder.append(NEW_LINE);
        }

        return messageBuilder.toString();
    }

    private String buildWtUpdateFailureNotificationMessage(ShipmentEntity shipmentEntity) {
        String message = "Failed to automatically update HWT/EARWT for the below shipment. The shipment is still successful.";
        StringBuilder messageBuilder = new StringBuilder(message).append(NEW_LINE);
        appendShipmentBidAndContactsInfo(shipmentEntity, messageBuilder, false);
        return messageBuilder.toString();
    }

    private String buildWtUpdateFailureExceptionMessage(ShipmentEntity shipmentEntity, String message) {
        StringBuilder messageBuilder = new StringBuilder("Failed to automatically update HWT/EARWT for the shipment: ");
        messageBuilder.append(shipmentEntity.getShipmentId()).append(NEW_LINE);
        messageBuilder.append("Exception details: ").append(NEW_LINE).append(message);
        return messageBuilder.toString();
    }

    private void appendShipmentBidAndContactsInfo(ShipmentEntity shipmentEntity, StringBuilder messageBuilder, boolean displayConfirmationUrl) {
        messageBuilder.append(DESCRIPTION).append(shipmentEntity.getComments()).append(TAB);
        messageBuilder.append(NEW_LINE);

        messageBuilder.append(SHIPMENT_BID);
        messageBuilder.append(shipmentEntity.getShipmentBarcode());
        if (displayConfirmationUrl) {
            messageBuilder.append(" - ").append(confirmationBaseUrl).append(shipmentEntity.getShipmentBarcode());
        }
        messageBuilder.append(NEW_LINE);

        messageBuilder.append(SHIP_FROM);
        ShipmentContactEntity fromContact = shipmentEntity.getFromContact();
        messageBuilder.append(fromContact.getFirstName()).append(SPACE).append(fromContact.getLastName()).append(TAB);
        messageBuilder.append(NEW_LINE);

        ShipmentPackingListEntity packingList = Iterables.get(shipmentEntity.getShipmentContainers(), 0).getShipmentPackingList();

        if (StringUtils.isNotEmpty(packingList.getShipToAttn())) {
            messageBuilder.append(SHIP_TO_ATTN).append(packingList.getShipToAttn()).append(TAB);
            messageBuilder.append(NEW_LINE);
        }

        messageBuilder.append(SHIP_TO);
        ShipmentContactEntity toContact = shipmentEntity.getToContact();
        messageBuilder.append(toContact.getFirstName()).append(SPACE).append(toContact.getLastName()).append(TAB);
        messageBuilder.append(NEW_LINE);
    }

    private String buildShipmentCreatedSubject(ShipmentEntity shipmentEntity) {
        return String.format(SHIPMENT_CREATED_EMAIL_SUBJECT, shipmentEntity.getShipmentBarcode(), new Date(), shipmentEntity.getStatus().getName());
    }

    private String buildHWTUpdateFailureNotificationSubject(ShipmentEntity shipmentEntity) {
        return String.format(HWT_UPDATE_FAILURE_NOTIFICATION_SUBJECT, shipmentEntity.getShipmentBarcode());
    }

    private String buildHWTUpdateFailureExceptionMsgSubject(ShipmentEntity shipmentEntity) {
        return String.format(HWT_UPDATE_FAILURE_EXCEPTION_MSG_SUBJECT, shipmentEntity.getShipmentBarcode());
    }

    private String buildSubject(String barcode, String status) {
        return String.format(TRACKING_EMAIL_SUBJECT, barcode, new Date(), status);
    }

    private boolean isProduction() {
        return EnvironmentHelper.sf_cstrPrd.equals(EnvironmentHelper.getFunction());
    }

    private void sendMimeMessage(String toAddresses, String subject, String body, String shipmentBarcode,
                                 List<ShippingPlotObservationValue> failedPlotsList) throws MessagingException, IOException {
        if (StringUtils.isNotEmpty(toAddresses)) {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            mimeMessage.setFrom(new InternetAddress(fromAddresses));
            mimeMessage.setRecipients(TO, getRecipients(toAddresses));
            mimeMessage.setSubject(subject);
            mimeMessage.setSentDate(new Date());

            MimeBodyPart attachment = new MimeBodyPart();
            attachment.setDataHandler(getDataHandler(shipmentBarcode, failedPlotsList));
            attachment.setFileName("Shipment (" + shipmentBarcode + ").xls");

            MimeBodyPart bodyOfEmail = new MimeBodyPart();
            bodyOfEmail.setText(getMimeMessageText(toAddresses, body));

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(attachment);
            multipart.addBodyPart(bodyOfEmail);
            mimeMessage.setContent(multipart);

            mailSender.send(mimeMessage);
        }
    }

    private DataHandler getDataHandler(String shipmentBarcode, List<ShippingPlotObservationValue> failedPlotsList) throws IOException {
        Workbook xlsFile = new HSSFWorkbook();
        CreationHelper helper = xlsFile.getCreationHelper();
        Sheet sheet = xlsFile.createSheet(shipmentBarcode);

        Row header = sheet.createRow(0);
        header.createCell(0, 1).setCellValue(getRichTextStringForHeader(helper, "Plot BID"));
        header.createCell(1, 1).setCellValue(getRichTextStringForHeader(helper, "Weight"));
        header.createCell(2, 1).setCellValue(getRichTextStringForHeader(helper, "UOM"));
        for (int i = 1; i <= failedPlotsList.size(); i++) {
            ShippingPlotObservationValue value = failedPlotsList.get(i - 1);
            Row row = sheet.createRow(i);
            row.createCell(0, 1).setCellValue(helper.createRichTextString(value.getPlotBID()));
            row.createCell(1, 0).setCellValue(value.getNumberValue());
            row.createCell(2, 1).setCellValue(helper.createRichTextString(value.getNumberValueUomName()));
        }

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        xlsFile.write(stream);
        stream.close();

        DataSource dataSource = new ByteArrayDataSource(stream.toByteArray(), "application/vnd.ms-excel");
        return new DataHandler(dataSource);
    }

    private RichTextString getRichTextStringForHeader(CreationHelper helper, String headerValue) {
        RichTextString richTextString = helper.createRichTextString(headerValue);
        richTextString.applyFont(Font.BOLDWEIGHT_BOLD);
        return richTextString;
    }

    private String getMimeMessageText(String toAddresses, String body) {
        if (!isProduction()) {
            body += "\n***Non Production Email*** Email would have been sent to: " + toAddresses;
        }
        return body;
    }

    private Address[] getRecipients(String toAddresses) throws AddressException {
        if (isProduction()) {
            String[] recipientAddresses = toAddresses.split(",");
            Address[] recipients = new Address[recipientAddresses.length];
            for (int i = 0; i < recipientAddresses.length; i++) {
                recipients[i] = new InternetAddress(recipientAddresses[i]);
            }
            return recipients;
        } else {
            Address[] recipients = new Address[1];
            String nonProdToAddressOverride = System.getProperty("nonProdToAddress");
            if (StringUtils.isNotEmpty(nonProdToAddressOverride)) {
                recipients[0] = new InternetAddress(nonProdToAddressOverride.trim());
            } else {
                recipients[0] = new InternetAddress(nonProdToAddress);
            }
            return recipients;
        }
    }
}
