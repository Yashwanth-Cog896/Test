package com.monsanto.tps.shipping.sap.client.api.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * User: pgadi
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapDeliveryShipmentApiErrorTabBapi", propOrder = {
        "type",
        "id",
        "number",
        "message",
        "logNo",
        "logMessageNo",
        "messageV1",
        "messageV2",
        "messageV3",
        "messageV4",
        "parameter",
        "row",
        "field",
        "system"
})
public class SapDeliveryShipmentApiErrorTabBapi {
    @XmlElement(name = "Type", required = true)
    private String type;
    @XmlElement(name = "Id", required = true)
    private String id;
    @XmlElement(name = "Number", required = true)
    private String number;
    @XmlElement(name = "Message", required = true)
    private String message;
    @XmlElement(name = "LogNo", required = true)
    private String logNo;
    @XmlElement(name = "LogMsgNo", required = true)
    private String logMessageNo;
    @XmlElement(name = "Parameter", required = true)
    private String parameter;
    @XmlElement(name = "MessageV1", required = true)
    private String messageV1;
    @XmlElement(name = "MessageV2", required = true)
    private String messageV2;
    @XmlElement(name = "MessageV3", required = true)
    private String messageV3;
    @XmlElement(name = "MessageV4", required = true)
    private String messageV4;
    @XmlElement(name = "Row", required = true)
    private String row;
    @XmlElement(name = "Field", required = true)
    private String field;
    @XmlElement(name = "System", required = true)
    private String system;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLogNo() {
        return logNo;
    }

    public void setLogNo(String logNo) {
        this.logNo = logNo;
    }

    public String getLogMessageNo() {
        return logMessageNo;
    }

    public void setLogMessageNo(String logMessageNo) {
        this.logMessageNo = logMessageNo;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getMessageV1() {
        return messageV1;
    }

    public void setMessageV1(String messageV1) {
        this.messageV1 = messageV1;
    }

    public String getMessageV2() {
        return messageV2;
    }

    public void setMessageV2(String messageV2) {
        this.messageV2 = messageV2;
    }

    public String getMessageV3() {
        return messageV3;
    }

    public void setMessageV3(String messageV3) {
        this.messageV3 = messageV3;
    }

    public String getMessageV4() {
        return messageV4;
    }

    public void setMessageV4(String messageV4) {
        this.messageV4 = messageV4;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }
}
