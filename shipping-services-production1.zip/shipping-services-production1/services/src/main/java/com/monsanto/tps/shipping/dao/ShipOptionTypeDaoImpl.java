package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipOptionTypeEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Repository
public class ShipOptionTypeDaoImpl implements ShipOptionTypeDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public ShipOptionTypeEntity getShipOptionType(Long shipOptionTypeId) {
        return (ShipOptionTypeEntity) sessionFactory.getCurrentSession().load(ShipOptionTypeEntity.class, shipOptionTypeId);
    }

    @Trace
    @Override
    public void saveShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity) {
        sessionFactory.getCurrentSession().saveOrUpdate(shipOptionTypeEntity);
    }

    @Trace
    @Override
    public void deleteShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity) {
        sessionFactory.getCurrentSession().delete(shipOptionTypeEntity);
    }

    @Override
    public List<ShipOptionTypeEntity> findAllShipOptionTypes() {
        return sessionFactory.getCurrentSession().createQuery("from ShipOptionTypeEntity").list();
    }
}