package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;

import java.util.List;

/**
 * User: pgadi
 */
public interface ShipmentTypeDao {

    ShipmentTypeEntity findById(Long shipmentTypeId);

    ShipmentTypeEntity findByName(String shipmentTypeName);

    List<ShipmentTypeEntity> findShipmentTypes();
}
