package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by DCENGL
 */
@Entity
@Table(name = "EXTERNAL_COMPLIANCE_PERMIT", schema = "INVENTORY_MGT")
public class ExternalPermitEntity {

    @Id
    @Column(name = "EXTERNAL_COMPLIANCE_PERMIT_ID")
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AGENCY_ID")
    private AgencyEntity agency;

    @Column(name = "OTHER_AGENCY_NM")
    private String otherAgencyName;

    @Column(name = "PERMIT_NBR")
    private String permitNumber;

    @Column(name = "EXPIRATION_DT")
    private Date expirationDate;

    @Column(name = "MATERIAL_DSC")
    private String materialDescription;

    @Column(name = "CREATION_DT")
    private Date creationDate;

    @Column(name = "CREATED_BY_MIDAS_USER_ID")
    private Long createdByMidasUserId;

    @Column(name = "LAST_MODIFIED_DT")
    private Date lastModifiedDate;

    @Column(name = "LAST_MODIFIED_BY_MIDAS_USER_ID")
    private Long lastModifiedMidasUserId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SHIPMENT_CONTAINER_ID")
    private ShipmentContainerEntity shipmentContainer;

    @Column(name = "CONSTRUCT_NAME")
    private String constructName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EXTERNAL_MATERIAL_TYPE_ID")
    private ExternalMaterialTypeEntity externalMaterialType;

    @Column(name = "EVENT_NAME")
    private String eventName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AgencyEntity getAgency() {
        return agency;
    }

    public void setAgency(AgencyEntity agency) {
        this.agency = agency;
    }

    public String getOtherAgencyName() {
        return otherAgencyName;
    }

    public void setOtherAgencyName(String otherAgencyName) {
        this.otherAgencyName = otherAgencyName;
    }

    public String getPermitNumber() {
        return permitNumber;
    }

    public void setPermitNumber(String permitNumber) {
        this.permitNumber = permitNumber;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getCreatedByMidasUserId() {
        return createdByMidasUserId;
    }

    public void setCreatedByMidasUserId(Long createdByMidasUserId) {
        this.createdByMidasUserId = createdByMidasUserId;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public Long getLastModifiedMidasUserId() {
        return lastModifiedMidasUserId;
    }

    public void setLastModifiedMidasUserId(Long lastModifiedMidasUserId) {
        this.lastModifiedMidasUserId = lastModifiedMidasUserId;
    }

    public ShipmentContainerEntity getShipmentContainer() {
        return shipmentContainer;
    }

    public void setShipmentContainer(ShipmentContainerEntity shipmentContainer) {
        this.shipmentContainer = shipmentContainer;
    }
    
    public String getConstructName() {
        return constructName;
    }
    
    public void setConstructName(String constructName) {
        this.constructName = constructName;        
    }
    
    public ExternalMaterialTypeEntity getExternalMaterialType() {
        return externalMaterialType;        
    }
    
    public void setExternalMaterialType(ExternalMaterialTypeEntity externalMaterialType) {
        this.externalMaterialType = externalMaterialType;        
    }
    
    public String getEventName() {
        return eventName;        
    }
    
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
}
