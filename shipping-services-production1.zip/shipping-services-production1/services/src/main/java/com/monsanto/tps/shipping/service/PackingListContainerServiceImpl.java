package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.ShipmentContainerBusiness;
import com.monsanto.tps.shipping.converter.PackingListContainerConversion;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


/**
 * User: pgadi
 */
@Component("packingListContainerService")
public class PackingListContainerServiceImpl implements PackingListContainerService {

    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;
    @Autowired
    private PackingListContainerConversion containerConversion;

    @Override
    @Trace
    @Transactional
    public PackingListContainer createShipmentContainer(Long packingListId) {
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.createShipmentContainer(packingListId);
        return containerConversion.toDto().apply(shipmentContainerEntity);
    }

    @Override
    @Trace
    @Transactional
    public PackingListContainer createStagingContainer(Long packingListId) {
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.createStagingContainer(packingListId);
        return containerConversion.toDto().apply(shipmentContainerEntity);
    }

    @Override
    @Trace
    @Transactional
    public void save(Long shipmentContainerId, PackingListContainer container) {
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);
        containerConversion.toEntity(container, shipmentContainerEntity);
        shipmentContainerBusiness.save(shipmentContainerEntity);
        containerConversion.toDto().apply(shipmentContainerEntity);
    }

    @Override
    @Trace
    @Transactional
    public void deleteShipmentContainer(Long shipmentContainerId) {
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);
        shipmentContainerBusiness.deleteShipmentContainer(shipmentContainerEntity);
    }
}