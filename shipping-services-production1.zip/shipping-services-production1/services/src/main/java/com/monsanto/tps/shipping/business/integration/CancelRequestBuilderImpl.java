package com.monsanto.tps.shipping.business.integration;

import com.google.common.collect.Lists;
import com.monsanto.services.domain.shipping.Carrier;
import com.monsanto.shipping.CarrierType;
import com.monsanto.shipping.common.request.CancelRequest;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * User: DCENGL
 */
@Service
public class CancelRequestBuilderImpl implements CancelRequestBuilder {

    @Autowired
    private ClientProfileBusiness clientProfileBusiness;

    @Override
    public CancelRequest buildCancelRequest(ShipmentEntity shipmentEntity) {
        CancelRequest cancelRequest = new CancelRequest();
        cancelRequest.setShipmentId(shipmentEntity.getShipmentId());
        Carrier carrier = new Carrier();
        carrier.setName(shipmentEntity.getCarrier().getName());
        carrier.setCarrierId(shipmentEntity.getCarrier().getCarrierId());
        carrier.setIntegrated(shipmentEntity.getCarrier().isSupportIntegratedShipping());
        cancelRequest.setShipmentTrackingId(shipmentEntity.getTrackingNumber());
        if (carrier.getName().equals(CarrierType.UPS_AIR_FREIGHT.getName())) {
            cancelRequest.setPackageTrackingIds(getAirFreightNumber(shipmentEntity));
        }
        cancelRequest.setCarrier(carrier);
        cancelRequest.setClientProfile(clientProfileBusiness.getClientProfile(shipmentEntity.getCarrier().getCarrierId(), shipmentEntity.getFromAccountId(), shipmentEntity.getFromContact().getIrdContactId()));

        return cancelRequest;
    }

    private List<String> getAirFreightNumber(ShipmentEntity shipmentEntity) {
        return Lists.newArrayList(shipmentEntity.getShipmentContainers().iterator().next().getCarrierTrackingId());
    }
}
