package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.ExternalMaterialTypeBusiness;
import com.monsanto.tps.shipping.domain.ExternalMaterialTypeEntity;
import com.monsanto.tps.shipping.service.model.ExternalMaterialType;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Component("externalMaterialTypeService")
public class ExternalMaterialTypeServiceImpl implements ExternalMaterialTypeService {

    @Autowired
    private ExternalMaterialTypeBusiness externalMaterialTypeBusiness;

    @Trace
    @Transactional(readOnly = true)
    @Override
    public Collection<ExternalMaterialType> getExternalMaterialTypes() {
        Collection<ExternalMaterialTypeEntity> externalMaterialTypeEntities = externalMaterialTypeBusiness.getAllActive();

        return toTransferObject(externalMaterialTypeEntities);
    }

    private Collection<ExternalMaterialType> toTransferObject(Collection<ExternalMaterialTypeEntity> externalMaterialTypeEntities) {
        Collection<ExternalMaterialType> externalMaterialTypes = Lists.newArrayList();
        for (ExternalMaterialTypeEntity externalMaterialTypeEntity : externalMaterialTypeEntities) {
            ExternalMaterialType externalMaterialType = new ExternalMaterialType();
            externalMaterialType.setId(externalMaterialTypeEntity.getExternalMaterialTypeId());
            externalMaterialType.setDescription(externalMaterialTypeEntity.getDescription());

            externalMaterialTypes.add(externalMaterialType);
        }

        return externalMaterialTypes;
    }
}
