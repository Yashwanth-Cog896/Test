package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "SEED_TRAY_CELL", schema = "INVENTORY_MGT")
public class SeedTrayCellEntity implements Serializable {

    @Id
    @Column(name = "SEED_TRAY_CELL_ID")
    private Long id;

    @ManyToOne(fetch = LAZY, optional = false)
    @JoinColumn(name = "STORAGE_CONTAINER_ID")
    private StorageContainerEntity storageContainer;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "PLOT_ID")
    private PlotEntity plot;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "INVENTORY_ID")
    private InventoryEntity inventory;

    @Column(name = "CELL_NUMBER", nullable = false)
    private int cellNumber;

    @Column(name = "COORD_ROW_NBR")
    private Integer rowNumber;

    @Column(name = "COORD_COLUMN_NBR")
    private Integer columnNumber;

    @Column(name = "TARGET_QUANTITY")
    private Integer targetQuantity;

    @Column(name = "ACTUAL_QUANTITY")
    private Integer actualQuantity;

    @Column(name = "HYBRID_NUMBER")
    private Long hybridNumber;

    @Column(name = "STATION_NUMBER")
    private Integer stationNumber;

    @Column(name = "HOPPER_NUMBER")
    private Integer hopperNumber;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FILLED_DTTM")
    private Date filledDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_DTTM", nullable = false)
    private Date modifiedDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "INACTIVE_DTTM")
    private Date inactiveDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public StorageContainerEntity getStorageContainer() {
        return storageContainer;
    }

    public void setStorageContainer(StorageContainerEntity storageContainer) {
        this.storageContainer = storageContainer;
    }

    public PlotEntity getPlot() {
        return plot;
    }

    public void setPlot(PlotEntity plot) {
        this.plot = plot;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public int getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(int cellNumber) {
        this.cellNumber = cellNumber;
    }

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }

    public Integer getColumnNumber() {
        return columnNumber;
    }

    public void setColumnNumber(Integer columnNumber) {
        this.columnNumber = columnNumber;
    }

    public Integer getTargetQuantity() {
        return targetQuantity;
    }

    public void setTargetQuantity(Integer targetQuantity) {
        this.targetQuantity = targetQuantity;
    }

    public Integer getActualQuantity() {
        return actualQuantity;
    }

    public void setActualQuantity(Integer actualQuantity) {
        this.actualQuantity = actualQuantity;
    }

    public Long getHybridNumber() {
        return hybridNumber;
    }

    public void setHybridNumber(Long hybridNumber) {
        this.hybridNumber = hybridNumber;
    }

    public Integer getStationNumber() {
        return stationNumber;
    }

    public void setStationNumber(Integer stationNumber) {
        this.stationNumber = stationNumber;
    }

    public Integer getHopperNumber() {
        return hopperNumber;
    }

    public void setHopperNumber(Integer hopperNumber) {
        this.hopperNumber = hopperNumber;
    }

    public Date getFilledDate() {
        return filledDate;
    }

    public void setFilledDate(Date filledDate) {
        this.filledDate = filledDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Date getInactiveDate() {
        return inactiveDate;
    }

    public void setInactiveDate(Date inactiveDate) {
        this.inactiveDate = inactiveDate;
    }
}
