package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Document;
import com.monsanto.tps.shipping.service.model.FileResponse;
import com.wordnik.swagger.annotations.Api;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.MULTIPART_FORM_DATA;
import static javax.ws.rs.core.MediaType.TEXT_PLAIN;

@Path("/documents")
@Api(value = "/documents", description = "Operations for uploading/downloading documents.")
public interface DocumentService {

    @GET
    @Path("/scope/{scope}/id/{id}")
    @Produces(APPLICATION_JSON)
    public List<Document> getDocumentList(@PathParam("scope") String scope, @PathParam("id") Long id);

    @POST
    @Path("/scope/{scope}/id/{id}")
    @Produces(APPLICATION_JSON)
    @Consumes({MULTIPART_FORM_DATA, TEXT_PLAIN})
    public List<Document> uploadDocument(@PathParam("scope") String scope, @PathParam("id") Long id, @Multipart(required = false) MultipartBody multipartBody);

    @GET
    @Path("/scope/{scope}/id/{id}/fileName/{fileName}")
    public FileResponse downloadDocument(@PathParam("scope") String scope, @PathParam("id") Long id, @PathParam("fileName") String base64EncodedFileName);

    @DELETE
    @Path("/scope/{scope}/id/{id}/fileName/{fileName}")
    public void deleteDocument(@PathParam("scope") String scope, @PathParam("id") Long id, @PathParam("fileName") String base64EncodedFileName);

    @DELETE
    @Path("/scope/{scope}/id/{id}")
    public void deleteAll(@PathParam("scope") String scope, @PathParam("id") Long id);

    @GET
    @Path("/packing-list/{id}")
    @Produces(APPLICATION_JSON)
    public boolean pathExists(@PathParam("id") Long id);

}
