package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.PermitAssociationDetails;

import javax.ws.rs.*;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.TEXT_HTML;

/**
 * User: DCENGL
 */
@Path("/permit")
public interface PermitService {

    @GET
    @Path("/packing-list/{packingListId}")
    @Produces(APPLICATION_JSON)
    Collection<Event> getPermits(@PathParam("packingListId") Long packingListId);

    @PUT
    @Path("/packing-list/{packingListId}/event")
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    Collection<Event> getPermitsForEvents(@PathParam("packingListId") Long packingListId, Collection<Event> events);

    @POST
    @Path("/packing-list/{packing-list-id}")
    @Consumes(APPLICATION_JSON)
    void associatePermits(@PathParam("packing-list-id") Long packingListId, Collection<Event> events);

    @GET
    @Path("/packing-list/{packingListId}/associated")
    @Produces(APPLICATION_JSON)
    Collection<Event> getAssociatedPermits(@PathParam("packingListId") Long packingListId);

    @POST
    @Path("/packing-list/{packingListId}/arNumber/{userEnteredArNumber}")
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    Permit validateUserEnteredARNumber(@PathParam("packingListId") Long packingListId, @PathParam("userEnteredArNumber")String userEnteredArNumber, Event event);

    @GET
    @Path("/{packingListId}")
    @Produces(TEXT_HTML)
    boolean finalRegulatedCheck(@PathParam("packingListId") Long packingListId);

    @GET
    @Path("/event/{eventStack}")
    @Produces(APPLICATION_JSON)
    Collection<Permit> findPermitsForEvent(@PathParam("eventStack") String eventStack);

    @GET
    @Path("/association/{approvalNumber}")
    @Produces(APPLICATION_JSON)
    PermitAssociationDetails findPermitAssociations(@PathParam("approvalNumber") String approvalNumber);

}
