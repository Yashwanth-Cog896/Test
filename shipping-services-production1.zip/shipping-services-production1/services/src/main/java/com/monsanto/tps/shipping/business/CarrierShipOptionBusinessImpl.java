package com.monsanto.tps.shipping.business;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.monsanto.tps.shipping.dao.CarrierShipOptionDao;
import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Service
public class CarrierShipOptionBusinessImpl implements CarrierShipOptionBusiness {

    @Autowired
    private CarrierShipOptionDao carrierShipOptionDao;

    @Trace
    @Override
    public Collection<CarrierShipOptionEntity> findCarrierShipOptions(final Collection<Long> carrierShipOptionIds) {
        if (CollectionUtils.isEmpty(carrierShipOptionIds)) {
            return null;
        }

        Collection<CarrierShipOptionEntity> carrierShipOptions = Collections2.filter(findAllCarrierShipOptions(), new Predicate<CarrierShipOptionEntity>() {
            @Override
            public boolean apply(@Nullable CarrierShipOptionEntity carrierShipOption) {
                return carrierShipOptionIds.contains(carrierShipOption.getCarrierShipOptionId());
            }
        });

        return carrierShipOptions;
    }

    @Override
    public CarrierShipOptionEntity findCarrierShipOption(Long carrierShipOptionId) {
        return carrierShipOptionDao.findCarrierShipOption(carrierShipOptionId);
    }

    @Override
    public List<CarrierShipOptionEntity> findAllCarrierShipOptions() {
        return carrierShipOptionDao.findAllCarrierShipOptions();
    }

    @Override
    public List<CarrierShipOptionEntity> findCarrierShipOptionByCarrierId(Long carrierId) {
        return carrierShipOptionDao.findCarrierShipOptionByCarrierId(carrierId);
    }
}