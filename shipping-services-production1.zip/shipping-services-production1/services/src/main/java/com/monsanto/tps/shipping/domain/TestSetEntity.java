package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: pgadi
 */
@Entity
@Table(name = "TEST_SET", schema = "MIDAS")
public class TestSetEntity {

    @Id
    @Column(name = "TEST_SET_ID")
    private long id;
    @Column(name = "NAME")
    private String testSetName;
    @Column(name = "RANGES_TALL")
    private Integer rangesTall;
    @Column(name = "COLUMNS_WIDE")
    private Integer columnsWide;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTestSetName() {
        return testSetName;
    }

    public void setTestSetName(String testSetName) {
        this.testSetName = testSetName;
    }

    public Integer getColumnsWide() {
        return columnsWide;
    }

    public void setColumnsWide(Integer columnsWide) {
        this.columnsWide = columnsWide;
    }

    public Integer getRangesTall() {    return rangesTall;   }

    public void setRangesTall(Integer rangesTall) {    this.rangesTall = rangesTall;   }
}
