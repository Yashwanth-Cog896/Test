package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.HDTrayEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

@Service
public class HdTraysMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);

        addSelectedPermitsToTable(permitsTable, events, false, font);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            HDTrayEntity content = (HDTrayEntity) contentContainerEntity.getContent();
            String eventString = getEventString(content);

            appendCellToTable(contentContainerEntity.getScanOrder(), contentsTable, font);
            appendCellToTable(content.getBarcode(), contentsTable, font);
            appendCellToTable(content.getLimsId(), contentsTable, font);
            appendCellToTable(content.getProjectName(), contentsTable, font);
            appendCellToTable(content.getInventoryBarCodes(), contentsTable, font);
            appendCellToTable(eventString, contentsTable, font);
            appendCellToTable(contentContainerEntity.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(
                new String[]{"Item #", "Tray ID", "Lims ID", "Project Name", "Inv BIDs", "Events", "Box Barcode", "Received"},
                new float[]{15, 20, 25, 25, 65, 65, 25, 20}, font);
    }

    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(
                new String[]{"Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[]{120, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.HD_TRAY;
    }
}


