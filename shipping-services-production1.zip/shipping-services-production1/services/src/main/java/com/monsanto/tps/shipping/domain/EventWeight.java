package com.monsanto.tps.shipping.domain;

/**
 * User: pgadi
 */
public class EventWeight {
    private String event;
    private Double weight;

    public EventWeight(String event, Double weight) {
        this.event = event;
        this.weight = weight;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }
}
