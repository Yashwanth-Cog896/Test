package com.monsanto.tps.shipping.business.labels;

import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;

public interface ComplianceLabelBusiness {

    ContainerAgencyPermits getExternalPermitsByPackingList(ShipmentPackingListEntity shipmentPackingListEntity);
    ContainerAgencyPermits getExternalPermitsByContainer(ShipmentContainerEntity shipmentContainerEntity);
    void addIntegratedAgencyMessage(ShipmentTypeEntity shipmentTypeEntity, ContainerAgencyPermits containerAgencyPermits, ContainerLabelDataSet data);
    void addExternalAgencyMessage(ShipmentPackingListEntity shipmentPackingListEntity, ContainerLabelDataSet labelDataSet);
    void addExternalAgencyMessage(ShipmentContainerEntity shipmentContainerEntity, ContainerLabelDataSet labelDataSet);
    void addPermitDetailsToLabelDataSet(ContainerAgencyPermits containerAgencyPermits, ContainerLabelDataSet data, int agencyNumberLimit);
}
