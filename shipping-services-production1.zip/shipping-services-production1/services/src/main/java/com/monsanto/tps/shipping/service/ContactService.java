package com.monsanto.tps.shipping.service;

import com.monsanto.tps.party.transfer.ContactTO;
import com.monsanto.tps.shipping.service.model.ShipmentContact;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: DCENGL
 */
@Path("/contact")
public interface ContactService {

    @GET
    @Path("/account/{accountId}")
    @Produces(APPLICATION_JSON)
    public List<ShipmentContact> getAllForAccount(@PathParam("accountId") Long accountId);

    @GET
    @Path("/{contactId}")
    @Produces(APPLICATION_JSON)
    public ShipmentContact getContact(@PathParam("contactId") Long contactId);

    // This is to aid testing from REST client
    @GET
    @Path("/party/{contactId}")
    @Produces(APPLICATION_JSON)
    public ContactTO getContactTOByContactId(@PathParam("contactId") Long contactId);

    // This is to aid testing from REST client
    @GET
    @Path("/party/account/{accountId}")
    @Produces(APPLICATION_JSON)
    public List<ContactTO> getContactTOByAccountId(@PathParam("accountId") Long accountId);

}
