
package com.monsanto.tps.shipping.sap.client.api.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapApiErrorTabBapi", propOrder = {
    "mandt",
    "yypartnerId",
    "yyxmlDocid",
    "yypoLineItem",
    "yyapplArea",
    "yyerror",
    "yytype",
    "yymessgV1",
    "yymessgV2",
    "yymessgV3",
    "yymessgV4"
})
public class SapApiErrorTabBapi {

    @XmlElement(name = "Mandt", required = true)
    private String mandt;
    @XmlElement(name = "YypartnerId", required = true)
    private String yypartnerId;
    @XmlElement(name = "YyxmlDocid", required = true)
    private String yyxmlDocid;
    @XmlElement(name = "YypoLineItem", required = true)
    private String yypoLineItem;
    @XmlElement(name = "YyapplArea", required = true)
    private String yyapplArea;
    @XmlElement(name = "Yyerror", required = true)
    private String yyerror;
    @XmlElement(name = "Yytype", required = true)
    private String yytype;
    @XmlElement(name = "YymessgV1", required = true)
    private String yymessgV1;
    @XmlElement(name = "YymessgV2", required = true)
    private String yymessgV2;
    @XmlElement(name = "YymessgV3", required = true)
    private String yymessgV3;
    @XmlElement(name = "YymessgV4", required = true)
    private String yymessgV4;

    public SapApiErrorTabBapi() {
    }

    public SapApiErrorTabBapi(String yymessgV1) {
        this.yymessgV1 = yymessgV1;
    }

    public String getMandt() {
        return mandt;
    }

    public void setMandt(String mandt) {
        this.mandt = mandt;
    }

    public String getYypartnerId() {
        return yypartnerId;
    }

    public void setYypartnerId(String yypartnerId) {
        this.yypartnerId = yypartnerId;
    }

    public String getYyxmlDocid() {
        return yyxmlDocid;
    }

    public void setYyxmlDocid(String yyxmlDocid) {
        this.yyxmlDocid = yyxmlDocid;
    }

    public String getYypoLineItem() {
        return yypoLineItem;
    }

    public void setYypoLineItem(String yypoLineItem) {
        this.yypoLineItem = yypoLineItem;
    }

    public String getYyapplArea() {
        return yyapplArea;
    }

    public void setYyapplArea(String yyapplArea) {
        this.yyapplArea = yyapplArea;
    }

    public String getYyerror() {
        return yyerror;
    }

    public void setYyerror(String yyerror) {
        this.yyerror = yyerror;
    }

    public String getYytype() {
        return yytype;
    }

    public void setYytype(String yytype) {
        this.yytype = yytype;
    }

    public String getYymessgV1() {
        return yymessgV1;
    }

    public void setYymessgV1(String yymessgV1) {
        this.yymessgV1 = yymessgV1;
    }

    public String getYymessgV2() {
        return yymessgV2;
    }

    public void setYymessgV2(String yymessgV2) {
        this.yymessgV2 = yymessgV2;
    }

    public String getYymessgV3() {
        return yymessgV3;
    }

    public void setYymessgV3(String yymessgV3) {
        this.yymessgV3 = yymessgV3;
    }

    public String getYymessgV4() {
        return yymessgV4;
    }

    public void setYymessgV4(String yymessgV4) {
        this.yymessgV4 = yymessgV4;
    }
}
