package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by KERRA on 5/19/2014.
 */
@Entity
@Table(name="SHIP_OPTION_TYPE", schema="INVENTORY_MGT")
public class ShipOptionTypeEntity {

    @Id
    @Column(name = "SHIP_OPTION_TYPE_ID")
    private Long shipOptionTypeId;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type="true_false")
    private boolean refActive;

    public Long getShipOptionTypeId() {
        return shipOptionTypeId;
    }

    public void setShipOptionTypeId(Long shipOptionTypeId) {
        this.shipOptionTypeId = shipOptionTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public ShipOptionType getEnumValue() {
        return ShipOptionType.fromName(getName());
    }
}
