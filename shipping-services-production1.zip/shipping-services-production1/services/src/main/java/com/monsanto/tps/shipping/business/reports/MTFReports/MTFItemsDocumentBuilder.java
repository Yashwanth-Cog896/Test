package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;

import java.util.Collection;

public interface MTFItemsDocumentBuilder {

    void buildDocument(Document document, ShipmentPackingListEntity packingList, Collection<Event> permits) throws DocumentException;
    boolean canBuild(ShipmentTypeEntity shipmentType);

}
