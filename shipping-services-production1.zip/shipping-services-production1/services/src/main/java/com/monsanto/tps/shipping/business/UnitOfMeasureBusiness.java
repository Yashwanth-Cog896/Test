package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;

import java.util.List;

/**
 * User: pgadi
 */
public interface UnitOfMeasureBusiness {
    List<UnitOfMeasureEntity> getUnitOfMeasuresList();

    UnitOfMeasureEntity getUnitOfMeasure(Long uomId);

    UnitOfMeasureEntity getUnitOfMeasure(String refId);

    UnitOfMeasureEntity getUnitOfMeasureByName(String name);

    Long getUnitOfMeasureMidasId(String refId);

    Long getInventoryMgtUomIdFromAbbreviation(String refId);

    Long convertInventoryMgtUomIdToMidasId(Long inventoryMgtUomId);

    Long getPackingListUomId(ShipmentPackingListEntity shipmentPackingListEntity);

    UnitOfMeasureConversionEntity getUomConversion(Long fromUomId, Long toUomId);
}
