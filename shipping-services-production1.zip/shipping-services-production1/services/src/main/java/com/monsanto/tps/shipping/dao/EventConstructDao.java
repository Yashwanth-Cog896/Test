package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ContentEntity;

import java.util.Collection;
import java.util.List;

public interface EventConstructDao {
    List<? extends ContentEntity> findByBarcode(String barcode);

    List<? extends ContentEntity> findByBarcodes(Collection<String> barcodes);
}
