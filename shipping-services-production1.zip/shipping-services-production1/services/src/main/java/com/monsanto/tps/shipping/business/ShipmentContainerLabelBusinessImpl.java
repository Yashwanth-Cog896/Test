package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.ShipmentContainerLabelDao;
import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * User: SDCHIL
 */
@Service
public class ShipmentContainerLabelBusinessImpl implements ShipmentContainerLabelBusiness {

    @Autowired
    private ShipmentContainerLabelDao shipmentContainerLabelDao;

    @Trace
    @Override
    public void save(ShipmentContainerLabelEntity shipmentContainerLabelEntity) {
        shipmentContainerLabelDao.save(shipmentContainerLabelEntity);
    }

    @Trace
    @Override
    public void delete(ShipmentContainerLabelEntity shipmentContainerLabelEntity) {
        shipmentContainerLabelDao.delete(shipmentContainerLabelEntity);
    }
}
