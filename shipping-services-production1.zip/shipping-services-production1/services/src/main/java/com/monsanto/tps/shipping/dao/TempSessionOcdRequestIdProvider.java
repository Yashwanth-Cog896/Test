package com.monsanto.tps.shipping.dao;

@JdbcDao("tempSessionOcdRequestIdProvider")
public class TempSessionOcdRequestIdProvider {
    private static final int MIN_REQUEST_ID = 1;
    private static final int MAX_REQUEST_ID = 10000;

    private long currentRequestId = 0L;

    public synchronized long getNextRequestId() {
        currentRequestId++;
        if (MAX_REQUEST_ID < currentRequestId) {
            currentRequestId = MIN_REQUEST_ID;
        }
        return currentRequestId;
    }
}
