package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.AgencyEntity;

import java.util.Collection;

/**
 * Created by DCENGL
 */
public interface AgencyBusiness {

    Collection<AgencyEntity> getAllActive();

    AgencyEntity findByAbbreviation(String abbreviation);
}
