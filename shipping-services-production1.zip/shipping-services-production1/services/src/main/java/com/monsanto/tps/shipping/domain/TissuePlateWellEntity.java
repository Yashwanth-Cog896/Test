package com.monsanto.tps.shipping.domain;

/**
 * Created by DCENGL
 */
public class TissuePlateWellEntity {

    private String wellNumber;
    private Long scannedContainerId;
    private ScannedContainerEntity scannedContainer;

    private String barcode;
    private String plotBarcode;
    private Long sampleNumber;
    private String limsId;
    private String projectName;
    private String fieldName;
    private String setName;
    private String plateType;
    private String blockId;

    public TissuePlateWellEntity() {
    }

    public TissuePlateWellEntity(ScannedContainerEntity scannedContainerEntity, String wellNumber) {
        this.wellNumber = wellNumber;
        this.scannedContainer = scannedContainerEntity;
        this.scannedContainerId = scannedContainerEntity.getScannedContainerId();
    }

    public String getWellNumber() {
        return wellNumber;
    }

    public void setWellNumber(String wellNumber) {
        this.wellNumber = wellNumber;
    }

    public Long getScannedContainerId() {
        return scannedContainerId;
    }

    public void setScannedContainerId(Long scannedContainerId) {
        this.scannedContainerId = scannedContainerId;
    }

    public ScannedContainerEntity getScannedContainer() {
        return scannedContainer;
    }

    public void setScannedContainer(ScannedContainerEntity scannedContainer) {
        this.scannedContainer = scannedContainer;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getPlotBarcode() {
        return plotBarcode;
    }

    public void setPlotBarcode(String plotBarcode) {
        this.plotBarcode = plotBarcode;
    }

    public Long getSampleNumber() {
        return sampleNumber;
    }

    public void setSampleNumber(Long sampleNumber) {
        this.sampleNumber = sampleNumber;
    }

    public String getLimsId() {
        return limsId;
    }

    public void setLimsId(String limsId) {
        this.limsId = limsId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getSetName() {
        return setName;
    }

    public void setSetName(String setName) {
        this.setName = setName;
    }

    public String getPlateType() {
        return plateType;
    }

    public void setPlateType(String plateType) {
        this.plateType = plateType;
    }

    public String getBlockId() {
        return blockId;
    }

    public void setBlockId(String blockId) {
        this.blockId = blockId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TissuePlateWellEntity)) return false;

        TissuePlateWellEntity that = (TissuePlateWellEntity) o;

        if (scannedContainerId != null ? !scannedContainerId.equals(that.scannedContainerId) : that.scannedContainerId != null)
            return false;
        if (wellNumber != null ? !wellNumber.equals(that.wellNumber) : that.wellNumber != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = wellNumber != null ? wellNumber.hashCode() : 0;
        result = 31 * result + (scannedContainerId != null ? scannedContainerId.hashCode() : 0);
        return result;
    }
}
