package com.monsanto.tps.shipping.domain;

import com.monsanto.tps.filter.annotation.FilterableProperty;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GR_SEASON", schema = "MIDAS")
public class SeasonEntity {
    @Id
    @Column(name = "GR_SEASON_ID")
    private long id;

    @FilterableProperty(filterKey = "field_season_name", caseSensitive = "true")
    @Column(name = "NAME")
    @Basic
    private String name;

    @Column(name = "REF_ACTIVE")
    @Basic
    private String refActive;

    @Column(name = "IS_ARCHIVABLE")
    @Basic
    private String isArchivable;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getArchivable() {
        return isArchivable;
    }

    public void setArchivable(String archivable) {
        isArchivable = archivable;
    }
}
