package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.monsanto.tps.compliance.epa.services.EpaAgencyRequestLookupService;
import com.monsanto.tps.compliance.epa.transfer.EupAssignment;
import com.monsanto.tps.compliance.epa.transfer.EupAssignmentResult;
import com.monsanto.tps.compliance.planting.integrationdata.PlantedEventConstructSet;
import com.monsanto.tps.compliance.planting.integrationdata.planting.PlantedEventConstruct;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.regulatory.common.db.dao.EpaEventValidationDao;
import com.monsanto.tps.regulatory.common.db.model.EpaAgencyInfo;
import com.monsanto.tps.regulatory.common.db.model.EpaRegulateEventType;
import com.monsanto.tps.shipping.business.compliance.RegulatedMovementBusiness;
import com.monsanto.tps.shipping.dao.AgencyDao;
import com.monsanto.tps.shipping.dao.AgencyRequestDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.RegulatedEventStatusService;
import com.monsanto.tps.shipping.service.model.*;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import java.util.*;

/**
 * User: pgadi
 */
@Service
public class EpaBusinessImpl implements EpaBusiness {

    private static final Log LOG = LogFactory.getLog(EpaBusinessImpl.class);

    private static final Function<EventConstruct, PlantedEventConstruct> PLANTED_EVENT_CONSTRUCT_FUNCTION = new Function<EventConstruct, PlantedEventConstruct>() {
        @Override
        public PlantedEventConstruct apply(@Nullable EventConstruct eventConstruct) {
            PlantedEventConstruct construct = new PlantedEventConstruct();
            construct.setEventName(eventConstruct.getName());
            construct.setConstructs(eventConstruct.getConstructName());
            return construct;
        }
    };

    @Resource(name = "epaAgencyRequestLookupService")
    private EpaAgencyRequestLookupService epaAgencyRequestLookupService;
    @Autowired
    private EpaEventValidationDao epaEventValidationDao;
    @Autowired
    private AgencyDao agencyDao;
    @Autowired
    private AgencyRequestDao agencyRequestDao;
    @Autowired
    private RegulatedMovementBusiness regulatedMovementBusiness;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private RegulatedEventStatusService regulatedEventStatusService;

    @Trace
    @Override
    public Collection<Event> getEpaEvents(Collection<Event> events, Set<String> allEventStrings) {
        Set<Event> epaEvents = Sets.newHashSet();

        List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites = getEpaValidatedEventsAPI(allEventStrings);
        if (!CollectionUtils.isEmpty(epaAgencyInfoComposites)) {
            for (Event event : events) {

                boolean malePreEup = false;
                boolean maleEpaRegulated = false;
                EpaAgencyInfoCompositeAPI maleEpaAgencyInfoComposite = getMatchingAgencyInfoCompositeAPI(epaAgencyInfoComposites, event.getMaleEventString());
                if (maleEpaAgencyInfoComposite != null) {
                    if (maleEpaAgencyInfoComposite.isRegulated()) {
                        event.setRegulatedByMale(true);
                        maleEpaRegulated = true;
                    } else if (maleEpaAgencyInfoComposite.isPreEup()) {
                        malePreEup = true;
                    }
                }

                EpaAgencyInfoCompositeAPI epaAgencyInfoComposite = getMatchingAgencyInfoCompositeAPI(epaAgencyInfoComposites, event.getEventString());

                if ((epaAgencyInfoComposite != null && epaAgencyInfoComposite.isRegulated()) || maleEpaRegulated) {
                    event.getRegulatingAgencies().add(AgencyEnum.EPA);
                    epaEvents.add(event);
                }

                if ((epaAgencyInfoComposite != null && epaAgencyInfoComposite.isPreEup()) || malePreEup) {
                    event.getRegulatingAgencies().add(AgencyEnum.PRE_EUP);
                    epaEvents.add(event);
                }
            }
        }

        return epaEvents;
    }

    @Override
    public void addEpaEventDetails(EventDetails eventDetails) {
        List<EpaAgencyInfoComposite> epaAgencyInfoComposites = getEpaValidatedEvents(Lists.newArrayList(eventDetails.getEventString()));

        Collection<EpaStoredProcResult> epaStoredProcResults = Lists.newArrayList();

        if (!CollectionUtils.isEmpty(epaAgencyInfoComposites)) {
            EpaAgencyInfoComposite epaAgencyInfoComposite = getMatchingAgencyInfoComposite(epaAgencyInfoComposites, eventDetails.getEventString());

            if ((epaAgencyInfoComposite != null)) {
                if (!CollectionUtils.isEmpty(epaAgencyInfoComposite.getAgencyInfos())) {
                    for (EpaAgencyInfo epaAgencyInfo : epaAgencyInfoComposite.getAgencyInfos()) {
                        EpaStoredProcResult epaStoredProcResult = new EpaStoredProcResult();
                        epaStoredProcResult.setDiscovery("Y".equalsIgnoreCase(epaAgencyInfo.getDiscoveredMaterialsIndicator()));
                        epaStoredProcResult.setRegulated("Y".equalsIgnoreCase(epaAgencyInfo.getRegulatedIndicator()));
                        epaStoredProcResult.setMatchedEvent(epaAgencyInfo.getMatchedEvents());
                        epaStoredProcResult.setInputEventString(epaAgencyInfo.getEvent());
                        epaStoredProcResult.setMostAccuratePipStack(epaAgencyInfo.getMatchedEvents().equals(epaAgencyInfoComposite.getPipStackString()));

                        epaStoredProcResults.add(epaStoredProcResult);
                    }
                }

                eventDetails.setEpaStoredProcResults(epaStoredProcResults);
                eventDetails.setEpaRegulated(epaAgencyInfoComposite.isRegulated());
                eventDetails.setPreEup(epaAgencyInfoComposite.isPreEup());
            }
        }
    }

    private EpaAgencyInfoComposite getMatchingAgencyInfoComposite(List<EpaAgencyInfoComposite> epaAgencyInfoComposites, String eventString) {
        if (StringUtils.isEmpty(eventString)) {
            return null;
        }

        for (EpaAgencyInfoComposite epaAgencyInfoComposite : epaAgencyInfoComposites) {
            if (eventString.equals(epaAgencyInfoComposite.getEventStackString())) {
                return epaAgencyInfoComposite;
            }
        }
        return null;
    }

    private EpaAgencyInfoCompositeAPI getMatchingAgencyInfoCompositeAPI(List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites, String eventString) {
        if (StringUtils.isEmpty(eventString)) {
            return null;
        }

        for (EpaAgencyInfoCompositeAPI epaAgencyInfoComposite : epaAgencyInfoComposites) {
            if (eventString.equals(epaAgencyInfoComposite.getEventStackString())) {
                return epaAgencyInfoComposite;
            }
        }
        return null;
    }

    @Trace
    @Override
    public Collection<Permit> getPermits(Collection<Event> epaValidatedEvents, Long cropId, String stateCode) {
        if (CollectionUtils.isEmpty(epaValidatedEvents)) {
            return Lists.newArrayList();
        }

        Map<Long, Event> eventGroupIdToEventsMap = new HashMap<Long, Event>();
        List<PlantedEventConstructSet> plantedEventConstructSets = getPlantedEventConstructsSet(epaValidatedEvents, eventGroupIdToEventsMap);
        EupAssignmentResult eupAssignmentResult;

        if (!CollectionUtils.isEmpty(plantedEventConstructSets)) {
            eupAssignmentResult = epaAgencyRequestLookupService.findEpaAgencyRequestsForEvents(cropId, plantedEventConstructSets, stateCode);
        } else {
            eupAssignmentResult = new EupAssignmentResult();
        }


        return buildEpaPermits(eupAssignmentResult, eventGroupIdToEventsMap);
    }

    private List<EpaAgencyInfoCompositeAPI> getEpaValidatedEventsAPI(Collection<String> eventStrings) {
        List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites = Lists.newArrayList();
        List<RegulatedAPIResponse> regulatedAPIResponses = regulatedEventStatusService.getEPAValidatedEvents(eventStrings);
        for(RegulatedAPIResponse regulatedAPIResponse : regulatedAPIResponses) {
            if(regulatedAPIResponse.getCountries() != null) {
                for(RegulatedAPIResponse.Country country : regulatedAPIResponse.getCountries()) {
                    if("US".equals(country.getCountry())) {
                        epaAgencyInfoComposites.add(new EpaAgencyInfoCompositeAPI(regulatedAPIResponse.getEvent(), country.getAgencies()));
                        break;
                    }
                }
            }
        }
        return epaAgencyInfoComposites;
    }

    private List<EpaAgencyInfoComposite> getEpaValidatedEvents(Collection<String> eventStrings) {
        List<EpaAgencyInfoComposite> epaAgencyInfoComposites = Lists.newArrayList();

        List<EpaAgencyInfo> epaAgencyInfos = epaEventValidationDao.validateEvents(eventStrings, EpaRegulateEventType.AUTO_CREATE);

        Multimap<String, EpaAgencyInfo> eventStringAgencyInfoMap = HashMultimap.create();
        for (EpaAgencyInfo epaAgencyInfo : epaAgencyInfos) {
            eventStringAgencyInfoMap.put(epaAgencyInfo.getEvent(), epaAgencyInfo);
        }

        for (String eventString : eventStringAgencyInfoMap.keySet()) {
            EpaAgencyInfoComposite epaAgencyInfoComposite = new EpaAgencyInfoComposite(eventString, eventStringAgencyInfoMap.get(eventString));
            epaAgencyInfoComposites.add(epaAgencyInfoComposite);
        }

        return epaAgencyInfoComposites;
    }

    private PlantedEventConstructSet createNewSetForEventConstructs(Collection<EventConstruct> eventConstructs, Long eventGroupingId) {
        PlantedEventConstructSet plantedEventConstructSet = new PlantedEventConstructSet();
        plantedEventConstructSet.setId(eventGroupingId);
        plantedEventConstructSet.setPlantedEventConstructs(Lists.newArrayList(Iterables.transform(eventConstructs, PLANTED_EVENT_CONSTRUCT_FUNCTION)));

        return plantedEventConstructSet;
    }

    private Collection<Permit> buildEpaPermits(EupAssignmentResult eupAssignmentResult, Map<Long, Event> eventGroupIdToEventsMap) {
        Collection<Permit> epaPermits = Lists.newArrayList();
        for (EupAssignment eupAssignment : eupAssignmentResult.getEupAssignments()) {
            Event event = eventGroupIdToEventsMap.get(eupAssignment.getPlantedEventConstructSetId());
            if (CollectionUtils.isEmpty(eupAssignment.getErrors()) && event != null) {
                Permit permit = new Permit();
                permit.setEvent(event.getEventString());
                permit.setMaleEvent(event.getMaleEventString());
                permit.setAgency(AgencyEnum.EPA);
                permit.setApprovalNumber(eupAssignment.getApprovalNumber());
                permit.setMonsantoId(eupAssignment.getMonsantoId());
                permit.setAgencyRequestLocationId(eupAssignment.getLocationId());
                permit.setExpirationDate(eupAssignment.getExpirationDate());
                epaPermits.add(permit);
            }

        }

        return epaPermits;
    }

    private List<PlantedEventConstructSet> getPlantedEventConstructsSet(Collection<Event> epaValidatedEvents, Map<Long, Event> eventGroupIdToEventsMap) {
        List<PlantedEventConstructSet> plantedEventConstructSets = Lists.newArrayList();

        //The id on plantedEventConstructSet is just used as an identifier. In field compliance validation it is not used for any validations or additional lookups
        Long eventGroupingId = 1L;

        for (Event event : epaValidatedEvents) {
            if (!StringUtils.isEmpty(event.getEventString()) && !event.getFemaleEventConstructs().isEmpty()
                    && !StringUtils.isEmpty(event.getMaleEventString()) && !event.getMaleEventConstructs().isEmpty()) {
                eventGroupIdToEventsMap.put(eventGroupingId, event);
                List<EventConstruct> constructs = Lists.newArrayList(event.getFemaleEventConstructs());
                constructs.addAll(event.getMaleEventConstructs());
                plantedEventConstructSets.add(createNewSetForEventConstructs(constructs, eventGroupingId));
            } else if (!StringUtils.isEmpty(event.getEventString()) && !event.getFemaleEventConstructs().isEmpty()) {
                eventGroupIdToEventsMap.put(eventGroupingId, event);
                plantedEventConstructSets.add(createNewSetForEventConstructs(event.getFemaleEventConstructs(), eventGroupingId));
            } else if (!StringUtils.isEmpty(event.getMaleEventString()) && !event.getMaleEventConstructs().isEmpty()) {
                eventGroupIdToEventsMap.put(eventGroupingId, event);
                plantedEventConstructSets.add(createNewSetForEventConstructs(event.getMaleEventConstructs(), eventGroupingId));
            }
            eventGroupingId++;
        }

        return plantedEventConstructSets;
    }

    @Trace
    @Override
    public void loadAssociatedPermits(ShipmentPackingListEntity packingList, Collection<Event> events) {
        if (CollectionUtils.isEmpty(events)) {
            return;
        }

        Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());

        for (Event event : events) {
            if (!CollectionUtils.isEmpty(event.getRegulatedMovementIds())) {

                Collection<RegulatedInventoryMovementEntity> regulatedMovements = regulatedMovementBusiness.findByAgencyFromIds(event.getRegulatedMovementIds(), getAgency());

                if (!CollectionUtils.isEmpty(regulatedMovements)) {
                    for (RegulatedInventoryMovementEntity regulatedMovement : regulatedMovements) {
                        if (regulatedMovement.getMonsantoId() != null) {
                            Permit permit = new Permit();
                            String monsantoId = regulatedMovement.getMonsantoId();
                            // 05222014 tjm - Removed the permitByMonsantoIdMap and made call directly.  Was told by Don there should only be
                            //   a few epa regulated events per packing list on average, but if the below call creates a bottleneck,
                            //   we can refactor. The map was causing an issue with duplicates getting lost (see Jira 2393)

                            EupAssignmentResult eupAssignmentResult = epaAgencyRequestLookupService.findEpaAgencyRequestsForMonsantoId(Lists.newArrayList(monsantoId), toContact.getState());
                            if (eupAssignmentResult != null && eupAssignmentResult.getEupAssignments() != null && eupAssignmentResult.getEupAssignments().get(0) != null) {
                                EupAssignment eupAssignment = eupAssignmentResult.getEupAssignments().get(0);
                                String approvalNumber = eupAssignment.getApprovalNumber();
                                AgencyRequestEntity agencyRequest = agencyRequestDao.findAgencyRequestByApprovalNumber(eupAssignment.getApprovalNumber());
                                permit.setAgencyRequestLocationId(eupAssignment.getLocationId());
                                permit.setApprovalNumber(approvalNumber);
                                permit.setExpirationDate(agencyRequest.getExpirationDate());
                            }

                            permit.setMonsantoId(monsantoId);
                            permit.setAgency(AgencyEnum.EPA);
                            permit.setEvent(event.getEventString());
                            event.addSelectedPermit(permit);

                            break;
                        }
                    }
                }
            }
        }
    }

    public AgencyEntity getAgency() {
        return agencyDao.findByAbbr(AgencyEnum.EPA.getAbbr());
    }

    private class EpaAgencyInfoCompositeAPI {
        private static final String USDA_REGULATED = "Regulated";
        private static final String USDA_DE_REGULATED = "Deregulated";
        private static final String EPA_PRE_REGISTERED = "Pre-Registration";
        private static final String EPA_DISCOVERY_RELEASE = "Discovery-Release";
        private static final String EPA_REGISTERED = "Registered";

        private EpaAgencyInfoCompositeAPI(String eventStackString, Collection<RegulatedAPIResponse.Country.Agency> agencies) {
            this.eventStackString = eventStackString;
            this.agencies = agencies;

            this.findMostAccuratePipStack();
        }

        private String eventStackString;
        private Collection<RegulatedAPIResponse.Country.Agency> agencies;
        private RegulatedAPIResponse.Country.Agency pipStack;

        public String getEventStackString() {
            return eventStackString;
        }

        public boolean isRegulated() {
            boolean isRegulated = false;
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if((agency.getAgency().equals(AgencyEnum.EPA.getAbbr()) && agency.getStatusInfo() != null
                        && EPA_PRE_REGISTERED.equals(agency.getStatusInfo().getStatus()))) {
                    isRegulated = true;
                    break;
                }
            }
            return  isRegulated;
        }

        public boolean isPreEup() {
            boolean isRegulated = !isRegulated();
            boolean isPreEup = false;
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getAgency().equals(AgencyEnum.EPA.getAbbr()) && agency.getStatusInfo() != null
                        && EPA_DISCOVERY_RELEASE.equals(agency.getStatusInfo().getStatus())) {
                    isPreEup = true;
                    break;
                }
            }
            return isRegulated && isPreEup;
        }

        private void findMostAccuratePipStack() {
            Set<String> singles = getSinglePips(); //Find matching events strings that are not stacks (single)

            String eventStack = getPipStackString(singles);
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                String matchedEvents = "";
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
                if(eventStack.equals(matchedEvents))
                    pipStack = agency;
            }
        }

        private String getPipStackString(Set<String> singles) {
            StringBuilder pipStack = new StringBuilder();
            for (String single : singles) {
                pipStack.append(single);
                pipStack.append(",");
            }
            pipStack.deleteCharAt(pipStack.lastIndexOf(","));
            return pipStack.toString();
        }

        public String getPipStackString() {
            String matchedEvents = "";
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
            }
            return matchedEvents;
        }

        private Set<String> getSinglePips() {
            Set<String> singles = new TreeSet<String>();
            String matchedEvents = "";
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
                singles.addAll(Arrays.asList(matchedEvents.split(",")));
            }
            return singles;
        }
    }

    private class EpaAgencyInfoComposite {

        private EpaAgencyInfoComposite(String eventStackString, Collection<EpaAgencyInfo> agencyInfos) {
            this.eventStackString = eventStackString;
            this.agencyInfos = agencyInfos;

            this.findMostAccuratePipStack();
        }

        private String eventStackString;
        private Collection<EpaAgencyInfo> agencyInfos;
        private EpaAgencyInfo pipStack = null; //

        public String getEventStackString() {
            return eventStackString;
        }

        public void setEventStackString(String eventStackString) {
            this.eventStackString = eventStackString;
        }

        public Collection<EpaAgencyInfo> getAgencyInfos() {
            return agencyInfos;
        }

        public void setAgencyInfos(Collection<EpaAgencyInfo> agencyInfos) {
            this.agencyInfos = agencyInfos;
        }

        public boolean isRegulated() {
            return pipStack != null && "Y".equalsIgnoreCase(pipStack.getRegulatedIndicator());
        }

        public boolean isPreEup() {
            return pipStack == null || (!isRegulated() && "Y".equalsIgnoreCase(pipStack.getDiscoveredMaterialsIndicator()));
        }

        public String getPipStackString() {
            if (pipStack == null) {
                return  null;
            }

            return pipStack.getMatchedEvents();
        }

        private void findMostAccuratePipStack() {
            if (CollectionUtils.isEmpty(agencyInfos)) {
                return;
            }

            Set<String> singles = getSinglePips(); //Find matching events strings that are not stacks (single)

            String eventStack = getPipStackString(singles);

            for (EpaAgencyInfo agencyInfo : agencyInfos) {
                if (agencyInfo.getMatchedEvents().equals(eventStack)) {
                    pipStack = agencyInfo;
                    break;
                }
            }
        }

        private String getPipStackString(Set<String> singles) {
            StringBuilder pipStack = new StringBuilder();
            for (String single : singles) {
                pipStack.append(single);
                pipStack.append(",");
            }
            pipStack.deleteCharAt(pipStack.lastIndexOf(","));
            return pipStack.toString();
        }

        private Set<String> getSinglePips() {
            Set<String> singles = Sets.newTreeSet();

            for (EpaAgencyInfo agencyInfo : agencyInfos) {
                if (agencyInfo.getMatchedEvents().split(",").length == 1) {
                    singles.add(agencyInfo.getMatchedEvents());
                }
            }
            return singles;
        }
    }
}
