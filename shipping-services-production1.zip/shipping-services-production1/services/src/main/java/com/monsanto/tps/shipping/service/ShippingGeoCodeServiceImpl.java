package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.ShippingGeoCodeBusiness;
import com.monsanto.tps.shipping.service.model.AgencyRequestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by pthad on 12/16/15.
 */

@Component("shippingGeoCodeService")
public class ShippingGeoCodeServiceImpl implements ShippingGeoCodeService {

    @Autowired
    private ShippingGeoCodeBusiness shippingGeoCodeBusiness;

    @Override
    public AgencyRequestResponse getAgencyRequestResponseByContactIds(Long fromContactId, Long toContactId) {
        return shippingGeoCodeBusiness.getAgencyRequestResponseByContactIds(fromContactId, toContactId);
    }

}
