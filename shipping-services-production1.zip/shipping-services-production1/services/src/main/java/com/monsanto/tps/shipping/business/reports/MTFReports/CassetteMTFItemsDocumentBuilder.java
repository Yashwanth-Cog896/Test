package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by DCENGL
 */
@Service
public class CassetteMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException{
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);
        Map<String, Event> eventsStringToEventInCurrentCassetteMap = Maps.newHashMap();

        addSelectedPermitsToTable(permitsTable, events, false, font);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            CassetteContainerEntity cassetteContainer = (CassetteContainerEntity) contentContainerEntity;
            CassetteEntity cassette = cassetteContainer.getCassette();

            List<SeedTrayCellEntity> seedTrayCells = cassette.getSeedTrayCells();
            Collections.sort(seedTrayCells, new Comparator<SeedTrayCellEntity>() {
                @Override
                public int compare(SeedTrayCellEntity o1, SeedTrayCellEntity o2) {
                    return o1.getCellNumber() - o2.getCellNumber();
                }
            });

            eventsStringToEventInCurrentCassetteMap.clear();
            Integer firstFoundScanOrder = null;
            String firstFoundScannedContainerBarcode = "";
            String firstFoundBoxBarcode = "";
            String firstFoundFieldName = "";
            String firstFoundTestSet = "";
            String firstFoundSeasonName = "";
            Collection<Event> cassetteEvents = getEventsForCassette(contentContainerEntity.getContainerId(), events);

            for (SeedTrayCellEntity seedTrayCell : seedTrayCells) {
                InventoryEntity inventory = seedTrayCell.getInventory();
                String eventString = getEventString(inventory);
                PlotEntity plot = seedTrayCell.getPlot();
                Event event = getEvent(eventString, cassetteEvents);

                if (firstFoundScanOrder == null) {
                    firstFoundScanOrder = contentContainerEntity.getScanOrder();
                }
                if (firstFoundScannedContainerBarcode.isEmpty()) {
                    firstFoundScannedContainerBarcode = cassetteContainer.getBarcode();
                }
                if (firstFoundBoxBarcode.isEmpty()) {
                    firstFoundBoxBarcode = contentContainerEntity.getStorageContainer().getBarcode();
                }
                if (!eventsStringToEventInCurrentCassetteMap.containsKey(eventString)) {
                    eventsStringToEventInCurrentCassetteMap.put(eventString, event);
                }

                if (firstFoundFieldName.isEmpty() && (plot != null && plot.getField() != null)) {
                    firstFoundFieldName = plot.getField().getFieldName();
                }
                if (firstFoundTestSet.isEmpty() && (plot != null && plot.getRep() != null && plot.getRep().getTestSet() != null)) {
                    firstFoundTestSet = plot.getRep().getTestSet().getTestSetName();
                }
                if (firstFoundSeasonName.isEmpty() && (plot != null && plot.getField() != null && plot.getField().getSeason() != null)) {
                    firstFoundSeasonName = plot.getField().getSeason().getName();
                }
            }
            appendCellToTable(firstFoundScanOrder, contentsTable, font);
            appendCellToTable(firstFoundScannedContainerBarcode, contentsTable, font);
            appendCellToTable(firstFoundBoxBarcode, contentsTable, font);
            appendCellToTable(getEventsStringForTable(eventsStringToEventInCurrentCassetteMap), contentsTable, font);
            appendCellToTable(firstFoundFieldName, contentsTable, font);
            appendCellToTable(firstFoundTestSet, contentsTable, font);
            appendCellToTable(firstFoundSeasonName, contentsTable, font);

            contentsTable.completeRow();
        }
    }

    private Event getEvent(String eventString, Collection<Event> cassetteEvents) {
        for (Event cassetteEvent : cassetteEvents) {
            if (cassetteEvent.getEventString() != null && cassetteEvent.getEventString().equals(eventString)) {
                return cassetteEvent;
            }
        }

        return null;
    }

    private Collection<Event> getEventsForCassette(Long containerId, Collection<Event> events) {
        Collection<Event> containerEvents = Lists.newArrayList();

        for (Event event : events) {
            if (event.getContentContainerIds() != null && event.getContentContainerIds().contains(containerId)) {
                containerEvents.add(event);
            }
        }

        return containerEvents;
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Scanned Container BID", "Box Barcode", "Event", "Field Name", "Test Set", "Season Name", "Received"},
                new float[] {15, 50, 20, 85, 15, 15, 15, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[] {120, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.CASSETTE;
    }

    private String getEventsStringForTable(Map<String, Event> eventsStringToEventInCurrentCassetteMap) {
        StringBuilder eventsStringForTableBuilder = new StringBuilder();
        for (String eventString : eventsStringToEventInCurrentCassetteMap.keySet()) {
            if (eventString == null || eventString.isEmpty()) {
                if (eventsStringToEventInCurrentCassetteMap.size() == 1) {
                    return "";
                }
            }
            else {
                eventsStringForTableBuilder.append(eventString).append("\n");
            }
        }
        return eventsStringForTableBuilder.toString();
    }
}
