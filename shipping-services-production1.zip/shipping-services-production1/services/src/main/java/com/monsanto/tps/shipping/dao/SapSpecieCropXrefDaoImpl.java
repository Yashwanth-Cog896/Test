package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapSpecieCropXrefEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User: pgadi
 */
@Repository
public class SapSpecieCropXrefDaoImpl implements SapSpecieCropXrefDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    @SuppressWarnings("unchecked")
    public List<SapSpecieCropXrefEntity> getSapSpecieCropEntities() {
        return (List<SapSpecieCropXrefEntity>) sessionFactory.getCurrentSession().createQuery("from SapSpecieCropXrefEntity where isActive = 'Y'").list();
    }

    @Trace
    @Override
    public SapSpecieCropXrefEntity getSapSpecieCropEntityByCropSubclassId(Long cropId) {
        return (SapSpecieCropXrefEntity) sessionFactory.getCurrentSession().createQuery("from SapSpecieCropXrefEntity where cropSubClassId = :cropId and isActive = 'Y'")
                .setParameter("cropId", cropId).uniqueResult();
    }
}
