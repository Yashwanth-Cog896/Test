package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.EventConstructEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

@Repository
public class EventConstructDaoImpl implements EventConstructDao {

    @Resource
    private TempOcdTableDao tempOcdTableDao;
    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<EventConstructEntity> findByBarcode(String barcode) {
        return sessionFactory.getCurrentSession()
                .createQuery("from EventConstructEntity e where e.barcode = :barcode")
                .setParameter("barcode", barcode)
                .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<EventConstructEntity> findByBarcodes(Collection<String> barcodes) {
        if (CollectionUtils.isNotEmpty(barcodes) && barcodes.size() == 1) {
            return findByBarcode(barcodes.iterator().next());
        }

        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(barcodes));

        return sessionFactory.getCurrentSession()
                .createQuery("from EventConstructEntity e where e.barcode in (select tempOcdId from TempOcdTable tempTable where tempTable.sessionId = :requestId)")
                .setParameter("requestId", requestId)
                .list();
    }
}
