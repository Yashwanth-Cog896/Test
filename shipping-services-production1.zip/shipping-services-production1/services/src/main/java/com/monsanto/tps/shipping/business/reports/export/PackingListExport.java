package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by brthie1
 */
public interface PackingListExport {

    ByteArrayOutputStream getXlsxReport(ShipmentPackingListEntity packingList) throws IOException;
}
