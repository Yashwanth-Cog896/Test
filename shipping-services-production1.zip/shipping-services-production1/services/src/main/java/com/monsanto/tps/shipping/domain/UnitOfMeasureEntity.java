package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: slaks
 * Date: 8/26/13
 */
@Table(name = "UOM", schema = "MIDAS")
@Entity
public class UnitOfMeasureEntity {

    @Id
    @Column(name = "UOM_ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "REF_ACTIVE")
    @Type(type = "true_false")
    private Boolean refActive;

    @Column(name = "UOM_REF_ID")
    private String uomRefId;

    public UnitOfMeasureEntity() {}

    public UnitOfMeasureEntity(String uomRefId) {
        this.uomRefId = uomRefId;
    }

    public UnitOfMeasureEntity(Long id, String uomRefId) {
        this.id = id;
        this.uomRefId = uomRefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUomRefId() {
        return uomRefId;
    }

    public void setUomRefId(String uomRefId) {
        this.uomRefId = uomRefId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true;}
        if (o == null || getClass() != o.getClass()){ return false;}

        UnitOfMeasureEntity that = (UnitOfMeasureEntity) o;

        return !(id != null ? !id.equals(that.id) : that.id != null);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
