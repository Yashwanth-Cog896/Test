package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface CustomsBrokerPreferenceBusiness {

    Collection<CustomsBrokerPreferenceEntity> loadAll();

    void save(CustomsBrokerPreferenceEntity customsBrokerPreference);

}
