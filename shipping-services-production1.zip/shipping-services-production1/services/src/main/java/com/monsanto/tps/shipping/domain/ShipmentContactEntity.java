package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

/**
 * User: DCENGL
 */
@Entity
@Table(name="CONTACT", schema="INVENTORY_MGT")
public class ShipmentContactEntity {

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    @Column(name="CONTACT_ID")
    private Long contactId;

    @Column(name = "IRD_CONTACT_ID")
    private Long irdContactId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "CREATION_DTTM")
    private Date creationDate;

    @Column(name = "COMPANY_NAME")
    private String companyName;

    @Transient
    private String phoneNumber;

    @Transient
    private String email;

    @Transient
    private String attention;

    public ShipmentContactEntity() {
    }

    public ShipmentContactEntity(String name) {
        this.firstName = name;
        this.lastName = " ";
        this.creationDate = new Date();
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public Long getIrdContactId() {
        return irdContactId;
    }

    public void setIrdContactId(Long irdContactId) {
        this.irdContactId = irdContactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAttention() {
        return attention;
    }

    public void setAttention(String attention) {
        this.attention = attention;
    }
}
