package com.monsanto.tps.shipping.service;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.shipping.common.request.ClientProfile;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.business.integration.ClientProfileBusiness;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ShipmentStatus;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.springframework.util.StringUtils.commaDelimitedListToStringArray;

/**
 * Created by vshan on 3/6/17.
 */
@Component("shipmentStatusService")
public class ShipmentStatusServiceImpl implements ShipmentStatusService {

    private static final Logger log = LogManager.getLogger(ShipmentStatusServiceImpl.class);

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Autowired
    private ClientProfileBusiness clientProfileBusiness;

    @Override
    @Transactional(readOnly = true)
    public List<ShipmentStatus> getPackingLists(String ids) {
        List<ShipmentStatus> shipmentStatusList = Lists.newArrayList();

        ShippingWebException.checkArgument(ids != null, "PackingListIds cannot be null");

        String[] packingListIds = commaDelimitedListToStringArray(ids);

        for (String packingListId : packingListIds) {
            ShipmentPackingListEntity shipmentPackingListEntity = shipmentPackingListBusiness.getShipmentPackingList(Long.valueOf(packingListId));
            if (shipmentPackingListEntity != null) {
                ShipmentStatus shipmentStatus = convertToShipmentStatus(shipmentPackingListEntity);
                if (shipmentStatus != null) {
                    shipmentStatusList.add(shipmentStatus);
                }
            }
        }

        return shipmentStatusList;
    }

    private ShipmentStatus convertToShipmentStatus(ShipmentPackingListEntity shipmentPackingListEntity) {
        ShipmentStatus shipmentStatus = null;

        ShipmentEntity shipmentEntity = Iterables.get(shipmentPackingListEntity.getShipmentContainers(), 0).getShipment();

        if (shipmentEntity != null) {
            shipmentStatus = new ShipmentStatus();
            populateDetails(shipmentPackingListEntity, shipmentStatus, shipmentEntity);
            populateFromContact(shipmentPackingListEntity, shipmentStatus, shipmentEntity);
            populateToContact(shipmentPackingListEntity, shipmentStatus, shipmentEntity);
            populateTrackInfo(shipmentStatus, shipmentEntity);
            if (shipmentStatus.getTrackInfo() != null) {
                populateClientProfile(shipmentStatus, shipmentEntity);
            }
        }

        return shipmentStatus;
    }

    private void populateClientProfile(ShipmentStatus shipmentStatus, ShipmentEntity shipmentEntity) {

        ShipmentStatus.ClientProfile shipmentClientProfile = new ShipmentStatus.ClientProfile();
        try {
            ClientProfile clientProfile = clientProfileBusiness.getClientProfile(
                    shipmentEntity.getCarrier().getCarrierId(),
                    shipmentEntity.getFromAccountId(),
                    shipmentEntity.getFromContact().getIrdContactId()
            );
            shipmentClientProfile.setMeterNumber(clientProfile.getMeterNumber());
            shipmentClientProfile.setAccountNumber(clientProfile.getAccountNumber());
        } catch (ShippingWebException shippingWebException) {
            log.error("Unable to get client profile for shipment with carrier id " + shipmentEntity.getCarrier().getCarrierId()
                    + " and fromAccount id " + shipmentEntity.getFromAccountId()
                    + " and IRD contact id " + shipmentEntity.getFromContact().getIrdContactId());
        }
        shipmentStatus.setClientProfile(shipmentClientProfile);
    }

    private void populateTrackInfo(ShipmentStatus shipmentStatus, ShipmentEntity shipmentEntity) {
        ShipmentStatus.TrackInfo trackInfo;
        CarrierEntity carrier = shipmentEntity.getCarrier();
        if (carrier != null && carrier.isSupportIntegratedShipping()) {
            trackInfo = new ShipmentStatus.TrackInfo();
            trackInfo.setCarrierName(carrier.getName());
            trackInfo.setTrackingUrl(carrier.getTrackingUrl() + shipmentEntity.getTrackingNumber());
            trackInfo.setTrackingNumber(shipmentEntity.getTrackingNumber());
            shipmentStatus.setTrackInfo(trackInfo);
        }
    }

    private void populateToContact(ShipmentPackingListEntity shipmentPackingListEntity, ShipmentStatus shipmentStatus, ShipmentEntity shipmentEntity) {
        ShipmentStatus.Details.Contact toContact = new ShipmentStatus.Details.Contact();
        toContact.setId(shipmentPackingListEntity.getToContactId());
        toContact.setFirstName(shipmentEntity.getToContact().getFirstName());
        toContact.setLastName(shipmentEntity.getToContact().getLastName());
        toContact.setCity(shipmentEntity.getToAddress().getCity());
        toContact.setCountry(shipmentEntity.getToAddress().getCountry());
        toContact.setState(shipmentEntity.getToAddress().getState());
        toContact.setZip(shipmentEntity.getToAddress().getPostalCode());

        shipmentStatus.getDetails().setToContact(toContact);
    }

    private void populateFromContact(ShipmentPackingListEntity shipmentPackingListEntity, ShipmentStatus shipmentStatus, ShipmentEntity shipmentEntity) {
        ShipmentStatus.Details.Contact fromContact = new ShipmentStatus.Details.Contact();
        fromContact.setId(shipmentPackingListEntity.getFromContactId());
        fromContact.setFirstName(shipmentEntity.getFromContact().getFirstName());
        fromContact.setLastName(shipmentEntity.getFromContact().getLastName());
        fromContact.setCity(shipmentEntity.getFromAddress().getCity());
        fromContact.setCountry(shipmentEntity.getFromAddress().getCountry());
        fromContact.setState(shipmentEntity.getFromAddress().getState());
        fromContact.setZip(shipmentEntity.getFromAddress().getPostalCode());

        shipmentStatus.getDetails().setFromContact(fromContact);
    }

    private void populateDetails(ShipmentPackingListEntity shipmentPackingListEntity, ShipmentStatus shipmentStatus, ShipmentEntity shipmentEntity) {
        ShipmentStatus.Details details = new ShipmentStatus.Details();
        details.setId(shipmentPackingListEntity.getShipmentPackingListId());
        details.setDescription(shipmentPackingListEntity.getDescription());
        details.setBarcode(shipmentPackingListEntity.getBarcode());
        details.setCreatedBy(shipmentPackingListEntity.getCreatedBy().getLoginId());
        details.setRegulatedStatus(shipmentPackingListEntity.getRegulatedStatusText());
        details.setStatus(shipmentEntity.getStatus().getName());

        shipmentStatus.setDetails(details);
    }
}
