package com.monsanto.tps.shipping.business.reports.checklist;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by DCENGL
 */
public interface ChecklistReport {

    ByteArrayOutputStream getPdfReport(ShipmentPackingListEntity packingListEntity) throws IOException;

}
