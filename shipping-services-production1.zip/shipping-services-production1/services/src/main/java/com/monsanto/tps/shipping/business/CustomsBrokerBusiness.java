package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;
import com.monsanto.tps.shipping.service.model.CustomsBroker;

import java.util.Collection;

/**
 * Created by TMILB on 7/8/14.
 */
public interface CustomsBrokerBusiness {
    //TODO Refactor this to return entity and transform to the transfer object at the service layer
    public CustomsBroker findBy(Long fromAccountId, String countryCode);
    public CustomsBrokerEntity findEntityBy(Long accountId, String isoCountryCode);

    Collection<CustomsBrokerEntity> loadAll();
}
