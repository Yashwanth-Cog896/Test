package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * User: SDCHIL
 */
@Repository
public class ShipmentContainerLabelDaoImpl implements  ShipmentContainerLabelDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public void save(ShipmentContainerLabelEntity shipmentContainerLabelEntity) {
        sessionFactory.getCurrentSession().save(shipmentContainerLabelEntity);
    }

    @Trace
    @Override
    public void delete(ShipmentContainerLabelEntity label) {
        sessionFactory.getCurrentSession().delete(label);
    }
}
