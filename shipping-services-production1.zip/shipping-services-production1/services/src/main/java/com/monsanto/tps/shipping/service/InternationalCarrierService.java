package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.InternationalCarrier;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/international/carrier")
public interface InternationalCarrierService {
    @GET
    @Produces(APPLICATION_JSON)
    public List<InternationalCarrier> getCarriers();
}
