package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.util.Collection;

/**
 * Created by DCENGL
 */
public interface ContentContainerBusiness {

    Collection<ScannedContainerEntity> getAllContentContainers(ShipmentPackingListEntity packingList);

    Collection<? extends ScannedContainerEntity> getAllContentContainersWithContent(ShipmentPackingListEntity packingList, ContentEntity content);


}
