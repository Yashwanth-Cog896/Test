package com.monsanto.tps.shipping.business.integration;

import com.monsanto.shipping.common.request.ClientProfile;
import com.monsanto.tps.shipping.dao.CarrierAccountInstructionDao;
import com.monsanto.tps.shipping.domain.CarrierAccountInstructionEntity;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * User: DCENGL
 */
@Service
public class ClientProfileBusinessImpl implements ClientProfileBusiness {

    @Autowired
    private CarrierAccountInstructionDao carrierAccountInstructionDao;

    @Override
    public ClientProfile getClientProfile(Long carrierId, Long fromAccountId, Long fromIrdContactId) {
        ClientProfile clientProfile = new ClientProfile();
        CarrierAccountInstructionEntity carrierAccountInstructionEntity =
                carrierAccountInstructionDao.findByCarrierAcountContact(carrierId, fromAccountId, fromIrdContactId);
        ShippingWebException.checkArgument(carrierAccountInstructionEntity != null, "Cannot ship shipment - no carrier account info found for sender.");
        clientProfile.setMeterNumber(carrierAccountInstructionEntity.getMeterNumber());
        clientProfile.setAccountNumber(carrierAccountInstructionEntity.getSenderAccountNumber());
        return clientProfile;
    }
}
