/**
 * Created by TMILB on 7/8/14.
 */

package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.CustomsBrokerDao;
import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;
import com.monsanto.tps.shipping.service.model.CustomsBroker;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

import static com.google.common.base.Preconditions.checkArgument;

@Service
public class CustomsBrokerBusinessImpl implements CustomsBrokerBusiness {
    @Autowired
    private CustomsBrokerDao customsBrokerDao;

    @Override
    @Trace
    public CustomsBroker findBy(Long fromAccountId, String countryCode) {

        CustomsBrokerEntity cbe = findEntityBy(fromAccountId, countryCode);
        CustomsBroker cb=new CustomsBroker();
        cb.setBrokerName(cbe.getName());
        cb.setCompanyName(cbe.getCompanyName());
        cb.setAddress1(cbe.getAddress1());
        cb.setAddress2(cbe.getAddress2());
        cb.setCity(cbe.getCity());
        cb.setPhoneNumber(cbe.getPhoneNumber());
        return cb;
    }

    @Trace
    @Override
    public CustomsBrokerEntity findEntityBy(Long accountId, String isoCountryCode) {
        checkArgument(accountId != null, "Account ID can't be null when looking for a broker");
        checkArgument(isoCountryCode != null, "Country code can't be null when looking for a broker");

        CustomsBrokerEntity customsBroker = customsBrokerDao.findBy(accountId, isoCountryCode);
        if (customsBroker == null) {
            throw new ShippingWebException("Unable to locate Broker for account " + accountId + ", country ISO code " + isoCountryCode);
        }
        return customsBroker;

    }

    @Override
    public Collection<CustomsBrokerEntity> loadAll() {
        return customsBrokerDao.loadAll();
    }
}
