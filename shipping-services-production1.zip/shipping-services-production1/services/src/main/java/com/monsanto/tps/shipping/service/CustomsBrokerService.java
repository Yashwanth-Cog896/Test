/**
 * Created by TMILB on 7/9/14.
 */


package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.CustomsBroker;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/broker")
public interface CustomsBrokerService {
    @GET
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/{account-id}/country-code/{country-code}")
    public CustomsBroker getBroker(@PathParam("account-id") Long accountId,
                                    @PathParam("country-code") String countryCode);

    @GET
    @Produces(APPLICATION_JSON)
    public Collection<CustomsBroker> getBrokers();

}
