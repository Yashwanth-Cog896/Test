package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.GlobalTradeDocumentsBusiness;
import com.monsanto.tps.shipping.transfer.GlobalTradeDocuments;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

@Component("globalTradeDocumentsService")
public class GlobalTradeDocumentsServiceImpl implements GlobalTradeDocumentsService {

    private static final Log LOG = LogFactory.getLog(GlobalTradeDocumentsServiceImpl.class);

    public static final String NO_DOCUMENTS_FOUND = "No documents found";

    @Autowired
    private GlobalTradeDocumentsBusiness globalTradeDocumentsBusiness;

    @Context
    private HttpServletResponse response;

    @Override
    public List<GlobalTradeDocuments> getGlobalTradeDocumentsList(Long sapOrderShipmentId) {
        return globalTradeDocumentsBusiness.getGlobalTradeDocumentsList(sapOrderShipmentId);
    }

    @Override
    public HttpServletResponse getGlobalTradeDocumentPdf(String encodedDocumentUrl, String encodedTitle) {
        String title = decodeTitle(encodedTitle);
        Cookie cookie = new Cookie("fileDownload", "true");
        cookie.setPath("/");

        response.setHeader("Content-Disposition", "attachment; filename=\""+ title + ".pdf\"");
        response.addCookie(cookie);

        byte[] responsePdf = globalTradeDocumentsBusiness.getGlobalTradeDocumentPdf(encodedDocumentUrl, title);
        try {
            if(responsePdf.length > 0) {
                response.getOutputStream().write(responsePdf);
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, NO_DOCUMENTS_FOUND);
            }
        } catch (IOException e) {
            throw new ShippingWebException("Error downloading " + title + " document" , e);
        }

        return response;
    }

    private String decodeTitle(String encodedTitle) {
        String title;
        try {
            title = URLDecoder.decode(new String(Base64.decodeBase64(encodedTitle), "UTF-8"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOG.error("Unable to decode the global trade document title. [encodedTitle: " + encodedTitle + "]");
            throw new ShippingWebException("Unable to decode the global trade document title. [encodedTitle: " + encodedTitle + "]", e);
        }
        return title;
    }

}
