package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ContentEntity;

import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 * Date: 1/22/13
 * Time: 5:32 PM
 */
public interface InventoryDao {

    List<? extends ContentEntity> findByBarcode(String barcode);

    List<? extends ContentEntity> findByBarcode(Collection<String> barcodes);
}