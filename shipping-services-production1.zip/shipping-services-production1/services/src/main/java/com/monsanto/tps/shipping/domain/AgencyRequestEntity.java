package com.monsanto.tps.shipping.domain;


import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * User: pgadi
 */
@Entity
@Table(name = "AGENCY_REQUEST", schema = "FCM")
public class AgencyRequestEntity {

    @Id
    @Column(name = "AGENCY_REQUEST_ID")
    private Long id;

    @Column(name = "MONSANTO_ID")
    private String monsantoId;

    @Column(name = "AGENCY_APRV_NBR")
    private String agencyApprovalNumber;

    @Column(name = "ACT_EXPR_DATE")
    @Temporal(TemporalType.DATE)
    private Date expirationDate;

    @Column(name = "ACT_EFF_DATE")
    @Temporal(TemporalType.DATE)
    private Date effectiveDate;

    @Column(name = "CROP_ID")
    private Long cropId;

    @Column(name = "STATUS_CODE", nullable = false)
    private String statusCode;

    @Column(name = "AGENCY_ACRONYM")
    private String agencyAcronym;

    @Column(name = "FIELD_TRIAL_RSPNSBLTY_CODE")
    private String pipelineFunction;

    @OneToMany(mappedBy = "agencyRequest")
    private List<AgencyRequestLocation> locations;

    public String getAgencyAcronym() {
        return agencyAcronym;
    }

    public void setAgencyAcronym(String agencyAcronym) {
        this.agencyAcronym = agencyAcronym;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMonsantoId() {
        return monsantoId;
    }

    public void setMonsantoId(String monsantoId) {
        this.monsantoId = monsantoId;
    }

    public String getAgencyApprovalNumber() {
        return agencyApprovalNumber;
    }

    public void setAgencyApprovalNumber(String agencyApprovalNumber) {
        this.agencyApprovalNumber = agencyApprovalNumber;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getPipelineFunction() {
        return pipelineFunction;
    }

    public void setPipelineFunction(String pipelineFunction) {
        this.pipelineFunction = pipelineFunction;
    }

    public List<AgencyRequestLocation> getLocations() {
        return locations;
    }

    public void setLocations(List<AgencyRequestLocation> locations) {
        this.locations = locations;
    }

    @Override
    public String toString() {
        return "AgencyRequestEntity{" +
                "id=" + id +
                ", monsantoId='" + monsantoId + '\'' +
                ", agencyApprovalNumber='" + agencyApprovalNumber + '\'' +
                ", expirationDate=" + expirationDate +
                ", effectiveDate=" + effectiveDate +
                ", cropId=" + cropId +
                ", statusCode='" + statusCode + '\'' +
                '}';
    }
}
