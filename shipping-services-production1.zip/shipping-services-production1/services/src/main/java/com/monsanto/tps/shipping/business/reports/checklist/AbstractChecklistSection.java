package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.Multimap;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.commons.lang.StringUtils;

/**
 * Created by DCENGL
 */
public abstract class AbstractChecklistSection implements ChecklistSection {

    public float writeSection(Document document, PdfWriter writer, float startingY) throws DocumentException {
        Multimap<String, String> questionsMap = getSectionMap();

        float y = addSectionHeader(writer, startingY) - 15;

        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setAlignment(Element.ALIGN_LEFT);

        boolean firstSubSection = true;

        for (String subSection : questionsMap.keySet()) {
            columnText.setSimpleColumn(new Phrase(subSection, ChecklistSection.SUB_SECTION_HEADER_FONT), 20, 0, document.getPageSize().getRight() - 160, y, 0, Element.ALIGN_LEFT);
            columnText.go();

            if (firstSubSection) {
                onFirstSubSection(writer, y);
            }

            y = columnText.getYLine() - 1;

            for (String question : questionsMap.get(subSection)) {
                y = addQuestion(writer, ChecklistSection.QUESTION_TEXT_FONT, question, y);
            }

            y -= 10;
            firstSubSection = false;
        }

        return y;
    }

    private float addSectionHeader(PdfWriter writer, float startingPosition) throws DocumentException {
        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setAlignment(Element.ALIGN_LEFT);
        columnText.addElement(new Paragraph(getHeaderText(), ChecklistSection.SECTION_HEADER_FONT));
        columnText.setSimpleColumn(20, 0, writer.getPageSize().getRight(), startingPosition + 5);
        columnText.go();

        return columnText.getYLine();
    }

    protected abstract String getHeaderText();

    protected abstract void onFirstSubSection(PdfWriter writer, float y) throws DocumentException;

    protected abstract Multimap<String, String> getSectionMap();

    private float addQuestion(PdfWriter writer, Font font, String question, float startingPosition) throws DocumentException {
        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setAlignment(Element.ALIGN_LEFT);
        Paragraph paragraph = new Paragraph(question, font);
        paragraph.setSpacingBefore(4);
        paragraph.setSpacingAfter(4);
        columnText.addElement(paragraph);
        columnText.setSimpleColumn(20, 0, writer.getPageSize().getRight() - 160, startingPosition);
        columnText.go();

        if (StringUtils.equals(question, "Microbial shipment verified in Breeding GPS Compliance Tool Suite.")) {
            drawCheckbox(writer, startingPosition, 1, BaseColor.WHITE);
        } else {
            drawCheckbox(writer, startingPosition, 1, BaseColor.BLACK);
        }

        drawCheckbox(writer, startingPosition, 2,  BaseColor.BLACK);
        drawCheckbox(writer, startingPosition, 3,  BaseColor.BLACK);
        drawCheckbox(writer, startingPosition, 4,  BaseColor.BLACK);

        return columnText.getYLine();
    }

    private void drawCheckbox(PdfWriter writer, float startingPosition, int i, BaseColor color) {
        float right = writer.getPageSize().getRight();

        float lowerLeftX = right - (i * 40);
        float lowerLeftY = startingPosition - 20;

        PdfContentByte cb = writer.getDirectContent();
        cb.saveState();
        cb.setColorStroke(color);
        cb.rectangle(lowerLeftX, lowerLeftY, 17.5f, 15.5f);
        cb.stroke();
        cb.restoreState();
    }
}
