package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.*;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.business.compliance.RegulatedMovementBusiness;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * User: DCENGL
 */
@Service
public class RegulatedEventBusinessImpl implements RegulatedEventBusiness {

    private static final Log LOG = LogFactory.getLog(RegulatedEventBusinessImpl.class);

    public static final String ICB_FIELD_DOES_NOT_HAVE_ASSOCIATED_ICB_GENETIC_MATERIAL = "ICB Field does not have associated ICB Genetic Material";
    public static final String PLANTING_DATE_MISSING = "Some Harvested Material is missing Plot/Field Planting Date; Please have Planting Date information updated in Field Manager";

    @Autowired
    private EpaBusiness epaBusiness;
    @Autowired
    private UsdaBusiness usdaBusiness;
    @Autowired
    private SelectionAdvancementBusiness selectionAdvancementBusiness;
    @Autowired
    private PlotBusiness plotBusiness;
    @Autowired
    private EventHelper eventHelper;
    @Autowired
    private StewardshipBusiness stewardshipBusiness;
    @Autowired
    private RegulatedCountryBusiness regulatedCountryBusiness;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private RegulatedMovementBusiness regulatedMovementBusiness;
    @Autowired
    private AgencyBusiness agencyBusiness;
    @Autowired
    private RegulatedStatusCheck regulatedStatusCheck;

    @Trace
    @Override
    public Map<AgencyEnum, Collection<Event>> getRegulatedEvents(ShipmentPackingListEntity shipmentPackingList) {
        if (shipmentPackingList.isInternational()) {
            return new HashMap<AgencyEnum, Collection<Event>>();
        }

        return getRegulatedEvents(shipmentPackingList, EventHelper.getContentContainers(shipmentPackingList));
    }

    @Trace
    @Override
    public Map<AgencyEnum, Collection<Event>> getRegulatedEvents(ShipmentPackingListEntity shipmentPackingList, Collection<? extends ScannedContainerEntity> scannedContainers) {
        Multimap<Event, ContentEntity> contentsByEvent = eventHelper.getEventMap(scannedContainers);

        return getRegulatedEvents(shipmentPackingList, scannedContainers, contentsByEvent);
    }

    private Map<AgencyEnum, Collection<Event>> getRegulatedEvents(ShipmentPackingListEntity shipmentPackingList,
                                                                  Collection<? extends ScannedContainerEntity> scannedContainers,
                                                                  Multimap<Event, ContentEntity> contentsByEvent) {
        if (shipmentPackingList.getShipmentType().isHarvested()) {
            Collection<PlotEntity> femalePlots = getFemalePlots(scannedContainers);

            addICBMaleEvents(contentsByEvent, femalePlots);
            addMaleEventsForBinaryFemalePlots(contentsByEvent, femalePlots);
            isMissingPlantingDate(scannedContainers);
        }

        Map<AgencyEnum, Collection<Event>> eventsByAgency = filterOutNonRegulatedEvents(shipmentPackingList, contentsByEvent.keySet());

        populateContentContainerIdsOnEvents(shipmentPackingList, eventsByAgency, contentsByEvent);

        return eventsByAgency;
    }

    @Trace
    @Override
    public Map<AgencyEnum, Collection<Event>> createRegulatedMovements(ShipmentPackingListEntity shipmentPackingList) {

        Collection<? extends ScannedContainerEntity> contentContainers = EventHelper.getContentContainers(shipmentPackingList);

        Multimap<Event, ContentEntity> contentsByEvent = eventHelper.getEventMap(contentContainers);

        Map<AgencyEnum, Collection<Event>> eventsByAgency = getRegulatedEvents(shipmentPackingList, contentContainers, contentsByEvent);
        createRegulatedMovements(shipmentPackingList, eventsByAgency, contentsByEvent);

        return eventsByAgency;
    }

    @Override
    public Collection<Event> getRolledUpRegulatedEvents(Map<AgencyEnum, Collection<Event>> eventsByAgency) {
        Collection<Event> events = Sets.newHashSet();
        for (Map.Entry<AgencyEnum, Collection<Event>> agencyCollectionEntry : eventsByAgency.entrySet()) {
            events.addAll(agencyCollectionEntry.getValue());
        }
        return events;
    }

    private void populateContentContainerIdsOnEvents(ShipmentPackingListEntity shipmentPackingList, Map<AgencyEnum, Collection<Event>> eventsByAgency, Multimap<Event, ContentEntity> contentsByEvent) {

        Collection<ScannedContainerEntity> allContentContainers = getContentContainersForPackingList(shipmentPackingList);

        for (Map.Entry<AgencyEnum, Collection<Event>> agencyCollectionEntry : eventsByAgency.entrySet()) {
            for (Event event : agencyCollectionEntry.getValue()) {
                Collection<ScannedContainerEntity> contentContainersForEvent = Lists.newArrayList();
                Collection<RegulatedInventoryMovementEntity> regulatedMovementEntitiesForEvent = Lists.newArrayList();

                for (ContentEntity content : contentsByEvent.get(event)) {
                    contentContainersForEvent.addAll(getContentContainersForContent(allContentContainers, content));
                    regulatedMovementEntitiesForEvent.addAll(getRegulatedMovementsForContent(allContentContainers, content, agencyCollectionEntry.getKey()));
                }
                event.setContentContainerIds(Collections2.transform(contentContainersForEvent, new Function<ScannedContainerEntity, Long>() {
                    @Override
                    public Long apply(ScannedContainerEntity scannedContainerEntity) {
                        return scannedContainerEntity.getContainerId();
                    }
                }));

                if (!CollectionUtils.isEmpty(regulatedMovementEntitiesForEvent)) {
                    event.addRegulatedMovementIds(Collections2.transform(regulatedMovementEntitiesForEvent, new Function<RegulatedInventoryMovementEntity, Long>() {
                        @Override
                        public Long apply(RegulatedInventoryMovementEntity regulatedMovement) {
                            return regulatedMovement.getId();
                        }
                    }));
                }
            }
        }
    }

    private Collection<RegulatedInventoryMovementEntity> getRegulatedMovementsForContent(Collection<ScannedContainerEntity> allContentContainers, ContentEntity content, AgencyEnum agencyEnum) {
        Collection<RegulatedInventoryMovementEntity> movementsForContent = Lists.newArrayList();

        for (ScannedContainerEntity scannedContainer : allContentContainers) {
            if (!CollectionUtils.isEmpty(scannedContainer.getRegulatedMovements())) {

                if (scannedContainer instanceof MultiContentContainerEntity) {
                    if (((MultiContentContainerEntity) scannedContainer).getContents().contains(content)) {
                        for (RegulatedInventoryMovementEntity regulatedInventoryMovementEntity : (Collection<RegulatedInventoryMovementEntity>) scannedContainer.getRegulatedMovements()) {
                            if (regulatedInventoryMovementEntity.getAgency().getEnumValue() == agencyEnum && regulatedInventoryMovementEntity.getContent().equals(content)) {
                                movementsForContent.add(regulatedInventoryMovementEntity);
                            }

                        }
                    }
                } else {
                    if (scannedContainer.getContent().equals(content)) {
                        for (RegulatedInventoryMovementEntity regulatedInventoryMovementEntity : (Collection<RegulatedInventoryMovementEntity>) scannedContainer.getRegulatedMovements()) {
                            if (regulatedInventoryMovementEntity.getAgency().getEnumValue() == agencyEnum) {
                                movementsForContent.add(regulatedInventoryMovementEntity);
                            }
                        }
                    }
                }

            }
        }

        return movementsForContent;
    }


    private void isMissingPlantingDate(Collection<? extends ScannedContainerEntity> contentContainers) {
        for (ScannedContainerEntity scannedContainerEntity : contentContainers) {
            Date plantingDate = plotBusiness.getPlantingDate((PlotEntity)(scannedContainerEntity.getContent()));
            if (plantingDate == null) {
                PlotDataErrorsHolder.addError(PLANTING_DATE_MISSING);
            }
        }
    }

    private void createRegulatedMovements(ShipmentPackingListEntity shipmentPackingList, Map<AgencyEnum, Collection<Event>> eventsByAgency, Multimap<Event, ContentEntity> contentsByEvent) {
        regulatedMovementBusiness.deleteMovementsByPackingList(shipmentPackingList);
        clearRegulatedMovementIds(eventsByAgency);

        for (Map.Entry<AgencyEnum, Collection<Event>> agencyCollectionEntry : eventsByAgency.entrySet()) {
            AgencyEnum key = agencyCollectionEntry.getKey();
            Collection<Event> value = agencyCollectionEntry.getValue();
            AgencyEntity agencyEntity = agencyBusiness.findByAbbreviation(key.getAbbr());

            for (Event event : value) {
                Collection<RegulatedInventoryMovementEntity> regulatedMovements = regulatedMovementBusiness.createRegulatedMovements(shipmentPackingList, agencyEntity, contentsByEvent.get(event), event);
                if (!CollectionUtils.isEmpty(regulatedMovements)) {
                    event.addRegulatedMovementIds(Collections2.transform(regulatedMovements, new Function<RegulatedInventoryMovementEntity, Long>() {
                        @Override
                        public Long apply(RegulatedInventoryMovementEntity regulatedMovement) {
                            return regulatedMovement.getId();
                        }
                    }));
                }
            }
        }
    }

    private void clearRegulatedMovementIds(Map<AgencyEnum, Collection<Event>> eventsByAgency) {
        for (Collection<Event> events : eventsByAgency.values()) {
            for (Event event : events) {
                if (!CollectionUtils.isEmpty(event.getRegulatedMovementIds())) {
                    event.getRegulatedMovementIds().clear();
                }
            }
        }
    }

    private Collection<ScannedContainerEntity> getContentContainersForPackingList(ShipmentPackingListEntity shipmentPackingList) {
        Collection<ScannedContainerEntity> contentContainers = Lists.newArrayList();
        for (ShipmentContainerEntity shipmentContainer : shipmentPackingList.getShipmentContainers()) {
            contentContainers.addAll(shipmentContainer.getStorageContainer().getContainers());
        }

        return contentContainers;
    }

    private Collection<ScannedContainerEntity> getContentContainersForContent(Collection<ScannedContainerEntity> allScannedContainers, ContentEntity content) {
        Collection<ScannedContainerEntity> scannedContainerIds = Lists.newArrayList();

        for (ScannedContainerEntity scannedContainer : allScannedContainers) {
            if (scannedContainer instanceof MultiContentContainerEntity) {
                if (((MultiContentContainerEntity) scannedContainer).getContents().contains(content)) {
                    scannedContainerIds.add(scannedContainer);
                }
            } else {
                if (scannedContainer.getContent().equals(content)) {
                    scannedContainerIds.add(scannedContainer);
                }
            }
        }

        return scannedContainerIds;
    }



    private Map<AgencyEnum, Collection<Event>> filterOutNonRegulatedEvents(ShipmentPackingListEntity packingListEntity, Collection<Event> events) {
        Map<AgencyEnum, Collection<Event>> agencyToEventsMap = Maps.newHashMap();

        //Flatten out the events to strings for the stored procedure calls
        Set<String> eventStrings = eventHelper.getEventStrings(events);
        //combinedEventStrings needs to be used for stewarded because it can handle event stacks (NK603,ZM_S21773821)
        //Other regulated shipments do not use event stacks, only stewarded does
        Set<String> combinedEventStrings = eventHelper.getCombinedEventStrings(events);

        Contact toContact = contactBusiness.getPartyContact(packingListEntity.getToContactId());
        List<RegulatedAPIResponse> regulatedAPIResponses = null;

        regulatedAPIResponses = regulatedStatusCheck.checkRegulatedStatus(events, eventStrings);
        if(regulatedCountryBusiness.isCountryRegulatedByUsdaEpa(toContact.getCountry())){
            Collection<Event> usdaRegulatedEvents = null;

            usdaRegulatedEvents = regulatedStatusCheck.getRegulatedEvents(events, regulatedAPIResponses);
            if (!CollectionUtils.isEmpty(usdaRegulatedEvents)) {
                agencyToEventsMap.put(AgencyEnum.USDA, usdaRegulatedEvents);
            }

            Collection<Event> epaEvents = null;
            epaEvents = regulatedStatusCheck.getEpaEvents(events, regulatedAPIResponses);
            if (!CollectionUtils.isEmpty(epaEvents)) {
                Collection<Event> epaRegulatedEvents = getEventsForAgency(epaEvents, AgencyEnum.EPA);
                if (!CollectionUtils.isEmpty(epaRegulatedEvents)) {
                    agencyToEventsMap.put(AgencyEnum.EPA, epaRegulatedEvents);
                }

                Collection<Event> preEupEvents = getEventsForAgency(epaEvents, AgencyEnum.PRE_EUP);
                if (!CollectionUtils.isEmpty(preEupEvents)) {
                    agencyToEventsMap.put(AgencyEnum.PRE_EUP, epaEvents);
                }
            }
        }

        //Stewardship must be processed last (Checks if any other agency is regulating the event)
        //Collection<Event> stewardshipEvents = stewardshipBusiness.getEvents(packingListEntity, events, eventStrings);
        regulatedAPIResponses = regulatedStatusCheck.checkRegulatedStatus(events, combinedEventStrings);
        Collection<Event> stewardshipEvents = regulatedStatusCheck.getStewardshipEvents(packingListEntity, events, combinedEventStrings, regulatedAPIResponses);
        if (!CollectionUtils.isEmpty(stewardshipEvents)) {
            agencyToEventsMap.put(AgencyEnum.STEWARDSHIP, stewardshipEvents);
        }

        return agencyToEventsMap;
    }

    private Collection<Event> getEventsForAgency(Collection<Event> events, AgencyEnum agencyEnum) {
        Collection<Event> agencyEvents = Lists.newArrayList();

        for (Event event : events) {
            if (event.getRegulatingAgencies().contains(agencyEnum)) {
                agencyEvents.add(event);
            }
        }

        return agencyEvents;
    }

    private void addICBMaleEvents(Multimap<Event, ContentEntity> contentsByEvent, Collection<PlotEntity> femalePlots) {
        Iterator<PlotEntity> femalePlotsIterator = femalePlots.iterator();

        while (femalePlotsIterator.hasNext()) {
            PlotEntity femalePlot = femalePlotsIterator.next();
            FieldEntity field = femalePlot.getField();
            if (field != null && field.isIcb()) {
                if (field.getIcbGeneticMaterial() != null) {

                    addMaleEvent(femalePlot, field.getIcbGeneticMaterial().getGermplasm().getEvents(), contentsByEvent);

                    femalePlotsIterator.remove();
                } else {
                    PlotDataErrorsHolder.addError(ICB_FIELD_DOES_NOT_HAVE_ASSOCIATED_ICB_GENETIC_MATERIAL);
                    LOG.warn(ICB_FIELD_DOES_NOT_HAVE_ASSOCIATED_ICB_GENETIC_MATERIAL + ": " + field);
                }
            }
        }
    }

    private Event getEventForContent(PlotEntity plot, Multimap<Event, ContentEntity> contentsByEvent) {
        for (Event event : contentsByEvent.keySet()) {
            if (contentsByEvent.get(event).contains(plot)) {
                return event;
            }
        }

        return null;
    }

    private void addMaleEventsForBinaryFemalePlots(Multimap<Event, ContentEntity> contentsByEvent, Collection<PlotEntity> femalePlots) {
        processFemalePlotsForSelectionAdvancement(contentsByEvent, femalePlots);
        processFemalePlotsForPlotMalePlot(contentsByEvent, femalePlots);
    }

    private void processFemalePlotsForSelectionAdvancement(Multimap<Event, ContentEntity> contentsByEvent, Collection<PlotEntity> femalePlots) {
        if (CollectionUtils.isEmpty(femalePlots)) {
            LOG.trace("Will not search selection advancements.  No more female plots to process.");
            return;
        }

        Map<PlotEntity, PlotEntity> selectionAdvancementMalePlotsByFemalePlots = selectionAdvancementBusiness.getMalePlotsForFemalePlotsWithBinaryOperations(femalePlots);
        for (Map.Entry<PlotEntity, PlotEntity> entry : selectionAdvancementMalePlotsByFemalePlots.entrySet()) {
            addMaleEvent(entry.getKey(), entry.getValue().getGeneticMaterial().getGermplasm().getEvents(), contentsByEvent);
        }
    }

    private void processFemalePlotsForPlotMalePlot(Multimap<Event, ContentEntity> contentsByEvent, Collection<PlotEntity> femalePlots) {
        if (CollectionUtils.isEmpty(femalePlots)) {
            LOG.trace("Will not search plot male plot.  No more female plots to process.");
            return;
        }

        Map<PlotEntity, PlotEntity> malePlotsByFemalePlot = plotBusiness.getMalePlotsForFemalePlotsWithBinaryOperations(femalePlots);
        for (Map.Entry<PlotEntity, PlotEntity> entry : malePlotsByFemalePlot.entrySet()) {
            addMaleEvent(entry.getKey(), entry.getValue().getGeneticMaterial().getGermplasm().getEvents(), contentsByEvent);
        }
    }

    private Collection<PlotEntity> getFemalePlots(Collection<? extends ScannedContainerEntity> items) {
        Collection<PlotEntity> femalePlots = Sets.newHashSet();

        for (ScannedContainerEntity scannedContainerEntity : items) {
            //TODO find a safer method to cast (With hibernate proxies)
            femalePlots.add(PlotEntity.class.cast(scannedContainerEntity.getContent()));
        }

        return femalePlots;
    }

    private void addMaleEvent(PlotEntity femalePlot, Collection<EventConstructEntity> maleEventConstructs, Multimap<Event, ContentEntity> contentsByEvent) {
        Event femaleEvent = getEventForContent(femalePlot, contentsByEvent);

        String maleEventString = eventHelper.getEventString(maleEventConstructs);

        eventHelper.addMaleEventToEventMap(femalePlot, femaleEvent, maleEventString, maleEventConstructs, contentsByEvent);
    }
}
