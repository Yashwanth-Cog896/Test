package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.services.domain.shipping.Carrier;
import com.monsanto.shipping.common.ShippingStatusEnum;
import com.monsanto.shipping.common.request.CancelRequest;
import com.monsanto.shipping.common.request.ClientProfile;
import com.monsanto.shipping.common.request.ShipRequest;
import com.monsanto.shipping.common.request.TrackRequest;
import com.monsanto.shipping.common.response.CancelResponse;
import com.monsanto.shipping.common.response.PackageResponse;
import com.monsanto.shipping.common.response.ShipResponse;
import com.monsanto.shipping.common.response.TrackResponse;
import com.monsanto.shipping.delegate.ShippingServiceDelegator;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.business.integration.CancelRequestBuilder;
import com.monsanto.tps.shipping.business.integration.ClientProfileBusiness;
import com.monsanto.tps.shipping.dao.CountryDao;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.dao.ProgramDao;
import com.monsanto.tps.shipping.dao.ShipmentContentProcessDao;
import com.monsanto.tps.shipping.dao.ShipmentDao;
import com.monsanto.tps.shipping.dao.ShipmentLabelTypeDao;
import com.monsanto.tps.shipping.dao.ShipmentStatusDao;
import com.monsanto.tps.shipping.dao.ShipmentTypeDao;
import com.monsanto.tps.shipping.dao.SourceSystemDao;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.domain.CountryEntity;
import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.ShipmentAddressEntity;
import com.monsanto.tps.shipping.domain.ShipmentContactEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentLabelTypeEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.ShippingStatus;
import com.monsanto.tps.shipping.service.model.Dimensions;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.Shipment;
import com.monsanto.tps.shipping.service.model.ShipmentAcknowledgement;
import com.monsanto.tps.shipping.service.model.ShipmentEmailOptions;
import com.monsanto.tps.shipping.service.model.enums.ShipmentLabelTypeEnum;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.TextUtils;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * User: pgadi
 */
@Service
public class ShipmentBusinessImpl implements ShipmentBusiness {
    private static final String OUTGOING = "outgoing";
    private static final String COMPLETED = "completed";

    @Autowired
    private ShipmentTypeDao shipmentTypeDao;
    @Autowired
    private SourceSystemDao sourceSystemDao;
    @Autowired
    private ShipmentStatusDao shipmentStatusDao;
    @Autowired
    private ShipmentDao shipmentDao;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private ShipmentContentProcessDao shipmentContentProcessDao;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private ShipmentAddressBusiness shipmentAddressBusiness;
    @Autowired
    private ShipmentCarrierOptionBusiness shipmentCarrierOptionBusiness;
    @Autowired
    private ShippingServiceDelegator shippingServiceDelegator;
    @Autowired
    private ShipRequestBuilder shipRequestBuilder;
    @Autowired
    private CancelRequestBuilder cancelRequestBuilder;
    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;
    @Autowired
    private ShipmentLabelTypeDao shipmentLabelTypeDao;
    @Autowired
    private ShipmentContainerLabelBusiness shipmentContainerLabelBusiness;
    @Autowired
    private EmailBusiness emailBusiness;
    @Autowired
    private CarrierBusiness carrierBusiness;
    @Autowired
    private ClientProfileBusiness clientProfileBusiness;
    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;
    @Autowired
    private ProgramDao programDao;
    @Autowired
    private CommodityBusiness commodityBusiness;
    @Resource
    private CountryDao countryDao;
    @Autowired
    private InternationalCompositesDao internationalCompositesDao;
    private static final Log LOG = LogFactory.getLog(ShipmentBusinessImpl.class);

    private static final String SOURCE_SYSTEM_NAME = "Shipping Web";
    private static final String PROCESSING_STATUS_CODE = "Unknown";
    private static final ObjectMapper LOG_OBJECT_MAPPER = new ObjectMapper();

    @Override
    @Trace
    public ShipmentEntity createShipment(ShipmentPackingListEntity packingList, Shipment shipment, String createdBy) {
        shipmentPackingListBusiness.removeEmptyContainers(packingList);

        ShipmentEntity shipmentEntity = new ShipmentEntity();

        CarrierEntity carrier = carrierBusiness.findCarrier(shipment.getCarrier().getCarrierId());
        shipmentEntity.setCarrier(carrier);

        StringBuilder notificationEmailsStringBuilder = new StringBuilder();
        if (shipment.getShipmentEmailOptions().isEmailOriginator()) {
            notificationEmailsStringBuilder.append(createdBy).append("@monsanto.com,");
        }
        if (packingList.getSapOrderShipment() != null) {
            packingList.setRegulatedStatusText(null);
            shipment.setBrokerCheckRequired(false);
            shipmentEntity.setSapOrderNumber(packingList.getSapOrderShipment().getSapOrderNumber()); // Setting this for Global Trade Label issue. (VELSHIP-171)
        }
        addFromContactDataToShipment(packingList, shipmentEntity, notificationEmailsStringBuilder, shipment.getShipmentEmailOptions());
        addToContactDataToShipment(packingList, shipmentEntity, notificationEmailsStringBuilder, shipment);
        shipmentEntity.setNotificationEmails(StringUtils.stripEnd(notificationEmailsStringBuilder.toString(), ","));

        shipmentEntity.setShipmentBarcode(packingList.getBarcode());

        if (!StringUtils.isEmpty(shipment.getComments())) {
            shipmentEntity.setComments(shipment.getComments());
        } else {
            shipmentEntity.setComments(packingList.getDescription());
        }

        shipmentEntity.setSourceSystem(sourceSystemDao.getSourceSystemByName(SOURCE_SYSTEM_NAME));
        shipmentEntity.setShipmentType(packingList.getShipmentType());
        shipmentEntity.setShipmentContentProcessedStateId(
            shipmentContentProcessDao.getShipmentContentProcessId(PROCESSING_STATUS_CODE));

        rollupWeightFromContainers(shipmentEntity, packingList.getShipmentContainers());
        updateShipmentContainers(packingList.getShipmentContainers(), shipment.getDimensions());

        shipmentEntity.setShipmentContainers(Lists.newArrayList(packingList.getShipmentContainers()));

        if (carrier.isSupportIntegratedShipping()) {
            commodityBusiness.associateCommodity(shipmentEntity);
            shipmentEntity.setStatus(shipmentStatusDao.getByName(ShippingStatus.READY_FOR_PICKUP));
            shipmentEntity.setShipmentCarrierOptions(shipmentCarrierOptionBusiness
                .getCarrierOptionsForShipment(shipmentEntity, shipment.getCarrierShipOptions()));
            shipmentEntity.setBrokerCheckRequired(shipment.isBrokerCheckRequired());
            shipShipment(shipmentEntity);
        } else {
            shipmentEntity.setStatus(shipmentStatusDao.getByName(ShippingStatus.IN_TRANSIT));
            shipmentEntity.setTrackingNumber(shipment.getTrackingNumber());
        }

        shipmentDao.saveShipment(shipmentEntity);
        associateShipmentToContainers(shipmentEntity, packingList.getShipmentContainers());
        emailBusiness.sendShipmentCreatedMessage(shipmentEntity);

        return shipmentEntity;
    }

    private void associateShipmentToContainers(ShipmentEntity shipmentEntity,
                                               Collection<ShipmentContainerEntity> shipmentContainers) {
        for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
            shipmentContainer.setShipment(shipmentEntity);
        }
    }

    @Override
    @Trace
    public void saveStatus(String shBarcode, String statusName) {
        ShipmentEntity entity = shipmentDao.findByBarcode(shBarcode);
        if (entity == null) {
            throw new ShippingWebException("Could not find shipment: " + shBarcode);
        }
        saveStatus(entity, statusName);
    }

    public void saveStatus(ShipmentEntity entity, String statusName) {
        ShippingStatus status = shipmentStatusDao.getByName(statusName);

        if (status == null) {
            throw new IllegalArgumentException("Invalid shipping-status: " + statusName);
        }
        entity.setStatus(status);
    }


    public void acknowledge(ShipmentEntity shipment, ShipmentPackingListEntity packingList,
                            ShipmentAcknowledgement acknowledgement) {
        saveStatus(shipment, acknowledgement.getStatus());
        shipment.setReceivedInGoodCondition(acknowledgement.getGoodCondition());

        StringBuilder notificationEmailsStringBuilder = new StringBuilder();
        if (acknowledgement.getEmailOptions().isEmailOriginator()) {
            notificationEmailsStringBuilder.append(packingList.getCreatedBy().getLoginId()).append("@monsanto.com,");
        }
        if (acknowledgement.getEmailOptions().isEmailShipFrom() && packingList.getFromContactId() != null) {
            Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
            notificationEmailsStringBuilder.append(fromContact.getEmailAddress()).append(",");
        }
        if (acknowledgement.getEmailOptions().isEmailShipTo() && packingList.getToContactId() != null) {
            Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());
            notificationEmailsStringBuilder.append(toContact.getEmailAddress()).append(",");
        }

        emailBusiness.sendShipmentAcknowledgedMessage(notificationEmailsStringBuilder.toString(), shipment, packingList);

        saveStatus(shipment, acknowledgement.getStatus());
    }

    @Override
    @Trace
    public ShipmentEntity getShipment(String shBarcode) {
        return shipmentDao.findByBarcode(shBarcode);
    }

    @Override
    @Trace
    public ShipmentEntity getShipment(Long shipmentId) {
        return shipmentDao.load(shipmentId);
    }

    private void addToContactDataToShipment(ShipmentPackingListEntity packingList, ShipmentEntity shipmentEntity, StringBuilder notificationEmails, Shipment shipment) {
        if (packingList.getSapOrderShipment() != null) {
            InternationalCustomer contact = internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getShipToCustomerNumber());

            ShipmentAddressEntity toAddress = shipmentAddressBusiness.buildShipmentAddress(contact);
            shipmentEntity.setToAddress(toAddress);

            ShipmentContactEntity contactEntity = new ShipmentContactEntity(contact.getName());
            contactEntity.setCompanyName(contact.getName());
            contactEntity.setFirstName(StringUtils.defaultString(shipment.getShipToFirstNameOverride(), "").trim());
            if (StringUtils.isEmpty(contactEntity.getFirstName())) {
                contactEntity.setFirstName(contact.getName());
            }
            contactEntity.setLastName(StringUtils.defaultIfEmpty(StringUtils.trim(shipment.getShipToLastNameOverride()), " "));
            contactEntity.setPhoneNumber(StringUtils.defaultString(shipment.getShipToPhoneOverride(),"").replaceAll("[^0-9]", "").trim());
            shipmentEntity.setToContact(contactEntity);
        } else if (packingList.getToContactId() != null) {
            Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());

            ShipmentAddressEntity toAddress = shipmentAddressBusiness.buildShipmentAddress(toContact);
            shipmentEntity.setToAddress(toAddress);
            shipmentEntity.setToAccountId(toContact.accountId);
            shipmentEntity.setToContact(contactBusiness.createShipmentContact(toContact, packingList.getShipToAttn()));

            if (shipment.getShipmentEmailOptions().isEmailShipTo()) {
                notificationEmails.append(toContact.getEmailAddress()).append(",");
            }
        }
    }

    private void addFromContactDataToShipment(ShipmentPackingListEntity packingList, ShipmentEntity shipmentEntity,
                                              StringBuilder notificationEmails,
                                              ShipmentEmailOptions shipmentEmailOptions) {
        if (packingList.getSapOrderShipment() != null) {
            InternationalStorageLocation contact = internationalCompositesDao
                .getStorageLocation(packingList.getSapOrderShipment().getSapStorageLocationCode());
            ShipmentAddressEntity fromAddress = shipmentAddressBusiness.buildShipmentAddress(contact);
            shipmentEntity.setFromAddress(fromAddress);

            if (packingList.getFromContactId() != null) {
                Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
                shipmentEntity.setFromAccountId(fromContact.getAccountId());
                shipmentEntity.setFromContact(contactBusiness.createShipmentContact(fromContact));
                shipmentEntity.getFromContact().setCompanyName(contact.getName());
                shipmentEntity.setBillToAccountId(fromContact.getAccountId());
            }  else {
                shipmentEntity.setFromContact(new ShipmentContactEntity(contact.getName()));
            }
        } else if (packingList.getFromContactId() != null) {
            Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
            ShipmentAddressEntity fromAddress = shipmentAddressBusiness.buildShipmentAddress(fromContact);

            shipmentEntity.setFromAddress(fromAddress);
            shipmentEntity.setFromAccountId(fromContact.getAccountId());
            MidasUserEntity createdBy = packingList.getCreatedBy();
            shipmentEntity.setFromContact(contactBusiness.createShipmentContact(fromContact,
                    TextUtils.getDelimitedStringWithSpace(TextUtils.removeEmptyValues(createdBy.getFirstName(), createdBy.getLastName()))));
            shipmentEntity.setBillToAccountId(fromContact.getAccountId());

            if (shipmentEmailOptions.isEmailShipFrom()) {
                notificationEmails.append(fromContact.getEmailAddress()).append(",");
            }
        }
    }

    private void shipShipment(ShipmentEntity shipmentEntity) {
        ShipRequest shipRequest = shipRequestBuilder.buildShipRequest(shipmentEntity);

        if (LOG.isInfoEnabled()) {
            LOG.info("Outbound carrier ShipRequest payload=" + serializeForLog(shipRequest));
        }

        ShipResponse shipResponse = shippingServiceDelegator.ship(shipRequest);

        if (LOG.isInfoEnabled()) {
            LOG.info("Inbound carrier ShipResponse payload=" + serializeForLog(shipResponse));
        }

        if (shipResponse != null && Boolean.FALSE.equals(shipResponse.isError())) {
            shipmentEntity.setSenderAccountNumber(shipRequest.getClientProfile().getAccountNumber());
            shipmentEntity.setMeterNumber(shipRequest.getClientProfile().getMeterNumber());
            shipmentEntity.setTrackingNumber(shipResponse.getTrackingId());
            shipmentEntity.setCurrencyId(shipResponse.getCurrencyId());
            shipmentEntity.setShipmentCost(shipResponse.getNetShippingCost());
            ShipmentLabelTypeEntity shipmentLabelTypeEntity = shipmentLabelTypeDao
                .findByName(ShipmentLabelTypeEnum.CARRIER_LABEL.getTypeName());
            for (ShipmentContainerEntity shipmentContainerEntity : shipmentEntity.getShipmentContainers()) {
                for (PackageResponse packageResponse : shipResponse.getPackageResponses()) {
                    if (packageResponse.getContainerId().compareTo(shipmentContainerEntity.getShipmentContainerId()) == 0) {
                        ShipmentContainerLabelEntity shipmentContainerLabelEntity = new ShipmentContainerLabelEntity();
                        shipmentContainerLabelEntity.setShipmentLabelTypeId(shipmentLabelTypeEntity.getShipmentLabelTypeId());
                        shipmentContainerLabelEntity.setLabelData(packageResponse.getLabelBytes());
                        shipmentContainerLabelEntity.setShipmentContainerId(shipmentContainerEntity.getShipmentContainerId());
                        shipmentContainerLabelBusiness.save(shipmentContainerLabelEntity);
                        shipmentContainerEntity.getShipmentContainerLabels().add(shipmentContainerLabelEntity);
                        shipmentContainerEntity.setCarrierTrackingId(packageResponse.getTrackingId());
                        shipmentContainerBusiness.save(shipmentContainerEntity);
                        break;
                    }
                }
            }
        } else {
            throw new ShippingWebException(buildShipFailureMessage(shipRequest, shipResponse));
        }
    }

    private String buildShipFailureMessage(ShipRequest shipRequest, ShipResponse shipResponse) {
        String carrierName = null;
        if (shipRequest != null && shipRequest.getCarrier() != null) {
            carrierName = StringUtils.trimToNull(shipRequest.getCarrier().getName());
        }

        String carrierContext = StringUtils.isBlank(carrierName) ? "" : " (carrier: " + carrierName + ")";

        if (shipResponse == null) {
            return "Shipping error: no response received from carrier service" + carrierContext;
        }

        String responseMessage = StringUtils.trimToNull(shipResponse.getMessage());
        if (responseMessage != null) {
            return "Shipping error: " + responseMessage;
        }

        if (shipResponse.isError() == null) {
            return "Shipping error: carrier response did not include an error status" + carrierContext;
        }

        return "Shipping error: carrier returned an error without details" + carrierContext;
    }

    private String serializeForLog(Object value) {
        if (value == null) {
            return "null";
        }

        try {
            return LOG_OBJECT_MAPPER.writeValueAsString(value);
        } catch (Exception e) {
            LOG.warn("Failed to serialize value for shipment debug logging", e);
            return String.valueOf(value);
        }
    }

    public List<ShipmentTypeEntity> getShipmentTypeList() {
        return shipmentTypeDao.findShipmentTypes();
    }

    public ShipmentTypeEntity getShipmentType(Long shipmentTypeId) {
        return shipmentTypeDao.findById(shipmentTypeId);
    }

    @Override
    @Trace
    public List<ShipmentEntity> getShipmentsByAccountIdAndShippedDate(Long accountId, Date shippedAfterDate,
                                                                      String shipmentDirection) {
        return shipmentDao.getShipments(accountId, shippedAfterDate, shipmentDirection.toLowerCase().contains(OUTGOING),
            getStatusList(shipmentDirection));
    }

    @Override
    @Trace
    public List<ShipmentEntity> getShipmentsByCountryAndShippedDate(String countryCode, Date shippedAfterDate,
                                                                    String shipmentDirection) {
        CountryEntity country = countryDao.getCountry(countryCode);
        if (country != null) {
            return shipmentDao.getShipmentsByCountry(country.getIsoCode(), shippedAfterDate,
                shipmentDirection.toLowerCase().contains(OUTGOING), getStatusList(shipmentDirection));
        } else {
            throw new ShippingWebException("invalid country code: " + countryCode);
        }
    }


    private List<String> getStatusList(String shipmentDirection) {
        if (shipmentDirection.toLowerCase().contains(COMPLETED)) {
            return ShippingStatus.COMPLETED_SHIPMENTS_STATUS;
        } else {
            return ShippingStatus.IN_PROGRESS_SHIPMENTS_STATUS;
        }
    }

    @Trace
    @Override
    public void cancelShipment(Long shipmentId) {
        ShipmentEntity shipment = shipmentDao.load(shipmentId);

        boolean integratedShipping = shipment.getCarrier().isSupportIntegratedShipping();
        checkStatusIsValidForCancel(shipment, integratedShipping);

        Collection<ShipmentContainerEntity> shipmentContainers = shipment.getShipmentContainers();

        if (integratedShipping) {
            // make sure it's cancelled with carrier before deleting from database
            CancelRequest cancelRequest = cancelRequestBuilder.buildCancelRequest(shipment);
            CancelResponse cancelResponse = shippingServiceDelegator.cancel(cancelRequest);
            if (cancelResponse.isError()) {
                throw new ShippingWebException(cancelResponse.getMessage());
            }

            ShipmentLabelTypeEntity shipmentLabelTypeEntity = shipmentLabelTypeDao
                .findByName(ShipmentLabelTypeEnum.CARRIER_LABEL.getTypeName());
            for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
                Iterator<ShipmentContainerLabelEntity> labelIterator = shipmentContainer.getShipmentContainerLabels()
                    .iterator();
                while (labelIterator.hasNext()) {
                    ShipmentContainerLabelEntity label = labelIterator.next();
                    if (label.getShipmentLabelTypeId().equals(shipmentLabelTypeEntity.getShipmentLabelTypeId())) {
                        labelIterator.remove();
                        shipmentContainerLabelBusiness.delete(label);
                    }
                }
            }
        }

        for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
            shipmentContainer.setShipment(null);
            shipmentContainerBusiness.save(shipmentContainer);
        }

        shipmentDao.delete(shipment);

        emailBusiness.sendShipmentCancelledMessage(shipment);
    }

    private void checkStatusIsValidForCancel(ShipmentEntity shipment, boolean integratedShipping) {

        if (integratedShipping) {
            ShippingStatus readyForPickupStatus = shipmentStatusDao.getByName(ShippingStatus.READY_FOR_PICKUP);

            if (shipment.getStatus().compareTo(readyForPickupStatus) > 0) {
                throw new ShippingWebException(
                    "Cannot cancel shipment that is [" + shipment.getStatus().getName() + "]");
            }
        } else {
            ShippingStatus inTransitStatus = shipmentStatusDao.getByName(ShippingStatus.IN_TRANSIT);

            if (shipment.getStatus().compareTo(inTransitStatus) > 0) {
                throw new ShippingWebException(
                    "Cannot cancel shipment that is [" + shipment.getStatus().getName() + "]");
            }
        }
    }

    private void updateShipmentContainers(Collection<ShipmentContainerEntity> shipmentContainers,
                                          Dimensions dimensions) {
        int displayOrder = 1;

        for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainers) {
            shipmentContainerEntity.setDisplayOrder(displayOrder++);
            if (dimensions != null) {
                shipmentContainerEntity.setHeight(dimensions.getHeight());
                shipmentContainerEntity.setWidth(dimensions.getWidth());
                shipmentContainerEntity.setLength(dimensions.getLength());
                shipmentContainerEntity.setDimensionUnitOfMeasureId(
                    unitOfMeasureBusiness.getInventoryMgtUomIdFromAbbreviation(dimensions.getUnitOfMeasure()));
            }
        }
    }

    private void rollupWeightFromContainers(ShipmentEntity shipment,
                                            Collection<ShipmentContainerEntity> shipmentContainers) {
        Double totalWeight = 0.0;
        Long weightUOMId = null;

        for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainers) {
            if (shipmentContainerEntity.getGrossWeight() != null) {
                totalWeight += shipmentContainerEntity.getGrossWeight();
                weightUOMId = shipmentContainerEntity.getUomId();
            }
        }
        shipment.setWeight(totalWeight);
        if (weightUOMId != null) {
            shipment.setWeightUOMId(weightUOMId);
        }
    }

    @Override
    @Trace
    public void updateUndeliveredShipmentStatuses() {
        List<CarrierEntity> carriers = carrierBusiness.findIntegratedCarriers();
        for (CarrierEntity carrierEntity : carriers) {
            updateUndeliveredShipmentStatuses(carrierEntity);
        }
    }

    private void updateUndeliveredShipmentStatuses(CarrierEntity carrierEntity) {
        List<ShipmentEntity> shipments = shipmentDao.getUndeliveredShipments(carrierEntity.getCarrierId());
        for (ShipmentEntity shipmentEntity : shipments) {
            updateUndeliveredShipment(shipmentEntity, carrierEntity);
        }
    }

    private void updateUndeliveredShipment(ShipmentEntity shipmentEntity, CarrierEntity carrierEntity) {
        try {
            TrackRequest request = createTrackRequest(shipmentEntity, carrierEntity);
            TrackResponse response = shippingServiceDelegator.track(request);
            updateShipmentStatus(shipmentEntity, response.getShipmentStatus());
            if (response.isDelivered()) {
                emailBusiness.sendShipmentDeliveredMessage(shipmentEntity);
            }
        } catch (Exception e) {
            LOG.error("An error occurred tracking the status of shipment " + shipmentEntity.getShipmentId(), e);
        }
    }

    private void updateShipmentStatus(ShipmentEntity shipmentEntity, ShippingStatusEnum newStatus) {
        if (newStatus != null) {
            ShippingStatus updatedStatus = shipmentStatusDao.getByName(newStatus.toString());

            if (!updatedStatus.equals(shipmentEntity.getStatus())) {
                shipmentEntity.setStatus(updatedStatus);
                shipmentDao.saveShipment(shipmentEntity);
            }
        }
    }

    private TrackRequest createTrackRequest(ShipmentEntity shipmentEntity, CarrierEntity carrierEntity) {
        Long shipmentId = shipmentEntity.getShipmentId();
        String trackingId = shipmentEntity.getTrackingNumber();
        TrackRequest request = new TrackRequest(shipmentId, trackingId);
        Carrier carrier = new Carrier(carrierEntity.getCarrierId(), carrierEntity.getName());
        carrier.setCarrierId(carrierEntity.getCarrierId());
        carrier.setIntegrated(true);
        request.setCarrier(carrier);
        Long carrierId = carrierEntity.getCarrierId();
        Long fromAccountId = shipmentEntity.getFromAccountId();
        Long fromIrdContactId = shipmentEntity.getFromContact().getIrdContactId();
        ClientProfile clientProfile = clientProfileBusiness
            .getClientProfile(carrierId, fromAccountId, fromIrdContactId);
        request.setClientProfile(clientProfile);
        return request;
    }

}