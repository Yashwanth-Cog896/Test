package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "SAP_ORDER_SHIPMENT", schema = "INVENTORY_MGT")
public class SapOrderShipmentEntity {

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid",
        strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    @Column(name = "SAP_ORDER_SHIPMENT_ID", nullable = false)
    private Long sapOrderShipmentId;

    @Column(name = "SAP_ORDER_NBR", nullable = true)
    private String sapOrderNumber;

    @Column(name = "SAP_SHIPMENT_NBR", nullable = true)
    private String shipmentNumber;

    @Column(name = "USERID", nullable = true)
    private String userId;

    @Column(name = "SOLD_TO_CUST_NBR", nullable = true)
    private String soldToCustomerNumber;

    @Column(name = "SHIP_TO_CUST_NBR", nullable = true)
    private String shipToCustomerNumber;

    @Column(name = "DELIVERY_BLOCK_CD", nullable = true)
    private String deliveryBlockCode;

    @Column(name = "END_USE_VNDR_NBR", nullable = true)
    private String endUseVendorNumber;

    @Column(name = "CARRIER_VNDR_NBR", nullable = true)
    private String carrierVendorNumber;

    @Column(name = "BROKER_CUST_NBR", nullable = true)
    private String brokerCustomerNumber;

    @Column(name = "SAP_PLANT_CD", nullable = true)
    private String sapPlantCode;

    @Column(name = "SAP_STORAGE_LOCATION_CD", nullable = true)
    private String sapStorageLocationCode;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "sapOrderShipment", orphanRemoval = true)
    private Collection<SapOrderItemEntity> orderItems;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREATED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity createdBy;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LAST_MODIFIED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity modifiedBy;

    @Column(name = "LAST_MODIFIED_DATE", nullable = false)
    private Date lastModifiedDate;

    @Column(name = "SAP_ERROR_MESSAGE_TXT", nullable = true)
    private String sapErrorMessageText;

    public Long getSapOrderShipmentId() {
        return sapOrderShipmentId;
    }

    public void setSapOrderShipmentId(Long id) {
        sapOrderShipmentId = id;
    }

    public String getSapOrderNumber() {
        return sapOrderNumber;
    }

    public void setSapOrderNumber(String orderNumber) {
        sapOrderNumber = orderNumber;
    }

    public String getShipmentNumber() {
        return shipmentNumber;
    }

    public void setShipmentNumber(String shipmentNum) {
        shipmentNumber = shipmentNum;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String id) {
        userId = id;
    }

    public String getSoldToCustomerNumber() {
        return soldToCustomerNumber;
    }

    public void setSoldToCustomerNumber(String customerNum) {
        soldToCustomerNumber = customerNum;
    }

    public String getShipToCustomerNumber() {
        return shipToCustomerNumber;
    }

    public void setShipToCustomerNumber(String customerNum) {
        shipToCustomerNumber = customerNum;
    }

    public String getDeliveryBlockCode() {
        return deliveryBlockCode;
    }

    public void setDeliveryBlockCode(String code) {
        deliveryBlockCode = code;
    }

    public String getEndUseVendorNumber() {
        return endUseVendorNumber;
    }

    public void setEndUseVendorNumber(String vendorNum) {
        endUseVendorNumber = vendorNum;
    }

    public String getCarrierVendorNumber() {
        return carrierVendorNumber;
    }

    public void setCarrierVendorNumber(String carrierNum) {
        carrierVendorNumber = carrierNum;
    }

    public String getBrokerCustomerNumber() {
        return brokerCustomerNumber;
    }

    public void setBrokerCustomerNumber(String vendorNum) {
        brokerCustomerNumber = vendorNum;
    }

    public String getSapPlantCode() {
        return sapPlantCode;
    }

    public void setSapPlantCode(String code) {
        sapPlantCode = code;
    }

    public String getSapStorageLocationCode() {
        return sapStorageLocationCode;
    }

    public void setSapStorageLocationCode(String code) {
        sapStorageLocationCode = code;
    }

    public SapOrderItemEntity findOrderItem(SapOrderItemKey itemKey) {
        SapOrderItemEntity match = null;
        for (SapOrderItemEntity entity : getOrderItems()) {
            if (entity.isKeyMatch(itemKey)) {
                match = entity;
                break;
            }
        }
        return match;
    }

    public String getSapErrorMessageText() {
        return sapErrorMessageText;
    }

    public void setSapErrorMessageText(String sapErrorMessageText) {
        this.sapErrorMessageText = sapErrorMessageText;
    }

    public void addOrderItem(SapOrderItemEntity entity) {
        orderItems.add(entity);
    }

    public void removeOrderItem(SapOrderItemEntity entity) {
        orderItems.remove(entity);
    }

    public Collection<SapOrderItemEntity> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(Collection<SapOrderItemEntity> items) {
        orderItems = items;
    }

    public MidasUserEntity getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(MidasUserEntity user) {
        createdBy = user;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date date) {
        creationDate = date;
    }

    public MidasUserEntity getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(MidasUserEntity user) {
        modifiedBy = user;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date date) {
        lastModifiedDate = date;
    }

}