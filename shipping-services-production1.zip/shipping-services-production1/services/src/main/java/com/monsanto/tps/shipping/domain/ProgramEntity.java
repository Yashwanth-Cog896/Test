package com.monsanto.tps.shipping.domain;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * User: PGADI
 */
@Entity
@Table(name="BR_PROG", schema="MIDAS")
public class ProgramEntity implements Serializable {
    @Id
    @Column(name="BR_PROG_ID", nullable=false)
    private Long programId;

    @Type(type = "true_false")
    @Column(name="REF_ACTIVE", nullable=false)
    private boolean refActive;

    @Column(name="NAME", nullable=false)
    private String name;

    @Type(type="true_false")
    @Column(name="MIDAS_PROGRAM", nullable=false)
    private boolean midasProgram;

    @Column(name="BR_PROG_REF_ID", nullable=false)
    private String refId;

    @ManyToOne
    @JoinColumn(name="CROP_ID", nullable=false)
    private CropEntity crop;

    @Column(name="ACCT_ID")
    private Long accountId;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "BR_PROG_PIPELINE_FUNCTION",
            schema = "MIDAS",
            joinColumns = {@JoinColumn(name = "BR_PROG_ID")},
            inverseJoinColumns = {@JoinColumn(name = "PIPELINE_FUNCTION_ID")}
    )
    private Collection<PipelineFunctionEntity> pipelineFunctions;

    public Long getProgramId() {
        return programId;
    }

    public void setProgramId(Long programId) {
        this.programId = programId;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isMidasProgram() {
        return midasProgram;
    }

    public void setMidasProgram(boolean midasProgram) {
        this.midasProgram = midasProgram;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Collection<PipelineFunctionEntity> getPipelineFunctions() {
        return pipelineFunctions;
    }

    public void setPipelineFunctions(Collection<PipelineFunctionEntity> pipelineFunctions) {
        this.pipelineFunctions = pipelineFunctions;
    }

    @Override
    public String toString() {
        return "ProgramEntity{" +
                "programId=" + programId +
                ", refActive=" + refActive +
                ", refId='" + refId + '\'' +
                ", accountId=" + accountId +
                ", name='" + name + '\'' +
                ", crop=" + crop +
                '}';
    }
}
