package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;

import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface RegulatedEventStatusService {

    Set<String> getUsdaValidatedEvents(Collection<String> eventStrings);
    List<RegulatedAPIResponse> getEPAValidatedEvents(Collection<String> eventStrings);
    List<RegulatedAPIResponse> getRegulatedAPIResponses(Collection<String> eventStrings);
}
