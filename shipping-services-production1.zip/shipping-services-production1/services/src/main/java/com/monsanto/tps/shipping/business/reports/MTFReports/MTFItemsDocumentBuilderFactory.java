package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

public interface MTFItemsDocumentBuilderFactory {

    MTFItemsDocumentBuilder getDocumentBuilder(ShipmentPackingListEntity shipmentPackingListEntity);

}
