package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.PermitAssociationDetails;

import java.util.Collection;
import java.util.Map;

/**
 * User: DCENGL
 */
public interface PermitBusiness {

    Collection<Permit> getPermitsByPackingList(ShipmentPackingListEntity packingList, Map<AgencyEnum, Collection<Event>> regulatedEventsByAgency);

    void associatePermits(ShipmentPackingListEntity packingList, Collection<Event> events);

    Collection<Event> loadAssociatedPermits(ShipmentPackingListEntity packingList);

    Collection<Event> getRegulatedEvents(ShipmentPackingListEntity packingList);

    void setPermitsOnEvents(ShipmentPackingListEntity packingList, Collection<Event> events);

    ContainerAgencyPermits loadAssociatedPermits(ShipmentPackingListEntity packingList, ShipmentContainerEntity container);

    ContainerAgencyPermits loadAssociatedPermitsForPackingListLabel(ShipmentPackingListEntity packingList);

    Collection<Permit> validatePermitForEvent(ShipmentPackingListEntity packingList, Event regulatedEvent);

    boolean isComplianceValid(Collection<Event> validEvents);

    Collection<Permit> findPermitsForEvent(String eventStack);

    PermitAssociationDetails findPermitAssociations(AgencyRequestEntity agencyRequestEntity);
}
