package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.regulatory.common.db.dao.EventValidationDao;
import com.monsanto.tps.regulatory.common.db.dao.UsdaEventValidationDao;
import com.monsanto.tps.regulatory.common.db.model.AgencyInfo;
import com.monsanto.tps.shipping.business.compliance.RegulatedMovementBusiness;
import com.monsanto.tps.shipping.dao.AgencyDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.RegulatedEventStatusService;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.UsdaStoredProcResult;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
@Service
public class UsdaBusinessImpl implements UsdaBusiness {

    private static final Log LOG = LogFactory.getLog(UsdaBusinessImpl.class);

    private static final Function<AgencyInfo, String> AGENCY_EVENT_NAME_FUNCTION = new Function<AgencyInfo, String>() {
        @Override
        public String apply(@Nullable AgencyInfo input) {
            return input.getEvent();
        }
    };

    @Autowired
    private RegulatedCountryBusiness regulatedCountryBusiness;
    @Autowired
    private EventHelper eventHelper;
    @Autowired
    private EventValidationDao eventValidationDao;
    @Autowired
    private UsdaEventValidationDao usdaEventValidationDao;
    @Autowired
    private AgencyRequestBusiness agencyRequestBusiness;
    @Autowired
    private AgencyDao agencyDao;
    @Autowired
    private RegulatedMovementBusiness regulatedMovementBusiness;
    @Autowired
    private EventErrorBusiness eventErrorBusiness;
    @Autowired
    private RegulatedEventStatusService regulatedEventStatusService;

    //FIXME add tests
    @Trace
    @Override
    public Collection<Event> getRegulatedEvents(Collection<Event> events, Set<String> allEventStrings) {
        Collection<Event> usdaRegulatedEvents = Lists.newArrayList();

        Set<String> usdaValidatedEventStrings = getUsdaValidatedEvents(allEventStrings);
        if (usdaValidatedEventStrings != null) {
            for (Event event : events) {
                boolean regulatedByMale = event.getMaleEventString() != null && usdaValidatedEventStrings.contains(event.getMaleEventString());

                if (usdaValidatedEventStrings.contains(event.getEventString()) || regulatedByMale) {
                    event.getRegulatingAgencies().add(AgencyEnum.USDA);

                    //if the passed in event is already regulatedByMale then we don't want to set it to false if the male isn't usda regulated
                    if (regulatedByMale) {
                        event.setRegulatedByMale(true);
                    }

                    usdaRegulatedEvents.add(event);
                }
            }
        }

        return usdaRegulatedEvents;
    }

    @Override
    public void addUsdaEventDetails(EventDetails eventDetails) {

        List<AgencyInfo> agencyInfoList = usdaEventValidationDao.validateEvents(Lists.newArrayList(eventDetails.getEventString()));

        Boolean usdaRegulated = false;

        if (!CollectionUtils.isEmpty(agencyInfoList)) {
            Collection<UsdaStoredProcResult> usdaStoredProcResults = Lists.newArrayList();

            for (AgencyInfo agencyInfo : agencyInfoList) {
                UsdaStoredProcResult usdaStoredProcResult = new UsdaStoredProcResult();
                usdaStoredProcResult.setInputEventString(agencyInfo.getEvent());
                usdaStoredProcResult.setMatchedEvent(agencyInfo.getMatchedEvents());

                if (eventDetails.getEventString().equals(agencyInfo.getEvent())) {
                    usdaRegulated = true;
                }

                usdaStoredProcResults.add(usdaStoredProcResult);
            }

            eventDetails.setUsdaStoredProcResults(usdaStoredProcResults);
        }

        eventDetails.setUsdaRegulated(usdaRegulated);
    }

    @Trace
    @Override
    public Collection<Permit> getPermits(String country, Long fromContactId, Long toContactId, Collection<Event> events, Long cropId) {
        Collection<Permit> usdaPermits = Lists.newArrayList();
        if (CollectionUtils.isEmpty(events) || !regulatedCountryBusiness.isCountryRegulatedByUsdaEpa(country)) {
            return usdaPermits;
        }

        List<AgencyInfo> agencyInfos = eventValidationDao.getPossibleAgencyRequests(eventHelper.getEventStrings(events));

        if (CollectionUtils.isEmpty(agencyInfos)) {
            return usdaPermits;
        }

        for (AgencyInfo agencyInfo : agencyInfos) {
            Permit permit = new Permit();
            permit.setId(agencyInfo.getAgencyRequestId());
            permit.setMonsantoId(agencyInfo.getMonsantoId());
            Set<String> eventStrings = Sets.newHashSet(agencyInfo.getEvent().split(","));
            permit.setEvent(eventHelper.getSortedEvent(eventStrings));
            permit.setPipelineFunction(agencyInfo.getFieldTrialResponsibilityCode());
            permit.setApprovalNumber(agencyInfo.getAgencyApprovalNumber());
            permit.setAgency(AgencyEnum.USDA);

            usdaPermits.add(permit);
        }

        agencyRequestBusiness.addAgencyRequestDataForPermits(usdaPermits, toContactId);

        eventErrorBusiness.addUsdaPermitErrors(usdaPermits, cropId, fromContactId, toContactId);

        return usdaPermits;
    }

    @Trace
    @Override
    public void loadAssociatedPermits(ShipmentPackingListEntity packingList, Collection<Event> events) {
        if (CollectionUtils.isEmpty(events)) {
            return;
        }

        Collection<Permit> permits = Lists.newArrayList();

        for (Event event : events) {
            if (!CollectionUtils.isEmpty(event.getRegulatedMovementIds())) {

                Collection<RegulatedInventoryMovementEntity> regulatedMovements = regulatedMovementBusiness.findByAgencyFromIds(event.getRegulatedMovementIds(), getAgency());

                for (RegulatedInventoryMovementEntity regulatedMovement : regulatedMovements) {
                    if (regulatedMovement.getMonsantoId() != null) {
                        Permit permit = new Permit();
                        permit.setMonsantoId(regulatedMovement.getMonsantoId());
                        permit.setAgencyRequestLocationId(regulatedMovement.getAgencyRequestLocationId());
                        permit.setAgency(AgencyEnum.USDA);
                        permit.setEvent(event.getEventString());

                        permits.add(permit);

                        event.addSelectedPermit(permit);

                        break;
                    }
                }
            }
        }

        if (!CollectionUtils.isEmpty(permits)) {
            agencyRequestBusiness.addAgencyRequestDataForPermits(permits, packingList.getToContactId());
        }
    }

    private Set<String> getUsdaValidatedEvents(Collection<String> eventStrings) {
        Set<String> events = regulatedEventStatusService.getUsdaValidatedEvents(eventStrings);
        return events;
    }

    private AgencyEntity getAgency() {
        return agencyDao.findByAbbr(AgencyEnum.USDA.getAbbr());
    }
}
