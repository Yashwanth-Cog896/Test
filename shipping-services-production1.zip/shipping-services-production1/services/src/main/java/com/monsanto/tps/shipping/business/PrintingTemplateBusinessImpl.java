package com.monsanto.tps.shipping.business;

import com.google.common.collect.Maps;
import com.monsanto.tps.labelprinting.common.LabelTemplate;
import com.monsanto.tps.labelprinting.common.TemplateData;
import com.monsanto.tps.labelprinting.common.TemplateListData;
import com.monsanto.tps.labelprinting.common.service.TemplateService;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class PrintingTemplateBusinessImpl implements PrintingTemplateBusiness {

    public static final String TEMPLATE_TYPE = "SHIPPING_WEB_CONTAINER_LABEL";
    public static final String TEMPLATES_NOT_AVAILABLE = "Label templates were not available for category name ";
    public static final String TEMPLATE_NOT_AVAILABLE = "Label template is not available for template name ";


    @Resource(name = "templateService")
    @SuppressWarnings("SpringJavaAutowiringInspection")
    private TemplateService templateService;

    @Override
    @Trace
    @Cacheable("METHOD_CACHE")
    public Map<String, LabelTemplate> getTemplateMap() {
        Map<String, LabelTemplate> templateMap = Maps.newHashMap();
        TemplateListData templateListData = templateService.getTemplatesByCategoryName(TEMPLATE_TYPE);
        if (!Boolean.TRUE.equals(templateListData.getSuccess())) {
            throw new ShippingWebException(TEMPLATES_NOT_AVAILABLE + TEMPLATE_TYPE);
        }
        for (LabelTemplate template : templateListData.getTemplateList()) {
            templateMap.put(template.getName(), template);
        }

        return templateMap;
    }

    @Override
    @Trace
    @Cacheable("METHOD_CACHE")
    public LabelTemplate getTemplateByName(String templateName) {
        TemplateData templateData = templateService.getTemplateByName(templateName);
        if (!Boolean.TRUE.equals(templateData.getSuccess())) {
            throw new ShippingWebException(TEMPLATE_NOT_AVAILABLE + templateName);
        }

        return templateData.getTemplate();
    }
}
