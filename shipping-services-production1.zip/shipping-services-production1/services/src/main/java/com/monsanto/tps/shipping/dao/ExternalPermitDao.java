package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.service.model.ExternalPermit;

public interface ExternalPermitDao {

    ExternalPermitEntity load(long externalPermitId);
    ExternalPermitEntity findByExternalPermit(ExternalPermit externalPermit);
    void save(ExternalPermitEntity externalPermitEntity);
    void delete(ExternalPermitEntity externalPermitEntity);
}
