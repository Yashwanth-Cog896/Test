package com.monsanto.tps.shipping.domain;

import java.io.ByteArrayOutputStream;

public class EupMasterLabel {
    private String agencyApprovalNumber;
    private ByteArrayOutputStream labelStream;

    public String getAgencyApprovalNumber() {
        return agencyApprovalNumber;
    }

    public void setAgencyApprovalNumber(String agencyApprovalNumber) {
        this.agencyApprovalNumber = agencyApprovalNumber;
    }

    public ByteArrayOutputStream getLabelStream() {
        return labelStream;
    }

    public void setLabelStream(ByteArrayOutputStream labelStream) {
        this.labelStream = labelStream;
    }
}
