package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.CarrierShipOptionBusiness;
import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;
import com.monsanto.tps.shipping.service.model.CarrierShipOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component("carrierShipOptionService")
public class CarrierShipOptionServiceImpl implements CarrierShipOptionService {

    @Autowired
    private CarrierShipOptionBusiness carrierShipOptionBusiness;

    @Override
    public CarrierShipOption findCarrierShipOption(Long carrierShipOptionId) {
        return getCarrierShipOption(carrierShipOptionBusiness.findCarrierShipOption(carrierShipOptionId));
    }

    @Override
    @Transactional
    public List<CarrierShipOption> findCarrierShipOptionsByCarrierId(Long carrierId) {
        List<CarrierShipOptionEntity> carrierShipOptionEntities = carrierShipOptionBusiness.findCarrierShipOptionByCarrierId(carrierId);
        List<CarrierShipOption> carrierShipOptions = new ArrayList<CarrierShipOption>();
        if (carrierShipOptionEntities != null) {
            for (CarrierShipOptionEntity carrierShipOptionEntity : carrierShipOptionEntities) {
                carrierShipOptions.add(getCarrierShipOption(carrierShipOptionEntity));
            }
        }
        return carrierShipOptions;
    }

    @Override
    public List<CarrierShipOption> findAllCarrierShipOptions() {
        List<CarrierShipOptionEntity> carrierShipOptionEntities = carrierShipOptionBusiness.findAllCarrierShipOptions();
        List<CarrierShipOption> carrierShipOptions = new ArrayList<CarrierShipOption>();
        if (carrierShipOptionEntities != null) {
            for (CarrierShipOptionEntity carrierShipOptionEntity : carrierShipOptionEntities) {
                carrierShipOptions.add(getCarrierShipOption(carrierShipOptionEntity));
            }
        }
        return carrierShipOptions;
    }

    private CarrierShipOption getCarrierShipOption(CarrierShipOptionEntity carrierShipOptionEntity) {
        CarrierShipOption carrierShipOption = new CarrierShipOption();
        carrierShipOption.setCarrierShipOptionId(carrierShipOptionEntity.getCarrierShipOptionId());
        carrierShipOption.setShipOptionId(carrierShipOptionEntity.getShipOptionId());
        carrierShipOption.setShipOptionTypeId(carrierShipOptionEntity.getShipOptionTypeEntity().getShipOptionTypeId());
        carrierShipOption.setShipOptionTypeName(carrierShipOptionEntity.getShipOptionTypeEntity().getName());
        carrierShipOption.setShipOption(carrierShipOptionEntity.getShipOption());
        Long carrierId = carrierShipOptionEntity.getCarrierEntity() == null ? null : carrierShipOptionEntity.getCarrierEntity().getCarrierId();
        carrierShipOption.setShipOptionRefId(carrierShipOptionEntity.getShipOptionRefId());
        carrierShipOption.setCarrierEntityId(carrierId);

        return carrierShipOption;
    }
}