package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.AgencyRequestLocation;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.State;

import java.util.Collection;

/**
 * User: pgadi
 */
public interface AgencyRequestBusiness {

    void addAgencyRequestDataForPermits(Collection<Permit> permits, long toContactId);

    AgencyRequestEntity getAgencyRequest(String approvalNumber);

    Collection<Long> getIrdContactIds(Collection<AgencyRequestLocation> agencyRequestLocations);

    Collection<State> findStatesCoveredByEUP(String agencyApprovalNumber);
}
