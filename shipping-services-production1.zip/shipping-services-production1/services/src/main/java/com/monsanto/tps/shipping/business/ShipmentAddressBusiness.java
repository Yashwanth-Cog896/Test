package com.monsanto.tps.shipping.business;

import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.domain.ShipmentAddressEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;

/**
 * User: DCENGL
 */
public interface ShipmentAddressBusiness {

    ShipmentAddressEntity buildShipmentAddress(Contact contact);
    ShipmentAddressEntity buildShipmentAddress(AbstractContact contact);
}
