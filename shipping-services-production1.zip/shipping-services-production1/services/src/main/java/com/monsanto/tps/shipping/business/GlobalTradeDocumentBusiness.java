package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.transfer.GlobalTradeDocument;

import java.util.List;

/**
 * User: pgadi
 */
public interface GlobalTradeDocumentBusiness {
    public List<GlobalTradeDocument> getGlobalTradeDocumentsList(Long sapOrderShipmentId);

    public byte[] getGlobalTradeDocumentPdf(Long sequenceNumber, String title);
}
