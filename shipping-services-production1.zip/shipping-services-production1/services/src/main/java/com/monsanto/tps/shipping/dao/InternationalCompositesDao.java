package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.service.model.CropDescription;
import com.monsanto.tps.shipping.service.model.InternationalCarrier;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.InternationalVendor;
import com.monsanto.tps.shipping.service.model.SapOrderItem;

import java.util.List;

public interface InternationalCompositesDao {

    InternationalStorageLocation getStorageLocation(String id);

    List<InternationalStorageLocation> getStorageLocations();

    List<InternationalStorageLocation> getStorageLocations(String countryCode);

    InternationalCustomer getCustomer(String id);

    List<InternationalCustomer> getCustomers();

    InternationalCustomer getBroker(String id);

    List<InternationalCustomer> getBrokers();

    List<InternationalVendor> getGtmContacts();

    List<CropDescription> getCropDescriptions();

    List<InternationalCarrier> getCarriers();

    String getMaterialNbrForOrderItem(SapOrderItem sapOrderItem, String cropSpecieCode);

    String getEndUseVendorNumberForResearch();
}
