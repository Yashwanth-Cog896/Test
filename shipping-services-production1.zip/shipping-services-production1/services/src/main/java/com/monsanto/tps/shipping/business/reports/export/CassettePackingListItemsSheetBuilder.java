package com.monsanto.tps.shipping.business.reports.export;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.CassetteContainerEntity;
import com.monsanto.tps.shipping.domain.CassetteEntity;
import com.monsanto.tps.shipping.domain.InventoryEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.SeedTrayCellEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;

/**
 * Created by DCENGL
 */
@Service
public class CassettePackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Item BID", "Box Barcode", "Plot BID", "Inventory BID", "Cell Number", "Event", "Permit", "Field", "Test Set", "Season"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        int currentRowIndex = 1;
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        Collection<Event> events = getPermits(packingList);
        for (ScannedContainerEntity scannedContainerEntity : contentContainerEntities) {
            CassetteContainerEntity cassetteContainer = (CassetteContainerEntity) scannedContainerEntity;
            CassetteEntity cassette = cassetteContainer.getCassette();

            boolean firstRow = true;

            List<SeedTrayCellEntity> seedTrayCells = cassette.getSeedTrayCells();
            Collections.sort(seedTrayCells, new Comparator<SeedTrayCellEntity>() {
                @Override
                public int compare(SeedTrayCellEntity o1, SeedTrayCellEntity o2) {
                    return o1.getCellNumber() - o2.getCellNumber();
                }
            });

            Collection<Event> containerEvents = getEventsForContainer(scannedContainerEntity.getContainerId(), events);

            for (SeedTrayCellEntity seedTrayCell : seedTrayCells) {
                PlotEntity plot = seedTrayCell.getPlot();
                InventoryEntity inventory = seedTrayCell.getInventory();
                String eventString = getEventString(seedTrayCell.getInventory());

                Event cellEvent = getEventForCell(eventString, containerEvents);

                Row row = sheet.createRow(currentRowIndex);

                appendCell(row, defaultCellStyle, firstRow ? scannedContainerEntity.getScanOrder() : null);
                appendCell(row, defaultCellStyle, firstRow ? cassette.getBarcode() : null);
                appendCell(row, defaultCellStyle, firstRow ? scannedContainerEntity.getStorageContainer().getBarcode() : null);
                appendCell(row, defaultCellStyle, plot != null ? plot.getBarcode() : null);
                appendCell(row, defaultCellStyle, inventory != null ? inventory.getBarcode() : null);
                appendCell(row, defaultCellStyle, seedTrayCell.getCellNumber());
                appendCell(row, defaultCellStyle, eventString);
                appendCell(row, defaultCellStyle, getPermitString(cellEvent));
                appendCell(row, defaultCellStyle, plot != null && plot.getField() != null ? plot.getField().getFieldName() : null);
                appendCell(row, defaultCellStyle, plot != null && plot.getRep() != null && plot.getRep().getTestSet() != null ?
                        plot.getRep().getTestSet().getTestSetName() : null);
                appendCell(row, defaultCellStyle, plot != null && plot.getField() != null && plot.getField().getSeason() != null ?
                        plot.getField().getSeason().getName() : null);

                firstRow = false;
                currentRowIndex++;
            }
        }
    }

    private Collection<Event> getEventsForContainer(Long containerId, Collection<Event> events) {
        Collection<Event> containerEvents = Lists.newArrayList();

        for (Event event : events) {
            if (!CollectionUtils.isEmpty(event.getContentContainerIds()) && event.getContentContainerIds().contains(containerId)) {
                containerEvents.add(event);
            }
        }

        return containerEvents;
    }

    private Event getEventForCell(String eventString, Collection<Event> containerEvents) {
        for (Event containerEvent : containerEvents) {
            if (eventString != null && eventString.equals(containerEvent.getEventString())) {
                return containerEvent;
            }
        }

        return null;
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.CASSETTE;
    }
}
