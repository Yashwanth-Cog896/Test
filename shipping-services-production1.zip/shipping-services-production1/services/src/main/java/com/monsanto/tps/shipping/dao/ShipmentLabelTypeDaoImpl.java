package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentLabelTypeEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * User: SDCHIL
 */
@Repository
public class ShipmentLabelTypeDaoImpl implements ShipmentLabelTypeDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public ShipmentLabelTypeEntity findByName(String name) {
        return (ShipmentLabelTypeEntity) sessionFactory.getCurrentSession()
                    .createQuery("from ShipmentLabelTypeEntity s where s.name = :name")
                    .setParameter("name", name)
                    .uniqueResult();
    }
}
