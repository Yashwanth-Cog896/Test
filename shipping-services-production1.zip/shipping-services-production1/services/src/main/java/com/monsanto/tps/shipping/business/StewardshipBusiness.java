package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface StewardshipBusiness {

    Collection<Event> getEvents(ShipmentPackingListEntity packingListEntity, Collection<Event> events, Collection<String> eventStrings);

    void addStewardedEventDetails(EventDetails eventDetails, String countryAbbr);
}
