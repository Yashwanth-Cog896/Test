package com.monsanto.tps.shipping.business.labels;

import com.google.common.base.Function;
import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.converter.CassetteContentConverter;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.OtherContentEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.TissuePlateEntity;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.util.SequentialNumbersLoader;
import com.monsanto.tps.shipping.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * User: pgadi
 */
@Component
public class LabelContentDataSetter {

    public static final int CONTENT_LIMIT = 17;
    public static final int NO_COMPLIANCE_CONTENT_LIMIT = 25;

    @Autowired
    private CassetteContentConverter cassetteContentConverter;

    private static final Function<ScannedContainerEntity, PlotEntity> PLOT_ENTITY_FUNCTION = new Function<ScannedContainerEntity, PlotEntity>() {
        @Override
        public PlotEntity apply(ScannedContainerEntity input) {
            ContentEntity content = input.getContent();
            if (content instanceof PlotEntity) {
                return (PlotEntity) content;
            }
            return null;
        }
    };

    private static final Comparator<ScannedContainerEntity> SCAN_ORDER_COMPARATOR = new Comparator<ScannedContainerEntity>() {
        @Override
        public int compare(ScannedContainerEntity input1, ScannedContainerEntity input2) {
            return input1.getScanOrder().compareTo(input2.getScanOrder());
        }
    };

    public void setContentsData(ContainerLabelDataSet data, List<? extends ScannedContainerEntity> scannedContainerEntities, ShipmentTypeEntity shipmentType, boolean complianceRequired) {
        Collections.sort(scannedContainerEntities, SCAN_ORDER_COMPARATOR);
        data.put(ContainerLabelConstants.CONTENT_HEADER, ContainerLabelConstants.getContentHeader(shipmentType.getName()));

        Collection<String> contentValuesToSet = getValuesByContentType(scannedContainerEntities, shipmentType);
        setLabelData(data, contentValuesToSet, complianceRequired);
    }

    private void setLabelData(ContainerLabelDataSet data, Collection<String> contentValuesToSet, boolean complianceRequired) {
        int contentLimit = complianceRequired ? CONTENT_LIMIT : NO_COMPLIANCE_CONTENT_LIMIT;
        int contentNumber = 1;
        Set<String> contentValues = new HashSet<String>();

        for (String contentValue : contentValuesToSet) {
            if (!contentValues.contains(contentValue) && StringUtils.hasText(contentValue)) {
                if (contentNumber == contentLimit) {
                    data.put(ContainerLabelConstants.CONTENT_DESC + String.valueOf(contentNumber - 1), ContainerLabelConstants.MORE_CONTENTS_INFO);
                    break;
                }

                data.put(ContainerLabelConstants.CONTENT_DESC + contentNumber, contentValue);
                contentNumber++;
                contentValues.add(contentValue);
            }
        }
    }

    private Collection<String> getValuesByContentType(List<? extends ScannedContainerEntity> scannedContainerEntities, ShipmentTypeEntity shipmentType) {
        Collection<String> values = Lists.newLinkedList();
        ContentType contentType = shipmentType.getContentType();
        if (ContentType.INVENTORY == contentType) {
            values = getValuesFromInventory(scannedContainerEntities);
        } else if (ContentType.TISSUE_PLATE == contentType) {
            values = getValuesFromTissue(scannedContainerEntities);
        } else if (ContentType.OTHER == contentType) {
            values = getValuesFromOther(scannedContainerEntities);
        } else if (ContentType.PLOT == contentType || ContentType.MIXED_INV_PLOT == contentType) {
            values = getPlotData(shipmentType.getShipmentTypeEnum(), Lists.transform(scannedContainerEntities, PLOT_ENTITY_FUNCTION));
        } else if (ContentType.CASSETTE == contentType) {
            values = getContentValues(scannedContainerEntities);
        } else if (ContentType.WHOLE_PLANTS == contentType) {
            values = getValuesFromWholePlants(scannedContainerEntities);
        } else if (ContentType.HD_TRAY == contentType) {
            values = getValuesFromHdTrays(scannedContainerEntities);
        }

        return values;
    }

    /**
     * Sort by scan order first. And then, collapse by plot numbers if in sequence
     */
    private List<String> getPlotData(ShipmentTypeEnum shipmentType, List<PlotEntity> plotEntities) {
        Multimap<String, Integer> stringToPlotNumberMap = getPlotStringToPlotNumbersMap(plotEntities, shipmentType);

        List<String> plotValues = Lists.newLinkedList();
        for (String key : stringToPlotNumberMap.keySet()) {

            Integer[] plotNumbersArray = {};
            Set<Integer> plotNumbersList = Sets.newHashSet(stringToPlotNumberMap.get(key));
            if(plotNumbersList.size() > 1){
                plotNumbersList.remove(null);
            }
            plotNumbersArray = plotNumbersList.toArray(plotNumbersArray);
            Arrays.sort(plotNumbersArray);

            List<String> plotNumbersSequence = SequentialNumbersLoader.getSequences(plotNumbersArray);

            for (String plotNumberSequence : plotNumbersSequence) {
                String contentValueString = TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(key, plotNumberSequence));
                plotValues.add(contentValueString);
            }
        }

        return plotValues;
    }

    private Collection<String> getContentValues(List<? extends ScannedContainerEntity> cassetteContainers) {
        Collection<String> contentValues = new LinkedHashSet<String>();
        Collection<PlotEntity> plots = getPlotsForCassettes(cassetteContainers);
        for (PlotEntity plot : plots) {
            String field = null == plot.getField() ? null : plot.getField().getFieldName();
            String set = null == plot.getTestSetEntry() ? null : plot.getTestSetEntry().getTestSet().getTestSetName();
            if (StringUtils.hasText(field) && StringUtils.hasText(set)) {
                contentValues.add(TextUtils.getDelimitedStringWithComma(Lists.newArrayList(field, set)));
            }
        }
        return contentValues;
    }

    private Collection<PlotEntity> getPlotsForCassettes(List<? extends ScannedContainerEntity> cassetteContainers) {
        Collection<PlotEntity> plots = new ArrayList<PlotEntity>();

        for (ScannedContainerEntity cassetteEntity : cassetteContainers) {
            plots.addAll(cassetteContentConverter.getPlotsFromCassette(cassetteEntity.getContent()));
        }

        return plots;
    }

    /**
     * Data is set in the order of headers
     */
    private Multimap<String, Integer> getPlotStringToPlotNumbersMap(List<PlotEntity> plotEntities, ShipmentTypeEnum shipmentTypeEnum) {
        Multimap<String, Integer> plotStringToPlotNumberMap = LinkedListMultimap.create();

        for (PlotEntity plotEntity : plotEntities) {
            if (plotEntity != null) {
                List<String> plotValues = Lists.newArrayList();

                if (shipmentTypeEnum.equals(ShipmentTypeEnum.HARVESTED_PLOT)) {
                    plotValues.add(getFieldName(plotEntity));
                }

                plotValues.add(null == plotEntity.getTestSetEntry() ? null : plotEntity.getTestSetEntry().getTestSet().getTestSetName());
                plotValues.add(null == plotEntity.getRep() || null == plotEntity.getRep().getField() ? null : plotEntity.getRep().getField().getFieldName());
                plotValues.add(null == plotEntity.getRep() ? null : String.valueOf(plotEntity.getRep().getRepNumber()));

                plotStringToPlotNumberMap.put(TextUtils.getDelimitedStringWithComma(plotValues), plotEntity.getPlotNumber());
            }
        }

        return plotStringToPlotNumberMap;
    }

    private String getFieldName(PlotEntity plotEntity) {
        return null == plotEntity.getField() ? null : plotEntity.getField().getFieldName();
    }

    private List<String> getValuesFromInventory(List<? extends ScannedContainerEntity> scannedContainerEntities) {
        List<String> inventoryValues = Lists.newLinkedList();

        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            Integer sourcePlotNumber = scannedContainerEntity.getContent().getGeneticMaterial().getSourcePlotNumber();
            if(sourcePlotNumber != null) {
                inventoryValues.add(String.valueOf(sourcePlotNumber));
            }
        }

        return inventoryValues;
    }

    private List<String> getValuesFromOther(List<? extends ScannedContainerEntity> scannedContainerEntities) {
        List<String> otherValues = Lists.newLinkedList();
        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            List<String> values = Lists.newArrayList();
            values.add(scannedContainerEntity.getContent().getBarcode());
            values.add(((OtherContainerEntity) scannedContainerEntity).getName());

            otherValues.add(TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(StringUtils.toStringArray(values))));
        }

        return otherValues;
    }

    private List<String> getValuesFromTissue(List<? extends ScannedContainerEntity> scannedContainerEntities) {
        List<String> tissueValues = Lists.newLinkedList();
        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            List<String> values = Lists.newArrayList();
            ContentEntity contentEntity = scannedContainerEntity.getContent();
            if(contentEntity instanceof OtherContentEntity) {
                values.add(contentEntity.getBarcode());
            } else {
                values.add(contentEntity.getBarcode());
                values.add(((TissuePlateEntity)contentEntity).getLimsId());
                String fieldName = null;
                if (((TissuePlateEntity)contentEntity).getPlot() != null) {
                    fieldName = getFieldName(((TissuePlateEntity)contentEntity).getPlot());
                }
                values.add(null == fieldName ? "" : String.valueOf(fieldName));
            }

            tissueValues.add(TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(StringUtils.toStringArray(values))));
        }

        return tissueValues;
    }

    private List<String> getValuesFromWholePlants(List<? extends ScannedContainerEntity> scannedContainerEntities) {
        List<String> wholePlantsValues = Lists.newLinkedList();
        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            List<String> values = Lists.newArrayList();
            values.add(scannedContainerEntity.getContent().getBarcode());
            wholePlantsValues.add(TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(StringUtils.toStringArray(values))));
        }

        return wholePlantsValues;
    }

    private List<String> getValuesFromHdTrays(List<? extends ScannedContainerEntity> scannedContainerEntities) {
        List<String> hdTrayValues = Lists.newLinkedList();
        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            List<String> values = Lists.newArrayList();
            values.add(scannedContainerEntity.getContent().getBarcode());
            hdTrayValues.add(TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(StringUtils.toStringArray(values))));
        }

        return hdTrayValues;
    }
}