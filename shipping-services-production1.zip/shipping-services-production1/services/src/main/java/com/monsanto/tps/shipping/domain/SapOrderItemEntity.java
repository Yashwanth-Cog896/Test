package com.monsanto.tps.shipping.domain;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "SAP_ORDER_ITEM", schema = "INVENTORY_MGT")
public class SapOrderItemEntity {

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid",
        strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    @Column(name = "SAP_ORDER_ITEM_ID", nullable = false)
    private Long sapOrderItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SAP_ORDER_SHIPMENT_ID")
    private SapOrderShipmentEntity sapOrderShipment;

    @Column(name = "SAP_ORDER_ITEM_NBR")
    private String sapOrderItemNumber;

    @Column(name = "SAP_MATERIAL_NBR")
    private String sapMaterialNbr;

    @Column(name = "SAP_COMMODITY_CODE_DESC_CD")
    private String sapCcdVal;

    @Column(name = "STORAGE_CONTAINER_BARCODE_NBR")
    private String storageContainerBarcode;

    @Column(name = "MATERIAL_ORIGIN_COUNTRY_CD")
    private String countryOfOrigin;

    @Column(name = "MATERIAL_ORIGIN_REGION_CD")
    private String regionOfOrigin;

    @Column(name = "EVENT_STACK_TXT")
    private String eventStack;

    @Column(name = "PHYTOSANITARY_TXT")
    private String phytoNumber;

    @Column(name = "IMPORT_PERMIT_NBR")
    private String importPermitNumber;

    @Column(name = "SEED_TREATMENT_TXT")
    private String seedTreatment;

    @Column(name = "REJECTION_REASON_CD")
    private String rejectionReasonCode;

    @Column(name = "LC_ERROR_MESSAGE_TXT")
    private String lcErrorMessage;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREATED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity createdBy;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LAST_MODIFIED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity modifiedBy;

    @Column(name = "LAST_MODIFIED_DATE", nullable = false)
    private Date lastModifiedDate;

    public SapOrderItemEntity() {
        super();
    }

    public SapOrderItemEntity(SapOrderItemKey key) {
        this();
        this.countryOfOrigin = key.getCountryOfOrigin();
        this.eventStack = key.getEventStack();
        this.storageContainerBarcode = key.getStorageContainerBarcode();
    }

    public Long getSapOrderItemId() {
        return sapOrderItemId;
    }

    public void setSapOrderItemId(Long id) {
        sapOrderItemId = id;
    }

    public String getSapOrderItemNumber() {
        return sapOrderItemNumber;
    }

    public void setSapOrderItemNumber(String itemNumber) {
        sapOrderItemNumber = itemNumber;
    }

    public String getStorageContainerBarcode() {
        return storageContainerBarcode;
    }

    public void setStorageContainerBarcode(String barcode) {
        storageContainerBarcode = barcode;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String country) {
        countryOfOrigin = country;
    }

    public String getEventStack() {
        return eventStack;
    }

    public void setEventStack(String stack) {
        eventStack = stack;
    }

    public String getPhytoNumber() {
        return phytoNumber;
    }

    public void setPhytoNumber(String phyto) {
        phytoNumber = phyto;
    }

    public String getImportPermitNumber() {
        return importPermitNumber;
    }

    public void setImportPermitNumber(String permitNumber) {
        importPermitNumber = permitNumber;
    }

    public String getSeedTreatment() {
        return seedTreatment;
    }

    public void setSeedTreatment(String treatment) {
        seedTreatment = treatment;
    }

    public String getRejectionReasonCode() {
        return rejectionReasonCode;
    }

    public void setRejectionReasonCode(String rejectionReasonCode) {
        this.rejectionReasonCode = rejectionReasonCode;
    }

    public String getLcErrorMessage() {
        return lcErrorMessage;
    }

    public void setLcErrorMessage(String message) {
        lcErrorMessage = message;
    }

    public MidasUserEntity getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(MidasUserEntity user) {
        createdBy = user;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date date) {
        creationDate = date;
    }

    public MidasUserEntity getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(MidasUserEntity user) {
        modifiedBy = user;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date date) {
        lastModifiedDate = date;
    }

    public String getSapMaterialNbr() {
        return sapMaterialNbr;
    }

    public void setSapMaterialNbr(String sapMaterialNbr) {
        this.sapMaterialNbr = sapMaterialNbr;
    }

    public SapOrderShipmentEntity getSapOrderShipment() {
        return sapOrderShipment;
    }

    public void setSapOrderShipment(SapOrderShipmentEntity sapOrderShipment) {
        this.sapOrderShipment = sapOrderShipment;
    }

    public String getSapCcdVal() {
        return sapCcdVal;
    }

    public void setSapCcdVal(String sapCcdVal) {
        this.sapCcdVal = sapCcdVal;
    }

    public String getRegionOfOrigin() {
        return regionOfOrigin;
    }

    public void setRegionOfOrigin(String regionOfOrigin) {
        this.regionOfOrigin = regionOfOrigin;
    }

    public boolean isKeyMatch(SapOrderItemKey itemKey) {
        boolean eventMatch;

        if(StringUtils.isEmpty(itemKey.getEventStack())) {
            eventMatch = null == getEventStack();
        } else {
            eventMatch = itemKey.getEventStack().equals(getEventStack());
        }

        return itemKey.getCountryOfOrigin().equals(getCountryOfOrigin())
            && itemKey.getStorageContainerBarcode().equals(getStorageContainerBarcode())
            && eventMatch;
    }

    public boolean equals(SapOrderItemEntity that) {
        Long thisId = getSapOrderItemId();
        Long thatId = that.getSapOrderItemId();
        return (thisId != null) ? thisId.equals(thatId) : (thatId == null);
    }

    public int hashCode() {
        Long id = getSapOrderItemId();
        return (id != null) ? id.hashCode() : 0;
    }
}