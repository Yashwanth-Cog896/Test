package com.monsanto.tps.shipping.domain;

import javax.persistence.*;

/**
 * User: DCENGL
 */
@Entity
@Table(name="SHIPPING_PREFERENCE", schema="INVENTORY_MGT")
public class ShippingPreferenceEntity {

    @Id
    @Column(name = "SHIPPING_PREFERENCE_ID")
    private long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SHIPPING_PREFERENCE_TYPE_ID")
    private ShippingPreferenceTypeEntity shippingPreferenceTypeEntity;

    @Column(name = "ACCT_ID")
    private Long accountId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SOURCE_SYSTEM_ID")
    private SourceSystem sourceSystem;

    @Column(name = "VALUE")
    private String value;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public ShippingPreferenceTypeEntity getShippingPreferenceTypeEntity() {
        return shippingPreferenceTypeEntity;
    }

    public void setShippingPreferenceTypeEntity(ShippingPreferenceTypeEntity shippingPreferenceTypeEntity) {
        this.shippingPreferenceTypeEntity = shippingPreferenceTypeEntity;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public SourceSystem getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(SourceSystem sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
