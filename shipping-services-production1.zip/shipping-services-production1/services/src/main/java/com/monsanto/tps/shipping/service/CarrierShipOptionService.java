package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.CarrierShipOption;

import javax.ws.rs.*;

import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by KERRA on 5/19/2014.
 */
@Path("/carrier-ship-option")
public interface CarrierShipOptionService {

    @Path("/{carrier-ship-option-id}")
    @Produces(APPLICATION_JSON)
    CarrierShipOption findCarrierShipOption(@PathParam("carrier-ship-option-id") Long carrierShipOptionId);

    @GET
    @Path("/{carrier-id}")
    @Produces(APPLICATION_JSON)
    List<CarrierShipOption> findCarrierShipOptionsByCarrierId(@PathParam("carrier-id") Long carrierId);

    @GET
    @Path("/")
    @Produces(APPLICATION_JSON)
    List<CarrierShipOption> findAllCarrierShipOptions();
}
