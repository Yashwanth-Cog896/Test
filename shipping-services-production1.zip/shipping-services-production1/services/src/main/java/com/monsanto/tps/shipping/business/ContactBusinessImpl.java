package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.party.service.ContactService;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.party.transfer.ContactTO;
import com.monsanto.tps.shipping.domain.ShipmentContactEntity;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * User: DCENGL
 */
@Service
public class ContactBusinessImpl implements ContactBusiness {

    @Resource(name = "partyContactService")
    private ContactService contactService;

    @Trace
    @Override
    public List<ShipmentContact> getContactsForAccount(Long accountId) {
        List<ShipmentContact> shipmentContacts = Lists.newArrayList();
        Collection<Contact> contacts = contactService.shippingContactsByAccountIds(Lists.newArrayList(accountId));
        for (Contact contact : contacts) {
            ShipmentContact shipmentContact = getShipmentContact(contact);
            shipmentContacts.add(shipmentContact);
        }
        return shipmentContacts;
    }

    @Trace
    @Override
    public ShipmentContact getContact(Long contactId) {
        Contact contact = contactService.shippingContactsByContactIds(Lists.newArrayList(contactId)).iterator().next();
        return getShipmentContact(contact);
    }

    @Trace
    @Override
    public Contact getPartyContact(Long contactId) {
        return contactService.shippingContactsByContactIds(Lists.newArrayList(contactId)).iterator().next();
    }

    @Trace
    @Override
    public ContactTO getPartyContactByContactId(Long contactId) {
        return contactService.contactsByContactIds(Lists.newArrayList(contactId)).iterator().next();
    }

    @Trace
    @Override
    public List<ContactTO> getPartyContactsByAccountId(Long accountId) {
        List<ContactTO> contactTOList = Lists.newArrayList();
        contactTOList.addAll(contactService.contactsByAccountIds(Lists.newArrayList(accountId)));
        return contactTOList;
    }

    @Trace
    @Override
    public Collection<ShipmentContact> getContacts(Collection<Long> contactIds) {
        List<ShipmentContact> shipmentContacts = Lists.newArrayList();
        Collection<Contact> contacts = contactService.shippingContactsByContactIds(contactIds);
        for (Contact contact : contacts) {
            ShipmentContact shipmentContact = getShipmentContact(contact);
            shipmentContacts.add(shipmentContact);
        }
        return shipmentContacts;
    }

    @Trace
    @Override
    public ShipmentContactEntity createShipmentContact(Contact contact) {
        ShipmentContactEntity contactEntity = new ShipmentContactEntity();

        contactEntity.setIrdContactId(contact.getContactId());
        contactEntity.setFirstName(contact.getFirstName());
        contactEntity.setLastName(contact.getLastName());
        contactEntity.setCreationDate(new Date());
        contactEntity.setPhoneNumber(contact.getPhoneNumber());
        contactEntity.setCompanyName(contact.getAccountName());
        contactEntity.setEmail(contact.getEmailAddress());
        return contactEntity;
    }

    @Override
    public ShipmentContactEntity createShipmentContact(Contact contact, String shipmAttn) {
        ShipmentContactEntity contactEntity = createShipmentContact(contact);
        contactEntity.setAttention(shipmAttn);
        return contactEntity;
    }

    private ShipmentContact getShipmentContact(Contact contact) {
        ShipmentContact shipmentContact = new ShipmentContact();
        shipmentContact.setId(contact.getContactId());
        shipmentContact.setName(contact.getFirstName() + " " + contact.getLastName());
        shipmentContact.setAccountId(contact.getAccountId());
        shipmentContact.setAddressLine1(contact.getAddressLine1());
        shipmentContact.setAddressLine2(contact.getAddressLine2());
        shipmentContact.setAddressLine3(contact.getAddressLine3());
        shipmentContact.setCity(contact.getCity());
        shipmentContact.setState(contact.getState());
        shipmentContact.setZip(contact.getZipCode());
        shipmentContact.setZipFour(contact.getZipCode4());
        shipmentContact.setCountry(contact.getCountry());
        shipmentContact.setIsoCountryCode(contact.getIsoCountryCode());
        shipmentContact.setPhoneNumber(contact.getPhoneNumber());
        return shipmentContact;
    }
}
