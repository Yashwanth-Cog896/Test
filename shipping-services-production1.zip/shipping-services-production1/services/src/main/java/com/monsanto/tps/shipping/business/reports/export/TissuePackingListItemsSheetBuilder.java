package com.monsanto.tps.shipping.business.reports.export;

import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.business.TissuePlateWellBusiness;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.TissuePlateWellEntity;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Set;

/**
 * Created by DCENGL
 */
@Service
public class TissuePackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Plate BID", "Box Barcode", "Plot BID", "Sample #", "Well #", "LIMS ID", "Project ID", "Field", "Set", "Plate Type"};

    @Autowired
    private TissuePlateWellBusiness tissuePlateWellBusiness;

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        int currentRowIndex = 1;

        Collection<TissuePlateWellEntity> tissuePlateWells = tissuePlateWellBusiness.getTissuePlateWells(packingList);

        Set<ScannedContainerEntity> processedScannedContainers = Sets.newHashSet();

        for (TissuePlateWellEntity tissuePlateWell : tissuePlateWells) {
            Row tissuePlateItemRow = sheet.createRow(currentRowIndex);
            ScannedContainerEntity scannedContainer = tissuePlateWell.getScannedContainer();

            appendCell(tissuePlateItemRow, defaultCellStyle, !processedScannedContainers.contains(scannedContainer) ? scannedContainer.getScanOrder() : null);
            appendCell(tissuePlateItemRow, defaultCellStyle, !processedScannedContainers.contains(scannedContainer) ? scannedContainer.getContent().getBarcode() : null);
            appendCell(tissuePlateItemRow, defaultCellStyle, !processedScannedContainers.contains(scannedContainer) ? scannedContainer.getStorageContainer().getBarcode() : null);
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getPlotBarcode());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getSampleNumber());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getWellNumber());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getLimsId());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getProjectName());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getFieldName());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getSetName());
            appendCell(tissuePlateItemRow, defaultCellStyle, tissuePlateWell.getPlateType());

            processedScannedContainers.add(scannedContainer);
            currentRowIndex++;
        }
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.TISSUE_PLATE;
    }
}
