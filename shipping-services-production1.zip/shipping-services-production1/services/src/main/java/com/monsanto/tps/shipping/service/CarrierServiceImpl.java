package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.CarrierBusiness;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.service.model.Carrier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component("carrierService")
public class CarrierServiceImpl implements CarrierService {

    @Autowired
    private CarrierBusiness carrierBusiness;

    @Override
    public Carrier findCarrier(Long carrierId) {
        return getCarrier(carrierBusiness.findCarrier(carrierId));
    }

    @Override
    @Transactional
    public List<Carrier> findCarriersByAccountId(Long accountId) {
        List<CarrierEntity> carrierEntities = carrierBusiness.findCarriersByAccountId(accountId);
        List<Carrier> carriers = new ArrayList<Carrier>();

        for (CarrierEntity carrierEntity : carrierEntities) {
            carriers.add(getCarrier(carrierEntity));
        }
        return carriers;
    }

    @Override
    @Transactional
    public List<Carrier> findAllCarriers(Boolean integrated) {
        List<CarrierEntity> carrierEntities;
        if (Boolean.FALSE.equals(integrated)) {
            carrierEntities = carrierBusiness.findNonIntegratedCarriers();
        } else {
            carrierEntities = carrierBusiness.findAllCarriers();
        }

        List<Carrier> carriers = new ArrayList<Carrier>();

        for (CarrierEntity carrierEntity : carrierEntities) {
            carriers.add(getCarrier(carrierEntity));
        }
        return carriers;
    }

    private Carrier getCarrier(CarrierEntity carrierEntity) {
        Carrier carrier = new Carrier();
        carrier.setCarrierId(carrierEntity.getCarrierId());
        if (carrierEntity.getName().startsWith("Other - ")) {
            carrier.setName(carrierEntity.getName().replaceFirst("Other - ", ""));
        } else {
            carrier.setName(carrierEntity.getName());
        }
        carrier.setSupportIntegratedShipping(carrierEntity.isSupportIntegratedShipping());
        carrier.setWebsiteUrl(carrierEntity.getWebsiteUrl());
        return carrier;
    }
}