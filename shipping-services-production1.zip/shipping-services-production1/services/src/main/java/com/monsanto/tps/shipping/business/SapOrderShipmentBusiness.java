package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.service.model.SapOrderShipment;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;

import java.util.List;

public interface SapOrderShipmentBusiness {

    void saveSapOrderShipment(SapOrderShipmentEntity sapOrderShipmentEntity);

    List<SapOrderShipmentEntity> getAllSapOrderShipments();

    SapOrderShipmentEntity findBySapOrderNumber(String orderNumber);

    String editSapOrderShipmentStatus(SapOrderShipment sapOrderShipment);

    SapOrderShipmentEntity createSapOrderShipment(ShipmentPackingList shipmentPackingList,
                                                  MidasUserEntity midasUserEntity);

    String editSapOrderShipmentLcStatus(SapOrderShipment sapOrderShipment);

    SapOrderShipmentEntity getSapOrderShipmentById(Long orderShipmentId);

    void sendCreateOrder(SapOrderShipment orderShipment);

    void sendUpdateOrder(SapOrderShipment orderShipment, boolean validateWeights);

    void requestLcApproval(SapOrderShipment orderShipment);

    SapOrderShipmentEntity saveOrderShipment(SapOrderShipment orderShipment);

    SapOrderShipment createSapDelivery(SapOrderShipment sapOrderShipment, SapOrderShipmentEntity entity);
}
