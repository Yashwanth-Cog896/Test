package com.monsanto.tps.shipping.dao;

public interface BarcodeGeneratorDao {

    public String generateNewShipmentBarcode();

    public String generateNewStorageContainerBarcode();

}
