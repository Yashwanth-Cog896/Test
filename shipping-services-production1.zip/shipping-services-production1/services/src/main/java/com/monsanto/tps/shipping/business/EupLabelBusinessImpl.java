package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.EupEventWeight;
import com.monsanto.tps.shipping.domain.PackingListEupMasterLabels;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;

@Service
public class EupLabelBusinessImpl implements EupLabelBusiness {

    @Resource
    private EupEventWeightLabelBusiness eupEventWeightLabelBusiness;
    @Resource
    private EupMasterLabelDocumentCollaborator eupMasterLabelDocumentCollaborator;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Override
    @Trace
    @Transactional
    public PackingListEupMasterLabels getEupMasterLabels(Long packingListId) throws ShippingWebException {
        ShipmentPackingListEntity shipmentPackingListEntity = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        PackingListEupMasterLabels packingListEupMasterLabels = new PackingListEupMasterLabels();
        packingListEupMasterLabels.setBarcode(shipmentPackingListEntity.getBarcode());

        Collection<EupEventWeight> eupEventWeights = eupEventWeightLabelBusiness.getEupEventWeightSummary(shipmentPackingListEntity);
        packingListEupMasterLabels.setEupMasterLabels(eupMasterLabelDocumentCollaborator.fetchEupMasterLabels(eupEventWeights));

        return packingListEupMasterLabels;
    }
}
