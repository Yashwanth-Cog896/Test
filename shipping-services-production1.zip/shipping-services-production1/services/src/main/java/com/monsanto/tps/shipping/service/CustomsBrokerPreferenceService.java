package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.CustomsBrokerPreference;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: DCENGL
 */
@Path("/broker-preference")
public interface CustomsBrokerPreferenceService {

    @GET
    @Produces(APPLICATION_JSON)
    public Collection<CustomsBrokerPreference> getBrokerPreferences();

    @PUT
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/{customs-broker-preference-id}")
    public CustomsBrokerPreference edit(CustomsBrokerPreference customsBrokerPreference);

    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    public CustomsBrokerPreference create(CustomsBrokerPreference customsBrokerPreference);

}
