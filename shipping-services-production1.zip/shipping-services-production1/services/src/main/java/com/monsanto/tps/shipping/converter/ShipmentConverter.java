package com.monsanto.tps.shipping.converter;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShippingStatus;
import com.monsanto.tps.shipping.service.model.Carrier;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.Shipment;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Component
public class ShipmentConverter {

    @Autowired
    private ContactConverter contactConverter;
    @Autowired
    private PackingListContainerConversion packingListContainerConversion;

    public List<Shipment> buildShipments(List<ShipmentEntity> shipmentEntities) {
        List<Shipment> shipments = new ArrayList<Shipment>();
        for (ShipmentEntity shipmentEntity : shipmentEntities) {
            shipments.add(buildShipment(shipmentEntity));
        }
        return shipments;
    }

    public Shipment buildShipment(ShipmentEntity shipmentEntity) {
        Shipment shipment = new Shipment();
        shipment.setId(shipmentEntity.getShipmentId());
        shipment.setBarcode(shipmentEntity.getShipmentBarcode());
        shipment.setDescription(shipmentEntity.getComments());
        shipment.setStatus(getStatus(shipmentEntity));
        shipment.setCarrier(getCarrier(shipmentEntity));
        shipment.setTrackingNumber(shipmentEntity.getTrackingNumber());
        shipment.setShipDate(shipmentEntity.getShipDate());
        shipment.setShipFromContact(contactConverter.setContactDetails(shipmentEntity.getFromAddress(), shipmentEntity.getFromContact()));
        shipment.setShipToContact(contactConverter.setContactDetails(shipmentEntity.getToAddress(), shipmentEntity.getToContact()));
        shipment.setPackingListContainers(getPackingListContainers(shipmentEntity));
        shipment.setToAccountId(shipmentEntity.getToAccountId());
        shipment.setShipmentTypeId(shipmentEntity.getShipmentType().getShipmentTypeId());
        setPackingListDetails(shipment, shipmentEntity);
        return shipment;
    }

    private List<PackingListContainer> getPackingListContainers(ShipmentEntity shipmentEntity) {
        List<PackingListContainer> packingListContainers = new ArrayList<PackingListContainer>();
        for (ShipmentContainerEntity shipmentContainerEntity : shipmentEntity.getShipmentContainers()) {
            packingListContainers.add(packingListContainerConversion.toBaseDto().apply(shipmentContainerEntity));
        }
        return packingListContainers;
    }

    private void setPackingListDetails(Shipment shipment, ShipmentEntity shipmentEntity) {
        ShipmentContainerEntity shipmentContainerEntity = Iterables.get(shipmentEntity.getShipmentContainers(), 0);
        ShipmentPackingListEntity shipmentPackingList = shipmentContainerEntity.getShipmentPackingList();
        shipment.setPackingListId(shipmentPackingList.getShipmentPackingListId());
        shipment.setInternational(shipmentPackingList.isInternational());
        if(shipmentPackingList.isInternational()) {
            shipment.setSapOrderShipmentId(shipmentPackingList.getSapOrderShipment().getSapOrderShipmentId());
        }
        shipment.setRegulatedStatus(new RegulatedStatus(shipmentPackingList.getRegulatedStatusText()));
        shipment.setHasExternalPermits(shipmentPackingList.hasExternalPermits());
        shipment.setShipToAttn(shipmentPackingList.getShipToAttn());
    }

    private String getStatus(ShipmentEntity shipment) {
        String currentShipmentStatus = shipment.getStatus().getName();
        String acknowledgedMessage = checkIfAcknowledged(currentShipmentStatus, shipment.getShipmentContainers());
        return StringUtils.isEmpty(acknowledgedMessage) ? currentShipmentStatus : acknowledgedMessage;
    }

    private String checkIfAcknowledged(String currentStatus, Collection<ShipmentContainerEntity> shipmentContainers) {
        String updatedMessage = "";

        if (ShippingStatus.IN_PROGRESS_SHIPMENTS_STATUS.contains(currentStatus)) {
            int acknowledgedCount = getAcknowledgedContainerCount(shipmentContainers);
            if (acknowledgedCount > 0) {
                updatedMessage = ShippingStatus.ACKNOWLEDGED + " " + acknowledgedCount + "/" + shipmentContainers.size();
            }
        }

        return updatedMessage;
    }

    private int getAcknowledgedContainerCount(Collection<ShipmentContainerEntity> shipmentContainers) {
        return Collections2.filter(shipmentContainers, new Predicate<ShipmentContainerEntity>() {
            @Override
            public boolean apply(ShipmentContainerEntity shipmentContainer) {
                return shipmentContainer.getStatus() != null && shipmentContainer.getStatus().getName().equals(ShippingStatus.ACKNOWLEDGED);
            }
        }).size();
    }

    private Carrier getCarrier(ShipmentEntity shipmentEntity) {
        Carrier carrier = new Carrier();
        final CarrierEntity carrierEntity = shipmentEntity.getCarrier();
        if (carrierEntity != null) {
            carrier.setName(carrierEntity.getName());
            carrier.setTrackingUrl(getTrackingUrl(shipmentEntity));
            carrier.setSupportIntegratedShipping(carrierEntity.isSupportIntegratedShipping());
        }
        return carrier;
    }

    private String getTrackingUrl(ShipmentEntity shipmentEntity) {
        String trackingUrl = null;
        if(StringUtils.isNotEmpty(shipmentEntity.getTrackingNumber()) && StringUtils.isNotEmpty(shipmentEntity.getCarrier().getTrackingUrl())){
            trackingUrl = shipmentEntity.getCarrier().getTrackingUrl() + shipmentEntity.getTrackingNumber();
        }
        return trackingUrl;
    }
}
