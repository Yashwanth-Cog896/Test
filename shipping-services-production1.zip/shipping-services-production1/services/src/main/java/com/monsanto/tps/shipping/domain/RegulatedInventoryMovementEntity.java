package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "REGULATED_INV_MOVEMENT", schema = "MIDAS")
public class RegulatedInventoryMovementEntity {

    @Id
    @Column(name = "REGULATED_INV_MOVEMENT_ID", nullable = false)
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.shipping.dao.primarykey.HibernatePrimaryKeyGenerator")
    private Long regulatedInvMovementId;

    @ManyToOne
    @JoinColumn(name = "INVENTORY_ID")
    private InventoryEntity inventory;

    @Column(name = "IS_HARVESTED_IND", nullable = false)
    @Type(type = "true_false")
    private Boolean harvested;

    @ManyToOne
    @JoinColumn(name = "SCANNED_CONTAINER_ID")
    private ScannedContainerEntity scannedContainer;

    @Column(name = "EVENT_NAME_STACK_TXT")
    private String eventString;

    @Column(name = "MONSANTO_ID", nullable = true)
    private String monsantoId;

    @Column(name = "AGENCY_REQUEST_LOCATION_ID", nullable = true)
    private Long agencyRequestLocationId;

    @ManyToOne(fetch = FetchType.LAZY, cascade = {})
    @JoinColumn(name = "AGENCY_ID", referencedColumnName = "AGENCY_ID")
    private AgencyEntity agency;

    @Column(name = "IS_USER_OVERRIDEN", nullable = false)
    @Type(type = "true_false")
    private Boolean userOverridden;

    public RegulatedInventoryMovementEntity() {
    }

    public RegulatedInventoryMovementEntity(Long regulatedInvMovementId) {
        this.regulatedInvMovementId = regulatedInvMovementId;
    }

    public Long getRegulatedInvMovementId() {
        return regulatedInvMovementId;
    }

    public void setRegulatedInvMovementId(Long regulatedInvMovementId) {
        this.regulatedInvMovementId = regulatedInvMovementId;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public Boolean getHarvested() {
        return harvested;
    }

    public void setHarvested(Boolean harvested) {
        this.harvested = harvested;
    }

    public ScannedContainerEntity getScannedContainer() {
        return scannedContainer;
    }

    public void setScannedContainer(ScannedContainerEntity scannedContainer) {
        this.scannedContainer = scannedContainer;
    }

    public String getEventString() {
        return eventString;
    }

    public void setEventString(String eventString) {
        this.eventString = eventString;
    }

    public String getMonsantoId() {
        return monsantoId;
    }

    public void setMonsantoId(String monsantoId) {
        this.monsantoId = monsantoId;
    }

    public Long getAgencyRequestLocationId() {
        return agencyRequestLocationId;
    }

    public void setAgencyRequestLocationId(Long agencyRequestLocationId) {
        this.agencyRequestLocationId = agencyRequestLocationId;
    }

    public Boolean getUserOverridden() {
        return userOverridden;
    }

    public void setUserOverridden(Boolean userOverridden) {
        this.userOverridden = userOverridden;
    }

    public AgencyEntity getAgency() {
        return agency;
    }

    public void setAgency(AgencyEntity agency) {
        this.agency = agency;
    }

    public void setContent(ContentEntity content) {
        setInventory((InventoryEntity) content);
    }

    public Long getId() {
        return getRegulatedInvMovementId();
    }

    public void setContainer(ScannedContainerEntity container) {
        if (container instanceof ScannedContainerEntity) {
            setScannedContainer(container);
            if (container.getContent() != null && container.getContent().getInventory() != null) {
                setInventory(container.getContent().getInventory());
            }
        }
    }

    public ScannedContainerEntity getContainer() {
        return getScannedContainer();
    }

    public ContentEntity getContent() {
        return getInventory();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (!(o instanceof RegulatedInventoryMovementEntity)) {return false;}

        RegulatedInventoryMovementEntity that = (RegulatedInventoryMovementEntity) o;

        return !(regulatedInvMovementId != null ? !regulatedInvMovementId.equals(that.regulatedInvMovementId) : that.regulatedInvMovementId != null);

    }

    @Override
    public int hashCode() {
        return regulatedInvMovementId != null ? regulatedInvMovementId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RegulatedInventoryMovementEntity{" +
                "regulatedInvMovementId=" + regulatedInvMovementId +
                ", inventory=" + inventory +
                ", scannedContainer=" + scannedContainer +
                ", eventString='" + eventString + '\'' +
                '}';
    }
}
