package com.monsanto.tps.shipping.business;

import com.monsanto.tps.labelprinting.common.LabelTemplate;

import java.util.Map;

public interface PrintingTemplateBusiness {
    Map<String, LabelTemplate> getTemplateMap();

    LabelTemplate getTemplateByName(String templateName);
}
