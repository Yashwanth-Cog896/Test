package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;

import java.util.Collection;
import java.util.Map;

/**
 * User: DCENGL
 */
public interface RegulatedEventBusiness {

    Map<AgencyEnum, Collection<Event>> getRegulatedEvents(ShipmentPackingListEntity shipmentPackingList);

    Map<AgencyEnum, Collection<Event>> createRegulatedMovements(ShipmentPackingListEntity shipmentPackingList);

    Collection<Event> getRolledUpRegulatedEvents(Map<AgencyEnum, Collection<Event>> eventsByAgency);

    Map<AgencyEnum, Collection<Event>> getRegulatedEvents(ShipmentPackingListEntity shipmentPackingList, Collection<? extends ScannedContainerEntity> items);

}
