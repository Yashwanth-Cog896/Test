package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

/**
 * User: DCENGL
 */
public interface CropBusiness {

    CropEntity getCropByPackingList(ShipmentPackingListEntity shipmentPackingListEntity);

    CropEntity getCropEntityByPackingListWithContainers(ShipmentPackingListEntity shipmentPackingListEntity);
}
