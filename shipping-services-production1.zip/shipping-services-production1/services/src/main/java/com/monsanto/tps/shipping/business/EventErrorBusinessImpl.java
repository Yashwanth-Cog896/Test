package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.dao.IrdContactXrefDao;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.IrdContactXref;
import com.monsanto.tps.shipping.domain.PipelineFunctionEntity;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.service.model.AgencyRequestResponse;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventError;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.AgencyRequestStatusCodeEnum;
import com.monsanto.tps.shipping.util.EventErrorConstants;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
@Service
public class EventErrorBusinessImpl implements EventErrorBusiness {

    public static final String UNITED_STATES = "UNITED STATES";

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private IrdContactXrefDao irdContactXrefDao;

    @Autowired
    private ContactBusiness contactBusiness;

    @Autowired
    private ProgramBusiness programBusiness;

    @Autowired
    private ShippingGeoCodeBusiness shippingGeoCodeBusiness;

    @Trace
    @Override
    public boolean rollupPermitErrors(Collection<Event> events) {
        boolean errorPresent = false;
        for (Event event : events) {
            processAgencyErrors(AgencyEnum.USDA, event, EventErrorConstants.USDA_NO_PERMITS_FOUND);
            processAgencyErrors(AgencyEnum.EPA, event, EventErrorConstants.EPA_NO_PERMITS_FOUND);
            if (!event.getEventErrors().isEmpty()) {
                errorPresent = true;
            }
        }
        return errorPresent;
    }

    private void processAgencyErrors(AgencyEnum agencyEnum, Event event, EventError noPermitsError) {
        if (event.getRegulatingAgencies().contains(agencyEnum)) {
            Collection<Permit> agencyPermits = getPermitsByAgency(agencyEnum, event.getPermits());

            if (CollectionUtils.isEmpty(agencyPermits)) {
                event.getEventErrors().add(noPermitsError);
            } else {
                Collection<EventError> eventErrors = Sets.newHashSet();

                int numberOfPermitsWithError = 0;
                for (Permit agencyPermit : agencyPermits) {
                    if (!CollectionUtils.isEmpty(agencyPermit.getErrors())) {
                        if(agencyEnum.equals(AgencyEnum.USDA) && agencyPermit.getErrors().size()==1 && agencyPermit.getErrors().iterator().next().equals(EventErrorConstants.USDA_OUTSIDE_PIPELINE_FUNCTION)){
                            event.setOutsidePipelineFunction(true);
                        }
                        eventErrors.addAll(agencyPermit.getErrors());

                        event.getPermits().remove(agencyPermit);
                        numberOfPermitsWithError++;
                    }
                }

                if (numberOfPermitsWithError == agencyPermits.size()) {
                    event.getEventErrors().addAll(eventErrors);
                }
            }
        }
    }

    private Collection<Permit> getPermitsByAgency(AgencyEnum agencyEnum, Collection<Permit> permits) {
        Collection<Permit> agencyPermits = Lists.newArrayList();

        if (CollectionUtils.isEmpty(permits)) {
            return agencyPermits;
        }

        for (Permit permit : permits) {
            if (agencyEnum == permit.getAgency()) {
                agencyPermits.add(permit);
            }
        }

        return agencyPermits;
    }


    @Trace
    @Override
    public void addUsdaPermitErrors(Collection<Permit> permits, long cropId, long fromContactId, long toContactId) {
        Date now = new Date();
        Collection<String> validPipelineFunctions = getPipelineFunctions(toContactId, fromContactId);
        List<Long> fcmFromContactIds = getAllFCMContacts(fromContactId);
        List<Long> fcmToContactIds = getAllFCMContacts(toContactId);

        boolean validatePermitsByAddress = false;
        List<Long> arIdsByShipFromAddress = null;
        List<Long> arIdsByShipToAddress = null;

        ShipmentContact shipToContact = contactBusiness.getContact(toContactId);
        if (UNITED_STATES.equalsIgnoreCase(shipToContact.getCountry())) {
            AgencyRequestResponse agencyRequestResponse = getAgencyRequestResponseByContactIds(fromContactId, toContactId);
            validatePermitsByAddress = agencyRequestResponse.isValidateByAddress();
            if (validatePermitsByAddress) {
                arIdsByShipFromAddress = agencyRequestResponse.getAgencyRequestIdsByContactIds().get(fromContactId);
                arIdsByShipToAddress = agencyRequestResponse.getAgencyRequestIdsByContactIds().get(toContactId);
            }
        }

        for (Permit permit : permits) {
            checkCrop(permit, cropId);
            checkStatus(permit);
            checkAgency(permit);
            checkExpirationDate(permit, now);
            checkEffectiveDate(permit, now);
            //checkPipelineFunction(permit, validPipelineFunctions);
            if (validatePermitsByAddress) {
                checkIfValidForShipFromAddress(arIdsByShipFromAddress, permit);
                checkIfValidForShipToAddress(arIdsByShipToAddress, permit);
            } else {
                checkOrigin(permit, fcmFromContactIds);
                checkDestination(permit, fcmToContactIds);
            }
        }
    }

    private void checkCrop(Permit permit, long cropId) {
        if (cropId != permit.getCropId()) {
            permit.addError(EventErrorConstants.USDA_WRONG_CROP);
        }
    }

    private void checkStatus(Permit permit) {
        if (AgencyRequestStatusCodeEnum.APPROVED != permit.getStatus()) {
            permit.addError(EventErrorConstants.USDA_NOT_APPROVED);
        }
    }

    private void checkAgency(Permit permit) {
        if (AgencyEnum.USDA != permit.getAgency()) {
            permit.addError(EventErrorConstants.USDA_WRONG_AGENCY);
        }
    }

    private void checkExpirationDate(Permit permit, Date now) {
        if (null != permit.getExpirationDate() && permit.getExpirationDate().before(now)) {
            permit.addError(EventErrorConstants.USDA_EXPIRED);
        }
    }

    private void checkEffectiveDate(Permit permit, Date now) {
        if (permit.getEffectiveDate() == null) {
            permit.addError(EventErrorConstants.USDA_NO_EFFECTIVE_DATE);
        } else if (permit.getEffectiveDate().after(now)) {
            permit.addError(EventErrorConstants.USDA_NOT_ACTIVE_YET);
        }
    }

    private void checkOrigin(Permit permit, List<Long> fcmFromContactIds) {
        if (CollectionUtils.isEmpty(permit.getOriginContactIds()) || !CollectionUtils.containsAny(permit.getOriginContactIds(), fcmFromContactIds)) {
            permit.addError(EventErrorConstants.USDA_ORIGIN_NOT_APPROVED);
        }
    }

    private void checkDestination(Permit permit, List<Long> fcmToContactIds) {
        if (CollectionUtils.isEmpty(permit.getDestinationContactIds()) || !CollectionUtils.containsAny(permit.getDestinationContactIds(), fcmToContactIds)) {
            permit.addError(EventErrorConstants.USDA_DESTINATION_NOT_APPROVED);
        }
    }

    private void checkPipelineFunction(Permit permit, Collection<String> validPipelineFunctions) {
        if (!validPipelineFunctions.contains(permit.getPipelineFunction())) {
            permit.addError(EventErrorConstants.USDA_OUTSIDE_PIPELINE_FUNCTION);
        }
    }

    private Collection<String> getPipelineFunctions(long toContactId, long fromContactId) {
        Set<String> validPipelineFunctions = Sets.newHashSet(getPipelineFunctions(toContactId));
        validPipelineFunctions.addAll(Sets.newHashSet(getPipelineFunctions(fromContactId)));
        return validPipelineFunctions;
    }

    private Collection<String> getPipelineFunctions(long contactId) {
        ShipmentContact contact = contactBusiness.getContact(contactId);
        ProgramEntity program = programBusiness.getProgramByAccount(contact.getAccountId());
        sessionFactory.getCurrentSession().refresh(program);
        Collection<String> pipelineFunctionNames = new HashSet<String>();
        for (PipelineFunctionEntity pipelineFunction : program.getPipelineFunctions()) {
            pipelineFunctionNames.add(pipelineFunction.getRefId());
        }
        return pipelineFunctionNames;
    }

    private List<Long> getAllFCMContacts(long contactId) {
        List<Long> contactXref = Lists.newArrayList();
        for (IrdContactXref irdContactXref : irdContactXrefDao.findContactsXrefs(contactId)) {
            if (irdContactXref.getIrdContactId() == contactId) {
                contactXref.add(irdContactXref.getFcmContactId());
            }
        }
        return contactXref;
    }

    private void checkIfValidForShipToAddress(List<Long> arIdsByShipToAddress, Permit permit) {
        if(!arIdsByShipToAddress.contains(permit.getId())){
            permit.addError(EventErrorConstants.USDA_NO_AR_FOR_SHIP_TO);
        }
    }

    private void checkIfValidForShipFromAddress(List<Long> arIdsByShipFromAddress, Permit permit) {
        if(!arIdsByShipFromAddress.contains(permit.getId())){
            permit.addError(EventErrorConstants.USDA_NO_AR_FOR_SHIP_FROM);
        }
    }

    private AgencyRequestResponse getAgencyRequestResponseByContactIds(Long fromContactId, Long toContactId) {
        return shippingGeoCodeBusiness.getAgencyRequestResponseByContactIds(fromContactId, toContactId);
    }

}
