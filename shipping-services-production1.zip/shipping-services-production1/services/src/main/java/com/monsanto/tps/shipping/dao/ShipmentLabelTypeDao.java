package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentLabelTypeEntity;

/**
 * User: SDCHIL
 */
public interface ShipmentLabelTypeDao {

    ShipmentLabelTypeEntity findByName(String name);
}
