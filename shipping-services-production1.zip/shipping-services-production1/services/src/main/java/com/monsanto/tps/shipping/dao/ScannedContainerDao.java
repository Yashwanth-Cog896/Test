package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface ScannedContainerDao {

    ScannedContainerEntity load(Long contentContainerId, ContentType contentType);

    void delete(ScannedContainerEntity contentContainerEntity);

    void save(ScannedContainerEntity contentContainerEntity);

    void updateUom(Collection<Long> storageContainerIds, long uomId);

    void updateWeight(Collection<Long> scannedContainerIds, double amount, long uomId);

    void updateName(Collection<Long> scannedContainerIds, String name);
    
    void updateComment(Collection<Long> scannedContainerIds, String name);
    
    void updateSeedCount(Collection<Long> scannedContainerIds, long amount);

    void updateSeedCountWeightAndUOM(Collection<Long> scannedContainerIds, long amount, Double weight, long uomId);

    void updateVerifyTimeStamp(Long scannedContainerId, Long storageContainerId, Boolean outGoing);

    void updateVerifyContentTimeStamp(Collection<Long> scannedContainerIds, Long storageContainerId, Boolean outGoing);

    void resetVerifyTimeStamp(Long scannedContainerId, Boolean outGoing);
}
