package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.InternationalCustomer;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/international/customer")
public interface InternationalCustomerService {

    @GET
    @Path("{id}")
    @Produces(APPLICATION_JSON)
    InternationalCustomer getCustomer(@PathParam("id") String id);

    @GET
    @Produces(APPLICATION_JSON)
    List<InternationalCustomer> getCustomers();
}
