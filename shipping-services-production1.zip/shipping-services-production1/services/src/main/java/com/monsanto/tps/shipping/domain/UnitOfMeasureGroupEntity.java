package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * User: pgadi
 */
@Entity
@Table(name = "UOM_GROUP", schema = "MIDAS")
public class UnitOfMeasureGroupEntity {

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name="UOM_GROUP_ITEM",schema = "MIDAS", joinColumns=@JoinColumn(name="UOM_GROUP_ID",referencedColumnName = "UOM_GROUP_ID"),
            inverseJoinColumns=@JoinColumn(name="UOM_ID",referencedColumnName = "UOM_ID"))
    private List<UnitOfMeasureEntity> unitOfMeasureEntities;

    @Id
    @Column(name = "UOM_GROUP_ID")
    private Long id;

    @Column(name = "NAME")
    private String groupName;

    @Column(name = "REF_ACTIVE")
    @Type(type = "true_false")
    private Boolean refActive;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Boolean getRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public List<UnitOfMeasureEntity> getUnitOfMeasureEntities() {
        return unitOfMeasureEntities;
    }

    public void setUnitOfMeasureEntities(List<UnitOfMeasureEntity> unitOfMeasureEntities) {
        this.unitOfMeasureEntities = unitOfMeasureEntities;
    }
}
