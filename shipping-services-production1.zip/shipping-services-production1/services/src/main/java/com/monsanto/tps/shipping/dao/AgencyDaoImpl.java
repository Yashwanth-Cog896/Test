package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class AgencyDaoImpl implements AgencyDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public AgencyEntity findById(Long id) {
        return (AgencyEntity) sessionFactory.getCurrentSession().load(AgencyEntity.class, id);
    }

    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public AgencyEntity findByAbbr(String abbreviation) {
        return (AgencyEntity) sessionFactory.getCurrentSession()
                .createQuery("from AgencyEntity a where a.abbr = :abbr and a.refActive = true")
                .setString("abbr", abbreviation)
                .uniqueResult();
    }

    @Trace
    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public Collection<AgencyEntity> findAllActive() {
        return sessionFactory.getCurrentSession().createQuery("from AgencyEntity where refActive = true").list();
    }
}
