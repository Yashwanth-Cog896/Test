package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "EVENT_CONSTRUCT", schema = "MIDAS")
public class EventConstructEntity implements ContentEntity, Serializable {

    @Id
    @Column(name = "EVENT_CONSTRUCT_ID", nullable = false)
    private Long id;

    @Column(name = "EVENT_NAME")
    private String name;

    @Column(name = "CONSTRUCT_NAME")
    private String constructName;

    @Column(name = "BARCODE")
    private String barcode;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CROP_ID")
    private CropEntity crop;

    public EventConstructEntity() {
    }

    public EventConstructEntity(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getConstructName() {
        return constructName;
    }

    public void setConstructName(String constructName) {
        this.constructName = constructName;
    }

    @Override
    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    @Override
    public Long getContentId() {
        return id;
    }

    public void setContentId(Long id){

    }

    @Override
    public GeneticMaterialEntity getGeneticMaterial() {
        return null;
    }

    public void setGeneticMaterial(GeneticMaterialEntity geneticMaterial){

    }

    @Override
    public InventoryEntity getInventory() {
        return null;
    }

    public void setInventory(InventoryEntity inventory){

    }

    @Override
    public ContentType getContentType() {
        return ContentType.WHOLE_PLANTS;
    }

    public void setContentType(ContentType contentType) {

    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

}
