package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.SapOrderItemBusiness;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("sapOrderItemService")
public class SapOrderItemServiceImpl implements SapOrderItemService {

    @Autowired
    private SapOrderItemBusiness sapOrderItemBusiness;

    @Override
    @Transactional
    public void saveSapOrderItem(SapOrderItem orderItem) {
        sapOrderItemBusiness.saveSapOrderItem(orderItem);
    }
}
