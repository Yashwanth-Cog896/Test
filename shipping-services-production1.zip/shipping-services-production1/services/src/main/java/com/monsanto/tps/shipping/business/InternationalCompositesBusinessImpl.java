package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.service.model.InternationalCarrier;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.InternationalVendor;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.List;

@Service
public class InternationalCompositesBusinessImpl implements InternationalCompositesBusiness {
    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    private static final Function<InternationalStorageLocation, String> TO_LOC_ID = new Function<InternationalStorageLocation, String>() {
        @Override
        public String apply(@Nullable InternationalStorageLocation value) {
            return value.getId();
        }
    };

    @Cacheable("METHOD_CACHE")
    public InternationalStorageLocation getStorageLocation(String id) {
        return internationalCompositesDao.getStorageLocation(id);
    }

    @Cacheable("METHOD_CACHE")
    public List<InternationalStorageLocation> getStorageLocations() {
        return internationalCompositesDao.getStorageLocations();
    }

    @Cacheable("METHOD_CACHE")
    public List<String> getStorageLocationIds(String countryCode) {
        return Lists.transform(internationalCompositesDao.getStorageLocations(countryCode), TO_LOC_ID);
    }

    @Cacheable("METHOD_CACHE")
    public List<InternationalCustomer> getCustomers() {
        return internationalCompositesDao.getCustomers();
    }

    @Trace
    @Override
    @Cacheable("METHOD_CACHE")
    public List<InternationalCarrier> getCarriers() {
        return internationalCompositesDao.getCarriers();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public InternationalCustomer getBroker(String id) {
        return internationalCompositesDao.getBroker(id);
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public List<InternationalCustomer> getBrokers() {
        return internationalCompositesDao.getBrokers();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public List<InternationalVendor> getGtmContacts() {
        return internationalCompositesDao.getGtmContacts();
    }

    @Cacheable("METHOD_CACHE")
    public InternationalCustomer getCustomer(String id) {
        return internationalCompositesDao.getCustomer(id);
    }

    @Cacheable("METHOD_CACHE")
    public String getEndUseVendorNumberForResearch() {
        return internationalCompositesDao.getEndUseVendorNumberForResearch();
    }
}
