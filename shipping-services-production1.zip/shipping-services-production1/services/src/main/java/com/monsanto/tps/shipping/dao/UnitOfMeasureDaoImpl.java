package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * User: DCENGL
 */
@Repository
public class UnitOfMeasureDaoImpl implements UnitOfMeasureDao {

    @Autowired
    private org.hibernate.SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public UnitOfMeasureEntity load(Long unitOfMeasureId) {
        return (UnitOfMeasureEntity) sessionFactory.getCurrentSession().get(UnitOfMeasureEntity.class, unitOfMeasureId);
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public UnitOfMeasureEntity findByName(String name) {
        return (UnitOfMeasureEntity) sessionFactory.getCurrentSession()
                .createQuery("from UnitOfMeasureEntity where name = :uomName ")
                .setParameter("uomName", name).uniqueResult();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public String getAbbreviationFromInventoryMgtUomId(Long uomId) {
        if (uomId == null) {
            return null;
        }
        return (String) sessionFactory.getCurrentSession().createSQLQuery(
                "select uom_abbrev from inventory_mgt.unit_of_measure where unit_of_measure_id = :uomId")
                .setParameter("uomId", uomId)
                .uniqueResult();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public Long getInventoryMgtUomIdFromAbbreviation(String uomAbbreviation) {
        if (StringUtils.isBlank(uomAbbreviation)) {
            return null;
        }
        return ((BigDecimal)sessionFactory.getCurrentSession().createSQLQuery(
                "select unit_of_measure_id from inventory_mgt.unit_of_measure where uom_abbrev = :uomAbbreviation")
                .setParameter("uomAbbreviation", uomAbbreviation.toUpperCase())
                .uniqueResult())
                .longValue();
    }
}
