package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public interface MTFExport {
    
    ByteArrayOutputStream getPdfReport(ShipmentPackingListEntity packingList) throws IOException;
    
}
