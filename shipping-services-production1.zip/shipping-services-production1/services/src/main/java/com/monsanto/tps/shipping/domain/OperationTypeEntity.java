package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "OPERATION_TYPE", schema = "MIDAS")
public class OperationTypeEntity {

    @Id
    @Column(name = "OPERATION_TYPE_ID")
    private Long id;
    @Column(name = "OPERATION_TYPE_NAME")
    private String operationTypeName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOperationTypeName() {
        return operationTypeName;
    }

    public void setOperationTypeName(String operationTypeName) {
        this.operationTypeName = operationTypeName;
    }
}
