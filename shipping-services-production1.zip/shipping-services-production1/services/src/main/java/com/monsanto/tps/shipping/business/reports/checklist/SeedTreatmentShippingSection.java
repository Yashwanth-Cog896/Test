package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by wwahme
 */

@Service
public class SeedTreatmentShippingSection extends AbstractChecklistSection {

    private static final String HEADER = "Additional Requirements for the�movement of Seed Treated with Regulated/Unregistered Seed Treatments (including all microbial treatments)";

    private final static String SECTION_1 = "Shipping";
    private final static String SECTION_1_QUESTION_1 = "Microbial shipment verified in Breeding GPS Compliance Tool Suite.";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);

        return questionsMap;
    }
}
