package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShippingPreferenceEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * User: DCENGL
 */
@Repository
public class ShippingPreferenceDaoImpl implements ShippingPreferenceDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public ShippingPreferenceEntity findShippingPreferenceByType(String name, Long accountId) {
        //TODO Switch to Shipping Web source system when data is created
        return (ShippingPreferenceEntity) sessionFactory.getCurrentSession().createQuery("from ShippingPreferenceEntity " +
                " where shippingPreferenceTypeEntity.name = :name" +
                "   and accountId = :accountId " +
                "   and shippingPreferenceTypeEntity.active = true" +
                "   and sourceSystem.name = 'Shipping Web'")
                .setParameter("name", name)
                .setParameter("accountId", accountId)
                .uniqueResult();
    }
}
