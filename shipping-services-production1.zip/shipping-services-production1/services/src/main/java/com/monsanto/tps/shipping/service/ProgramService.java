package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Program;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: DCENGL
 */
@Path("/program")
public interface ProgramService {


    @GET
    @Produces(APPLICATION_JSON)
    public List<Program> getPrograms();

    @GET
    @Path("/user")
    @Produces(APPLICATION_JSON)
    public List<Program> getAllForUser();

    @GET
    @Path("/account/{accountId}")
    @Produces(APPLICATION_JSON)
    public Program getProgramByAccount(@PathParam("accountId") Long accountId);

    @GET
    @Path("/shipto/plot/{type}/{barcode}")
    @Produces(APPLICATION_JSON)
    public Program getShipToProgramByPlot(@PathParam("type")String type,@PathParam("barcode") String plotBarcode);

    @GET
    @Path("/grower/{packingListId}/shipment-type/{shipmentType}")
    @Produces(APPLICATION_JSON)
    public List<Program> getGrowerProgramsForPackingList(@PathParam("packingListId") Long packingListId,
                                                         @PathParam("shipmentType") String shipmentType);
}
