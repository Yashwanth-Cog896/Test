package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.PlotMalePlotEntity;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface PlotMalePlotDao {

    Collection<PlotMalePlotEntity> findBinaryPlotMalePlotsForFemalePlots(Collection<Long> femalePlotIds);
    Collection<PlotMalePlotEntity> findUnaryPlotMalePlotsWithMalePlots(Collection<Long> femalePlotIds);

}
