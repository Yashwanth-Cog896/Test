package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.Collection;

@Entity
@DiscriminatorValue("HD_TRAY")
public class HDTrayContainerEntity extends ScannedContainerEntity<HDTrayEntity> {

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BARCODE_NBR", referencedColumnName = "HD_TRAY_ID")
    private HDTrayEntity hdTrayEntity;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SCANNED_CONTAINER_ID", referencedColumnName = "SCANNED_CONTAINER_ID")
    private Collection<RegulatedInventoryMovementEntity> regulatedInventoryMovements;

    @Override
    public HDTrayEntity getContent() {
        return hdTrayEntity;
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public void setContent(HDTrayEntity contentEntity) {
        this.hdTrayEntity = contentEntity;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.HD_TRAY;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return regulatedInventoryMovements;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        if (regulatedInventoryMovements != null) {
            regulatedInventoryMovements.add(newMovement);
        } else {
            regulatedInventoryMovements = Lists.newArrayList(newMovement);
        }
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        this.regulatedInventoryMovements = movements;
    }

}
