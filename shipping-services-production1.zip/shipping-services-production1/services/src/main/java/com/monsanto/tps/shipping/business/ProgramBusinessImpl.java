package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.dao.ProgramDao;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.service.model.Program;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * User: DCENGL
 */
@Service
public class ProgramBusinessImpl implements ProgramBusiness {

    @Autowired
    private ProgramDao programDao;
    @Autowired
    private ContactBusiness contactBusiness;

    @Transactional(readOnly = true)
    @Trace
    @Override
    public Program getProgramByAccountId(Long accountId) {
        ProgramEntity programEntity = getProgramByAccount(accountId);
        return programEntity == null ? null : getProgram(programEntity);
    }

    @Trace
    @Override
    public ProgramEntity getProgramByAccount(Long accountId) {
        List<ProgramEntity> programs = programDao.findProgramsByAccountId(accountId);
        if (!CollectionUtils.isEmpty(programs)) {
            return programs.get(0);
        }
        return null;
    }

    @Trace
    @Override
    public ProgramEntity getProgramByContact(Long contactId) {
        ShipmentContact toContact = contactBusiness.getContact(contactId);
        return getProgramByAccount(toContact.getAccountId());
    }

    @Override
    public Program getShipToProgramForHarvestedPlotBarcode(String plotBarcode) {
        ProgramEntity program = programDao.getShipToProgramForHarvestedPlotBarcode(plotBarcode);
        return (program != null) ? getProgram(program) : null;
    }

    @Override
    public Program getShipToProgramForToBePlantedPlotBarcode(String plotBarcode) {
        ProgramEntity program = programDao.getShipToProgramForToBePlantedPlotBarcode(plotBarcode);
        return (program != null) ? getProgram(program) : null;
    }

    @Transactional(readOnly = true)
    @Trace
    @Override
    public List<Program> getPrograms() {
        List<Program> programs = Lists.newArrayList();
        List<ProgramEntity> programEntities = programDao.getActivePrograms();
        for (ProgramEntity programEntity : programEntities) {
            programs.add(getProgram(programEntity));
        }
        return programs;
    }

    @Transactional(readOnly = true)
    @Trace
    @Override
    public List<Program> getGrowerProgramsForPackingList(Long packingListId, ShipmentTypeEnum shipmentType) {
        List<Program> programs = Lists.newArrayList();
        List<ProgramEntity> programEntities;
        if (ShipmentTypeEnum.PLANTED_PLOT_INV.equals(shipmentType)) {
            programEntities = programDao.getGrowerProgramsForMixedPlots(packingListId);
        } else {
            programEntities = programDao.getGrowerProgramsByPackingListId(packingListId);
        }

        for (ProgramEntity programEntity : programEntities) {
            programs.add(getProgram(programEntity));
        }

        return programs;
    }

    @Transactional(readOnly = true)
    @Trace
    @Override
    public List<ProgramEntity> getProgramsByAccountIdExcludePipelineFunctions(Long accountId) {
        return programDao.getProgramsByAccountIdExcludePipelineFunctions(accountId);
    }

    private Program getProgram(ProgramEntity programEntity) {
        Program program = new Program();
        program.setId(programEntity.getProgramId());
        program.setReferenceId(programEntity.getRefId());
        program.setName(programEntity.getName());
        program.setCropId(programEntity.getCrop().getCropId());
        program.setCropName(programEntity.getCrop().getName());
        program.setAccountId(programEntity.getAccountId());
        return program;
    }

}
