package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ProgramEntity;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


/**
 * User: PGADI
 */
@Repository
public class ShipmentAccountDaoImpl implements ShipmentAccountDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public Long getAccountIdByProgramRefId(String programRefId) {
        return (Long) sessionFactory.getCurrentSession().createCriteria(ProgramEntity.class).
                add(Restrictions.eq("refId", programRefId)).
                setProjection(Projections.property("accountId")).uniqueResult();
    }
}
