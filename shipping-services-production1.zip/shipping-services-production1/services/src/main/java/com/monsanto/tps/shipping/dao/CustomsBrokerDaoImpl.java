/**
 * Created by TMILB on 7/8/14.
 */

package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;
import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class CustomsBrokerDaoImpl implements CustomsBrokerDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Trace
    public CustomsBrokerEntity findById(long id) {
        return (CustomsBrokerEntity) sessionFactory.getCurrentSession().load(CustomsBrokerEntity.class, id);
    }

    /**
     * Return the broker entity for a given account id and country code. currently, this should be at most one
     *    entry in the mapping table
     */
    public CustomsBrokerEntity findBy(Long fromAccountId, String countryCode) {
        CustomsBrokerEntity ret = null;
        CustomsBrokerPreferenceEntity preferencesEntity = (CustomsBrokerPreferenceEntity) sessionFactory.getCurrentSession()
                .createQuery("from CustomsBrokerPreferenceEntity where accountId = :acctId and countryName = :countryCode")
                .setParameter("acctId", fromAccountId)
                .setParameter("countryCode", countryCode)
                .uniqueResult();
        if (preferencesEntity != null) {
            ret = preferencesEntity.getCustomsBroker();
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<CustomsBrokerEntity> loadAll() {
        return (Collection<CustomsBrokerEntity>) sessionFactory.getCurrentSession().createQuery("from CustomsBrokerEntity where inactiveDateTime is null or inactiveDateTime < current_date()").list();
    }
}
