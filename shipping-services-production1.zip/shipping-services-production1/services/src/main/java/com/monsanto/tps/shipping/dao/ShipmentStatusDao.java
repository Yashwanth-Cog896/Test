package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShippingStatus;

/**
 * User: pgadi
 */
public interface ShipmentStatusDao {
    ShippingStatus getByName(String status);
}
