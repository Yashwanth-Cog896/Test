package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.service.model.State;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Set;

/**
 * User: pgadi
 */
@Repository
public class AgencyRequestDaoImpl implements AgencyRequestDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<AgencyRequestEntity> agencyRequestsForMonsantoIds(Set<String> monsantoIds) {
        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(monsantoIds));

        return sessionFactory.getCurrentSession()
                .createQuery("from AgencyRequestEntity ar " +
                        "where ar.monsantoId in (select tempOcdId from TempOcdTable tempTable where tempTable.sessionId = :requestId)")
                .setParameter("requestId", requestId).list();
    }

    @Trace
    @Override
    public AgencyRequestEntity findAgencyRequestByApprovalNumber(String approvalNumber) {
        return (AgencyRequestEntity) sessionFactory.getCurrentSession().createQuery("from AgencyRequestEntity where agencyApprovalNumber = :approvalNumber")
                .setParameter("approvalNumber", approvalNumber)
                .uniqueResult();
    }

    @Trace
    @Override
    public Collection<State> findStatesCoveredByEUP(String eup) {
        return jdbcTemplate.query(
                "select distinct \n" +
                "       wsc.sub_iso_name abbreviation, \n" +
                "       wsc.name \n" +
                "  from fcm.agency_request ar, \n" +
                "       compli_proc.compli_request cr, \n" +
                "       compli_proc.compli_request_lctn rl, \n" +
                "       compli_proc.land_parcel lp, \n" +
                "       place.world_sub_sub_country wssc, \n" +
                "       place.world_sub_country wsc \n" +
                " where ar.compli_request_id = cr.compli_request_id \n" +
                "   and cr.compli_request_id = rl.compli_request_id \n" +
                "   and rl.land_parcel_id = lp.land_parcel_id \n" +
                "   and lp.ctrycode = wssc.ctrycode \n" +
                "   and lp.sub_sub_country_admincode = wssc.sub_sub_country_admincode \n" +
                "   and wssc.ctrycode = wsc.ctrycode \n" +
                "   and wssc.sub_country_admincode = wsc.sub_country_admincode \n" +
                "   and ar.act_eff_date <= sysdate \n" +
                "   and ar.act_expr_date > sysdate" +
                "   and ar.agency_aprv_nbr = ?",
                new String[] {eup},
                BeanPropertyRowMapper.newInstance(State.class));
    }
}
