package com.monsanto.tps.shipping.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.sql.Types;
import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
@Repository
public class TempOcdTableDaoImpl implements TempOcdTableDao {

    private static final String INSERT_TEXT = "insert into midas.temp_session_ocd (request_id, text_1) " +
            "values (:requestId, :text1)";
    private static final String INSERT_NUMBERS = "insert into midas.temp_session_ocd (request_id, number_1) " +
            "values (:requestId, :number1)";
    private static final String TEXT_1 = "text1";
    private static final String NUMBER_1 = "number1";
    private static final String REQUEST_ID = "requestId";

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
    @Resource(name = "tempSessionOcdRequestIdProvider")
    private TempSessionOcdRequestIdProvider tempSessionOcdRequestIdProvider;

    @Override
    public long insertStrings(List<String> strings) {
        long requestId = getNextRequestId();
        BatchSqlUpdate batchSqlUpdate = buildTempTableTextBatchUpdate();
        for (String text : strings) {
            batchSqlUpdate.update(requestId, text);
        }
        batchSqlUpdate.flush();
        return requestId;
    }

    @Override
    public long insertLongs(Collection<Long> longs) {
        long requestId = getNextRequestId();
        BatchSqlUpdate batchSqlUpdate = buildTempTableNumberBatchUpdate();
        for (Long number : longs) {
            batchSqlUpdate.update(requestId, number);
        }
        batchSqlUpdate.flush();
        return requestId;
    }

    @Override
    public long getNextRequestId() {
        return tempSessionOcdRequestIdProvider.getNextRequestId();
    }


    private BatchSqlUpdate buildTempTableTextBatchUpdate() {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(), INSERT_TEXT);
        batchSqlUpdate.declareParameter(new SqlParameter(REQUEST_ID, Types.INTEGER));
        batchSqlUpdate.declareParameter(new SqlParameter(TEXT_1, Types.VARCHAR));
        return batchSqlUpdate;
    }

    private BatchSqlUpdate buildTempTableNumberBatchUpdate() {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(), INSERT_NUMBERS);
        batchSqlUpdate.declareParameter(new SqlParameter(REQUEST_ID, Types.INTEGER));
        batchSqlUpdate.declareParameter(new SqlParameter(NUMBER_1, Types.BIGINT));
        return batchSqlUpdate;
    }

}
