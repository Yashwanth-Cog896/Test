package com.monsanto.tps.shipping.domain;

public class SapOrderItemWeights {
    private Double boxWeight = 0D;
    private Double itemWeight = 0D;
    private Long uomId;

    public Double getBoxWeight() {
        return boxWeight;
    }

    public void setBoxWeight(Double boxWeight) {
        if(boxWeight != null) {
            this.boxWeight = boxWeight;
        }
    }

    public Double getItemWeight() {
        return itemWeight;
    }

    public void setItemWeight(Double itemWeight) {
        this.itemWeight = itemWeight;
    }

    public void addItemWeight(Double itemWeight) {
        if (itemWeight != null) {
            this.itemWeight += itemWeight;
        }
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        if (uomId != null) {
            this.uomId = uomId;
        }
    }
}
