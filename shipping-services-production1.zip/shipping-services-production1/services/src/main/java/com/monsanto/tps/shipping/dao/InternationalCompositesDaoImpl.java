package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.service.model.AbstractContact;
import com.monsanto.tps.shipping.service.model.CropDescription;
import com.monsanto.tps.shipping.service.model.InternationalCarrier;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.InternationalVendor;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Transactional("sapTransactionManager")
public class InternationalCompositesDaoImpl implements InternationalCompositesDao {


    @Resource(name = "compositesJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static final Object[] NO_ARGS = new Object[0];
    private static final String CONTACT_COLUMNS = "streetName, streetName2, streetName3, cityName, region, cityPostalCode, countryDescription, countryCode";

    private static final String GET_STORAGE_LOCATIONS_SQL =
        "select storageLocationCode, plantCode, locationName1, " + CONTACT_COLUMNS +
            " from ShipCenter.shippingCenterLocation where plantCode like 'R%'";
    private static final String GET_STORAGE_LOCATION_SQL = GET_STORAGE_LOCATIONS_SQL + " and storageLocationCode = ?";
    private static final String GET_STORAGE_LOCATIONS_BY_COUNTRY_SQL =
        GET_STORAGE_LOCATIONS_SQL + " and countryCode = ?";

    private static final String GET_CUSTOMERS_SQL =
        "select customerNumber, partnerFunctionAg, partnerFunctionWe, customerName1, salesOrganizationCode, " +
            CONTACT_COLUMNS
            + " from ShipCenter.shippingCenterCustomer where (partnerFunctionAg = 'Y' or partnerFunctionWe = 'Y') ";
    private static final String GET_CUSTOMER_SQL = GET_CUSTOMERS_SQL + " and customerNumber = ? ";

    public static final String CROP_DESC_SQL = "select distinct x.ccdValue, x.ccdDescription, x.cropValue from ShipCenter.shippingCenterProduct x where x.ccdValue is not null and x.ccdDescription is not null and x.cropValue is not null";

    public static final String GET_CARRIERS_SQL = "select scv.vendorName1, scv.vendorNumber from ShipCenter.shippingCenterVendor scv where scv.characteristicValue = 'ZC'";

    public static final String GET_GTM_CONTACTS_SQL = "select vendorName1, vendorNumber,  " + CONTACT_COLUMNS
        + " from ShipCenter.shippingCenterVendor scv where scv.characteristicValue = 'YK'";

    public static final String GET_BROKERS_SQL =
        "select customerNumber, customerName1, salesOrganizationCode, " + CONTACT_COLUMNS
            + " from ShipCenter.shippingCenterBroker";
    public static final String GET_BROKER_WITH_ID_SQL = GET_BROKERS_SQL + " where customerNumber = ? ";

    public static final String GET_MATERIAL_NBR_SQL = "select materialNumber from ShipCenter.shippingCenterProduct where eventDescription = ? and cropValue = ? and ccdValue :ccdQuery";
    public static final String GET_MATERIAL_NBR_CONVENTIONAL_SQL =
        "select materialNumber from ShipCenter.shippingCenterProduct where eventDescription is null and laboratoryCode = 'Z00' " +
            "and traitDescription = 'CONVENTIONAL' and cropValue = ? and ccdValue :ccdQuery";
    public static final String END_USE_VENDOR_NUMBER_SQL = "select vendorNumber from ShipCenter.shippingCenterVendor where vendorName1= 'FOR RESEARCH'";

    private static final RowMapper<InternationalStorageLocation> STORAGE_LOCATION_MAPPER = new RowMapper<InternationalStorageLocation>() {
        @Override
        public InternationalStorageLocation mapRow(ResultSet rs, int rowNum) throws SQLException {
            InternationalStorageLocation row = new InternationalStorageLocation();

            row.setId(rs.getString("storageLocationCode"));
            row.setPlant(rs.getString("plantCode"));
            row.setName(rs.getString("locationName1"));

            map(rs, row);

            return row;
        }
    };
    private static final RowMapper<InternationalCustomer> CUSTOMER_MAPPER = new RowMapper<InternationalCustomer>() {
        @Override
        public InternationalCustomer mapRow(ResultSet rs, int rowNum) throws SQLException {
            InternationalCustomer row = new InternationalCustomer();
            row.setId(rs.getString("customerNumber"));
            row.setValidShipTo("Y".equalsIgnoreCase(rs.getString("partnerFunctionWe")));
            row.setValidSoldTo("Y".equalsIgnoreCase(rs.getString("partnerFunctionAg")));
            row.setName(rs.getString("customerName1"));
            row.setSalesOrgCd(rs.getString("salesOrganizationCode"));
            map(rs, row);

            return row;
        }
    };

    private static final RowMapper<InternationalCustomer> BROKER_MAPPER = new RowMapper<InternationalCustomer>() {
        @Override
        public InternationalCustomer mapRow(ResultSet rs, int rowNum) throws SQLException {
            InternationalCustomer row = new InternationalCustomer();
            row.setId(rs.getString("customerNumber"));
            row.setName(rs.getString("customerName1"));
            row.setSalesOrgCd(rs.getString("salesOrganizationCode"));
            map(rs, row);

            return row;
        }
    };

    private static final RowMapper<InternationalVendor> VENDOR_MAPPER = new RowMapper<InternationalVendor>() {
        @Override
        public InternationalVendor mapRow(ResultSet rs, int rowNum) throws SQLException {
            InternationalVendor row = new InternationalVendor();
            row.setId(rs.getString("vendorNumber"));
            row.setName(rs.getString("vendorName1"));
            map(rs, row);

            return row;
        }
    };

    private static final ResultSetExtractor<String> MATERIAL_NBR_EXTRACTOR = new ResultSetExtractor<String>() {
        @Override
        public String extractData(ResultSet rs) throws SQLException, DataAccessException {
            return rs.next() ? rs.getString("materialNumber") : null;
        }
    };

    private static void map(ResultSet rs, AbstractContact row) throws SQLException {
        row.setAddressLine1(formatString(rs, "streetName"));
        row.setAddressLine2(formatString(rs, "streetName2"));
        row.setAddressLine3(formatString(rs, "streetName3"));
        row.setCity(formatString(rs, "cityName"));
        row.setState(StringUtils.defaultIfEmpty(formatString(rs, "region"), "--"));
        row.setZip(formatString(rs, "cityPostalCode"));
        row.setCountry(formatString(rs, "countryDescription"));
        row.setIsoCountryCode(formatString(rs, "countryCode"));
    }

    private static String formatString(ResultSet rs, String column) throws SQLException {
        String result = rs.getString(column);
        return StringUtils.isEmpty(result) ? null : result.trim();
    }

    @Override
    public InternationalStorageLocation getStorageLocation(String id) {
        return jdbcTemplate.queryForObject(GET_STORAGE_LOCATION_SQL, new Object[]{id}, STORAGE_LOCATION_MAPPER);
    }

    @Override
    public List<InternationalStorageLocation> getStorageLocations() {
        return jdbcTemplate.query(GET_STORAGE_LOCATIONS_SQL, NO_ARGS, STORAGE_LOCATION_MAPPER);
    }

    @Override
    public List<InternationalStorageLocation> getStorageLocations(String countryCode) {
        return jdbcTemplate
            .query(GET_STORAGE_LOCATIONS_BY_COUNTRY_SQL, new Object[]{countryCode}, STORAGE_LOCATION_MAPPER);
    }

    @Override
    public InternationalCustomer getCustomer(String id) {
        return DataAccessUtils
            .requiredSingleResult(map(jdbcTemplate.query(GET_CUSTOMER_SQL, new Object[]{id}, CUSTOMER_MAPPER)));
    }

    @Override
    public List<InternationalCustomer> getCustomers() {
        return map(jdbcTemplate.query(GET_CUSTOMERS_SQL, NO_ARGS, CUSTOMER_MAPPER));
    }

    @Override
    public InternationalCustomer getBroker(String id) {
        return jdbcTemplate.query(GET_BROKER_WITH_ID_SQL, new Object[]{id}, BROKER_MAPPER).get(0);
    }

    @Override
    public List<InternationalCustomer> getBrokers() {
        return map(jdbcTemplate.query(GET_BROKERS_SQL, BROKER_MAPPER));
    }

    @Override
    public List<InternationalVendor> getGtmContacts() {
        return jdbcTemplate.query(GET_GTM_CONTACTS_SQL, VENDOR_MAPPER);
    }

    @Trace
    @Override
    public List<CropDescription> getCropDescriptions() {
        return jdbcTemplate.query(CROP_DESC_SQL, new RowMapper<CropDescription>() {
            @Override
            public CropDescription mapRow(ResultSet rs, int rowNum) throws SQLException {
                return new CropDescription(rs.getString("ccdValue"), rs.getString("ccdDescription"),
                    rs.getString("cropValue"));
            }
        });
    }

    @Trace
    @Override
    public List<InternationalCarrier> getCarriers() {
        return jdbcTemplate.query(GET_CARRIERS_SQL, new RowMapper<InternationalCarrier>() {
            @Override
            public InternationalCarrier mapRow(ResultSet rs, int rowNum) throws SQLException {
                return new InternationalCarrier(rs.getString("vendorNumber"), rs.getString("vendorName1"));
            }
        });
    }

    @Trace
    @Override
    public String getMaterialNbrForOrderItem(SapOrderItem sapOrderItem, String cropSpecieCode) {
        String ccdQuery = null == sapOrderItem.getSapCcdVal() ? "is null and ? is null " : "= ?";

        if (StringUtils.isNotEmpty(sapOrderItem.getEventStack())) {
            return jdbcTemplate.query(GET_MATERIAL_NBR_SQL.replace(":ccdQuery", ccdQuery),
                new Object[]{sapOrderItem.getEventStack().replaceAll(",", "x"), cropSpecieCode, sapOrderItem.getSapCcdVal() },
                MATERIAL_NBR_EXTRACTOR);
        } else {
            return jdbcTemplate.query(GET_MATERIAL_NBR_CONVENTIONAL_SQL.replace(":ccdQuery", ccdQuery),
                new Object[]{cropSpecieCode, sapOrderItem.getSapCcdVal()}, MATERIAL_NBR_EXTRACTOR);
        }
    }

    @Trace
    @Override
    public String getEndUseVendorNumberForResearch() {
        return jdbcTemplate.query(END_USE_VENDOR_NUMBER_SQL, new ResultSetExtractor<String>() {
            @Override
            public String extractData(ResultSet rs) throws SQLException, DataAccessException {
                return rs.next() ? rs.getString("vendorNumber") : null;
            }
        });
    }

    private List<InternationalCustomer> map(List<InternationalCustomer> customers) {
        Map<String, InternationalCustomer> customerMap = new HashMap<String, InternationalCustomer>(customers.size());
        for (InternationalCustomer customer : customers) {
            InternationalCustomer mappedCustomer = customerMap.get(customer.getId());
            if (mappedCustomer == null) {
                mappedCustomer = customer;
            }
            mappedCustomer.getSalesOrgs().add(customer.getSalesOrgCd());
            customerMap.put(customer.getId(), mappedCustomer);
        }
        return new ArrayList<InternationalCustomer>(customerMap.values());
    }

}
