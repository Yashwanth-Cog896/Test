package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.dao.AgencyRequestDao;
import com.monsanto.tps.shipping.dao.FcmCropDao;
import com.monsanto.tps.shipping.dao.IrdContactXrefDao;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.AgencyRequestLocation;
import com.monsanto.tps.shipping.domain.IrdContactXref;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.State;
import com.monsanto.tps.shipping.util.AgencyRequestStatusCodeEnum;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * User: pgadi
 */
@Service
public class AgencyRequestBusinessImpl implements AgencyRequestBusiness {

    public static final Predicate<AgencyRequestLocation> DESTINATION_FILTER = new Predicate<AgencyRequestLocation>() {
        @Override
        public boolean apply(@Nullable AgencyRequestLocation location) {
            return location != null && location.isDestinationFlag();
        }
    };

    public static final Predicate<AgencyRequestLocation> ORIGIN_FILTER = new Predicate<AgencyRequestLocation>() {
        @Override
        public boolean apply(@Nullable AgencyRequestLocation location) {
            return location != null && location.isOriginFlag();
        }
    };


    private static final Function<AgencyRequestLocation, Long> CONTACT_ID = new Function<AgencyRequestLocation, Long>() {
        @Override
        public Long apply(@Nullable AgencyRequestLocation agencyRequestLocation) {
            return agencyRequestLocation.getContactId();
        }
    };

    private static final Function<Permit, String> MONSANTO_ID_FUNCTION = new Function<Permit, String>() {
        @Override
        public String apply(@Nullable Permit input) {
            return input.getMonsantoId();
        }
    };

    @Autowired
    private IrdContactXrefDao irdContactXrefDao;
    @Autowired
    private AgencyRequestDao agencyRequestDao;
    @Autowired
    private FcmCropDao cropDao;

    @Trace
    @Override
    public void addAgencyRequestDataForPermits(Collection<Permit> permits, long toContactId) {
        Set<String> monsantoIds = Sets.newHashSet(Collections2.transform(permits, MONSANTO_ID_FUNCTION));
        Collection<AgencyRequestEntity> agencyRequests = agencyRequestDao.agencyRequestsForMonsantoIds(monsantoIds);

        List<Long> toContactXref = getAllFCMContacts(toContactId);

        for (Permit permit : permits) {
            AgencyRequestEntity agencyRequest = getAgencyRequestByMonsantoId(agencyRequests, permit.getMonsantoId());

            if (agencyRequest != null) {
                Collection<AgencyRequestLocation> agencyRequestOrigins = Collections2.filter(agencyRequest.getLocations(), ORIGIN_FILTER);
                Collection<AgencyRequestLocation> agencyRequestDestinations = Collections2.filter(agencyRequest.getLocations(), DESTINATION_FILTER);

                permit.setId(agencyRequest.getId());
                permit.setCropId(getMidasCropId(agencyRequest.getCropId()));

                if (permit.getApprovalNumber() == null) {
                    permit.setApprovalNumber(agencyRequest.getAgencyApprovalNumber());
                }

                if (agencyRequest.getExpirationDate() != null) {
                    permit.setExpirationDate(new Date(agencyRequest.getExpirationDate().getTime()));
                }

                if (agencyRequest.getEffectiveDate() != null) {
                    permit.setEffectiveDate(new Date(agencyRequest.getEffectiveDate().getTime()));
                }

                permit.setStatus(AgencyRequestStatusCodeEnum.getByCode(agencyRequest.getStatusCode()));

                AgencyRequestLocation toContactLocation = findLocationIdForContact(agencyRequest.getLocations(), toContactXref);

                if (toContactLocation != null) {
                    permit.setAgencyRequestLocationId(toContactLocation.getId());
                }

                permit.setOriginContactIds(Collections2.transform(agencyRequestOrigins, CONTACT_ID));
                permit.setDestinationContactIds(Collections2.transform(agencyRequestDestinations, CONTACT_ID));
            }
        }
    }

    @Trace
    @Override
    public AgencyRequestEntity getAgencyRequest(String approvalNumber) {
        return agencyRequestDao.findAgencyRequestByApprovalNumber(approvalNumber);
    }

    @Trace
    @Override
    public Collection<State> findStatesCoveredByEUP(String agencyApprovalNumber) {
        return agencyRequestDao.findStatesCoveredByEUP(agencyApprovalNumber);
    }

    @Trace
    @Override
    public Collection<Long> getIrdContactIds(Collection<AgencyRequestLocation> agencyRequestLocations) {
        Collection<Long> fcmContactIds = Collections2.transform(agencyRequestLocations, CONTACT_ID);

        List<IrdContactXref> contactsXrefs = irdContactXrefDao.findContactsXrefs(fcmContactIds);

        return Collections2.transform(contactsXrefs, new Function<IrdContactXref, Long>() {
            @Override
            public Long apply(@Nullable IrdContactXref input) {
                return input.getIrdContactId();
            }
        });
    }

    private AgencyRequestEntity getAgencyRequestByMonsantoId(Collection<AgencyRequestEntity> agencyRequests, String monsantoId) {
        if (monsantoId == null) {
            return null;
        }

        for (AgencyRequestEntity agencyRequest : agencyRequests) {
            if (monsantoId.equals(agencyRequest.getMonsantoId())) {
                return agencyRequest;
            }
        }

        return null;
    }

    private AgencyRequestLocation findLocationIdForContact(Collection<AgencyRequestLocation> agencyRequestLocationList, List<Long> toContactXref) {
        for (AgencyRequestLocation agencyRequestLocation : agencyRequestLocationList) {
            for (Long toContact : toContactXref) {
                if (agencyRequestLocation.getContactId().equals(toContact) && agencyRequestLocation.isDestinationFlag()) {
                    return agencyRequestLocation;
                }
            }
        }
        return null;
    }

    private List<Long> getAllFCMContacts(long contactId) {
        List<Long> contactXref = Lists.newArrayList();
        for (IrdContactXref irdContactXref : irdContactXrefDao.findContactsXrefs(contactId)) {
            if (irdContactXref.getIrdContactId() == contactId) {
                contactXref.add(irdContactXref.getFcmContactId());
            }
        }
        return contactXref;
    }

    private Long getMidasCropId(Long cropId) {
        return cropDao.getMidasCropId(cropId);
    }
}
