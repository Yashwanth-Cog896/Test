package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.dao.SapSpecieCropXrefDao;
import com.monsanto.tps.shipping.domain.SapSpecieCropXrefEntity;
import com.monsanto.tps.shipping.service.model.CropDescription;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * User: pgadi
 */
@Service
public class SapCropDescriptionBusinessImpl implements SapCropDescriptionBusiness {

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Autowired
    private SapSpecieCropXrefDao sapSpecieCropXrefDao;

    @Trace
    @Override
    @Cacheable("METHOD_CACHE")
    public List<CropDescription> getCropDescriptions() {
        List<CropDescription> cropDescriptions = internationalCompositesDao.getCropDescriptions();
        Map<String, SapSpecieCropXrefEntity> sapSpecieCodeToSapSpecieCropMap = Maps.uniqueIndex(sapSpecieCropXrefDao.getSapSpecieCropEntities(), new Function<SapSpecieCropXrefEntity, String>() {
            @Override
            public String apply(SapSpecieCropXrefEntity input) {
                return input.getSapSpecieCode();
            }
        });

        List<CropDescription> cropDescriptionsWithNoSpecieCropMatch = Lists.newArrayListWithCapacity(cropDescriptions.size());

        for (final CropDescription cropDescription : cropDescriptions) {
            SapSpecieCropXrefEntity sapSpecieCropXrefEntity = sapSpecieCodeToSapSpecieCropMap.get(cropDescription.getSapCropVal());

            if(null != sapSpecieCropXrefEntity) {
                cropDescription.setCropId(sapSpecieCropXrefEntity.getCropSubClassId());
            } else {
                cropDescriptionsWithNoSpecieCropMatch.add(cropDescription);
            }
        }

        cropDescriptions.removeAll(cropDescriptionsWithNoSpecieCropMatch);

        return cropDescriptions;
    }
}
