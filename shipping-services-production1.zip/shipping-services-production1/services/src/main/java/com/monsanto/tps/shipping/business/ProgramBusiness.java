package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.service.model.Program;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;

import java.util.List;

/**
 * User: DCENGL
 */
public interface ProgramBusiness {

    @Deprecated
    Program getProgramByAccountId(Long accountId);

    Program getShipToProgramForHarvestedPlotBarcode(String plotBarcode);

    Program getShipToProgramForToBePlantedPlotBarcode(String plotBarcode);

    ProgramEntity getProgramByContact(Long contactId);

    ProgramEntity getProgramByAccount(Long accountId);

    List<Program> getPrograms();

    List<Program> getGrowerProgramsForPackingList(Long packingListId, ShipmentTypeEnum plantedPlot);

    List<ProgramEntity> getProgramsByAccountIdExcludePipelineFunctions(Long accountId);

}
