
package com.monsanto.tps.shipping.sap.client.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "shipCenterData"
})
@XmlRootElement(name = "DeliveryShipmentCreateRequest")
public class DeliveryShipmentCreateRequest {

    @XmlElement(name = "ShipCenterData", required = true)
    private DeliveryShipmentData shipCenterData;

    public DeliveryShipmentData getShipCenterData() {
        return shipCenterData;
    }

    public void setShipCenterData(DeliveryShipmentData value) {
        this.shipCenterData = value;
    }

}
