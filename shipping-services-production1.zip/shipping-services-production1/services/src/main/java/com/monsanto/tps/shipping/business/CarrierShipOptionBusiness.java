package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;

import java.util.Collection;
import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface CarrierShipOptionBusiness {
    CarrierShipOptionEntity findCarrierShipOption(Long carrierShipOptionId);
    Collection<CarrierShipOptionEntity> findCarrierShipOptions(Collection<Long> carrierShipOptionIds);
    List<CarrierShipOptionEntity> findAllCarrierShipOptions();
    List<CarrierShipOptionEntity> findCarrierShipOptionByCarrierId(Long carrierId);
}
