package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface CustomsBrokerPreferenceDao {

    Collection<CustomsBrokerPreferenceEntity> loadAllActive();

    void save(CustomsBrokerPreferenceEntity customsBrokerPreference);
}
