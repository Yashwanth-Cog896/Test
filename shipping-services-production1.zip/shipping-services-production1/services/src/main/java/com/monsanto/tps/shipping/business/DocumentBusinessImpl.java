package com.monsanto.tps.shipping.business;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.shipping.AttachmentUtil;
import com.monsanto.tps.shipping.config.S3Config;
import com.monsanto.tps.shipping.service.model.enums.DocumentEnum;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.io.FileUtils;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.*;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;

@Component("documentBusiness")
public class DocumentBusinessImpl implements DocumentBusiness {
    private static final Logger log = LogManager.getLogger(DocumentBusinessImpl.class);

    private static final String FOLDER_SEPARATOR = "/";

    @Autowired
    S3Config s3Config;

    @PostConstruct
    private void initializeS3Client() {
        s3Config.getClient();
    }

    @Override
    public List<String> saveAttachments(DocumentEnum documentEnum, Long id, List<Attachment> attachments) {
        handleAttachmentStreams(documentEnum, id, attachments);
        return retrieveFileNames(documentEnum, id);
    }

    @Override
    public List<String> retrieveFileNames(DocumentEnum documentEnum, Long id) {
        String folderName = generateS3Path(documentEnum, id, null);
        boolean folderExists = checkIfExists(folderName);

        List<String> fileNames = Collections.<String>emptyList();
        if (folderExists) {
            ListObjectsV2Request listObjectsV2Request = ListObjectsV2Request
                .builder()
                .bucket(s3Config.s3BucketName)
                .prefix(folderName)
                .build();

            ListObjectsV2Response res = s3Config.getClient().listObjectsV2(listObjectsV2Request);
            List<S3Object> contents = new ArrayList<>(res.contents());
            fileNames = extractFileNames(contents);
        }
        return fileNames;
    }

    @Async
    @Override
    public void deleteAsync(DocumentEnum documentEnum, Long id) {
        List<String> files = retrieveFileNames(documentEnum, id);
        for (String file: files) {
            delete(documentEnum, id, file);
        }
    }

    @Override
    public void delete(DocumentEnum documentEnum, Long id, String fileName) {
        String path = generateS3Path(documentEnum, id, fileName);
        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest
                .builder()
                .bucket(s3Config.s3BucketName)
                .key(path)
                .build();
        s3Config.getClient().deleteObject(deleteObjectRequest);
    }

    @Override
    public byte[] retrieveAttachment(DocumentEnum documentEnum, Long id, String fileName) {
        String filePath = generateS3Path(documentEnum, id, fileName);
        GetObjectRequest objectRequest = GetObjectRequest
                .builder()
                .key(filePath)
                .bucket(s3Config.s3BucketName)
                .build();
        return s3Config.getClient().getObjectAsBytes(objectRequest).asByteArray();
    }

    @Trace
    @Async
    public Future<byte[]> retrieveAttachmentAsync(DocumentEnum documentEnum, Long id, String fileName) {
        return new AsyncResult(retrieveAttachment(documentEnum, id, fileName));
    }

    @Override
    public boolean pathExists(DocumentEnum documentEnum, Long id){
        return checkIfExists(generateS3Path(documentEnum, id, null));
    }

    protected String generateS3Path(DocumentEnum documentEnum, Long id, String fileName) {
        StringBuilder basePath = getBasePath(documentEnum, id);
        return StringUtils.isNullOrEmpty(fileName) ? basePath.toString() : appendFileName(fileName, basePath).toString();
    }

    private StringBuilder getBasePath(DocumentEnum documentEnum, Long id) {
        return new StringBuilder()
                .append(documentEnum.getFolderName())
                .append(FOLDER_SEPARATOR)
                .append(String.valueOf(id))
                .append(FOLDER_SEPARATOR);
    }

    private StringBuilder appendFileName(String fileName, StringBuilder basePath) {
        return basePath.append(fileName);
    }

    /*
     * the folderName is the path
     * velocity-shipping/shipment/packing-list/964169078/
     */
    private boolean checkIfExists(String folderName) {
        try {
            ListObjectsV2Request request = ListObjectsV2Request
                    .builder()
                    .bucket(s3Config.s3BucketName)
                    .prefix(folderName)
                    .build();

            s3Config.getClient().listObjectsV2(request);
            return true;
        } catch (S3Exception e) {
            if (e.statusCode() == 404) {
                log.error("Object does not exist");
                return false;
            } else {
                log.error(e.toString());
                throw new ShippingWebException("Something went wrong while checking if the destination folder exists " + s3Config.s3BucketName + "/" + folderName, e);
            }
        }
    }

    private List<String> extractFileNames(List<S3Object> filePaths) {
        List<String> fileNames = new ArrayList<String>();
        for (S3Object filePath : filePaths) {
            String[] pathParts = filePath.key().split("/");
            fileNames.add(pathParts[pathParts.length - 1]);
        }
        return fileNames;
    }

    /**
     * Streams the inbound attachments to a tmp file, and then streams the tmp file contents to hdfs.  Ideally, we
     * would just connect the two streams, and let 'er rip; however, sometimes the hdfsProxy would need to stream
     * the contents more than once ( think cxf filters : wam, 302 handling, ... ) and in those cases, we would need
     * the initial stream ( or it's contents ) available somewhere.  We could keep a byte[] in memory, but then we
     * risk of hitting an OOME.  So, this solution tries to write the stream to a tmp file, use it for hdfs, and
     * then clean up - it's performance would be limited by the available IO on the server that the JVM is running on.
     *
     * @param documentEnum
     * @param id
     * @param attachments
     */
    private void handleAttachmentStreams(DocumentEnum documentEnum, Long id, List<Attachment> attachments) {
        for (Attachment attachment : attachments) {
            String attachmentFileName = AttachmentUtil.getFileName(attachment);
            String fileName = generateS3Path(documentEnum, id, attachmentFileName);
            File tmpFile = null;
            try {
                tmpFile = File.createTempFile(attachmentFileName, null);
                InputStream inputStream = attachment.getDataHandler().getInputStream();
                FileUtils.copyInputStreamToFile(inputStream, tmpFile);

                PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                        .bucket(s3Config.s3BucketName)
                        .key(fileName)
                        .build();
                s3Config.getClient().putObject(putObjectRequest, RequestBody.fromFile(tmpFile));
            } catch (S3Exception | IOException e) {
                System.err.println(e.getMessage());
            } finally {
                FileUtils.deleteQuietly(tmpFile);
            }
        }
    }
}
