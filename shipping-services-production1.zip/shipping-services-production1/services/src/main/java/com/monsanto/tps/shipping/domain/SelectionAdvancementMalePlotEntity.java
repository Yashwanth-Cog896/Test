package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "SLCTN_ADVNCMNT_MALE_PLT", schema = "MIDAS")
public class SelectionAdvancementMalePlotEntity {

    @Id
    @Column(name = "SLCTN_ADVNCMNT_MALE_PLT_ID")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "MALE_PLOT_ID", insertable = false, updatable = false)
    private PlotEntity malePlot;
    @Column(name = "INACTIVE_DTTM")
    private Date inactiveDttm;
    @OneToOne(optional = false)
    @JoinColumn(name = "SELECTION_ADVANCEMENT_ID", nullable = false)
    private SelectionAdvancementEntity selectionAdvancement;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlotEntity getMalePlot() {
        return malePlot;
    }

    public void setMalePlot(PlotEntity malePlot) {
        this.malePlot = malePlot;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public SelectionAdvancementEntity getSelectionAdvancement() {
        return selectionAdvancement;
    }

    public void setSelectionAdvancement(SelectionAdvancementEntity selectionAdvancement) {
        this.selectionAdvancement = selectionAdvancement;
    }
}
