
package com.monsanto.tps.shipping.sap.client.api;

import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiInfoTabItem;
import com.monsanto.tps.shipping.sap.client.api.model.SapDeliveryShipmentApiError;
import com.monsanto.tps.shipping.sap.client.api.model.SapDeliveryShipmentApiErrorTabBapi;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "errorTab",
        "errorTabBapi",
        "infoTab",
        "shipmentNbr"
})
@XmlRootElement(name = "DeliveryShipmentCreateResponse")
public class DeliveryShipmentCreateResponse {

    @XmlElementWrapper(name = "ErrorTab")
    @XmlElement(name = "item")
    private List<SapDeliveryShipmentApiError> errorTab = new ArrayList<SapDeliveryShipmentApiError>();

    @XmlElementWrapper(name = "ErrorTabBapi")
    @XmlElement(name = "item")
    private List<SapDeliveryShipmentApiErrorTabBapi> errorTabBapi;

    @XmlElementWrapper(name = "InfoTab")
    @XmlElement(name = "item", required = true)
    private List<SapApiInfoTabItem> infoTab;

    @XmlElement(name = "ShipmentNbr", required = true)
    private String shipmentNbr;

    public List<SapDeliveryShipmentApiError> getErrorTab() {
        return errorTab;
    }

    public void setErrorTab(List<SapDeliveryShipmentApiError> errorTab) {
        this.errorTab = errorTab;
    }

    public List<SapDeliveryShipmentApiErrorTabBapi> getErrorTabBapi() {
        return errorTabBapi;
    }

    public void setErrorTabBapi(List<SapDeliveryShipmentApiErrorTabBapi> errorTabBapi) {
        this.errorTabBapi = errorTabBapi;
    }

    public List<SapApiInfoTabItem> getInfoTab() {
        return infoTab;
    }

    public void setInfoTab(List<SapApiInfoTabItem> infoTab) {
        this.infoTab = infoTab;
    }

    public String getShipmentNbr() {
        return shipmentNbr;
    }

    public void setShipmentNbr(String shipmentNbr) {
        this.shipmentNbr = shipmentNbr;
    }

    public boolean hasErrors() {
        return !(CollectionUtils.isEmpty(errorTab) && CollectionUtils.isEmpty(errorTabBapi));
    }

    public String errorText() {
        Set<String> errorText = Sets.newHashSet();

        if (CollectionUtils.isNotEmpty(errorTab) ) {
            errorText.add(errorTab.get(0).getDesc());
        }
        if (CollectionUtils.isNotEmpty(errorTabBapi) ) {
           errorText.add(errorTabBapi.get(0).getMessage());
        }

        return CollectionUtils.isEmpty(errorText) ? "Failed to create SAP Delivery" : StringUtils.join(errorText, ", ");
    }
}
