package com.monsanto.tps.shipping.sap.client.api;

import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;

public interface SapApiOrderRequest {
    void setShipcenteruserid(String value);

    void setSapshiptonumber(String value);

    void setSapsoldtonumber(String value);

    void addItItem(SapApiOrderItem item);

    void setEndUse(String endUseVendorNumber);
}
