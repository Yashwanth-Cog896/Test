package com.monsanto.tps.shipping.business.reports.checklist;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfWriter;

import static com.itextpdf.text.Font.FontFamily.HELVETICA;

/**
 * Created by DCENGL
 */
public interface ChecklistSection {

    public static final Font SUB_SECTION_HEADER_FONT = new Font(HELVETICA, 8, Font.UNDERLINE);
    public static final Font SECTION_HEADER_FONT = new Font(HELVETICA, 8, Font.BOLD);
    public static final Font QUESTION_TEXT_FONT = new Font(HELVETICA, 8);

    float writeSection(Document document, PdfWriter writer, float startingY) throws DocumentException;

}
