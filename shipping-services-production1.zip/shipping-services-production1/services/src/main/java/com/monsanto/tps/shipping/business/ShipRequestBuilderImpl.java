package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.services.domain.contact.PostalAddress;
import com.monsanto.services.domain.shipping.Carrier;
import com.monsanto.services.domain.shipping.Commodity;
import com.monsanto.services.domain.shipping.CustomsBroker;
import com.monsanto.services.domain.shipping.Packaging;
import com.monsanto.services.domain.shipping.ServiceType;
import com.monsanto.services.domain.shipping.SignOption;
import com.monsanto.services.domain.shipping.contact.ShippingContact;
import com.monsanto.services.domain.shipping.contact.ShippingContactPostalAddress;
import com.monsanto.shipping.common.request.PackageRequest;
import com.monsanto.shipping.common.request.ShipRequest;
import com.monsanto.tps.shipping.business.integration.ClientProfileBusiness;
import com.monsanto.tps.shipping.dao.CarrierNoShipDateDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.domain.CarrierNoShipDate;
import com.monsanto.tps.shipping.domain.CommodityEntity;
import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;
import com.monsanto.tps.shipping.domain.ShipOptionType;
import com.monsanto.tps.shipping.domain.ShipmentAddressEntity;
import com.monsanto.tps.shipping.domain.ShipmentCarrierOptionEntity;
import com.monsanto.tps.shipping.domain.ShipmentContactEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShippingPreferenceTypeEntity;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * User: SDCHIL
 */
@Service
public class ShipRequestBuilderImpl implements ShipRequestBuilder {
    private double DEFAULT_DECLARED_VALUE = 1.00;

    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;
    @Autowired
    private CarrierNoShipDateDao carrierNoShipDateDao;
    @Autowired
    private ShippingPreferenceBusiness shippingPreferenceBusiness;
    @Autowired
    private ShipmentCarrierOptionBusiness shipmentCarrierOptionBusiness;
    @Autowired
    private ClientProfileBusiness clientProfileBusiness;
    @Autowired
    private CustomsBrokerBusiness customsBrokerBusiness;

    @Override
    public ShipRequest buildShipRequest(ShipmentEntity shipmentEntity) {
        ShipRequest shipRequest = new ShipRequest();
        shipRequest.setShipmentId(shipmentEntity.getShipmentId());
        shipRequest.setShipmentBarcode(shipmentEntity.getShipmentBarcode());
        shipRequest.setInsuredValue(shipmentEntity.getInsuredValue());
        shipRequest.setDeclaredValue(DEFAULT_DECLARED_VALUE);
        shipRequest.setRecipientContact(getShippingContact(shipmentEntity.getToAccountId(), shipmentEntity.getToContact(), shipmentEntity.getSapOrderNumber()));
        shipRequest.setRecipientAddress(getShippingAddress(shipmentEntity.getToAddress()));
        shipRequest.setRecipientCountryIsoCode(shipmentEntity.getToAddress().getIsoCountryCode());
        shipRequest.setSenderContact(getShippingContact(shipmentEntity.getFromAccountId(), shipmentEntity.getFromContact(), shipmentEntity.getSapOrderNumber()));
        shipRequest.setSenderAddress(getShippingAddress(shipmentEntity.getFromAddress()));
        shipRequest.setSenderCountryIsoCode(shipmentEntity.getFromAddress().getIsoCountryCode());

        Carrier carrier = new Carrier();
        carrier.setName(shipmentEntity.getCarrier().getName());
        carrier.setCarrierId(shipmentEntity.getCarrier().getCarrierId());
        carrier.setIntegrated(shipmentEntity.getCarrier().isSupportIntegratedShipping());
        shipRequest.setCarrier(carrier);
        shipRequest.setClientProfile(clientProfileBusiness.getClientProfile(carrier.getCarrierId(), shipmentEntity.getFromAccountId(), shipmentEntity.getFromContact().getIrdContactId()));
        shipRequest.setPackageRequests(getShipmentPackages(shipmentEntity.getShipmentContainers()));
        shipRequest.setShipDate(getNextAvailableShippingDate(shipmentCarrierOptionBusiness.getShipmentCarrierOptionByType(shipmentEntity.getShipmentCarrierOptions(), ShipOptionType.SERVICE_TYPE)));
        shipRequest.setPackaging(getPackaging(shipmentCarrierOptionBusiness.getShipmentCarrierOptionByType(shipmentEntity.getShipmentCarrierOptions(), ShipOptionType.PACKAGING)));
        shipRequest.setServiceType(getServiceType(shipmentCarrierOptionBusiness.getShipmentCarrierOptionByType(shipmentEntity.getShipmentCarrierOptions(), ShipOptionType.SERVICE_TYPE)));
        shipRequest.setSignOption(getSignOption(shipmentCarrierOptionBusiness.getShipmentCarrierOptionByType(shipmentEntity.getShipmentCarrierOptions(), ShipOptionType.SIGN_OPTION)));

        if (!shipRequest.getRecipientCountryIsoCode().equals(shipRequest.getSenderCountryIsoCode())) {
            if(shipmentEntity.isBrokerCheckRequired()) {
                shipRequest.setBroker(buildBroker(shipmentEntity.getFromAccountId(), shipRequest.getRecipientCountryIsoCode()));
            }
            shipRequest.setCommodities(buildCommodities(shipmentEntity.getCommodities()));
        }

        String costCenter = shippingPreferenceBusiness.getShippingPreferenceValue(ShippingPreferenceTypeEntity.COST_CENTER, shipmentEntity.getFromAccountId());
        if (costCenter == null || "".equals(costCenter)) {
            throw new ShippingWebException("Cost center not found for account [" + shipmentEntity.getFromAccountId() + "].  Please contact support.");
        }
        shipRequest.setCostCenter(costCenter);
        shipRequest.setFdaRegistrationNumber(shippingPreferenceBusiness.getShippingPreferenceValue(ShippingPreferenceTypeEntity.FDA_REGISTRATION_NUMBER, shipmentEntity.getFromAccountId()));
        shipRequest.setTaxIdentificationNumber(shippingPreferenceBusiness.getShippingPreferenceValue(ShippingPreferenceTypeEntity.TAX_IDENTIFICATION_NUMBER, shipmentEntity.getFromAccountId()));

        // TODO
        //shipRequest.setHandlingInstructions(getHandlingInstructions());
        //shipRequest.setBookingConfirmationNumber();

        shipRequest.setUnitOfMeasure(unitOfMeasureDao.getAbbreviationFromInventoryMgtUomId(shipmentEntity.getWeightUOMId()));
        ShipmentContainerEntity container = Iterables.get(shipmentEntity.getShipmentContainers(), 0);
        if (container.getDimensionUnitOfMeasureId() != null) {
            shipRequest.setDimensionsUnitOfMeasure(unitOfMeasureDao.getAbbreviationFromInventoryMgtUomId(container.getDimensionUnitOfMeasureId()));
        }

        shipRequest.setWeight(shipmentEntity.getWeight());
        return shipRequest;
    }

    private CustomsBroker buildBroker(Long fromAccountId, String recipientCountryIsoCode) {
        CustomsBrokerEntity customsBrokerEntity = customsBrokerBusiness.findEntityBy(fromAccountId, recipientCountryIsoCode);

        CustomsBroker customsBroker = new CustomsBroker();
        customsBroker.setCustomsBrokerId(customsBrokerEntity.getCustomsBrokerId());
        customsBroker.setName(customsBrokerEntity.getName());
        customsBroker.setAccountNumber(customsBrokerEntity.getAccountNumber());
        customsBroker.setTaxIdNumber(customsBrokerEntity.getTaxIdNumber());
        customsBroker.setAddress1(customsBrokerEntity.getAddress1());
        customsBroker.setAddress2(customsBrokerEntity.getAddress2());
        customsBroker.setCity(customsBrokerEntity.getCity());
        customsBroker.setStateProvince(customsBrokerEntity.getStateProvince());
        customsBroker.setPostalCode(customsBrokerEntity.getPostalCode());
        customsBroker.setCountryCode(customsBrokerEntity.getCountryCode());
        customsBroker.setCountryName(customsBrokerEntity.getCountryName());
        customsBroker.setCompanyName(customsBrokerEntity.getCompanyName());
        customsBroker.setEmailAddress(customsBrokerEntity.getEmailAddress());
        customsBroker.setFaxNumber(customsBrokerEntity.getFaxNumber());
        customsBroker.setPhoneNumber(customsBrokerEntity.getPhoneNumber());
        customsBroker.setPagerNumber(customsBrokerEntity.getPagerNumber());
        customsBroker.setComments(customsBrokerEntity.getComments());

        return customsBroker;
    }

    private List<Commodity> buildCommodities(Collection<CommodityEntity> commodities) {
        if (!CollectionUtils.isEmpty(commodities)) {
            return Lists.transform(Lists.newArrayList(commodities), new Function<CommodityEntity, Commodity>() {
                @Override
                public Commodity apply(@Nullable CommodityEntity commodityEntity) {
                    Commodity commodity = new Commodity();
                    commodity.setCommodityId(commodityEntity.getId());
                    commodity.setQuantity(commodityEntity.getQuantity());
                    commodity.setDescription(commodityEntity.getDescription());
                    commodity.setCountryOfManufactureCode(commodityEntity.getCountryOfManufactureISOCode());
                    commodity.setShipmentId(commodityEntity.getShipment().getShipmentId());
                    commodity.setTotalWeight(commodityEntity.getWeight());
                    commodity.setWeightUOMId(commodityEntity.getUnitOfMeasureId());
                    commodity.setTotalCustomsValue(commodityEntity.getCustomsValue());

                    return commodity;
                }
            });
        }
        return null;
    }

    private SignOption getSignOption(ShipmentCarrierOptionEntity signOptionShipOption) {
        return new SignOption(signOptionShipOption.getId(), signOptionShipOption.getCarrierShipOption().getCarrierEntity().getCarrierId(), signOptionShipOption.getCarrierShipOption().getShipOptionRefId());
    }

    private ServiceType getServiceType(ShipmentCarrierOptionEntity serviceTypeShipOption) {
        ServiceType serviceType = new ServiceType();
        serviceType.setServiceTypeID(serviceTypeShipOption.getId());
        serviceType.setShipOptionRefId(serviceTypeShipOption.getCarrierShipOption().getShipOptionRefId());
        serviceType.setName(serviceTypeShipOption.getCarrierShipOption().getShipOption());
        serviceType.setCarrierId(serviceTypeShipOption.getCarrierShipOption().getCarrierEntity().getCarrierId());
        return serviceType;
    }

    private Packaging getPackaging(ShipmentCarrierOptionEntity packagingOption) {
        return new Packaging(packagingOption.getId(), packagingOption.getCarrierShipOption().getCarrierEntity().getCarrierId(), packagingOption.getCarrierShipOption().getShipOptionRefId());
    }

    private ShippingContact getShippingContact(Long accountId, ShipmentContactEntity shipmentContactEntity, String sapOrderNumber) {
        ShippingContact shippingContact = new ShippingContact();
        shippingContact.setAccountId(accountId);
        shippingContact.setFirstName(StringUtils.isNotEmpty(sapOrderNumber) ? shipmentContactEntity.getCompanyName() : shipmentContactEntity.getAttention());
        shippingContact.setLastName("");
        shippingContact.setContactPhoneNumber(shipmentContactEntity.getPhoneNumber());
        shippingContact.setAccountName(shipmentContactEntity.getFirstName() + " " + shipmentContactEntity.getLastName());
        shippingContact.setEmailAddress(shipmentContactEntity.getEmail());
        return shippingContact;
    }

    private PostalAddress getShippingAddress(ShipmentAddressEntity shipmentAddressEntity) {
        PostalAddress postalAddress = new ShippingContactPostalAddress();
        postalAddress.setCity(shipmentAddressEntity.getCity());
        postalAddress.setCountry(shipmentAddressEntity.getCountry());
        postalAddress.setGeoCode(Integer.getInteger(shipmentAddressEntity.getGeoCode()));
        postalAddress.setLine1(shipmentAddressEntity.getAddressLine1());
        postalAddress.setLine2(shipmentAddressEntity.getAddressLine2());
        postalAddress.setLine3(shipmentAddressEntity.getAddressLine3());
        postalAddress.setState(shipmentAddressEntity.getState());
        postalAddress.setZipCode(shipmentAddressEntity.getPostalCode());
        postalAddress.setZipCodePlus4("");    // ???
        return postalAddress;
    }

    private Date getNextAvailableShippingDate(ShipmentCarrierOptionEntity serviceType) {
        // TODO: define these - in shipping-service it's GROUND_SERVICE_TYPE_IDENTIFIER
        return getNextAvailableBusinessDay(serviceType.getCarrierShipOption().getShipOption().toUpperCase().contains("GROUND"), new Date());
    }

    private Date getNextAvailableBusinessDay(Boolean allowWeekEndShipping, Date checkDate) {
        List<CarrierNoShipDate> carrierNoShipDates = getNonShipDays();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(checkDate);
        SimpleDateFormat sdf = new SimpleDateFormat("yy *yy-MM-dd");
        while (carrierNoShipDates.contains(sdf.format(calendar.getTime())) || weekendRollNeeded(calendar, allowWeekEndShipping)) {

            calendar.roll(Calendar.DATE, 1);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
        }
        return calendar.getTime();
    }

    private boolean weekendRollNeeded(Calendar calendar, Boolean allowWeekEndShipping) {
        boolean weekendDay = calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY;
        return weekendDay && (!allowWeekEndShipping);
    }

    private List<CarrierNoShipDate> getNonShipDays() {
        return carrierNoShipDateDao.findAll();
    }

    private List<PackageRequest> getShipmentPackages(Collection<ShipmentContainerEntity> shipmentContainerEntityCollection) {
        ShippingWebException.checkArgument(shipmentContainerEntityCollection != null && !shipmentContainerEntityCollection.isEmpty(), "Cannot ship shipment - no shipment containers found.");
        List<PackageRequest> packageRequests = new ArrayList<PackageRequest>();
        if (null != shipmentContainerEntityCollection && CollectionUtils.isNotEmpty(shipmentContainerEntityCollection)) {
            for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainerEntityCollection) {
                packageRequests.add(createPackageRequestForContainer(shipmentContainerEntity));
            }
        }
        return packageRequests;
    }

    private PackageRequest createPackageRequestForContainer(ShipmentContainerEntity shipmentContainerEntity) {
        PackageRequest shippingPackage = new PackageRequest();
        shippingPackage.setHeight(shipmentContainerEntity.getHeight());
        shippingPackage.setWeight(shipmentContainerEntity.getGrossWeight());
        shippingPackage.setWidth(shipmentContainerEntity.getWidth());
        shippingPackage.setLength(shipmentContainerEntity.getLength());
        shippingPackage.setContainerId(shipmentContainerEntity.getShipmentContainerId());
        return shippingPackage;
    }
}