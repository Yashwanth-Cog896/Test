package com.monsanto.tps.shipping.business;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.regulatory.common.db.dao.EventValidationDao;
import com.monsanto.tps.regulatory.common.db.model.EventValidationResult;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.StewardshipStoredProcResult;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Set;

/**
 * User: DCENGL
 */
@Service
public class StewardshipBusinessImpl implements StewardshipBusiness {

    public static final String COMMA = ",";
    public static final String PUERTO_RICO = "PUERTO RICO";
    public static final String UNITED_STATES = "UNITED STATES";
    @Autowired
    private RegulatedCountryBusiness regulatedCountryBusiness;
    @Autowired
    private EventHelper eventHelper;
    @Autowired
    private EventValidationDao eventValidationDao;

    @Autowired
    private ContactBusiness contactBusiness;

    @Trace
    @Override
    public Collection<Event> getEvents(ShipmentPackingListEntity packingListEntity, Collection<Event> events, Collection<String> eventsStrings) {
        Contact toContact = contactBusiness.getPartyContact(packingListEntity.getToContactId());
        String country = toContact.getCountry();

        Collection<Event> stewardedEvents = Lists.newArrayList();

        if (!regulatedCountryBusiness.isCountryRegulatedByStewardship(country)) {
            return stewardedEvents;
        }

        Collection<EventValidationResult> results = eventValidationDao.getStewardshipCountries(eventsStrings);
        Multimap<String, String> countryCodeToEventsMap = HashMultimap.create();

        for (EventValidationResult result : results) {
            Set<String> eventNames = Sets.newHashSet(result.getRegulatedEvents().split(COMMA));
            countryCodeToEventsMap.put(result.getCountryCode(), eventHelper.getSortedEvent(eventNames));
        }

        String toCountryCodeOfPackingList = regulatedCountryBusiness.lookUpCountryAbbr(country);
        Set<String> regulatedEvents = Sets.newHashSet(countryCodeToEventsMap.get(isPuertoRico(toCountryCodeOfPackingList) ? getUsaAbbr() : toCountryCodeOfPackingList));

        if (regulatedEvents != null) {
            for (Event event : events) {
                boolean regulatedByMale = event.getMaleEventString() != null && regulatedEvents.contains(event.getMaleEventString());
                if (regulatedEvents.contains(event.getEventString()) || regulatedByMale) {
                    if (event.getRegulatingAgencies().isEmpty()) {
                        event.getRegulatingAgencies().add(AgencyEnum.STEWARDSHIP);
                        //if the passed in event is already regulatedByMale then we don't want to set it to false if the male isn't stewarded
                        if (regulatedByMale) {
                            event.setRegulatedByMale(true);
                        }
                        stewardedEvents.add(event);
                    }
                }
            }
        }
        return stewardedEvents;
    }

    @Override
    public void addStewardedEventDetails(EventDetails eventDetails, String countryAbbreviation) {
        Collection<EventValidationResult> results = eventValidationDao.getStewardshipCountries(Lists.newArrayList(eventDetails.getEventString()));
        Multimap<String, String> countryCodeToEventsMap = HashMultimap.create();

        boolean stewardship = false;

        if (!CollectionUtils.isEmpty(results)) {
            Collection<StewardshipStoredProcResult> stewardshipStoredProcResults = Lists.newArrayList();
            for (EventValidationResult result : results) {
                String matchedEvent = eventHelper.getSortedEvent(Sets.newHashSet(result.getRegulatedEvents().split(COMMA)));
                countryCodeToEventsMap.put(result.getCountryCode(), matchedEvent);

                StewardshipStoredProcResult stewardshipStoredProcResult = new StewardshipStoredProcResult();
                stewardshipStoredProcResult.setCountry(result.getCountryCode());
                stewardshipStoredProcResult.setMatchedEvent(matchedEvent);

                stewardshipStoredProcResults.add(stewardshipStoredProcResult);

                if (countryAbbreviation.equals(result.getCountryCode()) && eventDetails.getEventString().equals(matchedEvent)) {
                    stewardship = true;
                }
            }
            eventDetails.setStewardshipStoredProcResults(stewardshipStoredProcResults);
        }

        eventDetails.setStewardship(stewardship);
    }

    private String getUsaAbbr() {
        return regulatedCountryBusiness.lookUpCountryAbbr(UNITED_STATES);
    }

    private boolean isPuertoRico(String toCountryCodeOfPackingList) {
        return toCountryCodeOfPackingList.equalsIgnoreCase(regulatedCountryBusiness.lookUpCountryAbbr(PUERTO_RICO));
    }
}
