package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.ShipmentBusiness;
import com.monsanto.tps.shipping.business.ShipmentContainerBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.business.labels.LabelBusiness;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.PrintOptions;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Map;

import static com.google.common.base.Preconditions.checkArgument;

@Component("printingService")
public class PrintingServiceImpl implements PrintingService {
    private static final Log LOG = LogFactory.getLog(PrintingServiceImpl.class);

    public static final String SHIPMENT_CONTAINER_ID_NOT_NULL = "Shipment container id cannot be null";
    public static final String PRINTER_ID_CANNOT_BE_NULL = "Printer id cannot be null";
    public static final String PACKING_LIST_ID_CANNOT_BE_NULL = "Packing list id cannot be null";
    public static final String SHIPMENT_ID_CANNOT_BE_NULL = "Shipment id cannot be null";

    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Autowired
    private ShipmentBusiness shipmentBusiness;

    @Autowired
    private LabelBusiness labelBusiness;

    @Override
    @Transactional
    public void printContainmentLabels(Long shipmentContainerId, Long printerId, PrintOptions printOptions) {
        checkArgument(shipmentContainerId != null, SHIPMENT_CONTAINER_ID_NOT_NULL);
        checkArgument(printerId != null, PRINTER_ID_CANNOT_BE_NULL);

        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);

        //Temporarily adding this fix until client fix is done.
        printOptions.getContainmentLayers().removeAll(Collections.singleton(null));
        labelBusiness.printContainmentLabels(shipmentContainerEntity, printerId, printOptions);
    }

    @Override
    @Transactional
    public void printAllContainmentLabels(Long packingListId, Long printerId, PrintOptions printOptions) {
        checkArgument(packingListId != null, PACKING_LIST_ID_CANNOT_BE_NULL);
        checkArgument(printerId != null, PRINTER_ID_CANNOT_BE_NULL);

        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        //Temporarily adding this fix until client fix is done.
        printOptions.getContainmentLayers().removeAll(Collections.singleton(null));
        labelBusiness.printAllContainmentLabels(packingList, printerId, printOptions);
    }

    @Override
    @Transactional
    public void printCarrierLabel(Long shipmentContainerId, Long printerId) {
        checkArgument(shipmentContainerId != null, SHIPMENT_CONTAINER_ID_NOT_NULL);
        checkArgument(printerId != null, PRINTER_ID_CANNOT_BE_NULL);

        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);
        labelBusiness.printCarrierLabels(Lists.newArrayList(shipmentContainerEntity), printerId);
    }

    @Override
    @Transactional
    public void printAllCarrierLabels(Long shipmentId, Long printerId) {
        checkArgument(shipmentId != null, SHIPMENT_ID_CANNOT_BE_NULL);
        checkArgument(printerId != null, PRINTER_ID_CANNOT_BE_NULL);

        ShipmentEntity shipmentEntity = shipmentBusiness.getShipment(shipmentId);
        labelBusiness.printCarrierLabels(shipmentEntity.getShipmentContainers(), printerId);
    }

    @Override
    @Transactional
    public Map<String, String> viewLabel(Long packingListId, String containmentLayer, Integer boxNumber, Boolean printTotalBoxes) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        return labelBusiness.viewLabel(packingList, containmentLayer, boxNumber, printTotalBoxes);

    }

}
