package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.Collection;

@Entity
@DiscriminatorValue("INVENTORY")
public class InventoryScannedContainerEntity extends ScannedContainerEntity<InventoryEntity> {

    @Column(name = "BARCODE_NBR")
    private String barcode;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "barcode_nbr", referencedColumnName = "barcode", insertable = false, updatable = false)
    private InventoryEntity inventoryEntity;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SCANNED_CONTAINER_ID", referencedColumnName = "SCANNED_CONTAINER_ID")
    private Collection<RegulatedInventoryMovementEntity> regulatedInventoryMovements;

    @Override
    public void setContent(InventoryEntity contentEntity) {
        inventoryEntity = contentEntity;
        if (contentEntity != null) {
            barcode = inventoryEntity.getBarcode();
        }
    }

    public String getBarcode() {
        return barcode;
    }

    public InventoryEntity getInventoryEntity() {
        return inventoryEntity;
    }

    @Override
    public InventoryEntity getContent() {
        return inventoryEntity;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.INVENTORY;
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return regulatedInventoryMovements;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        if (regulatedInventoryMovements != null) {
            regulatedInventoryMovements.add(newMovement);
        } else {
            regulatedInventoryMovements = Lists.newArrayList(newMovement);
        }
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        this.regulatedInventoryMovements = movements;
    }
}

