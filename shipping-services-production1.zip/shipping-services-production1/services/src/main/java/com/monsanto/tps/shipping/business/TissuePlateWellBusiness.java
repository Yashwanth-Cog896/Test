package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.TissuePlateWellEntity;

import java.util.List;

/**
 * Created by DCENGL
 */
public interface TissuePlateWellBusiness {
    List<TissuePlateWellEntity> getTissuePlateWells(ShipmentPackingListEntity packingListEntity);
}
