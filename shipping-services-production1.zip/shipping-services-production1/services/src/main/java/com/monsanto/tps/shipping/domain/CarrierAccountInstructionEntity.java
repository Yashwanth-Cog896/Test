package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: SDCHIL
 */
@Entity
@Table(name = "CARRIER_CURR_INSTRUCT", schema = "INVENTORY_MGT")
public class CarrierAccountInstructionEntity {

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    @Column(name = "CARRIER_CURR_INSTRUCT_ID", nullable = false)
    private Long carrierAccountInstructionId;

    @Column(name = "CARRIER_ID")
    private Long carrierId;

    @Column(name = "IRD_ACCT")
    private Long irdAccountId;

    @Column(name = "SENDER_ACCOUNT_NUMBER")
    private String senderAccountNumber;

    @Column(name = "METER_NUMBER")
    private String meterNumber;

    @Column(name = "CONTACT_ID")
    private Long contactId;

    public Long getCarrierAccountInstructionId() {
        return carrierAccountInstructionId;
    }

    public void setCarrierAccountInstructionId(Long carrierAccountInstructionId) {
        this.carrierAccountInstructionId = carrierAccountInstructionId;
    }

    public Long getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(Long carrierId) {
        this.carrierId = carrierId;
    }

    public Long getIrdAccountId() {
        return irdAccountId;
    }

    public void setIrdAccountId(Long irdAccountId) {
        this.irdAccountId = irdAccountId;
    }

    public String getSenderAccountNumber() {
        return senderAccountNumber;
    }

    public void setSenderAccountNumber(String senderAccountNumber) {
        this.senderAccountNumber = senderAccountNumber;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }
}
