package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.AgencyRequestBusiness;
import com.monsanto.tps.shipping.business.PermitBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.PermitAssociationDetails;
import com.monsanto.tps.shipping.util.RegulatedStatusHandler;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.util.Collection;
import java.util.Date;

/**
 * User: DCENGL
 */
@Component("permitService")
public class PermitServiceImpl implements PermitService {

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Autowired
    private PermitBusiness permitBusiness;

    @Autowired
    private AgencyRequestBusiness agencyRequestBusiness;

    @Autowired
    private RegulatedStatusHandler regulatedStatusHandler;

    @Override
    @Trace
    @Transactional
    public Collection<Event> getPermits(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        Collection<Event> regulatedEvents = getEvents(packingList);

        return regulatedEvents;
    }

    @Override
    @Trace
    @Transactional
    public Collection<Event> getPermitsForEvents(Long packingListId, Collection<Event> events) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        permitBusiness.setPermitsOnEvents(packingList, events);

        return events;
    }

    private Collection<Event> getEvents(ShipmentPackingListEntity packingList) {
        Collection<Event> regulatedEvents = permitBusiness.getRegulatedEvents(packingList);

        //TODO this could probably be done on the client
        filterOutMaleEventStringsThatAreNotRegulated(regulatedEvents);
        return regulatedEvents;
    }

    private void filterOutMaleEventStringsThatAreNotRegulated(Collection<Event> regulatedEvents) {
        for (Event regulatedEvent : regulatedEvents) {
            if (!regulatedEvent.isRegulatedByMale()) {
                regulatedEvent.setMaleEventString(null);
            }
        }
    }

    @Override
    @Trace
    @Transactional
    public void associatePermits(Long packingListId, Collection<Event> events) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        // TODO may need event/permit association validation
        permitBusiness.associatePermits(packingList, events);
        packingList.setComplianceConfirmedDate(new Date());
    }

    @Override
    @Trace
    @Transactional
    public Collection<Event> getAssociatedPermits(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        return permitBusiness.loadAssociatedPermits(packingList);
    }

    @Override
    @Trace
    @Transactional
    public Permit validateUserEnteredARNumber(Long packingListId, String userEnteredArNumber, Event event){
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        Collection<Permit> permits = permitBusiness.validatePermitForEvent(packingList,event);

        for(Permit permit : permits){
            if(permit.getApprovalNumber() != null && permit.getApprovalNumber().equals(userEnteredArNumber)) {
                 return permit;
            }
        }

        throw new ShippingWebException("Not a valid AR number");
    }

    @Override
    @Trace
    @Transactional
    public boolean finalRegulatedCheck(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        if(regulatedStatusHandler.complianceDisabled(packingList.getShipmentType().getShipmentTypeEnum())){
            return true;
        }

        Collection<Event> validEvents = getEvents(packingList);

        boolean complianceValid = permitBusiness.isComplianceValid(validEvents);
        if (!complianceValid) {
            packingList.setComplianceConfirmedDate(null);
            shipmentPackingListBusiness.save(packingList);
        }

        return complianceValid;
    }

    @Transactional
    @Trace
    @Override
    public Collection<Permit> findPermitsForEvent(String eventStack) {
        return permitBusiness.findPermitsForEvent(eventStack);
    }

    @Transactional
    @Trace
    @Override
    public PermitAssociationDetails findPermitAssociations(String approvalNumber) {
        AgencyRequestEntity agencyRequestEntity = agencyRequestBusiness.getAgencyRequest(approvalNumber);

        if (agencyRequestEntity == null) {
            throw new WebApplicationException(Response.status(Response.Status.NOT_FOUND).entity("Approval Number [" + approvalNumber + "] Not Found").build());
        }

        return permitBusiness.findPermitAssociations(agencyRequestEntity);
    }
}
