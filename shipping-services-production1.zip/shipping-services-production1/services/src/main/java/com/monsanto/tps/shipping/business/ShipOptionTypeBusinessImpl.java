package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.ShipOptionTypeDao;
import com.monsanto.tps.shipping.domain.ShipOptionTypeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Service
public class ShipOptionTypeBusinessImpl implements ShipOptionTypeBusiness {

    @Autowired
    private ShipOptionTypeDao shipOptionTypeDao;

    @Override
    public ShipOptionTypeEntity findShipOptionType(long shipOptionTypeId) {
        return shipOptionTypeDao.getShipOptionType(shipOptionTypeId);
    }

    @Override
    public void saveShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity) {
        shipOptionTypeDao.saveShipOptionType(shipOptionTypeEntity);
    }

    @Override
    public List<ShipOptionTypeEntity> findAllShipOptionTypes() {
        return shipOptionTypeDao.findAllShipOptionTypes();
    }
}