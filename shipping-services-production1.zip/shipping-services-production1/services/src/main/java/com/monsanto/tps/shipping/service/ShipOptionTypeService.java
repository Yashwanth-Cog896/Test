package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.ShipOptionType;
import javax.ws.rs.*;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by KERRA on 5/19/2014.
 */
@Path("/ship-option-type")
public interface ShipOptionTypeService {

    @PUT
    @Path("/{ship-option-type-id}")
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    void saveShipOptionType(@PathParam("ship-option-type-id") Long shipOptionTypeId);

    @GET
    @Path("/{ship-option-type-id}")
    @Produces(APPLICATION_JSON)
    ShipOptionType findShipOptionType(@PathParam("ship-option-type-id") Long shipOptionTypeId);

    @GET
    @Path("/")
    @Produces(APPLICATION_JSON)
    List<ShipOptionType> findAllShipOptionTypes();
}