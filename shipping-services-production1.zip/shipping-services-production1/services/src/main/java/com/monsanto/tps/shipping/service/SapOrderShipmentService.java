package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.SapOrderShipment;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/sap-order-shipment")
public interface SapOrderShipmentService {

    //TODO THIS IS TO AID TESTING
    @GET
    @Path("/")
    @Produces(APPLICATION_JSON)
    public List<SapOrderShipment> getAllSapOrderShipments();

    //TODO THIS IS TO AID TESTING
    @GET
    @Path("/order-number/{orderNumber}")
    @Produces(APPLICATION_JSON)
    public SapOrderShipment getSapOrderShipmentForOrderNumber(@PathParam("orderNumber") String orderNum);

    @GET
    @Path("/{order-shipment-id}")
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    public SapOrderShipment getSapOrderShipment(@PathParam("order-shipment-id") Long orderShipmentId);

    @POST
    @Consumes(APPLICATION_JSON)
    public String editSapOrderShipmentStatus(SapOrderShipment sapOrderShipment);

    @POST
    @Path("/status-update/lc")
    @Consumes(APPLICATION_JSON)
    public String editSapOrderShipmentLcStatus(SapOrderShipment sapOrderShipment);

    @PUT
    @Consumes(APPLICATION_JSON)
    @Path("/{order-shipment-id}")
    public SapOrderShipment saveSapOrderShipment(SapOrderShipment sapOrderShipment);

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/{order-shipment-id}/send-sap-update")
    public SapOrderShipment sendSapUpdate(SapOrderShipment sapOrderShipment,
                                          @QueryParam("validateWeights") boolean validateWeights);

    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/{order-shipment-id}/send-sap-create")
    public SapOrderShipment createOrder(SapOrderShipment sapOrderShipment);

    @POST
    @Consumes(APPLICATION_JSON)
    @Path("/{order-shipment-id}/request-lc-approval")
    public SapOrderShipment requestLcApproval(SapOrderShipment sapOrderShipment);


    @POST
    @Path("/{order-shipment-id}/create-sap-delivery")
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    public SapOrderShipment createSapDelivery(@PathParam("order-shipment-id") Long orderShipmentId);
}