package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.CustomsBrokerBusiness;
import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;
import com.monsanto.tps.shipping.service.model.CustomsBroker;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by TMILB on 7/9/14.
 */
@Component("customsBrokerService")
public class CustomsBrokerServiceImpl implements CustomsBrokerService {

    @Autowired
    private CustomsBrokerBusiness customsBrokerBusiness;

    @Trace
    @Override
    @Transactional(readOnly = true)
    public CustomsBroker getBroker(Long accountId, String countryCode) {
       return customsBrokerBusiness.findBy(accountId, countryCode);
    }

    @Trace
    @Override
    @Transactional(readOnly = true)
    public Collection<CustomsBroker> getBrokers() {
        Collection<CustomsBroker> customsBrokers = Lists.newArrayList();


        Collection<CustomsBrokerEntity> customsBrokerEntities = customsBrokerBusiness.loadAll();

        for (CustomsBrokerEntity customsBrokerEntity : customsBrokerEntities) {
            CustomsBroker customsBroker = new CustomsBroker();
            customsBroker.setCustomsBrokerId(customsBrokerEntity.getCustomsBrokerId());
            customsBroker.setBrokerName(customsBrokerEntity.getName());
            customsBroker.setCompanyName(customsBrokerEntity.getCompanyName());
            customsBroker.setAddress1(customsBrokerEntity.getAddress1());
            customsBroker.setAddress2(customsBrokerEntity.getAddress2());
            customsBroker.setCity(customsBrokerEntity.getCity());
            customsBroker.setPhoneNumber(customsBrokerEntity.getPhoneNumber());
            customsBroker.setCountryName(customsBrokerEntity.getCountryName());

            customsBrokers.add(customsBroker);
        }

        return customsBrokers;
    }
}
