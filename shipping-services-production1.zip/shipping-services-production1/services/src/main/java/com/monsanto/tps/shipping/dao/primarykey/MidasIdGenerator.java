package com.monsanto.tps.shipping.dao.primarykey;

import org.hibernate.id.IdentifierGenerator;

public interface MidasIdGenerator extends IdentifierGenerator {
    long getNextId();
}
