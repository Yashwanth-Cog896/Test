package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.SapOrderItemBusiness;
import com.monsanto.tps.shipping.business.SapOrderShipmentBusiness;
import com.monsanto.tps.shipping.converter.SapOrderShipmentConverter;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.service.model.SapOrderShipment;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkArgument;

@Component("sapOrderShipmentService")
public class SapOrderShipmentServiceImpl implements SapOrderShipmentService {
    private static final Log LOG = LogFactory.getLog(SapOrderShipmentServiceImpl.class);
    public static final String NULL_SAP_ORDER_SHIPMENT = "No Sap Order Shipment Data Received";
    public static final String NULL_DELIVERY_BLOCK_CODE = "No Delivery Block Code Received";
    public static final String INVALID_DELIVERY_BLOCK_CODE = "Invalid Delivery Block Code";
    public static final String NO_ITEMS_REJECTED = "No Order Items Marked as Rejected";

    @Autowired
    private SapOrderShipmentBusiness sapOrderShipmentBusiness;

    @Autowired
    private SapOrderItemBusiness sapOrderItemBusiness;

    @Autowired
    private SapOrderShipmentConverter sapOrderShipmentConverter;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<SapOrderShipment> getAllSapOrderShipments() {
        SapOrderShipment shipment;

        List<SapOrderShipmentEntity> entities = sapOrderShipmentBusiness.getAllSapOrderShipments();
        List<SapOrderShipment> domainList = new ArrayList<SapOrderShipment>();
        for (SapOrderShipmentEntity entity : entities) {
            shipment = createSapOrderShipmentFromEntity(entity);
            domainList.add(shipment);
        }
        return domainList;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public SapOrderShipment getSapOrderShipmentForOrderNumber(String orderNum) {
        SapOrderShipmentEntity entity = sapOrderShipmentBusiness.findBySapOrderNumber(orderNum);
        return createSapOrderShipmentFromEntity(entity);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public SapOrderShipment getSapOrderShipment(Long orderShipmentId) {
        SapOrderShipmentEntity entity = sapOrderShipmentBusiness.getSapOrderShipmentById(orderShipmentId);
        SapOrderShipment shipment = createSapOrderShipmentFromEntity(entity);
        List<SapOrderItem> updatedItems = sapOrderItemBusiness.deriveSapOrderItems(orderShipmentId);
        shipment.setOrderItems(updatedItems);
        return shipment;
    }

    @Trace
    @Override
    @Transactional
    public String editSapOrderShipmentStatus(SapOrderShipment sapOrderShipment) {
        return sapOrderShipmentBusiness.editSapOrderShipmentStatus(sapOrderShipment);
    }

    @Trace
    @Override
    @Transactional
    public String editSapOrderShipmentLcStatus(SapOrderShipment sapOrderShipment) {
        checkArgument(sapOrderShipment != null, NULL_SAP_ORDER_SHIPMENT);
        try {
            checkArgument(sapOrderShipment.getDeliveryBlockCode() != null, NULL_DELIVERY_BLOCK_CODE);
            checkArgument(
                    sapOrderShipment.getDeliveryBlockCode().equals("R2") ||
                            StringUtils.isEmpty(sapOrderShipment.getDeliveryBlockCode()) ||
                            "XX".equalsIgnoreCase(sapOrderShipment.getDeliveryBlockCode()),
                    INVALID_DELIVERY_BLOCK_CODE + ": " + sapOrderShipment.getDeliveryBlockCode());
            if (sapOrderShipment.getDeliveryBlockCode().equals("R2")) {
                checkArgument(sapOrderShipment.getOrderItems() != null && sapOrderShipment.getOrderItems().size() > 0,
                        NO_ITEMS_REJECTED);
            }
            return sapOrderShipmentBusiness.editSapOrderShipmentLcStatus(sapOrderShipment);
        } catch (RuntimeException e) {
            LOG.error("failed to updated sap status for: " + sapOrderShipment.getSapOrderNumber(),  e);
            throw e;
        }
    }

    @Trace
    @Override
    @Transactional
    public SapOrderShipment createSapDelivery(Long orderShipmentId) {
        SapOrderShipmentEntity entity = sapOrderShipmentBusiness.getSapOrderShipmentById(orderShipmentId);
        SapOrderShipment sapOrderShipment = createSapOrderShipmentFromEntity(entity);
        return sapOrderShipmentBusiness.createSapDelivery(sapOrderShipment, entity);
    }

    @Trace
    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public SapOrderShipment saveSapOrderShipment(SapOrderShipment sapOrderShipment) {
        sapOrderShipmentBusiness.saveOrderShipment(sapOrderShipment);
        return sapOrderShipment;
    }

    @Override
    @Transactional
    public SapOrderShipment createOrder(SapOrderShipment sapOrderShipment) {
        sapOrderShipmentBusiness.sendCreateOrder(sapOrderShipment);
        return sapOrderShipment;
    }

    @Override
    @Transactional
    public SapOrderShipment sendSapUpdate(SapOrderShipment sapOrderShipment, boolean validateWeights) {
        sapOrderShipmentBusiness.sendUpdateOrder(sapOrderShipment, validateWeights);
        return sapOrderShipment;
    }

    @Override
    @Transactional
    public SapOrderShipment requestLcApproval(SapOrderShipment sapOrderShipment) {
        sapOrderShipmentBusiness.requestLcApproval(sapOrderShipment);
        return sapOrderShipment;
    }

    private SapOrderShipment createSapOrderShipmentFromEntity(SapOrderShipmentEntity entity) {
        return sapOrderShipmentConverter.convertSapOrderShipment(entity);
    }

}
