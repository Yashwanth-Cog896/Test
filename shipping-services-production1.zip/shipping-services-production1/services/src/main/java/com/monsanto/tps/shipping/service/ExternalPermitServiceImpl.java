package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.ExternalPermitBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ExternalPermit;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Component("externalComplianceService")
public class ExternalPermitServiceImpl implements ExternalPermitService {

    @Autowired
    private ExternalPermitBusiness externalPermitBusiness;

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Override
    @Transactional
    @Trace
    public Collection<ExternalPermit> getAssociatedExternalPermits(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        Collection<ExternalPermitEntity> externalPermitEntitiesForPackingList = externalPermitBusiness.getExternalPermitsForPackingList(packingList);

        return toTransferObjects(externalPermitEntitiesForPackingList);
    }

    private Collection<ExternalPermit> toTransferObjects(Collection<ExternalPermitEntity> externalPermitEntities) {
        Collection<ExternalPermit> externalPermits = Lists.newArrayList();
        for (ExternalPermitEntity externalPermitEntity : externalPermitEntities) {
            ExternalPermit externalPermit = new ExternalPermit();
            externalPermit.setAgency(externalPermitEntity.getOtherAgencyName());
            AgencyEntity agency = externalPermitEntity.getAgency();
            if (agency != null) {
                externalPermit.setAgencyId(agency.getAgencyId());
            }
            externalPermit.setExpirationDate(externalPermitEntity.getExpirationDate());
            externalPermit.setId(externalPermitEntity.getId());
            externalPermit.setMaterialDescription(externalPermitEntity.getMaterialDescription());
            externalPermit.setPermitName(externalPermitEntity.getPermitNumber());
            externalPermit.setShipmentContainerId(externalPermitEntity.getShipmentContainer().getShipmentContainerId());
            externalPermit.setConstructName(externalPermitEntity.getConstructName());
            externalPermit.setExternalMaterialType(externalPermitEntity.getExternalMaterialType().getExternalMaterialTypeId());
            externalPermit.setEventName(externalPermitEntity.getEventName());

            externalPermits.add(externalPermit);
        }

        return externalPermits;
    }
    
    @Override
    @Transactional
    @Trace
    public ExternalPermit save(ExternalPermit externalPermit) {
        ExternalPermitEntity externalPermitEntity = externalPermitBusiness.save(externalPermit);
        externalPermit.setId(externalPermitEntity.getId());

        return externalPermit;
    }

    @Trace
    @Override
    @Transactional
    public ExternalPermit update(ExternalPermit externalPermit) {
        externalPermitBusiness.save(externalPermit);

        return externalPermit;
    }

    @Override
    @Transactional
    @Trace
    public void delete(Long externalPermitId) {
        externalPermitBusiness.delete(externalPermitId);
    }
}
