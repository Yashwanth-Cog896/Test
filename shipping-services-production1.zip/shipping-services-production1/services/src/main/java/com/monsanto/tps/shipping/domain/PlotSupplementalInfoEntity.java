package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PLOT_SUPPLEMENTAL_INFO", schema = "MIDAS")
public class PlotSupplementalInfoEntity {

    @Id
    @Column(name = "PLOT_SPLMTL_INFO_ID", nullable = false)
    private Long id;

    @OneToOne()
    @JoinColumn(name = "PLOT_ID")
    private PlotEntity plot;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SHIPTO_BR_PROG_ID")
    private ProgramEntity shipToProgram;

    public Long getPlotSupplementalInfoId() {
        return id;
    }

    public void setPlotSupplementalInfoId(Long id) {
        this.id = id;
    }

    public ProgramEntity getShipToProgram() {
        return shipToProgram;
    }

    public void setShipToProgram(ProgramEntity program) {
        this.shipToProgram = program;
    }

    public String toString() {
        return "PlotSupplementalInfoEntity{" +
            "id=" + getPlotSupplementalInfoId() +
            "}";
    }

    public PlotEntity getPlot() {
        return plot;
    }

    public void setPlot(PlotEntity plot) {
        this.plot = plot;
    }
}
