package com.monsanto.tps.shipping.sap.client.api.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * User: pgadi
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapDeliveryShipmentApiError", propOrder = {
        "error",
        "id",
        "desc"
})
public class SapDeliveryShipmentApiError {
    @XmlElement(name = "error", required = true)
    private String error;
    @XmlElement(name = "id", required = true)
    private String id;
    @XmlElement(name = "desc", required = true)
    private String desc;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
