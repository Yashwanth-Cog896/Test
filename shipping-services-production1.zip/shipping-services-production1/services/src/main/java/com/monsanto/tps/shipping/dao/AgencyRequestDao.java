package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.service.model.State;

import java.util.Collection;
import java.util.Set;

/**
 * User: pgadi
 */
public interface AgencyRequestDao {

    Collection<AgencyRequestEntity> agencyRequestsForMonsantoIds(Set<String> monsantoIds);

    AgencyRequestEntity findAgencyRequestByApprovalNumber(String approvalNumber);

    Collection<State> findStatesCoveredByEUP(String eup);

}
