package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.InternationalCompositesBusiness;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("internationalCustomerService")
public class InternationalCustomerServiceImpl implements InternationalCustomerService {

    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    public InternationalCustomer getCustomer(String id) {
        return internationalCompositesBusiness.getCustomer(id);
    }

    public List<InternationalCustomer> getCustomers() {
        return internationalCompositesBusiness.getCustomers();
    }
}
