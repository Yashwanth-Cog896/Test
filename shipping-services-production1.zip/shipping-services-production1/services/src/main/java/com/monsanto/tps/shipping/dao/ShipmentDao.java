package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentEntity;

import java.util.Date;
import java.util.List;

/**
 * User: PGADI
 */
public interface ShipmentDao {

    public void saveShipment(ShipmentEntity shipmentEntity);

    public ShipmentEntity findByBarcode(String barcode);

    public List<ShipmentEntity> getShipments(Long accountId, Date shippedDate, boolean retrieveByFromAccountId,
                                             List<String> validStatuses);

    public List<ShipmentEntity> getShipmentsByCountry(String countryCode, Date shippedDate, boolean retrieveByFrom,
                                                      List<String> validStatuses);

    void delete(ShipmentEntity shipment);

    ShipmentEntity load(Long shipmentId);

    List<ShipmentEntity> getUndeliveredShipments(Long carrierId);


}
