package com.monsanto.tps.shipping.domain;

import com.monsanto.tps.shipping.service.model.SapOrderItem;
import org.apache.commons.lang.StringUtils;

public class SapOrderItemKey {

    private String countryOfOrigin;
    private String eventStack;
    private String storageContainerBarcode;
    private String boxNumber;

    public SapOrderItemKey(String country, String events, String code, String boxNum) {
        if ((country == null) || (events == null) || (code == null) || (boxNum == null)) {
            throw new IllegalArgumentException("Null argument(s) found");
        }
        countryOfOrigin = country;
        eventStack = events;
        storageContainerBarcode = code;
        boxNumber = boxNum;
    }

    public SapOrderItemKey(SapOrderItem itemDto) {
        countryOfOrigin = itemDto.getCountryOfOrigin();
        eventStack = itemDto.getEventStack();
        storageContainerBarcode = itemDto.getStorageContainerBarcode();
        boxNumber = itemDto.getBoxNumber();
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public String getEventStack() {
        return eventStack;
    }

    public String getStorageContainerBarcode() {
        return storageContainerBarcode;
    }

    public String getBoxNumber() {
        return boxNumber;
    }

    public int hashCode() {
        int hashCode = 17;
        String country = getCountryOfOrigin();
        hashCode = hashCode * 31 + country.hashCode();
        String events = getEventStack();
        if(!StringUtils.isEmpty(events)) {
            hashCode = hashCode * 31 + events.hashCode();
        }
        String code = getStorageContainerBarcode();
        hashCode = hashCode * 31 + code.hashCode();
        return hashCode;
    }

    public boolean equals(Object o) {
        boolean eventMatch;
        boolean isEqual = false;

        if (o instanceof SapOrderItemKey) {

            SapOrderItemKey that = (SapOrderItemKey) o;

            if(StringUtils.isEmpty(that.getEventStack())) {
                eventMatch = StringUtils.isEmpty(getEventStack());
            } else {
                eventMatch = that.getEventStack().equals(getEventStack());
            }

            isEqual = getCountryOfOrigin().equals(that.getCountryOfOrigin())
                && eventMatch
                && getStorageContainerBarcode().equals(that.getStorageContainerBarcode());
        }
        return isEqual;
    }

    public String toString() {
        return getClass().getSimpleName() + "[countryOfOrigin=" + getCountryOfOrigin() +
            ",eventStack=" + getEventStack() +
            ",storageContainerBarcode=" + getStorageContainerBarcode() +
            ",boxNumber=" + getBoxNumber() +
            "]";
    }

}
