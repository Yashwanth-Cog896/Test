package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: pgadi
  */
@Entity
@Cacheable
@Table(name="SOURCE_SYSTEM", schema="INVENTORY_MGT")
public class SourceSystem {

    @Id
    @Column(name="SOURCE_SYSTEM_ID", nullable=false)
    private Long sourceSystemId;

    @Column(name="NAME", nullable=false)
    private String name;

    @Column(name="REF_ACTIVE", nullable=false)
    @Type(type="true_false")
    private boolean active = true;

    public Long getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(Long sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
