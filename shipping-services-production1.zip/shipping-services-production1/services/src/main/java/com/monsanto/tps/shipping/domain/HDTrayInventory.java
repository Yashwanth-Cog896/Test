package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name="HD_TRAYS_INV_VW", schema="INVENTORY_MGT")
public class HDTrayInventory implements Serializable {

    @Id
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INVENTORY_ID", insertable = false, updatable = false)
    private InventoryEntity inventory;

    @Column(name="HD_TRAY_ID")
    private Long hdTrayId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HD_TRAY_ID", insertable = false, updatable = false)
    private HDTrayEntity hdTrayEntity;

    public HDTrayEntity getHdTrayEntity() {
        return hdTrayEntity;
    }

    public void setHdTrayEntity(HDTrayEntity hdTrayEntity) {
        this.hdTrayEntity = hdTrayEntity;
    }

    public Long getHdTrayId() {
        return hdTrayId;
    }

    public void setHdTrayId(Long hdTrayId) {
        this.hdTrayId = hdTrayId;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HDTrayInventory that = (HDTrayInventory) o;

        if (!hdTrayId.equals(that.hdTrayId)) return false;
        if (!inventory.equals(that.inventory)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = inventory.hashCode();
        result = 31 * result + hdTrayId.hashCode();
        return result;
    }
}

