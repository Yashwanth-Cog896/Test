package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: PGADI
 */
@Entity
@Table(name="SHPMT_CONTENT_PRCSG_STAT", schema="INVENTORY_MGT")
public class ShipmentContentProcessedStateEntity {
    @Id
    @Column(name="SHPMT_CONTENT_PRCSG_STAT_ID", nullable=false)
    private Long shipmentContentProcessedStatusId;

    @Column(name="PROCESSING_STATUS_CODE")
    private String processingStatusCode;

    @Column(name="STATUS_DESCRIPTION")
    private String statusDescription;


    public Long getShipmentContentProcessedStatusId() {
        return shipmentContentProcessedStatusId;
    }

    public void setShipmentContentProcessedStatusId(Long shipmentContentProcessedStatusId) {
        this.shipmentContentProcessedStatusId = shipmentContentProcessedStatusId;
    }

    public String getProcessingStatusCode() {
        return processingStatusCode;
    }

    public void setProcessingStatusCode(String processingStatusCode) {
        this.processingStatusCode = processingStatusCode;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }
}
