package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Repository
public class CarrierShipOptionDaoImpl implements CarrierShipOptionDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public CarrierShipOptionEntity findCarrierShipOption(Long carrierShipOptionId) {
        return (CarrierShipOptionEntity) sessionFactory.getCurrentSession().load(CarrierShipOptionEntity.class, carrierShipOptionId);
    }

    @SuppressWarnings("unchecked")
    @Override
    @Cacheable("METHOD_CACHE")
    public List<CarrierShipOptionEntity> findAllCarrierShipOptions() {
        return sessionFactory.getCurrentSession().createQuery("from CarrierShipOptionEntity where refActive = true").list();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public List<CarrierShipOptionEntity> findCarrierShipOptionByCarrierId(Long carrierId) {
        return sessionFactory.getCurrentSession().createQuery("from CarrierShipOptionEntity cs join fetch cs.carrierEntity ce where ce.carrierId = :carrierId")
                .setLong("carrierId", carrierId)
                .list();
    }
}