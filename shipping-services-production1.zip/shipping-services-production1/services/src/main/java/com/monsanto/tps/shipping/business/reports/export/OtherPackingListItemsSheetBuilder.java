package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.SortedSet;

/**
 * Created by DCENGL
 */
@Service
public class OtherPackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Item BID", "Name", "Comments", "Weight", "UOM", "Count", "Box Barcode", "Permits"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        long currentStorageContainerId = -1;
        String permitsString = "";
        int currentRowIndex = 1;
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        for (ScannedContainerEntity scannedContainerEntity : contentContainerEntities) {
            OtherContainerEntity otherContainer = (OtherContainerEntity) scannedContainerEntity;

            Row row = sheet.createRow(currentRowIndex);

            appendCell(row, defaultCellStyle, otherContainer.getScanOrder());
            appendCell(row, defaultCellStyle, otherContainer.getBarcode());
            appendCell(row, defaultCellStyle, otherContainer.getName());
            appendCell(row, defaultCellStyle, otherContainer.getComments());
            appendCell(row, defaultCellStyle, otherContainer.getWeight());
            appendCell(row, defaultCellStyle, otherContainer.getWeightUOM() != null ? otherContainer.getWeightUOM().getUomRefId() : null);
            appendCell(row, defaultCellStyle, otherContainer.getQuantity());
            appendCell(row, defaultCellStyle, otherContainer.getStorageContainer().getBarcode());

            if (currentStorageContainerId != otherContainer.getStorageContainer().getStorageContainerId()) {
                permitsString = "";
                currentStorageContainerId = otherContainer.getStorageContainer().getStorageContainerId();
                for (ExternalPermitEntity permit : otherContainer.getStorageContainer().getShipmentContainer().getExternalPermits()) {
                    permitsString += permit.getPermitNumber() + ", ";
                }
                if (!permitsString.isEmpty()) {
                    permitsString = permitsString.substring(0, permitsString.length()-2);
                }
            }
            appendCell(row, defaultCellStyle, permitsString);

            currentRowIndex++;
        }
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.OTHER;
    }
}
