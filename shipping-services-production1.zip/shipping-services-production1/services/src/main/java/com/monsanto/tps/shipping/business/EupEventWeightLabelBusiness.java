package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.EupEventWeight;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.util.Collection;

/**
 * User: pgadi
 */
public interface EupEventWeightLabelBusiness {
    Collection<EupEventWeight> getEupEventWeightSummary(ShipmentPackingListEntity shipmentPackingListEntity);
}
