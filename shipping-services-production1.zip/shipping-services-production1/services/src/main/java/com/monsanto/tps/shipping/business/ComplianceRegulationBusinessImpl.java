package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.dao.ShipmentPackingListDao;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.RegulatedStatusWithEvents;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.util.RegulatedStatusHandler;
import com.monsanto.tps.shipping.util.RegulatedStatusText;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * User: pgadi
 */
@Service
public class ComplianceRegulationBusinessImpl implements ComplianceRegulationBusiness {
    public static final String INVENTORY = "Inventory";
    public static final String PLOT_DATA_ERROR = "PLOT_DATA_ERROR";

    private static final Log LOG = LogFactory.getLog(ComplianceRegulationBusinessImpl.class);

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private ShipmentPackingListDao shipmentPackingListDao;
    @Autowired
    private RegulatedStatusHandler regulatedStatusHandler;
    @Autowired
    private RegulatedEventBusiness regulatedEventBusiness;
    @Autowired
    private RegulatedCountryBusiness regulatedCountryBusiness;
    @Autowired
    private EpaBusiness epaBusiness;
    @Autowired
    private UsdaBusiness usdaBusiness;
    @Autowired
    private StewardshipBusiness stewardshipBusiness;


    @Override
    @Trace
    public RegulatedStatus getRegulatedStatusForPackingList(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        RegulatedStatus regulatedStatus;
        if (null == packingList.getRegulatedStatusText()) {
            regulatedStatus = updateRegulatedStatusForPackingList(packingListId);
        } else {
            regulatedStatus = new RegulatedStatus(packingList.getRegulatedStatusText());
        }
        return regulatedStatus;
    }

    @Override
    @Trace
    public RegulatedStatus saveRegulatedStatusForPackingList(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        RegulatedStatus regulatedStatus = getRegulatedStatus(packingList);
        persistRegulatedStatus(packingList, regulatedStatus);
        return regulatedStatus;
    }

    private void persistRegulatedStatus(ShipmentPackingListEntity packingList, RegulatedStatus regulatedStatus) {
        packingList.setComplianceConfirmedDate(null);
        if (PlotDataErrorsHolder.hasErrors()) {
            packingList.setMaterialStatusText(PLOT_DATA_ERROR);
            packingList.setRegulatedStatusText(null);
        } else {
            packingList.setMaterialStatusText(null);
            packingList.setRegulatedStatusText(regulatedStatus.getRegulatedStatus());
        }
        shipmentPackingListDao.updatePackingList(packingList);
    }

    @Override
    @Trace
    public RegulatedStatus updateRegulatedStatusForPackingList(Long packingListId) {
        return saveRegulatedStatusForPackingList(packingListId);
    }

    @Override
    @Trace
    public RegulatedStatusWithEvents getRegulatedStatusWithEventsForPackingList(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);

        if (!canCheckRegulatedStatus(packingList)) {
            return new RegulatedStatusWithEvents();
        }

        List<AgencyEnum> regulatedAgencies = Lists.newArrayList();

        Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());

        String regulatedStatusText;
        Collection<Event> events = null;
        ShipmentTypeEnum shipmentType = packingList.getShipmentType().getShipmentTypeEnum();
        if (regulatedCountryBusiness.isCountryRegulatedByUsdaEpa(toContact.getCountry()) || regulatedCountryBusiness.isCountryRegulatedByStewardship(toContact.getCountry())
                && !regulatedStatusHandler.complianceDisabled(shipmentType)) {
            Map<AgencyEnum, Collection<Event>> regulatedEventsByAgency = regulatedEventBusiness.createRegulatedMovements(packingList);


            getUsdaEpaRegulatedAgencies(regulatedEventsByAgency, regulatedAgencies);

            if (regulatedAgencies.isEmpty()) {
                if (regulatedEventsByAgency.get(AgencyEnum.STEWARDSHIP) != null) {
                    regulatedAgencies.add(AgencyEnum.STEWARDSHIP);
                }
            }

            regulatedStatusText = regulatedStatusHandler.getRegulatedStatusString(regulatedAgencies, shipmentType);

            events = regulatedEventBusiness.getRolledUpRegulatedEvents(regulatedEventsByAgency);
        } else {
            regulatedStatusText = RegulatedStatusText.COMPLIANCE_DISABLED.getRegulatedStatusText();
        }

        RegulatedStatusWithEvents regulatedStatusWithEvents = new RegulatedStatusWithEvents(regulatedStatusText, events);
        persistRegulatedStatus(packingList, regulatedStatusWithEvents);

        return regulatedStatusWithEvents;
    }

    private RegulatedStatus getRegulatedStatus(ShipmentPackingListEntity shipmentPackingListEntity) {
        if (!canCheckRegulatedStatus(shipmentPackingListEntity)) {
            return new RegulatedStatus();
        }

        List<AgencyEnum> regulatedAgencies = getAgenciesForContent(shipmentPackingListEntity);
        String regulatedStatusText = regulatedStatusHandler.getRegulatedStatusString(regulatedAgencies, shipmentPackingListEntity.getShipmentType().getShipmentTypeEnum());
        return new RegulatedStatus(regulatedStatusText);
    }

    private boolean canCheckRegulatedStatus(ShipmentPackingListEntity packingList) {
        return packingList.getToContactId() != null && packingList.getFromContactId() != null && hasContent(packingList);
    }


    private boolean hasContent(ShipmentPackingListEntity packingList) {
        if (CollectionUtils.isEmpty(packingList.getShipmentContainers())) {
            return false;
        }
        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            StorageContainerEntity storageContainer = shipmentContainerEntity.getStorageContainer();
            if (!CollectionUtils.isEmpty(storageContainer.getContainers())) {
                return true;
            }
        }
        return false;
    }


    private List<AgencyEnum> getAgenciesForContent(ShipmentPackingListEntity shipmentPackingListEntity) {
        List<AgencyEnum> regulatedAgencies = Lists.newArrayList();

        Contact toContact = contactBusiness.getPartyContact(shipmentPackingListEntity.getToContactId());
        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.createRegulatedMovements(
            shipmentPackingListEntity);
        if (regulatedCountryBusiness.isCountryRegulatedByUsdaEpa(toContact.getCountry())) {
            getUsdaEpaRegulatedAgencies(regulatedEvents, regulatedAgencies);
        }

        if (regulatedAgencies.isEmpty()) {
            if (regulatedEvents.get(AgencyEnum.STEWARDSHIP) != null) {
                regulatedAgencies.add(AgencyEnum.STEWARDSHIP);
            }
        }
        return regulatedAgencies;
    }

    private void getUsdaEpaRegulatedAgencies(Map<AgencyEnum, Collection<Event>> regulatedEvents,
                                             List<AgencyEnum> regulatedAgencies) {
        if (!regulatedEvents.isEmpty()) {
            for (Map.Entry<AgencyEnum, Collection<Event>> agencyCollectionEntry : regulatedEvents.entrySet()) {
                if(CollectionUtils.isNotEmpty(agencyCollectionEntry.getValue())){
                    regulatedAgencies.add(agencyCollectionEntry.getKey());
                }
            }
        }
    }

    @Trace
    @Override
    public EventDetails getEventDetails(String eventString, String countryAbbr) {
        EventDetails eventDetails = new EventDetails();
        eventDetails.setEventString(eventString);
        eventDetails.setCountryAbbreviation(countryAbbr);

        if (regulatedCountryBusiness.isCountryAbbrRegulatedByUsdaEpa(countryAbbr)) {
            usdaBusiness.addUsdaEventDetails(eventDetails);
            epaBusiness.addEpaEventDetails(eventDetails);
            eventDetails.setValidCountryForUsdaEpa(true);
        }
        if (regulatedCountryBusiness.isCountryAbbrRegulatedByStewardship(countryAbbr)) {
            stewardshipBusiness.addStewardedEventDetails(eventDetails, countryAbbr);
            eventDetails.setValidCountryForStewardship(true);
        }

        List<AgencyEnum> regulatedAgencies = Lists.newArrayList();
        if (eventDetails.isPreEup()) {
            regulatedAgencies.add(AgencyEnum.PRE_EUP);
        }
        if (eventDetails.isEpaRegulated()) {
            regulatedAgencies.add(AgencyEnum.EPA);
        }
        if (eventDetails.isUsdaRegulated()) {
            regulatedAgencies.add(AgencyEnum.USDA);
        }
        if (eventDetails.isStewardship()) {
            regulatedAgencies.add(AgencyEnum.STEWARDSHIP);
        }

        String regulatedStatusText = regulatedStatusHandler.getRegulatedStatusString(regulatedAgencies, null);
        eventDetails.setRegulatedStatus(new RegulatedStatus(regulatedStatusText));

        return eventDetails;
    }
}
