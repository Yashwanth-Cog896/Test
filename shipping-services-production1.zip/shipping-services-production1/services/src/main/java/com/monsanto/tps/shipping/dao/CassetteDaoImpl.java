package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.CassetteEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
@Repository
public class CassetteDaoImpl implements CassetteDao {

    @Resource
    private TempOcdTableDao tempOcdTableDao;

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public List<CassetteEntity> findByBarcode(String barcode) {
        String query = "select c from CassetteEntity c where c.barcode = :barcode and c.storageContainerType.name = 'Cassette'";
        return sessionFactory.getCurrentSession()
                .createQuery(query)
                .setParameter("barcode", barcode).list();
    }

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public List<CassetteEntity> findByBarcode(Set<String> barcodes) {
        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(barcodes));
        String query = "from CassetteEntity c where c.barcode in (select tempOcdId from TempOcdTable tempTable where" +
                " tempTable.sessionId = :requestId) and c.storageContainerType.name = 'Cassette'";

        return sessionFactory.getCurrentSession()
                .createQuery(query)
                .setParameter("requestId", requestId).list();
    }
}
