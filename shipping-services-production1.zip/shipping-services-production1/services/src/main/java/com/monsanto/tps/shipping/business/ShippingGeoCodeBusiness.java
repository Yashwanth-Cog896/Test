package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.AgencyRequestResponse;

/**
 * Created by pthad on 12/8/15.
 */

public interface ShippingGeoCodeBusiness {

    AgencyRequestResponse getAgencyRequestResponseByContactIds(Long fromContactId, Long toContactId);
}
