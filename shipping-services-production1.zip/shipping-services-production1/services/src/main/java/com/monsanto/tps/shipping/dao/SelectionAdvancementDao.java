package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SelectionAdvancementEntity;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface SelectionAdvancementDao {

    Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementForFemalePlots(Collection<Long> femalePlotIds);
    Collection<SelectionAdvancementEntity> findUnarySelectionAdvancementsForFemalePlots(Collection<Long> femalePlotIds);
    Collection<SelectionAdvancementEntity> findUnarySelectionAdvancementsWithMalePlots(Collection<Long> femalePlotIds);
    Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementsWithNoMalePlots(Collection<Long> femalePlotIds);
    Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementsWithNoOperation(Collection<Long> femalePlotIds);

}
