package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;

/**
 * User: DCENGL
 */
public interface UnitOfMeasureDao {

    UnitOfMeasureEntity load(Long unitOfMeasureId);

    UnitOfMeasureEntity findByName(String name);

    String getAbbreviationFromInventoryMgtUomId(Long uomId);

    Long getInventoryMgtUomIdFromAbbreviation(String uomAbbreviation);
}
