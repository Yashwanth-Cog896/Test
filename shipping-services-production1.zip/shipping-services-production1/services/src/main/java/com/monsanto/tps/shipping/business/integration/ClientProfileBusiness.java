package com.monsanto.tps.shipping.business.integration;

import com.monsanto.shipping.common.request.ClientProfile;

/**
 * User: DCENGL
 */
public interface ClientProfileBusiness {

    ClientProfile getClientProfile(Long carrierId, Long fromAccountId, Long fromIrdContactId);

}
