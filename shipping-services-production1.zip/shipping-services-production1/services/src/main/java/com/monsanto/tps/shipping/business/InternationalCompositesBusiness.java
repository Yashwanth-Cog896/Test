package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.InternationalCarrier;
import com.monsanto.tps.shipping.service.model.InternationalCustomer;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.InternationalVendor;

import java.util.List;

public interface InternationalCompositesBusiness {
    InternationalStorageLocation getStorageLocation(String id);

    List<InternationalStorageLocation> getStorageLocations();

    List<String> getStorageLocationIds(String countryCode);

    InternationalCustomer getCustomer(String id);

    List<InternationalCustomer> getCustomers();

    List<InternationalCarrier> getCarriers();

    InternationalCustomer getBroker(String id);

    List<InternationalCustomer> getBrokers();

    List<InternationalVendor> getGtmContacts();

    String getEndUseVendorNumberForResearch();
}
