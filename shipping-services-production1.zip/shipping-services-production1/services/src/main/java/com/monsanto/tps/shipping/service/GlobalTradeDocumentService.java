package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.transfer.GlobalTradeDocument;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/global-trade-document")
public interface GlobalTradeDocumentService {

    @GET
    @Produces(APPLICATION_JSON)
    @Path("/list/sap-order-shipment-id/{sap-order-shipment-id}")
    public List<GlobalTradeDocument> getGlobalTradeDocumentsList(@PathParam("sap-order-shipment-id") Long sapOrderShipmentId);

    @GET
    @Produces("application/pdf")
    @Path("/download/file/{sequence-number}/title/{title}")
    public HttpServletResponse getGlobalTradeDocumentPdf(@PathParam("sequence-number") Long sequenceNumber,
                                                         @PathParam("title") String title);
}
