package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.RegulatedStatusWithEvents;

import javax.ws.rs.*;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/compliance-regulation")
public interface ComplianceRegulationService {

    @GET
    @Path("/packing-list/{packing-list-id}")
    @Produces(APPLICATION_JSON)
    public RegulatedStatus getRegulatedStatus(@PathParam("packing-list-id") Long packingListId);

    @GET
    @Path("/packing-list/{packing-list-id}/event")
    @Produces(APPLICATION_JSON)
    public RegulatedStatusWithEvents getRegulatedStatusWithEvents(@PathParam("packing-list-id") Long packingListId);

    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/packing-list/{packing-list-id}")
    public RegulatedStatus saveRegulatedStatus(@PathParam("packing-list-id") Long packingListId);

    @PUT
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/packing-list/{packing-list-id}")
    public RegulatedStatus updateRegulatedStatus(@PathParam("packing-list-id") Long packingListId);

    @GET
    @Path("/event/{event-string}/country/{countryAbbr}")
    @Produces(APPLICATION_JSON)
    public EventDetails getEventDetails(@PathParam("event-string") String eventString, @PathParam("countryAbbr") String countryAbbr);
}
