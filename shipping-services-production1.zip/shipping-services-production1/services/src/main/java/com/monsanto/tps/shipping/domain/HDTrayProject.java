package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="HD_TRAYS_PROJ_VW", schema="INVENTORY_MGT")
public class HDTrayProject implements Serializable {
    @Id
    @Column(name = "HD_TRAY_ID")
    private String barcode;

    @Column(name = "PROJECT_NAME")
    private String projectName;

    @Column(name = "MAB_PROJECT_ID")
    private Integer projectId;

    @Column(name = "LIMS_ID")
    private String limsId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HD_TRAY_ID", insertable = false, updatable = false)
    private HDTrayEntity hdTrayEntity;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getLimsId() {
        return limsId;
    }

    public void setLimsId(String limsId) {
        this.limsId = limsId;
    }

    public HDTrayEntity getHdTrayEntity() {
        return hdTrayEntity;
    }

    public void setHdTrayEntity(HDTrayEntity hdTrayEntity) {
        this.hdTrayEntity = hdTrayEntity;
    }
}

