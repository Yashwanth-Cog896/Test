package com.monsanto.tps.shipping.dao.primarykey;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerationException;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;

public class HibernatePrimaryKeyGenerator implements IdentifierGenerator {
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        try {
            IdentifierGenerator identifierGenerator = getGenerator();
            return identifierGenerator.generate(session, object);
        } catch (Exception e) {
            throw new IdentifierGenerationException("cannot generate next_id identifier", e);
        }
    }

    protected MidasIdGenerator getGenerator() {
        return MidasIdGeneratorImpl.getInstance();
    }
}
