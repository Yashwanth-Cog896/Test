package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.RegulatedStatusWithEvents;

/**
 * User: pgadi
 */
public interface ComplianceRegulationBusiness {

    RegulatedStatus getRegulatedStatusForPackingList(Long packingListId);

    RegulatedStatus saveRegulatedStatusForPackingList(Long packingListId);

    RegulatedStatus updateRegulatedStatusForPackingList(Long packingListId);

    RegulatedStatusWithEvents getRegulatedStatusWithEventsForPackingList(Long packingListId);

    EventDetails getEventDetails(String eventString, String countryAbbr);
}
