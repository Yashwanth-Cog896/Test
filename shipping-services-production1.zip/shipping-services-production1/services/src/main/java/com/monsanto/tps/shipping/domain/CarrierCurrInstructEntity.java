package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CARRIER_CURR_INSTRUCT", schema="INVENTORY_MGT")
public class CarrierCurrInstructEntity {

    @Id
    @Column(name = "CARRIER_CURR_INSTRUCT_ID")
    private Long carrierCurrInstructId;

    @ManyToOne
    @JoinColumn(name = "CARRIER_ID")
    private CarrierEntity carrier;

    @Column(name = "IRD_ACCT", nullable = false)
    private Long irdAcct;

    public Long getCarrierCurrInstructId() {
        return carrierCurrInstructId;
    }

    public void setCarrierCurrInstructId(Long carrierCurrInstructId) {
        this.carrierCurrInstructId = carrierCurrInstructId;
    }

    public CarrierEntity getCarrier() {
        return carrier;
    }

    public void setCarrier(CarrierEntity carrier) {
        this.carrier = carrier;
    }

    public Long getIrdAcct() {
        return irdAcct;
    }

    public void setIrdAcct(Long irdAcct) {
        this.irdAcct = irdAcct;
    }
}
