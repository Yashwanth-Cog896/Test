package com.monsanto.tps.shipping.business.labels;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.business.ContactBusiness;
import com.monsanto.tps.shipping.business.CropBusiness;
import com.monsanto.tps.shipping.business.PermitBusiness;
import com.monsanto.tps.shipping.business.ProgramBusiness;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.domain.AgencyRequestLocation;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.GenusSpeciesEntity;
import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerComparator;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;
import com.monsanto.tps.shipping.util.ComplianceHandler;
import com.monsanto.tps.shipping.util.TextUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * User: pgadi
 */
@Component
public class ContainerLabelDataSetBuilder {
    private static final int AGENCY_NUMBER_LIMIT = 5;
    private static final int WRAP_LENGTH = 60;

    private static final String NEW_LINE = "\n";
    public static final String FROM_APPENDER = "_FROM";
    public static final String TO_APPENDER = "_TO";
    public static final String BOX_OF = " of ";

    @Autowired
    private CropBusiness cropBusiness;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private ProgramBusiness programBusiness;
    @Autowired
    private PermitBusiness permitBusiness;
    @Autowired
    private LabelContentDataSetter labelContentDataSetter;
    @Autowired
    private ComplianceLabelBusiness complianceLabelBusiness;
    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    public ContainerLabelDataSet buildContainerLabelDataSet(ShipmentContainerEntity shipmentContainerEntity, boolean printTotalNumberOfBoxes) {
        ContainerLabelDataSet labelDataSet = new ContainerLabelDataSet();
        ShipmentPackingListEntity packingList = shipmentContainerEntity.getShipmentPackingList();
        List<ShipmentContainerEntity> shipmentContainers = (List<ShipmentContainerEntity>) packingList.getShipmentContainers();
        Collections.sort(shipmentContainers, new ShipmentContainerComparator());

        ContainerAgencyPermits containerAgencyPermits = null;
        if (ComplianceHandler.isComplianceRequired(packingList)) {
            if (!packingList.getShipmentType().getContentType().equals(ContentType.OTHER)) {
                containerAgencyPermits = permitBusiness.loadAssociatedPermits(packingList, shipmentContainerEntity);
                complianceLabelBusiness.addIntegratedAgencyMessage(packingList.getShipmentType(), containerAgencyPermits, labelDataSet);
            } else {
                containerAgencyPermits = complianceLabelBusiness.getExternalPermitsByContainer(shipmentContainerEntity);
                if(CollectionUtils.isNotEmpty(containerAgencyPermits.getPermits())){
                    complianceLabelBusiness.addExternalAgencyMessage(shipmentContainerEntity, labelDataSet);
                }
            }

            complianceLabelBusiness.addPermitDetailsToLabelDataSet(containerAgencyPermits, labelDataSet, AGENCY_NUMBER_LIMIT);
        }

        labelDataSet.put(ContainerLabelConstants.CONTAINER_BARCODE, shipmentContainerEntity.getStorageContainer().getBarcode());

        setBoxData(shipmentContainerEntity, printTotalNumberOfBoxes, labelDataSet, shipmentContainers);

        boolean complianceRequired = containerAgencyPermits != null && CollectionUtils.isNotEmpty(containerAgencyPermits.getPermits());
        labelContentDataSetter.setContentsData(labelDataSet, shipmentContainerEntity.getStorageContainer().getContainers(), packingList.getShipmentType(), complianceRequired);

        return labelDataSet;
    }

    private void setBoxData(ShipmentContainerEntity shipmentContainerEntity, boolean printTotalNumberOfBoxes,
                            ContainerLabelDataSet data, List<ShipmentContainerEntity> shipmentContainers) {
        Collection<ShipmentContainerEntity> filteredContainers = getFilteredBoxes(shipmentContainers);
        String boxNumber = getBoxNumber(filteredContainers, shipmentContainerEntity);
        String totalNumberOfBoxes = printTotalNumberOfBoxes ? String.valueOf(filteredContainers.size()) : "";
        data.put(ContainerLabelConstants.BOX, boxNumber + BOX_OF + totalNumberOfBoxes);
    }

    private Collection<ShipmentContainerEntity> getFilteredBoxes(List<ShipmentContainerEntity> shipmentContainers) {
        return Collections2.filter(shipmentContainers, new Predicate<ShipmentContainerEntity>() {
            @Override
            public boolean apply(ShipmentContainerEntity container) {
                return container.getStorageContainer().getStorageContainerType().getName().equals("Box");
            }
        });
    }

    private String getBoxNumber(Collection<ShipmentContainerEntity> shipmentContainers, final ShipmentContainerEntity shipmentContainerEntity) {
        int boxIndex = Iterables.indexOf(shipmentContainers, new Predicate<ShipmentContainerEntity>() {
            @Override
            public boolean apply(@Nullable ShipmentContainerEntity input) {
                return input.getShipmentContainerId().equals(shipmentContainerEntity.getShipmentContainerId());
            }
        });
        return String.valueOf(boxIndex + 1);
    }

    public ContainerLabelDataSet buildPackingListSpecificData(ShipmentPackingListEntity packingList) {
        ContainerLabelDataSet data = new ContainerLabelDataSet();
        addFormattedDate(data);
        addCropInfoHeader(packingList, data);
        addContactAndPrograms(packingList, data);
        addDescription(data, packingList.getDescription());
        addShipmentBarcode(packingList, data);
        return data;
    }

    private void addShipmentBarcode(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        data.put(ContainerLabelConstants.SHIPMENT_BARCODE, packingList.getBarcode());
    }

    private void addContactAndPrograms(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        if (packingList.getSapOrderShipment() != null) {
            processInternationalContacts(packingList, data);
        } else {
            processContactsAndProgram(packingList, data);
        }
    }

    private void addCropInfoHeader(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        ContentType contentType = packingList.getShipmentType().getContentType();
        if(contentType.equals(ContentType.OTHER)){
            data.put(ContainerLabelConstants.SEED_CROP_INFO_HEADER, ContainerLabelConstants.OTHER_CROP_HEADER);
        } else if(contentType.equals(ContentType.WHOLE_PLANTS)) {
            data.put(ContainerLabelConstants.SEED_CROP_INFO_HEADER, ContainerLabelConstants.WHOLE_PLANTS_CROP_HEADER);
        } else {
            addCropInfo(packingList, data);
        }
    }

    private void addCropInfo(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        CropEntity cropEntity = cropBusiness.getCropByPackingList(packingList);
        if (cropEntity != null) {
            String genus = "";
            if (!cropEntity.getGenusSpecies().isEmpty()) {
                GenusSpeciesEntity genusSpecies = cropEntity.getGenusSpecies().get(0);
                genus = genusSpecies.getGenus();
            }

            if (packingList.getShipmentType().getContentType().equals(ContentType.TISSUE_PLATE)) {
                data.put(ContainerLabelConstants.SEED_CROP_INFO_HEADER, String.format(ContainerLabelConstants.TISSUE_CROP_HEADER, cropEntity.getName()));
            } else {
                data.put(ContainerLabelConstants.SEED_CROP_INFO_HEADER, cropEntity.getName() + ContainerLabelConstants.SEED);
            }
            data.put(ContainerLabelConstants.GENUS_SPECIES_HEADER, genus);
        }
    }

    private void addFormattedDate(ContainerLabelDataSet data) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        data.put(ContainerLabelConstants.DATE_PRINTED, dateFormat.format(new Date()));
    }

    private void addDescription(ContainerLabelDataSet data, String description) {
        int lineNo = 1;

        for (String text : TextUtils.wrapText(description, WRAP_LENGTH, NEW_LINE)) {
            data.put(ContainerLabelConstants.DESCRIPTION + lineNo, text);
            lineNo++;
        }
    }

    private void processContactsAndProgram(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());
        Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
        setToContactInfo(packingList, toContact, data);
        setFromContactInfo(packingList, fromContact, data);
        data.put(ContainerLabelConstants.TO_PROGRAM, programBusiness.getProgramByAccount(toContact.getAccountId()).getRefId());
        data.put(ContainerLabelConstants.FROM_PROGRAM, programBusiness.getProgramByAccount(fromContact.getAccountId()).getRefId());
    }

    private void processInternationalContacts(ShipmentPackingListEntity packingList, ContainerLabelDataSet data) {
        AbstractContact toContact = internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getShipToCustomerNumber());
        AbstractContact fromContact = internationalCompositesDao.getStorageLocation(packingList.getSapOrderShipment().getSapStorageLocationCode());
        setInternationalToContactInfo(toContact, data);
        setInternationalFromContactInfo(fromContact, data);
    }

    private void setFromContactInfo(ShipmentPackingListEntity packingList, Contact fromContact, ContainerLabelDataSet data) {
        MidasUserEntity midasUser = packingList.getCreatedBy();
        String shipFromAttn = TextUtils.getDelimitedStringWithSpace(TextUtils.removeEmptyValues(midasUser.getFirstName(), midasUser.getLastName()));
        setContactInfo(fromContact, shipFromAttn, data, FROM_APPENDER);
    }

    private void setToContactInfo(ShipmentPackingListEntity packingList, Contact toContact, ContainerLabelDataSet data) {
        String shipToAttn = null == packingList.getShipToAttn() ? "" : packingList.getShipToAttn();
        setContactInfo(toContact, shipToAttn, data, TO_APPENDER);
    }

    private void setInternationalFromContactInfo(AbstractContact fromContact, ContainerLabelDataSet data) {
        setInternationalContactInfo(fromContact, data, FROM_APPENDER);
    }

    private void setInternationalToContactInfo(AbstractContact toContact, ContainerLabelDataSet data) {
        setInternationalContactInfo(toContact, data, TO_APPENDER);
    }

    private void setContactInfo(Contact contact, String attentionField, ContainerLabelDataSet data, String appendText) {
        data.put(ContainerLabelConstants.CONTACT_NAME + appendText, attentionField);
        data.put(ContainerLabelConstants.COMPANY_NAME + appendText, TextUtils.getDelimitedStringWithSpace(TextUtils.removeEmptyValues(contact.getFirstName(), contact.getLastName())));
        data.put(ContainerLabelConstants.CONTACT_LINE1 + appendText, null == contact.getAddressLine1() ? " " : contact.getAddressLine1());
        data.put(ContainerLabelConstants.CONTACT_LINE2 + appendText, null == contact.getAddressLine2() ? " " : contact.getAddressLine2());
        data.put(ContainerLabelConstants.CONTACT_LINE3 + appendText, null == contact.getAddressLine3() ? " " : contact.getAddressLine3());

        String zipCode = contact.getZipCode();
        if (!StringUtils.isEmpty(contact.getZipCode4())) {
            zipCode = zipCode + "-" + contact.getZipCode4();
        }

        data.put(ContainerLabelConstants.CONTACT_CITY_STATE_ZIP + appendText, TextUtils.getDelimitedStringWithComma(TextUtils.removeEmptyValues(contact.getCity(), contact.getState(), zipCode)));
        data.put(ContainerLabelConstants.CONTACT_COUNTRY + appendText, null == contact.getCountry() ? " " : contact.getCountry());
        data.put(ContainerLabelConstants.CONTACT_PHONE + appendText, null == contact.getPhoneNumber() ? " " : contact.getPhoneNumber());
    }

    private void setInternationalContactInfo(AbstractContact contact, ContainerLabelDataSet data, String appendText) {
        data.put(ContainerLabelConstants.COMPANY_NAME + appendText, contact.getName());
        data.put(ContainerLabelConstants.CONTACT_LINE1 + appendText,
                null == contact.getAddressLine1() ? " " : contact.getAddressLine1());
        data.put(ContainerLabelConstants.CONTACT_LINE2 + appendText,
                null == contact.getAddressLine2() ? " " : contact.getAddressLine2());
        data.put(ContainerLabelConstants.CONTACT_LINE3 + appendText,
                null == contact.getAddressLine3() ? " " : contact.getAddressLine3());
        String zipCode = contact.getZip();
        if (!StringUtils.isEmpty(contact.getZipFour())) {
            zipCode = zipCode + "-" + contact.getZipFour();
        }
        data.put(ContainerLabelConstants.CONTACT_CITY_STATE_ZIP + appendText, TextUtils
                .getDelimitedStringWithComma(TextUtils.removeEmptyValues(contact.getCity(), contact.getState(), zipCode)));
        data.put(ContainerLabelConstants.CONTACT_COUNTRY + appendText,
                null == contact.getCountry() ? " " : contact.getCountry());
        data.put(ContainerLabelConstants.CONTACT_PHONE + appendText,
                null == contact.getPhoneNumber() ? " " : contact.getPhoneNumber());
    }
}