package com.monsanto.tps.shipping.business.labels;

import com.google.common.collect.ImmutableMap;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;


/**
 * User: pgadi
 */
public final class ContainerLabelConstants {

    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String SEED_CROP_INFO_HEADER = "SEED_CROP_INFO_HEADER";
    public static final String GENUS_SPECIES_HEADER ="GENUS_SPECIES_HEADER";
    public static final String CONTACT_NAME = "CONTACT_NAME";
    public static final String COMPANY_NAME = "COMPANY_NAME";
    public static final String CONTACT_LINE1 = "CONTACT_LINE1";
    public static final String CONTACT_LINE2 = "CONTACT_LINE2";
    public static final String CONTACT_LINE3 = "CONTACT_LINE3";
    public static final String CONTACT_CITY_STATE_ZIP = "CONTACT_CITY_STATE_ZIP";
    public static final String CONTAINER_BARCODE = "CONT_BID";
    public static final String REGULATED_SUMMARY_LINE = "REGULATED_SUMMARY_LINE";
    public static final String PRE_EUP_SUMMARY_LINE = "PRE_EUP_SUMMARY_LINE";
    public static final String AGENCY_APPROVAL_NUMBERS = "AGENCY_APPROVAL_NUMBERS";
    public static final String AGENCY_APPROVAL_NUMBERS_LABEL = "AGENCY APPROVAL #(s): ";
    public static final String AGENCY_NUM = "AGENCY_NUM_";
    public static final String CONTAINERS = "CONTAINERS_";
    public static final String CONTACT_COUNTRY = "CONTACT_COUNTRY";
    public static final String CONTACT_PHONE = "CONTACT_PHONE";
    public static final String TO_PROGRAM = "TO_PRGRM";
    public static final String FROM_PROGRAM = "FROM_PRGRM";
    public static final String CONTAINMENT_LAYER = "CONTAINMENT_LAYER";
    public static final String STEWARDSHIP_WARNING = "Stewardship : Product not approved for commerce";
    public static final String SEED = " Seed";
    public static final String TISSUE_CROP_HEADER = "Dried %s Tissue";
    public static final String OTHER_CROP_HEADER = "Other";
    public static final String WHOLE_PLANTS_CROP_HEADER = "Whole Plants";
    public static final String SHIPMENT_BARCODE = "SHIPMENT_BID";
    public static final String CONTENT_DESC = "CONTENT_DESC";
    public static final String BOX = "BOX";
    public static final String CONTENT_HEADER = "CONTENT_HEADER";
    public static final String DATE_PRINTED = "DATE_PRINTED";
    public static final String MORE_CONTENTS_INFO = "    ***** Refer to the packing list for additional items *****    ";
    public static final String EXTERNAL_AGENCY_MESSAGE = "Contains %s regulated material";
    public static final String PRE_EUP_MESSAGE = "Experimental Use Only";

    private static ImmutableMap<String, String> contentHeaderMap = ImmutableMap.<String, String>builder()
            .put(ShipmentTypeEnum.INVENTORY.getTypeName(), "SRC PLOT #")
            .put(ShipmentTypeEnum.PLANTED_PLOT.getTypeName(), "SET, TRACK ID, REP, PLOT #")
            .put(ShipmentTypeEnum.PLANTED_PLOT_INV.getTypeName(), "SET, TRACK ID, REP, PLOT #")
            .put(ShipmentTypeEnum.HARVESTED_PLOT.getTypeName(), "FIELD, SET, TRACK ID, REP, PLOT #")
            .put(ShipmentTypeEnum.TISSUE_PLATE.getTypeName(), "PLATE BID, LIMS ID, FIELD")
            .put(ShipmentTypeEnum.CASSETTE.getTypeName(), "Field, Set")
            .put(ShipmentTypeEnum.OTHER.getTypeName(), "BID, Name")
            .put(ShipmentTypeEnum.WHOLE_PLANTS.getTypeName(), "BID")
            .put(ShipmentTypeEnum.HD_TRAY.getTypeName(), "Tray ID")
            .build();

    public static String getContentHeader(String name) {
        return contentHeaderMap.get(name);
    }

    private static ImmutableMap<String, String> regMessageMap = ImmutableMap.<String, String>builder()
            .put("USDA, EPA_REGULATORY_MSG", "Contains USDA, EPA regulated material")
            .put("EPA_REGULATORY_MSG", "Contains EPA regulated material")
            .put("USDA_REGULATORY_MSG", "Contains USDA regulated material")
            .put("STEWARDSHIP_REGULATORY_MSG", STEWARDSHIP_WARNING)
            .build();

    public static String getRegMessage(String name) {
        return regMessageMap.get(name);
    }
}
