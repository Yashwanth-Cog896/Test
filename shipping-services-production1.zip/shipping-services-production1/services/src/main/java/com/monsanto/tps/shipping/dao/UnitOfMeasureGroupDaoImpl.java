package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureGroupEntity;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User: pgadi
 */
@Repository
public class UnitOfMeasureGroupDaoImpl implements UnitOfMeasureGroupDao {
    @Autowired
    private org.hibernate.SessionFactory sessionFactory;
    public static final String SHIPPING_WEB_GROUP = "Shipping Web UOM";

    @Override
    @Cacheable("METHOD_CACHE")
    public List<UnitOfMeasureEntity> getValidUnitOfMeasuresForShippingGroup() {
        return ((UnitOfMeasureGroupEntity)sessionFactory.getCurrentSession()
                .createCriteria(UnitOfMeasureGroupEntity.class)
                .add(Restrictions.eq("groupName",SHIPPING_WEB_GROUP))
                .uniqueResult())
                .getUnitOfMeasureEntities();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public UnitOfMeasureEntity findByAbbreviation(String abbreviation) {
        if (abbreviation != null) {
            List<UnitOfMeasureEntity> uoms = getValidUnitOfMeasuresForShippingGroup();
            for (UnitOfMeasureEntity uom : uoms) {
                if (abbreviation.equalsIgnoreCase(uom.getUomRefId())) {
                    return uom;
                }
            }
        }
        return null;
    }
}

