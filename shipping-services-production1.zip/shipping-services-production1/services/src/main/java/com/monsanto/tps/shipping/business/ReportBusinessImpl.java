package com.monsanto.tps.shipping.business;

import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.business.reports.MTFReports.MTFExport;
import com.monsanto.tps.shipping.business.reports.checklist.ChecklistReport;
import com.monsanto.tps.shipping.business.reports.export.PackingListExport;
import com.monsanto.tps.shipping.domain.EupMasterLabel;
import com.monsanto.tps.shipping.domain.PackingListEupMasterLabels;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Report;
import com.monsanto.tps.shipping.service.model.enums.ReportEnum;
import com.monsanto.tps.shipping.util.FileZipper;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;

/**
 * Created by rlcasw
 */
@Service
public class ReportBusinessImpl implements ReportBusiness {
    public static final String EUP_MASTER_LABEL = "EUP_Master_Label_";

    @Autowired
    private FileZipper fileZipper;

    @Autowired
    private EupLabelBusiness eupLabelBusiness;

    @Autowired
    private PackingListExport packingListExport;

    @Autowired
    private MTFExport MTFExport;

    @Autowired
    private ChecklistReport checklistReport;

    @Autowired
    private ShipmentPackingListBusiness packingListBusiness;

    @Trace
    @Override
    public Report getReport(ReportEnum reportEnum, ShipmentPackingListEntity packingList) throws IOException {
        Report report;

        switch(reportEnum) {
            case PACKING_LIST_EXPORT:
                report = new Report();

                report.setFilename(reportEnum.getFileName(packingList.getBarcode()));
                report.setByteArrayOutputStream(packingListExport.getXlsxReport(packingList));
                break;
            case MTF:
                report = new Report();

                report.setFilename(reportEnum.getFileName(packingList.getBarcode()));
                report.setByteArrayOutputStream(MTFExport.getPdfReport(packingList));
                break;
            case CHECKLIST:
                report = new Report();

                report.setFilename(reportEnum.getFileName(packingList.getBarcode()));
                report.setByteArrayOutputStream(checklistReport.getPdfReport(packingList));
                break;
            case EPA_MASTER_LABEL:
                report = getEpaMasterLabel(packingList);
                break;
            default:
                throw new ShippingWebException("Invalid Report: " + reportEnum);

        }

        return report;
    }

    @Trace
    @Async
    @Transactional(readOnly = true)
    @Override
    public AsyncResult<Report> getReportAsync(ReportEnum reportEnum, Long packingListId) {

        ShipmentPackingListEntity packingList = packingListBusiness.getShipmentPackingList(packingListId);

        try {
            Report report = getReport(reportEnum, packingList);
            return new AsyncResult<Report>(report);
        } catch (Exception e) {
            throw new ShippingWebException("Error retrieving report: " + reportEnum, e, true);
        }
    }

    private Report getEpaMasterLabel(ShipmentPackingListEntity packingList) throws IOException {
        Report report = new Report();

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        PackingListEupMasterLabels packingListEupMasterLabels = eupLabelBusiness.getEupMasterLabels(packingList.getShipmentPackingListId());

        Collection<EupMasterLabel> eupMasterLabels = packingListEupMasterLabels.getEupMasterLabels();
        String barcode = packingListEupMasterLabels.getBarcode();

        if (CollectionUtils.isEmpty(eupMasterLabels)) {
            throw new ShippingWebException("No EPA documents found");
        } else if (eupMasterLabels.size() == 1) {
            EupMasterLabel eupMasterLabel = eupMasterLabels.iterator().next();

            report.setFilename(barcode + '_' + eupMasterLabel.getAgencyApprovalNumber() + ".pdf");
            report.setByteArrayOutputStream(eupMasterLabel.getLabelStream());
        } else {
            Map<String, ByteArrayOutputStream> zipFilesMap = Maps.newHashMap();

            for (EupMasterLabel eupMasterLabel : eupMasterLabels) {
                zipFilesMap.put(barcode + "_" + eupMasterLabel.getAgencyApprovalNumber() + ".pdf", eupMasterLabel.getLabelStream());
            }

            fileZipper.createZip(zipFilesMap, byteArrayOutputStream);

            report.setFilename(EUP_MASTER_LABEL + barcode + ".zip");
            report.setByteArrayOutputStream(byteArrayOutputStream);
        }

        return report;
    }
}
