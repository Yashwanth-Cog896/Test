package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.RepContent;

import java.util.List;

public interface RepBusiness {

    RepContent getRepContent(String barcode, Long cropId, Long shipToProgramId, ShipmentTypeEntity shipmentType);

    List<RepContent> save(ShipmentPackingListEntity packingList, String order, List<RepContent> repContents);

    List<RepContent> save(ShipmentPackingListEntity packingList, Integer plotsPerBox, Boolean continueLastBox,
                          String order, List<RepContent> repContents);
}
