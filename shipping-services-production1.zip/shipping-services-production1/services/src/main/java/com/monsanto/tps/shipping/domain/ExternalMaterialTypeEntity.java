package com.monsanto.tps.shipping.domain;


import org.hibernate.annotations.Type;

import javax.persistence.*;

@Entity
@Table(name = "EXTERNAL_MATERIAL_TYPE", schema = "INVENTORY_MGT")
public class ExternalMaterialTypeEntity {

    @Id
    @Column(name = "EXTERNAL_MATERIAL_TYPE_ID", nullable = false)
    private Long externalMaterialTypeId;
    
    @Column(name = "MATERIAL_DESC", nullable = false)
    private String description;
    
    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type = "true_false")
    private boolean refActive;

    public ExternalMaterialTypeEntity() {
    }

    
    public Long getExternalMaterialTypeId() {
        return externalMaterialTypeId;
    }

    public void setExternalMaterialTypeId(Long externalMaterialTypeId) {
        this.externalMaterialTypeId = externalMaterialTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    @Override
    public String toString() {
        return "ExternalMaterialType{externalMaterialTypeDescriptoin=" + description + "}";
    }
}
