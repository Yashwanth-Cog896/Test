package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Iterables;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.proxy.HibernateProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * User: DCENGL
 */
@Repository
public class ScannedContainerDaoImpl implements ScannedContainerDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public ScannedContainerEntity load(Long contentContainerId, ContentType contentType) {
        if (ContentType.OTHER == contentType) {
            return (ScannedContainerEntity) sessionFactory.getCurrentSession().load(OtherContainerEntity.class, contentContainerId);
        } else {
            ScannedContainerEntity scannedContainerEntity = (ScannedContainerEntity) sessionFactory.getCurrentSession().load(ScannedContainerEntity.class, contentContainerId);
            if(scannedContainerEntity instanceof HibernateProxy){
                Hibernate.initialize(scannedContainerEntity);
                scannedContainerEntity = (ScannedContainerEntity) ((HibernateProxy) scannedContainerEntity).getHibernateLazyInitializer().getImplementation();
            }
            return scannedContainerEntity;
        }
    }

    @Trace
    @Override
    public void delete(ScannedContainerEntity contentContainerEntity) {
        sessionFactory.getCurrentSession().delete(contentContainerEntity);
    }

    @Trace
    @Override
    public void save(ScannedContainerEntity contentContainerEntity) {
        sessionFactory.getCurrentSession().save(contentContainerEntity);
    }

    @Trace
    @Override
    public void updateUom(Collection<Long> storageContainerIds, long uomId) {
        Iterable<List<Long>> partitionedStorageContainerIds = Iterables.partition(storageContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedStorageContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getUpdateUomSql())
                    .setParameter("uomId", uomId)
                    .setParameterList("storageContainerId", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateWeight(Collection<Long> ids, double amount, long uomId) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(ids, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getWeightSql())
                    .setParameter("value", amount)
                    .setParameter("uomId", uomId)
                    .setParameterList("ids", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateName(Collection<Long> scannedContainerIds, String name) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(scannedContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getNameSql())
                    .setParameter("value", name)
                    .setParameterList("ids", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateVerifyContentTimeStamp(Collection<Long> scannedContainerIds, Long storageContainerId, Boolean outGoing) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(scannedContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(getSetVerifyContentTimeStampSql(outGoing.booleanValue()));
            sqlQuery.setParameter("verifyTimeStamp", new Date());
            sqlQuery.setParameterList("ids", partitionedIds);
            if (outGoing.booleanValue()) {
                sqlQuery.setParameter("storageContainerId", storageContainerId);
            }
            sqlQuery.executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateComment(Collection<Long> scannedContainerIds, String comment) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(scannedContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getCommentSql())
                    .setParameter("value", comment)
                    .setParameterList("ids", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateSeedCount(Collection<Long> scannedContainerIds, long amount) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(scannedContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getSeedCountSql())
                    .setParameter("value", amount)
                    .setParameterList("ids", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateSeedCountWeightAndUOM(Collection<Long> scannedContainerIds, long amount, Double weight, long uomId) {
        Iterable<List<Long>> partitionedScannedContainerIds = Iterables.partition(scannedContainerIds, 1000);
        for (List<Long> partitionedIds : partitionedScannedContainerIds) {
            sessionFactory.getCurrentSession().createSQLQuery(getSeedCountAndWeightSql())
                    .setParameter("value", amount)
                    .setParameter("weight", weight)
                    .setParameter("uomId", uomId)
                    .setParameterList("ids", partitionedIds)
                    .executeUpdate();
        }
    }

    @Trace
    @Override
    public void updateVerifyTimeStamp(Long scannedContainerId, Long storageContainerId, Boolean outGoing) {
        SQLQuery sqlQuery = sessionFactory.getCurrentSession().createSQLQuery(getSetVerifyTimeStampSql(outGoing.booleanValue()));
        sqlQuery.setParameter("scannedContainerId", scannedContainerId);
        sqlQuery.setParameter("verifyTimeStamp", new Date());
        if (outGoing.booleanValue()) {
            sqlQuery.setParameter("storageContainerId", storageContainerId);
        }
        sqlQuery.executeUpdate();
    }

    @Trace
    @Override
    public void resetVerifyTimeStamp(Long scannedContainerId, Boolean outGoing) {
        sessionFactory.getCurrentSession().createSQLQuery(getResetVerifyTimeStampSql(outGoing.booleanValue()))
                .setParameter("scannedContainerId", scannedContainerId).executeUpdate();
    }

    private String getSeedCountAndWeightSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET CONTENT_PIECES_QTY = :value, SHIPPED_WEIGHT_QTY = :weight, SHIPPED_WEIGHT_QTY_UOM_ID = :uomId WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getUpdateUomSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET SHIPPED_WEIGHT_QTY_UOM_ID = :uomId WHERE packed_in_storage_container_id in (:storageContainerId)";
    }

    private String getSeedCountSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET CONTENT_PIECES_QTY = :value WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getWeightSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET SHIPPED_WEIGHT_QTY = :value, SHIPPED_WEIGHT_QTY_UOM_ID = :uomId WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getNameSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET OTHER_NM = :value WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getCommentSql() {
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET OTHER_COMMENT_TXT = :value WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getSetVerifyTimeStampSql(boolean outGoing) {
        String columns = (outGoing == true) ? "packed_in_storage_container_id = :storageContainerId, SEND_VERIFY_SCAN_TSP = :verifyTimeStamp" : "RECEIVE_VERIFY_SCAN_TSP = :verifyTimeStamp";
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET " + columns + " WHERE SCANNED_CONTAINER_ID = :scannedContainerId";
    }
    private String getSetVerifyContentTimeStampSql(boolean outGoing) {
        String columns = (outGoing == true) ? "packed_in_storage_container_id = :storageContainerId, SEND_VERIFY_SCAN_TSP = :verifyTimeStamp" : "RECEIVE_VERIFY_SCAN_TSP = :verifyTimeStamp";
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET " + columns + " WHERE SCANNED_CONTAINER_ID in (:ids)";
    }

    private String getResetVerifyTimeStampSql(boolean outGoing) {
        String columnName = outGoing == true ? "SEND_VERIFY_SCAN_TSP" : "RECEIVE_VERIFY_SCAN_TSP";
        return "UPDATE INVENTORY_MGT.SCANNED_CONTAINER SET " + columnName + " = NULL WHERE SCANNED_CONTAINER_ID = :scannedContainerId";
    }

}
