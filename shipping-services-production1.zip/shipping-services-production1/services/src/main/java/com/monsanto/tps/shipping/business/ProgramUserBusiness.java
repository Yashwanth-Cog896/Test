package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.Program;

import java.util.List;

/**
 * User: DCENGL
 */
public interface ProgramUserBusiness {

    List<Program> getProgramsForLoginId(String loginId);

}
