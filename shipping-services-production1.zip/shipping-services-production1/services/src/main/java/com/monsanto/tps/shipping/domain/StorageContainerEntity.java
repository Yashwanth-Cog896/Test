package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static javax.persistence.FetchType.LAZY;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "STORAGE_CONTAINER", schema = "INVENTORY_MGT")
public class StorageContainerEntity<T extends ScannedContainerEntity> implements Serializable {

    @Id
    @Column(name = "STORAGE_CONTAINER_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    private Long storageContainerId;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

    @Column(name = "BARCODE", nullable = false)
    private String barcode;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;

    @OneToOne(mappedBy = "storageContainer")
    private ShipmentContainerEntity shipmentContainer;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "STORAGE_CONTAINER_TYPE_ID", nullable = false)
    private StorageContainerTypeEntity storageContainerType;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "storageContainer")
    private List<ScannedContainerEntity> containers = new ArrayList<ScannedContainerEntity>();

    public StorageContainerEntity() {
    }

    public StorageContainerEntity(Long storageContainerId, String name, String description, String barcode, Date creationDate) {
        this.storageContainerId = storageContainerId;
        this.name = name;
        this.description = description;
        this.barcode = barcode;
        this.creationDate = creationDate;
    }

    public Long getStorageContainerId() {
        return storageContainerId;
    }

    public void setStorageContainerId(Long storageContainerId) {
        this.storageContainerId = storageContainerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public ShipmentContainerEntity getShipmentContainer() {
        return shipmentContainer;
    }

    public void setShipmentContainer(ShipmentContainerEntity shipmentContainer) {
        this.shipmentContainer = shipmentContainer;
    }

    public StorageContainerTypeEntity getStorageContainerType() {
        return storageContainerType;
    }

    public void setStorageContainerType(StorageContainerTypeEntity storageContainerType) {
        this.storageContainerType = storageContainerType;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public void setContainers(List<ScannedContainerEntity> contentContainers) {
        this.containers = contentContainers;
    }

    public List<ScannedContainerEntity> getContainers() {
        return containers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        StorageContainerEntity that = (StorageContainerEntity) o;

        return !(storageContainerId != null ? !storageContainerId.equals(that.storageContainerId) : that.storageContainerId != null);
    }

    @Override
    public int hashCode() {
        return storageContainerId != null ? storageContainerId.hashCode() : 0;
    }
}