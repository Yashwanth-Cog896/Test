package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;
import com.monsanto.tps.shipping.domain.ShipOptionType;
import com.monsanto.tps.shipping.domain.ShipmentCarrierOptionEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.service.model.CarrierShipOption;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;

/**
 * User: DCENGL
 */
@Service
public class ShipmentCarrierOptionBusinessImpl implements ShipmentCarrierOptionBusiness {

    @Autowired
    private CarrierShipOptionBusiness carrierShipOptionBusiness;

    @Trace
    @Override
    public Collection<ShipmentCarrierOptionEntity> getCarrierOptionsForShipment(ShipmentEntity shipmentEntity, Collection<CarrierShipOption> carrierShipOptions) {
        if (CollectionUtils.isEmpty(carrierShipOptions)) {
            return Sets.newHashSet();
        }

        Collection<Long> carrierShipOptionIds = Collections2.transform(carrierShipOptions, new Function<CarrierShipOption, Long>() {
            @Override
            public Long apply(@Nullable CarrierShipOption carrierShipOption) {
                return carrierShipOption.getCarrierShipOptionId();
            }
        });

        Collection<CarrierShipOptionEntity> carrierShipOptionEntities = carrierShipOptionBusiness.findCarrierShipOptions(carrierShipOptionIds);


        Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptions = Sets.newHashSet();
        for (CarrierShipOptionEntity carrierShipOptionEntity : carrierShipOptionEntities) {
            ShipmentCarrierOptionEntity shipmentCarrierOptionEntity = new ShipmentCarrierOptionEntity();

            shipmentCarrierOptionEntity.setShipOptionType(carrierShipOptionEntity.getShipOptionTypeEntity());
            shipmentCarrierOptionEntity.setCarrierShipOption(carrierShipOptionEntity);
            shipmentCarrierOptionEntity.setShipment(shipmentEntity);

            shipmentCarrierOptions.add(shipmentCarrierOptionEntity);
        }

        return shipmentCarrierOptions;
    }

    @Override
    public boolean isIntegratedCarrier(Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptions) {
        if (CollectionUtils.isEmpty(shipmentCarrierOptions)) {
            return false;
        }

        ShipmentCarrierOptionEntity shipmentCarrierOption = shipmentCarrierOptions.iterator().next();
        return shipmentCarrierOption.getCarrierShipOption().getCarrierEntity().isSupportIntegratedShipping();
    }

    @Trace
    @Override
    public ShipmentCarrierOptionEntity getShipmentCarrierOptionByType(Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptions, ShipOptionType shipOptionType) {
        if (CollectionUtils.isEmpty(shipmentCarrierOptions) || shipOptionType == null) {
            return null;
        }

        for (ShipmentCarrierOptionEntity shipmentCarrierOption : shipmentCarrierOptions) {
            if (shipmentCarrierOption.getShipOptionType().getEnumValue() == shipOptionType) {
                return shipmentCarrierOption;
            }
        }

        return null;
    }
}
