package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.util.Date;
import java.util.List;

/**
 * @author Supreet Singh (sssing5)
 */
public interface ShipmentPackingListDao {

    public List<ShipmentPackingListEntity> getPackingListsByProgramAndCreationDate(Long accountId,
                                                                                   Date createdAfterDate);

    public ShipmentPackingListEntity getPackingListById(Long packingListId);

    public ShipmentPackingListEntity getPackingListBySapOrderShipmentId(Long sapOrderShipmentId);

    public ShipmentPackingListEntity getPackingListByBoxBarcode(String suBarcode);

    public ShipmentPackingListEntity getPackingListByShipmentBarcode(String shBarcode);

    public void savePackingList(ShipmentPackingListEntity shipmentPackingListEntity);

    public void updatePackingList(ShipmentPackingListEntity shipmentPackingListEntity);

    public void delete(ShipmentPackingListEntity shipmentPackingListEntity);

    public List<ShipmentPackingListEntity> getInternationalPackingListsByCreatedDate(Date createdAfterDate,
                                                                                     List<String> contactIds);

    public ShipmentPackingListEntity getPackingListBySapOrderNumber(String sapOrderNumber);

    public ShipmentPackingListEntity getPackingListBySapDeliveryShipmentNumber(String shipmentNumber);

}