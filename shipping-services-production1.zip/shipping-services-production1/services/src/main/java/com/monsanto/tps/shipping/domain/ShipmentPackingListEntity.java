package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import java.util.Collection;
import java.util.Date;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "SHPMT_PKG_LIST", schema = "INVENTORY_MGT")
public class ShipmentPackingListEntity {
    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    @Column(name = "SHPMT_PKG_LIST_ID", nullable = false)
    private Long shipmentPackingListId;
    @Column(name = "SHIPMENT_BARCODE", nullable = false)
    private String barcode;
    @Column(name = "DESCRIPTION", nullable = false)
    private String description;
    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;
    @Column(name = "LAST_MODIFIED_DATE", nullable = false)
    private Date lastModifiedDate;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREATED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity createdBy;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LAST_MODIFIED_BY_MIDAS_USER_ID", referencedColumnName = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity lastModifiedBy;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "shipmentPackingList", orphanRemoval = true)
    @OrderBy("shipmentContainerId")
    private Collection<ShipmentContainerEntity> shipmentContainers;
    @Column(name = "SHIP_FROM_CONTACT_ID")
    private Long fromContactId;
    @Column(name = "SHIP_TO_CONTACT_ID")
    private Long toContactId;
    @Column(name = "REGULATED_STATUS_TEXT")
    private String regulatedStatusText;
    @Column(name = "REG_COMPLI_CONFIRMED_DATE")
    private Date complianceConfirmedDate;
    @Column(name = "MATERIAL_STATUS_TXT")
    private String materialStatusText;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SAP_ORDER_SHIPMENT_ID", referencedColumnName = "SAP_ORDER_SHIPMENT_ID", nullable = false)
    private SapOrderShipmentEntity sapOrderShipment;
    @Column(name = "SHIP_TO_ATTN")
    private String shipToAttn;
    @Formula("(select count(*) from inventory_mgt.external_compliance_permit ecp INNER JOIN inventory_mgt.shipment_container sc on ecp.shipment_container_id = sc.shipment_container_id where sc.shpmt_pkg_list_id = shpmt_pkg_list_id)")
    private Boolean hasExternalPermits;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SHIPMENT_TYPE_ID", referencedColumnName = "SHIPMENT_TYPE_ID", nullable = false)
    private ShipmentTypeEntity shipmentType;

    public ShipmentPackingListEntity() {
    }

    public ShipmentPackingListEntity(Long shipmentPackingListId) {
        this.shipmentPackingListId = shipmentPackingListId;
    }

    public ShipmentPackingListEntity(ShipmentTypeEntity shipmentType) {
        this.shipmentType = shipmentType;
    }

    public Long getShipmentPackingListId() {
        return shipmentPackingListId;
    }

    public void setShipmentPackingListId(Long shipmentPackingListId) {
        this.shipmentPackingListId = shipmentPackingListId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MidasUserEntity getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(MidasUserEntity createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public MidasUserEntity getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(MidasUserEntity lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public Collection<ShipmentContainerEntity> getShipmentContainers() {
        return shipmentContainers;
    }

    public void setShipmentContainers(Collection<ShipmentContainerEntity> shipmentContainers) {
        this.shipmentContainers = shipmentContainers;
    }

    public Long getFromContactId() {
        return fromContactId;
    }

    public void setFromContactId(Long fromContactId) {
        this.fromContactId = fromContactId;
    }

    public Long getToContactId() {
        return toContactId;
    }

    public void setToContactId(Long toContactId) {
        this.toContactId = toContactId;
    }

    public ShipmentTypeEntity getShipmentType() {
        return shipmentType;
    }

    public void setShipmentType(ShipmentTypeEntity shipmentType) {
        this.shipmentType = shipmentType;
    }

    public String getRegulatedStatusText() {
        return regulatedStatusText;
    }

    public void setRegulatedStatusText(String regulatedStatusText) {
        this.regulatedStatusText = regulatedStatusText;
    }

    public Date getComplianceConfirmedDate() {
        return complianceConfirmedDate;
    }

    public String getMaterialStatusText() {
        return materialStatusText;
    }

    public void setMaterialStatusText(String materialStatusText) {
        this.materialStatusText = materialStatusText;
    }

    public boolean isInternational() {
        return (getSapOrderShipment() != null);
    }

    public SapOrderShipmentEntity getSapOrderShipment() {
        return this.sapOrderShipment;
    }

    public void setSapOrderShipment(SapOrderShipmentEntity entity) {
        this.sapOrderShipment = entity;
    }

    public void setComplianceConfirmedDate(Date complianceConfirmedDate) {
        this.complianceConfirmedDate = complianceConfirmedDate;
    }

    public String getShipToAttn() {
        return shipToAttn;
    }

    public void setShipToAttn(String shipToAttn) {
        this.shipToAttn = shipToAttn;
    }

    public Boolean hasExternalPermits() {
        return hasExternalPermits;
    }

    public void setHasExternalPermits(Boolean hasExternalPermits) {
        this.hasExternalPermits = hasExternalPermits;
    }

    @Override
    public String toString() {
        return "ShipmentPackingListEntity{" +
            "shipmentPackingListId=" + shipmentPackingListId +
            ", description='" + description + '\'' +
            ", lastModifiedDate=" + lastModifiedDate + '\'' +
            ", fromContactId=" + fromContactId + '\'' +
            ", toContactId=" + toContactId + '\'' +
            ", regulatedStatusText='" + regulatedStatusText + '\'' +
            '}';
    }
}
