package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.AgencyEntity;

import java.util.Collection;

public interface AgencyDao {
     AgencyEntity findById(Long id);

     AgencyEntity findByAbbr(String abbreviation);

    Collection<AgencyEntity> findAllActive();
}
