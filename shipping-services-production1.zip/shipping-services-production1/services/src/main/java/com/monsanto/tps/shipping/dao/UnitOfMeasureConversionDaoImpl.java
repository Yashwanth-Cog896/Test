package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
public class UnitOfMeasureConversionDaoImpl implements UnitOfMeasureConversionDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public UnitOfMeasureConversionEntity getUomConversion(Long fromUomId, Long toUomId) {
        return (UnitOfMeasureConversionEntity) sessionFactory.getCurrentSession()
                .createQuery("select uomConversion from UnitOfMeasureConversionEntity uomConversion " +
                        " where fromUom.id = :fromUomId and" +
                        " toUom.id = :toUomId and" +
                        " fromUom.refActive = true and" +
                        " toUom.refActive = true and" +
                        " uomConversion.refActive = true")
                .setParameter("fromUomId", fromUomId)
                .setParameter("toUomId", toUomId)
                .uniqueResult();
    }

}
