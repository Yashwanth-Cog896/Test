package com.monsanto.tps.shipping.domain;

public class OtherContentEntity implements ContentEntity {

    private Long scannedContainerId;
    private String barcode;

    public OtherContentEntity(Long id, String barcode) {
        this.scannedContainerId = id;
        this.barcode = barcode;
    }

    @Override
    public Long getContentId() {
        return null;
    }

    @Override
    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    @Override
    public GeneticMaterialEntity getGeneticMaterial() {
        return null;
    }

    @Override
    public InventoryEntity getInventory() {
        return null;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.OTHER;
    }

    @Override
    public String toString() {
        return "OtherContentEntity{" +
                ", scannedContainerId='" + scannedContainerId + '\'' +
                ", barcode='" + barcode + '\'' +
                '}';
    }
}
