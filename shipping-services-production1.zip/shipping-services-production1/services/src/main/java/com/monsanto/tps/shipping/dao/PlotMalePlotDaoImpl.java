package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.PlotMalePlotEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Repository
public class PlotMalePlotDaoImpl implements PlotMalePlotDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<PlotMalePlotEntity> findBinaryPlotMalePlotsForFemalePlots(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select plotMalePlot from PlotMalePlotEntity plotMalePlot, TempOcdTable tmp "+
                "where tmp.sessionId = :requestId " +
                "  and plotMalePlot.femalePlot.plotId = tmp.tempOcdNumber" +
                "  and upper(plotMalePlot.femalePlot.operationOperationType.operationType.operationTypeName) = upper('Binary')")
                .setParameter("requestId", requestId)
                .list();
    }

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<PlotMalePlotEntity> findUnaryPlotMalePlotsWithMalePlots(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select plotMalePlot from PlotMalePlotEntity plotMalePlot, TempOcdTable tmp "+
                "where tmp.sessionId = :requestId " +
                "  and plotMalePlot.femalePlot.plotId = tmp.tempOcdNumber" +
                "  and upper(plotMalePlot.femalePlot.operationOperationType.operationType.operationTypeName) = upper('Unary')")
                .setParameter("requestId", requestId)
                .list();
    }
}
