package com.monsanto.tps.shipping.business.compliance;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.dao.RegulatedMovementDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.CassetteContainerEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.InventoryEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Service
public class RegulatedCassetteMovementUpdater implements RegulatedMovementUpdater<InventoryEntity> {

    @Autowired
    private RegulatedMovementDao regulatedMovementDao;

    @Trace
    @Override
    public Collection<RegulatedInventoryMovementEntity> createRegulatedMovements(ShipmentPackingListEntity packingList, Collection<InventoryEntity> contents, AgencyEntity agencyEntity, Event event) {
        Collection<RegulatedInventoryMovementEntity> regulatedMovements = Lists.newArrayList();
        if (CollectionUtils.isEmpty(contents)) {
            return regulatedMovements;
        }


        Collection<CassetteContainerEntity> allCassettes = getCassettesForPackingList(packingList);

        for (ContentEntity content : contents) {

            Collection<CassetteContainerEntity> cassettesWithContent = getContentContainersForContent(allCassettes, content);

            for (CassetteContainerEntity cassette : cassettesWithContent) {
                RegulatedInventoryMovementEntity movement = newInstance((InventoryEntity) content, cassette, agencyEntity, event);
                regulatedMovementDao.save(movement);
                regulatedMovements.add(movement);
            }
        }


        return regulatedMovements;
    }

    private Collection<CassetteContainerEntity> getCassettesForPackingList(ShipmentPackingListEntity packingList) {
        Collection<CassetteContainerEntity> cassettes = Lists.newArrayList();

        for (ShipmentContainerEntity shipmentContainer : packingList.getShipmentContainers()) {
            StorageContainerEntity cassetteStorageContainer = shipmentContainer.getStorageContainer();
            cassettes.addAll(cassetteStorageContainer.getContainers());
        }

        return cassettes;
    }

    private RegulatedInventoryMovementEntity newInstance(InventoryEntity content, CassetteContainerEntity cassetteContainer, AgencyEntity agency, Event event) {
        RegulatedInventoryMovementEntity movement = new RegulatedInventoryMovementEntity();
        movement.setScannedContainer(cassetteContainer);
        movement.setInventory(content);
        movement.setAgency(agency);
        movement.setUserOverridden(false);
        movement.setEventString(event.getEventString());

        cassetteContainer.addRegulatedMovement(movement);

        return movement;
    }

    private Collection<CassetteContainerEntity> getContentContainersForContent(Collection<CassetteContainerEntity> allContentContainers, ContentEntity content) {
        Collection<CassetteContainerEntity> contentContainersWithContent = Lists.newArrayList();

        for (CassetteContainerEntity contentContainer : allContentContainers) {
            if (contentContainer.getContents().contains(content)) {
                contentContainersWithContent.add(contentContainer);
            }
        }

        return contentContainersWithContent;
    }

}
