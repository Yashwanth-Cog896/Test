package com.monsanto.tps.shipping.business;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.monsanto.tps.regulatory.cqa.db.model.questionnaire.LabelGroup;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.converter.SapApiOrderItemConverter;
import com.monsanto.tps.shipping.converter.SapDeliveryShipmentRequestBuilder;
import com.monsanto.tps.shipping.converter.SapOrderShipmentConverter;
import com.monsanto.tps.shipping.dao.SapOrderShipmentDao;
import com.monsanto.tps.shipping.dao.ShipmentPackingListDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderItemKey;
import com.monsanto.tps.shipping.domain.SapOrderItemWeights;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.sap.client.api.DeliveryShipmentCreateResponse;
import com.monsanto.tps.shipping.sap.client.api.DeliveryShipmentCreateService;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderCreate;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderCreateRequest;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderCreateResponse;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderRequest;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderUpdate;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderUpdateRequest;
import com.monsanto.tps.shipping.sap.client.api.SapApiOrderUpdateResponse;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.service.model.SapOrderShipment;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.RegulatedStatusText;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.TextUtils;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SapOrderShipmentBusinessImpl implements SapOrderShipmentBusiness {

    private static final Log LOG = LogFactory.getLog(SapOrderShipmentBusinessImpl.class);

    public static final String AIR_MODE = "40";
    public static final String SAP_ORDER_HOLD_STATUS_MESSAGE = "Sap Order hold status is: ";
    public static final String PACKING_LIST_NOT_FOUND = "Packing list not found for this SAP shipment number: ";
    public static final String MON_DC_STATUS_MESSAGE = "MonDcStatus received is: ";

    @Autowired
    private SapOrderShipmentDao sapOrderShipmentDao;

    @Autowired
    private SapOrderItemBusiness sapOrderItemBusiness;

    @Resource
    private ShipmentPackingListDao shipmentPackingListDao;

    public static final String SAP_ORDER_NUMBER_NOT_FOUND = "Sap Order not found";
    public static final String SAP_ORDER_SHIPMENT_HAS_NO_ITEMS = "Sap Order does not contain any items";
    public static final String SAP_ORDER_NO_PACKING_LIST = "Sap Order missing Packing-List Association";

    public static final String TO_UOM_NAME = "Kilograms";

    @Resource(name = "SapApiOrderCreate")
    private JaxWsProxyFactoryBean createOrderServiceFactory;

    @Resource(name = "SapApiOrderUpdate")
    private JaxWsProxyFactoryBean updateOrderServiceFactory;

    @Resource(name = "deliveryShipmentCreateService")
    private JaxWsProxyFactoryBean deliveryShipmentCreateServiceFactory;

    @Resource
    private SapDeliveryShipmentRequestBuilder sapDeliveryShipmentRequestBuilder;

    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Resource
    private SapApiOrderItemConverter sapApiOrderItemConverter;

    @Resource
    private EventHelper eventHelper;

    @Autowired
    private SapOrderShipmentConverter sapOrderShipmentConverter;

    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;

    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    @Override
    @Trace
    @Transactional(propagation = Propagation.REQUIRED)
    public void saveSapOrderShipment(SapOrderShipmentEntity sapOrderShipmentEntity) {
        sapOrderShipmentDao.saveSapOrderShipment(sapOrderShipmentEntity);
    }


    @Override
    @Trace
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<SapOrderShipmentEntity> getAllSapOrderShipments() {
        return sapOrderShipmentDao.getAllSapOrderShipments();
    }

    @Override
    @Trace
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public SapOrderShipmentEntity findBySapOrderNumber(String orderNumber) {
        return sapOrderShipmentDao.findBySapOrderNumber(orderNumber);
    }


    @Trace
    @Override
    public String editSapOrderShipmentStatus(SapOrderShipment sapOrderShipment) {
        String response = SAP_ORDER_HOLD_STATUS_MESSAGE + sapOrderShipment.getStatus();

        ShipmentPackingListEntity shipmentPackingListEntity = shipmentPackingListDao
            .getPackingListBySapDeliveryShipmentNumber(sapOrderShipment.getOrderNumber());
        ShippingWebException.checkArgument(null != shipmentPackingListEntity,
            PACKING_LIST_NOT_FOUND + sapOrderShipment.getOrderNumber());

        checkTheSapOrderShipmentHoldStatus(shipmentPackingListEntity.getSapOrderShipment(), sapOrderShipment);

        if (!StringUtils.isEmpty(sapOrderShipment.getMonDcStatus())) {
            response = TextUtils.getDelimitedStringWithComma(
                Lists.newArrayList(response, MON_DC_STATUS_MESSAGE + sapOrderShipment.getMonDcStatus()));
            if("Y".equalsIgnoreCase(sapOrderShipment.getMonDcStatus())) {
                shipmentPackingListEntity
                        .setRegulatedStatusText(RegulatedStatusText.GLOBAL_TRADE_DOCUMENTS_AVAILABLE.getRegulatedStatusText());
            }
        }
        LOG.warn("Response from editSapOrderShipmentStatus: " + response);
        return response;
    }

    private void checkTheSapOrderShipmentHoldStatus(SapOrderShipmentEntity sapOrderShipmentEntity,
                                                    SapOrderShipment sapOrderShipment) {
        if (StringUtils.isEmpty(sapOrderShipmentEntity.getSapErrorMessageText()) &&
            "H".equalsIgnoreCase(sapOrderShipment.getStatus())) {
            sapOrderShipmentEntity.setSapErrorMessageText("HOLD");
        } else if (!StringUtils.isEmpty(sapOrderShipmentEntity.getSapErrorMessageText()) &&
            "O".equalsIgnoreCase(sapOrderShipment.getStatus())) {
            sapOrderShipmentEntity.setSapErrorMessageText(null);
        }
    }

    @Trace
    @Override
    public SapOrderShipmentEntity createSapOrderShipment(ShipmentPackingList packingList,
                                                         MidasUserEntity midasUserEntity) {
        SapOrderShipmentEntity entity = new SapOrderShipmentEntity();

        entity.setSoldToCustomerNumber(packingList.getSoldToContactId());
        entity.setShipToCustomerNumber(packingList.getToContactId());
        entity.setSapStorageLocationCode(packingList.getFromSapContactId());
        entity.setModifiedBy(midasUserEntity);
        entity.setLastModifiedDate(new Date());
        entity.setCreatedBy(midasUserEntity);
        entity.setCreationDate(new Date());

        sapOrderShipmentDao.saveSapOrderShipment(entity);

        return entity;
    }

    @Trace
    @Override
    public String editSapOrderShipmentLcStatus(SapOrderShipment sapOrderShipment) {
        String response = "LC approval message";

        SapOrderShipmentEntity sapOrderShipmentEntity = sapOrderShipmentDao
            .findBySapOrderNumber(sapOrderShipment.getSapOrderNumber());
        if (sapOrderShipmentEntity == null) {
            throw new ShippingWebException(SAP_ORDER_NUMBER_NOT_FOUND);
        }
        if (sapOrderShipmentEntity.getOrderItems() == null || sapOrderShipmentEntity.getOrderItems().isEmpty()) {
            throw new ShippingWebException(SAP_ORDER_SHIPMENT_HAS_NO_ITEMS);
        }
        ShipmentPackingListEntity packingList = shipmentPackingListDao
            .getPackingListBySapOrderShipmentId(sapOrderShipmentEntity.getSapOrderShipmentId());
        if (packingList == null) {
            throw new ShippingWebException(SAP_ORDER_NO_PACKING_LIST);
        }
        sapOrderShipmentEntity.setDeliveryBlockCode(sapOrderShipment.getDeliveryBlockCode());
        if (StringUtils.isEmpty(sapOrderShipment.getDeliveryBlockCode())) {
            resetLcFields(sapOrderShipmentEntity);
            packingList.setRegulatedStatusText(RegulatedStatusText.LC_APPROVED.getRegulatedStatusText());
            response = "LC approved the request for order no: " + sapOrderShipment.getSapOrderNumber();
            LOG.warn(response);
        } else if (sapOrderShipment.getDeliveryBlockCode().equals("R2")) {
            List<SapOrderItem> orderItems = sapOrderShipment.getOrderItems();
            Collection<SapOrderItemEntity> sapOrderItemEntities = sapOrderShipmentEntity.getOrderItems();
            int rejectedCount = rejectSapOrderItemEntities(orderItems, sapOrderItemEntities);
            if (rejectedCount > 0) {
                packingList.setRegulatedStatusText(RegulatedStatusText.LC_APPROVAL_REJECTED.getRegulatedStatusText());
                LOG.warn("LC rejected the order for order no: " + sapOrderShipment.getSapOrderNumber());
                response = "LC rejected the order";
            } else {
                LOG.warn("Delivery block is R2 but none were rejected for order no: " + sapOrderShipment.getSapOrderNumber());
                response = "Unchanged";
            }
        } else if (sapOrderShipment.getDeliveryBlockCode().equalsIgnoreCase("XX") && StringUtils.isEmpty(sapOrderShipmentEntity.getShipmentNumber())) {
            try {
                SapOrderShipment createdSapDeliveryOrder = createSapDelivery(
                        sapOrderShipmentConverter.convertSapOrderShipment(sapOrderShipmentEntity), sapOrderShipmentEntity);
                packingList.setRegulatedStatusText(
                        RegulatedStatusText.AWAITING_GLOBAL_TRADE_DOCUMENTS.getRegulatedStatusText());
                response = "Create SAP delivery was successful with shipmentNbr: " + createdSapDeliveryOrder.getShipmentNumber();
                LOG.warn(response);
            } catch (ShippingWebException swe) {
                response = "Create SAP delivery failed";
                LOG.warn("Create SAP delivery failed with error: " + swe.getMessage() + "for order: " + sapOrderShipment.getSapOrderNumber());
            }
        }
        if(!sapOrderShipment.getDeliveryBlockCode().equalsIgnoreCase("xx")) {
            sapOrderShipmentEntity.setDeliveryBlockCode(sapOrderShipment.getDeliveryBlockCode());
        }
        sapOrderShipmentDao.saveSapOrderShipment(sapOrderShipmentEntity);

        return response;
    }

    private DeliveryShipmentCreateResponse createDeliveryShipment(SapOrderShipment sapOrderShipment) {
        DeliveryShipmentCreateService deliveryShipmentCreateService = (DeliveryShipmentCreateService) deliveryShipmentCreateServiceFactory
            .create();
        return deliveryShipmentCreateService
            .createDeliveryShipment(sapDeliveryShipmentRequestBuilder.getDeliveryShipmentRequest(sapOrderShipment));
    }

    private int rejectSapOrderItemEntities(List<SapOrderItem> sapOrderItems,
                                           Collection<SapOrderItemEntity> sapOrderItemEntities) {
        Map<String, SapOrderItem> modelMap = createOrderNumberToModelMap(sapOrderItems);
        int rejectedCount = 0;
        for (SapOrderItemEntity sapOrderItemEntity : sapOrderItemEntities) {
            String itemNumber = sapOrderItemEntity.getSapOrderItemNumber();
            if (modelMap.containsKey(itemNumber)) {
                SapOrderItem temp = modelMap.get(itemNumber);
                sapOrderItemEntity.setRejectionReasonCode(temp.getRejectionReasonCode());
                sapOrderItemEntity.setLcErrorMessage(temp.getErrorText());
                modelMap.remove(itemNumber);
                if (StringUtils.isNotBlank(temp.getErrorText())) {
                    rejectedCount++;
                }
            } else {
                sapOrderItemEntity.setRejectionReasonCode(null);
                sapOrderItemEntity.setLcErrorMessage(null);
            }
        }
        if (!modelMap.isEmpty()) {
            String remainingItemNumbers = modelMap.keySet().toString();
            throw new ShippingWebException("Item number(s) " + remainingItemNumbers + " not found in order");
        }
        return rejectedCount;
    }

    private Map<String, SapOrderItem> createOrderNumberToModelMap(List<SapOrderItem> sapOrderItems) {
        Map<String, SapOrderItem> modelMap = new HashMap<String, SapOrderItem>();
        for (SapOrderItem sapOrderItem : sapOrderItems) {
            if (!StringUtils.isEmpty(sapOrderItem.getErrorMessage())) {
                modelMap.put(sapOrderItem.getSapOrderItemNumber(), sapOrderItem);
            }
        }
        return modelMap;
    }

    private void resetLcFields(SapOrderShipmentEntity sapOrderShipmentEntity) {
        for (SapOrderItemEntity sapOrderItemEntity : sapOrderShipmentEntity.getOrderItems()) {
            sapOrderItemEntity.setRejectionReasonCode(null);
            sapOrderItemEntity.setLcErrorMessage(null);
        }
    }

    @Trace
    @Override
    public SapOrderShipmentEntity getSapOrderShipmentById(Long orderShipmentId) {
        return sapOrderShipmentDao.getSapOrderShipmentById(orderShipmentId);
    }

    @Trace
    @Override
    public void sendCreateOrder(SapOrderShipment sapOrderShipmentDto) {
        SapOrderShipmentEntity shipmentEntity = saveOrderShipment(sapOrderShipmentDto);
        ShipmentPackingListEntity packingList = shipmentPackingListDao
            .getPackingListBySapOrderShipmentId(shipmentEntity.getSapOrderShipmentId());

        SapOrderShipmentEntity sapOrderShipment = packingList.getSapOrderShipment();
        SapApiOrderCreateRequest request = new SapApiOrderCreateRequest();
        request.setShipcenterordernum(packingList.getBarcode().replace("SH", ""));
        Map<String, SapOrderItem> itemMap = populateRequest(request, packingList, sapOrderShipmentDto.getOrderItems(),
            false);

        SapApiOrderCreate createOrderService = (SapApiOrderCreate) createOrderServiceFactory.create();
        SapApiOrderCreateResponse response = createOrderService.createOrder(request);

        if (!response.hasErrors() && StringUtils.isNotEmpty(response.getOorderNum())) {
            sapOrderShipment.setSapOrderNumber(response.getOorderNum());
            sapOrderShipmentDto.setSapOrderNumber(response.getOorderNum());
            updateSapApiItems(packingList.getShipmentPackingListId(), response.getItemsTab(), itemMap);
        } else {
            throw new ShippingWebException(response.errorText());
        }
    }

    @Trace
    @Override
    public void sendUpdateOrder(SapOrderShipment sapOrderShipmentDto, boolean validateWeights) {
        SapOrderShipmentEntity shipmentEntity = saveOrderShipment(sapOrderShipmentDto);
        ShipmentPackingListEntity packingList = shipmentPackingListDao
            .getPackingListBySapOrderShipmentId(shipmentEntity.getSapOrderShipmentId());
        SapOrderShipmentEntity sapOrderShipment = packingList.getSapOrderShipment();

        SapApiOrderUpdateRequest request = new SapApiOrderUpdateRequest();
        Map<String, SapOrderItem> itemMap = populateRequest(request, packingList, sapOrderShipmentDto.getOrderItems(),
            validateWeights);
        request.setSapordernumber(sapOrderShipment.getSapOrderNumber());

        request.setSapdeliveryblock(null);

        SapApiOrderUpdate updateOrderService = (SapApiOrderUpdate) updateOrderServiceFactory.create();
        SapApiOrderUpdateResponse response = updateOrderService.updateOrder(request);

        if (validateWeights) {
            for (ShipmentContainerEntity containerEntity : packingList.getShipmentContainers()) {
                if (containerEntity.getStorageContainer().getContainers().size() == 0) {
                    throw new ShippingWebException("Please remove empty boxes from the shipment and try again.");
                }
            }
        }

        if (!response.hasErrors()) {
            LOG.info(packingList.getShipmentPackingListId() + " SAP Update Result: " + response.getInfoTab());
            for (SapOrderItem itemDto : sapOrderShipmentDto.getOrderItems()) {
                itemDto.setSapOrderItemNumber(null); // because it should be restored on the response
            }
            updateSapApiItems(packingList.getShipmentPackingListId(), response.getItemsTab(), itemMap);

        } else {
            throw new ShippingWebException(response.errorText());
        }
    }

    @Trace
    @Override
    public void requestLcApproval(SapOrderShipment sapOrderShipmentDto) {
        SapOrderShipmentEntity shipmentEntity = saveOrderShipment(sapOrderShipmentDto);
        ShipmentPackingListEntity packingList = shipmentPackingListDao
            .getPackingListBySapOrderShipmentId(shipmentEntity.getSapOrderShipmentId());

        SapApiOrderUpdateRequest request = new SapApiOrderUpdateRequest();
        populateRequest(request, packingList, sapOrderShipmentDto.getOrderItems(), true);
        request.setGtmcontact(sapOrderShipmentDto.getGtmId());
        request.setSapordernumber(shipmentEntity.getSapOrderNumber());
        request.setFreightforwarder(StringUtils.defaultIfBlank(sapOrderShipmentDto.getCarrierVendorNumber(), " "));
        request.setNotifyarrival(StringUtils.defaultIfBlank(sapOrderShipmentDto.getBrokerId(), " "));
        request.setShippingconditions(AIR_MODE);

        String deliveryBlock = "R3";

        shipmentEntity.setDeliveryBlockCode(deliveryBlock);
        request.setSapdeliveryblock(deliveryBlock);
        packingList.setRegulatedStatusText(RegulatedStatusText.WAITING_FOR_LC_APPROVAL.getRegulatedStatusText());

        resetLcFields(shipmentEntity);

        SapApiOrderUpdate updateOrderService = (SapApiOrderUpdate) updateOrderServiceFactory.create();
        SapApiOrderUpdateResponse response = updateOrderService.updateOrder(request);

        if (!response.hasErrors()) {
            LOG.info(
                packingList.getShipmentPackingListId() + " SAP Request LC Approval Result: " + response.getInfoTab());
        } else {
            throw new ShippingWebException(response.errorText());
        }
    }

    @Trace
    @Override
    public SapOrderShipment createSapDelivery(SapOrderShipment sapOrderShipment, SapOrderShipmentEntity entity) {
        DeliveryShipmentCreateResponse deliveryShipmentCreateResponse = createDeliveryShipment(sapOrderShipment);
        String shipmentNbr = deliveryShipmentCreateResponse.getShipmentNbr();

        if (!deliveryShipmentCreateResponse.hasErrors()) {
            ShipmentPackingListEntity packingList = shipmentPackingListDao
                .getPackingListBySapOrderShipmentId(sapOrderShipment.getSapOrderShipmentId());
            packingList
                .setRegulatedStatusText(RegulatedStatusText.AWAITING_GLOBAL_TRADE_DOCUMENTS.getRegulatedStatusText());

            entity.setShipmentNumber(shipmentNbr);

            sapOrderShipment.setShipmentNumber(shipmentNbr);
            sapOrderShipment
                .setMonDcStatus(RegulatedStatusText.AWAITING_GLOBAL_TRADE_DOCUMENTS.getRegulatedStatusText());
        } else {
            throw new ShippingWebException(deliveryShipmentCreateResponse.errorText());
        }

        return sapOrderShipment;
    }

    public void updateSapApiItems(Long packingListId, List<SapApiOrderItem> items, Map<String, SapOrderItem> itemMap) {
        for (SapApiOrderItem item : items) {
            String key = (item.getCustomermaterialnumber() + "-" + item.getSapmaterialnumber()).toUpperCase() + "-" +
                item.getSapcoo();
            SapOrderItem itemDto = itemMap.get(key);
            if (itemDto != null) {
                itemDto.setSapOrderItemNumber(item.getItemnumber());
                sapOrderItemBusiness.saveSapOrderItem(itemDto); // save the updated line number from SAP
            } else {
                LOG.error(packingListId + " Could not find match for sap material: " + key);
            }
        }
    }

    public Map<String, SapOrderItem> populateRequest(SapApiOrderRequest request, ShipmentPackingListEntity packingList,
                                                     List<SapOrderItem> items, boolean validateWeights) {
        SapOrderShipmentEntity sapOrderShipment = packingList.getSapOrderShipment();
        String user = null;
        if (userDetailsProvider.getUserDetails() != null) {
            user = userDetailsProvider.getUserDetails().getUsername();
        } else {
            user = System.getProperty("user.name");
        }
        ShippingWebException
            .checkArgument(StringUtils.isNotEmpty(sapOrderShipment.getSapStorageLocationCode()), "Ship-From Required");
        ShippingWebException
            .checkArgument(StringUtils.isNotEmpty(sapOrderShipment.getShipToCustomerNumber()), "Ship-To Required");
        request.setShipcenteruserid((user != null) && (!(user.isEmpty())) ? user : " ");
        request.setSapshiptonumber(sapOrderShipment.getShipToCustomerNumber());
        request.setSapsoldtonumber(sapOrderShipment.getSoldToCustomerNumber());
        request.setEndUse(internationalCompositesBusiness.getEndUseVendorNumberForResearch());

        Map<SapOrderItemKey, SapOrderItemWeights> weightMap = eventHelper.getComplianceKeyWeightMap(packingList);

        JSONArray errors = new JSONArray();
        Map<String, SapOrderItem> itemMap = new HashMap<String, SapOrderItem>();
        Long toUomId = unitOfMeasureDao.findByName(TO_UOM_NAME).getId();
        for (SapOrderItem itemDto : items) {
            try {
                if (StringUtils.isEmpty(itemDto.getValidationError())) {
                    SapOrderItemWeights weights = weightMap.get(new SapOrderItemKey(itemDto));
                    SapApiOrderItem item = sapApiOrderItemConverter
                        .convert(itemDto, sapOrderShipment, weights, toUomId);
                    request.addItItem(item);
                    if (validateWeights) {
                        ShippingWebException.checkArgument(item.getUomId() != null, "UOM is required");
                        ShippingWebException.checkArgument(weights.getBoxWeight() > 0.0, "Box Gross Weight Required");
                        ShippingWebException.checkArgument(weights.getItemWeight() > 0.0, "Item Net Weight Required");
                    }
                    String key =
                        (item.getCustomermaterialnumber() + "-" + itemDto.getSapMaterialNumber()).toUpperCase() + "-" +
                            item.getSapcoo();
                    itemMap.put(key, itemDto);
                } else {
                    throw new ShippingWebException(itemDto.getValidationError());
                }
            } catch (ShippingWebException e) {
                itemDto.setValidationError(e.getMessage());
                errors.put(new ImmutableMap.Builder<String, Object>()
                    .put("id", itemDto.getSapOrderItemId())
                    .put("error", itemDto.getValidationError())
                    .build());
            }
        }

        if (errors.length() != 0) {
            throw new ShippingWebException(new JSONObject(
                new ImmutableMap.Builder<String, Object>()
                    .put("error-items", errors)
                    .build()).toString());
        }
        return itemMap;
    }

    @Trace
    @Override
    public SapOrderShipmentEntity saveOrderShipment(SapOrderShipment shipmentDto) {
        SapOrderShipmentEntity shipmentEntity = sapOrderShipmentDao
            .getSapOrderShipmentById(shipmentDto.getSapOrderShipmentId());
        if (shipmentEntity == null) {
            throw new ShippingWebException(
                "Unable to find SapOrderShipment in database: " + shipmentDto.getSapOrderShipmentId());
        }
        Date modificationDate = new Date();
        shipmentEntity.setDeliveryBlockCode(shipmentDto.getDeliveryBlockCode());
        shipmentEntity.setCarrierVendorNumber(shipmentDto.getCarrierVendorNumber());
        shipmentEntity.setBrokerCustomerNumber(shipmentDto.getBrokerId());
        shipmentEntity.setLastModifiedDate(modificationDate);
        sapOrderShipmentDao.saveSapOrderShipment(shipmentEntity);
        List<SapOrderItem> itemDtos = shipmentDto.getOrderItems();
        for (SapOrderItem itemDto : itemDtos) {
            sapOrderItemBusiness.saveSapOrderItem(itemDto); // need to update sap material number
        }
        return shipmentEntity;
    }

}
