package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.dao.AgencyDao;
import com.monsanto.tps.shipping.dao.ExternalMaterialTypeDao;
import com.monsanto.tps.shipping.dao.ExternalPermitDao;
import com.monsanto.tps.shipping.dao.MidasUserDao;
import com.monsanto.tps.shipping.dao.ShipmentContainerDao;
import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ExternalPermit;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Date;

@Service
public class ExternalPermitBusinessImpl implements ExternalPermitBusiness {
    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;
    @Autowired
    private ExternalPermitDao externalPermitDao;
    @Autowired
    private ShipmentContainerDao shipmentContainerDao;
    @Autowired
    private MidasUserDao midasUserDao;
    @Autowired
    private AgencyDao agencyDao;
    @Autowired
    private ExternalMaterialTypeDao externalMaterialIdDao;
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public ExternalPermitEntity save(final ExternalPermit externalPermit) {
        //Check for existing external permit
        ExternalPermitEntity duplicatePermit = externalPermitDao.findByExternalPermit(externalPermit);
        if (duplicatePermit != null && !duplicatePermit.getId().equals(externalPermit.getId())) {
            throw new ShippingWebException("duplicatePermit");
        }

        ExternalPermitEntity externalPermitEntity;
        if (externalPermit.getId() != null) {
            externalPermitEntity = externalPermitDao.load(externalPermit.getId());
            applyValues(externalPermit, externalPermitEntity);
        } else {
            externalPermitEntity = createNewExternalPermitEntity(externalPermit);
        }

        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerDao.load(externalPermit.getShipmentContainerId());
        externalPermitEntity.setShipmentContainer(shipmentContainerEntity);

        externalPermitDao.save(externalPermitEntity);
        sessionFactory.getCurrentSession().flush();
        return externalPermitEntity;
    }

    @Override
    public void delete(Long externalPermitId) {
        ExternalPermitEntity externalPermitEntity = externalPermitDao.load(externalPermitId);
        externalPermitDao.delete(externalPermitEntity);
    }

    @Override
    public Collection<ExternalPermitEntity> getExternalPermitsForPackingList(ShipmentPackingListEntity packingList) {
        Collection<ExternalPermitEntity> externalPermitEntities = Lists.newArrayList();

        if (CollectionUtils.isEmpty(packingList.getShipmentContainers())) {
            return externalPermitEntities;
        }

        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            if (!CollectionUtils.isEmpty(shipmentContainerEntity.getExternalPermits())) {
                for (ExternalPermitEntity externalPermitEntity : shipmentContainerEntity.getExternalPermits()) {
                    externalPermitEntities.add(externalPermitEntity);
                }
            }
        }
        return externalPermitEntities;
    }


    private ExternalPermitEntity createNewExternalPermitEntity(ExternalPermit externalPermit) {
        ExternalPermitEntity externalPermitEntity = new ExternalPermitEntity();
        applyValues(externalPermit, externalPermitEntity);

        MidasUserEntity midasUserEntity = midasUserDao.getByUserId(userDetailsProvider.getUserDetails().getUsername());
        externalPermitEntity.setCreatedByMidasUserId(midasUserEntity.getMidasUserId());
        externalPermitEntity.setCreationDate(new Date());
        return externalPermitEntity;
    }

    private void applyValues(ExternalPermit externalPermit, ExternalPermitEntity externalPermitEntity) {
        setAgencyInfo(externalPermit, externalPermitEntity);
        externalPermitEntity.setPermitNumber(externalPermit.getPermitName());
        externalPermitEntity.setExpirationDate(externalPermit.getExpirationDate());
        externalPermitEntity.setMaterialDescription(externalPermit.getMaterialDescription());
        externalPermitEntity.setConstructName(externalPermit.getConstructName());
        externalPermitEntity.setExternalMaterialType(externalMaterialIdDao.findById(externalPermit.getExternalMaterialTypeId()));
        externalPermitEntity.setEventName(externalPermit.getEventName());
    }

    private void setAgencyInfo(ExternalPermit externalPermit, ExternalPermitEntity externalPermitEntity) {
        if (externalPermit.getAgencyId() != null) {
            externalPermitEntity.setAgency(agencyDao.findById(externalPermit.getAgencyId()));
            externalPermitEntity.setOtherAgencyName(null);
        } else {
            externalPermitEntity.setAgency(null);
            externalPermitEntity.setOtherAgencyName(externalPermit.getAgency());
        }
    }
}
