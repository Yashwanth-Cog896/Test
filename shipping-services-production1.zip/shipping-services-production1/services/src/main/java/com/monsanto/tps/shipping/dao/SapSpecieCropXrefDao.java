package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapSpecieCropXrefEntity;

import java.util.List;

/**
 * User: pgadi
 */
public interface SapSpecieCropXrefDao {
    List<SapSpecieCropXrefEntity> getSapSpecieCropEntities();

    SapSpecieCropXrefEntity getSapSpecieCropEntityByCropSubclassId(Long cropId);
}
