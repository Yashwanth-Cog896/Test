package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Report;
import com.monsanto.tps.shipping.service.model.enums.ReportEnum;

import java.io.IOException;
import java.util.concurrent.Future;

/**
 * Created by rlcasw
 */
public interface ReportBusiness {
    Report getReport(ReportEnum report, ShipmentPackingListEntity packingList) throws IOException;

    Future<Report> getReportAsync(ReportEnum report, Long packingListId);
}
