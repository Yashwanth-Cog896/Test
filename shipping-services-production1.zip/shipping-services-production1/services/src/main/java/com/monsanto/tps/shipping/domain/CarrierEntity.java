package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="CARRIER", schema="INVENTORY_MGT")
public class CarrierEntity {
    @Id
    @Column(name = "CARRIER_ID")
    private Long carrierId;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type="true_false")
    private boolean refActive;

    @Column(name = "SUPPORT_INTEGRATED_SHIPPING", nullable = true)
    @Type(type="true_false")
    private boolean supportIntegratedShipping;

    @Column(name = "MODIFIED_DTTM", nullable = true)
    private Date modifiedDttm;

    @Column(name="WEBSITE_URL_TXT", nullable = true)
    private String websiteUrl;

    @Column(name="SHIPMENT_TRACKING_URL_TXT", nullable = true)
    private String trackingUrl;

    public Long getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(Long carrierId) {
        this.carrierId = carrierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public boolean isSupportIntegratedShipping() {
        return supportIntegratedShipping;
    }

    public void setSupportIntegratedShipping(boolean supportIntegratedShipping) {
        this.supportIntegratedShipping = supportIntegratedShipping;
    }

    public Date getModifiedDttm() {
        return modifiedDttm;
    }

    public void setModifiedDttm(Date modifiedDttm) {
        this.modifiedDttm = modifiedDttm;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getTrackingUrl() {
        return trackingUrl;
    }

    public void setTrackingUrl(String trackingUrl) {
        this.trackingUrl = trackingUrl;
    }

    @Override
    public String toString() {
        return  name;
    }
}
