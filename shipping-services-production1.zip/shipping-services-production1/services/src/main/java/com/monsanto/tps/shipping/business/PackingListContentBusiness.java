package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.util.aspect.Trace;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
public interface PackingListContentBusiness {

    ScannedContainerEntity getContentContainer(Long id, ContentType contentType);

    ContentEntity getContents(String barcode, ContentType contentType);

    List<? extends ContentEntity> getContents(Set<String> barcodes, ContentType contentType);

    void updatePackingListContents(StorageContainerEntity storageContainerEntity,
                                   List<PackingListContent> packingListContents,
                                   ShipmentTypeEntity shipmentTypeEntity, Long uomId,
                                   Double permitUnitsUomConversionFactor);

    @Trace
    ScannedContainerEntity saveNewPackingListContent(ContentEntity contentEntity,
                                                     ShipmentContainerEntity shipmentContainerEntity,
                                                     PackingListContent packingListContent,
                                                     ShipmentTypeEntity shipmentType,
                                                     UnitOfMeasureEntity unitOfMeasureEntity);

    void deleteContent(Collection<? extends ScannedContainerEntity> containers);

    void deleteContent(Long contentId, Long shipmentTypeId);

    ScannedContainerEntity savePackingListContent(PackingListContent packingListContent, ContentEntity contentEntity,
                                                  Long shipmentContainerId, ShipmentTypeEntity shipmentType);

    void updateUom(Collection<Long> storageContainerIds, Long uomId);

    void updateWeight(Collection<Long> scannedContainerIds, Double amount, String uom);

    void updateName(Collection<Long> scannedContainerIds, String name);
    
    void updateComment(Collection<Long> scannedContainerIds, String comment);
    
    void updateSeedCount(Collection<Long> scannedContainerIds, Integer amount);

    void updateSeedCountAndWeight(Collection<Long> scannedContainerIds, Integer amount, Double weight, UnitOfMeasureEntity unitOfMeasureEntity);

    Double getPermitUnitsConversionFactor(UnitOfMeasureEntity unitOfMeasureEntity);

    void verifyContent(Long scannedContainerId, Long storageContainerId, Boolean outGoing);

    void verifyMultipleContents(Collection<Long> scannedContainerIds, Long storageContainerIds, Boolean outGoing);

    void resetVerifiedContent(Long scannedContainerId, Boolean outGoing);

}
