package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

@Service
public class WholePlantsMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);

        addSelectedPermitsToTable(permitsTable, events, false, font);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            String eventString = getEventString(contentContainerEntity.getContent());

            appendCellToTable(contentContainerEntity.getScanOrder(), contentsTable, font);
            appendCellToTable(contentContainerEntity.getContent().getBarcode(), contentsTable, font);
            appendCellToTable(eventString, contentsTable, font);
            appendCellToTable(contentContainerEntity.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(
                new String[]{"Item #", "Item BID", "Event", "Box Barcode", "Received"},
                new float[]{15, 55, 65, 25, 20}, font);
    }

    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(
                new String[]{"Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[]{120, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.WHOLE_PLANTS;
    }
}
