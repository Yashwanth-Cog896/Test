
package com.monsanto.tps.shipping.sap.client.api;

import com.monsanto.tps.shipping.sap.client.api.model.SapApiError;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiErrorTabBapi;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiInfoTabItem;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;
import org.apache.commons.collections.CollectionUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "errorTab",
    "errorTabBapi",
    "infoTab",
    "itemsTab",
    "oorderNum"
})
@XmlRootElement(name = "YSdgtmCreateSoIbResponse")
public class SapApiOrderCreateResponse {

    @XmlElementWrapper(name = "ErrorTab")
    @XmlElement(name = "item")
    private List<SapApiError> errorTab = new ArrayList<SapApiError>();

    @XmlElementWrapper(name = "ErrorTabBapi")
    @XmlElement(name = "item")
    private List<SapApiErrorTabBapi> errorTabBapi;

    @XmlElementWrapper(name = "InfoTab")
    @XmlElement(name = "item", required = true)
    private List<SapApiInfoTabItem> infoTab;

    @XmlElementWrapper(name = "ItemsTab")
    @XmlElement(name = "item", required = true)
    private List<SapApiOrderItem> itemsTab = new ArrayList<SapApiOrderItem>();

    @XmlElement(name = "OorderNum", required = true)
    private String oorderNum;

    public List<SapApiError> getErrorTab() {
        return errorTab;
    }

    public void setErrorTab(List<SapApiError> errorTab) {
        this.errorTab = errorTab;
    }

    public List<SapApiErrorTabBapi> getErrorTabBapi() {
        return errorTabBapi;
    }

    public void setErrorTabBapi(List<SapApiErrorTabBapi> errorTabBapi) {
        this.errorTabBapi = errorTabBapi;
    }

    public List<SapApiInfoTabItem> getInfoTab() {
        return infoTab;
    }

    public void setInfoTab(List<SapApiInfoTabItem> infoTab) {
        this.infoTab = infoTab;
    }

    public List<SapApiOrderItem> getItemsTab() {
        return itemsTab;
    }

    public void setItemsTab(List<SapApiOrderItem> itemsTab) {
        this.itemsTab = itemsTab;
    }

    public String getOorderNum() {
        return oorderNum;
    }

    public void setOorderNum(String oorderNum) {
        this.oorderNum = oorderNum;
    }

    public boolean hasErrors() {
        return
            !(CollectionUtils.isEmpty(errorTab) && CollectionUtils.isEmpty(errorTabBapi));
    }

    public String errorText() {
        if (CollectionUtils.isNotEmpty(errorTab)) {
            return errorTab.get(0).getYydesc();
        }
        if (CollectionUtils.isNotEmpty(errorTabBapi)) {
            return errorTabBapi.get(0).getYymessgV1();
        }
        return "Failed to Create SAP Order.";
    }

}
