package com.monsanto.tps.shipping.business;

import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.party.transfer.ContactTO;
import com.monsanto.tps.shipping.domain.ShipmentContactEntity;
import com.monsanto.tps.shipping.service.model.ShipmentContact;

import java.util.Collection;
import java.util.List;

/**
 * User: DCENGL
 */
public interface ContactBusiness {

    List<ShipmentContact> getContactsForAccount(Long accountId);

    ShipmentContact getContact(Long contactId);

    Contact getPartyContact(Long contactId);

    ContactTO getPartyContactByContactId(Long contactId);

    List<ContactTO> getPartyContactsByAccountId(Long accountId);

    Collection<ShipmentContact> getContacts(Collection<Long> contactIds);

    ShipmentContactEntity createShipmentContact(Contact contact);

    ShipmentContactEntity createShipmentContact(Contact contact, String shipmAttn);
}
