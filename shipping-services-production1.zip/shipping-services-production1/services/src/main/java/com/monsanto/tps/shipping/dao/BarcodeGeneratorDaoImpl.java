package com.monsanto.tps.shipping.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BarcodeGeneratorDaoImpl implements BarcodeGeneratorDao {

    @Autowired
    private SessionFactory sessionFactory;
    private static final Object LOCK = new Object();


    @Override
    public String generateNewShipmentBarcode() {
        return "SH" + generateNewBarcode();
    }

    @Override
    public String generateNewStorageContainerBarcode() {
        return "SU" + generateNewBarcode();
    }

    private String generateNewBarcode() {
        synchronized (LOCK) {
            return (String) sessionFactory.getCurrentSession().createSQLQuery("select TO_CHAR(column_value) FROM table(inventory_mgt.get_next_barcodeid(1))").uniqueResult();
        }
    }
}
