package com.monsanto.tps.shipping.dao;

/**
 * User: PGADI
 */
public interface ShipmentContentProcessDao {
    public Long getShipmentContentProcessId(String processingStatusCode);
}
