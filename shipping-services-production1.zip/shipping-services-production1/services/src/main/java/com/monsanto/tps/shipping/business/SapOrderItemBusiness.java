package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.service.model.SapOrderItem;

import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
public interface SapOrderItemBusiness {

    List<SapOrderItem> deriveSapOrderItems(Long sapOrderShipmentId);

    void saveSapOrderItem(SapOrderItem sapOrderItem);

    void deleteSapOrderItem(Collection<SapOrderItemEntity> sapOrderItems);
}
