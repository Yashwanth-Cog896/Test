package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.RepEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public class RepDaoImpl implements RepDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Trace
    public RepEntity findById(long id) {
        return (RepEntity) sessionFactory.getCurrentSession().load(RepEntity.class, id);
    }

    @Override
    @Trace
    public RepEntity findByBarcode(String barcode) {
        List<RepEntity> reps = (List<RepEntity>) sessionFactory.getCurrentSession()
                .createQuery("from RepEntity where barcode = :barcode")
                .setParameter("barcode", barcode).list();
        return CollectionUtils.isEmpty(reps) ? null : reps.get(0);
    }

    @Override
    @Trace
    public RepEntity findByPlotBarcode(String barcode) {
        List<RepEntity> reps = (List<RepEntity>) sessionFactory.getCurrentSession()
                .createQuery("select p.rep from PlotEntity p where p.barcode = :barcode")
                .setParameter("barcode", barcode).list();
        return CollectionUtils.isEmpty(reps) ? null : reps.get(0);
    }

    @Override
    public List<RepEntity> findRepsByShipmentPackingListId(Long shipmentPackingListId) {
        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(getRepsByShipmentPkgListIdSql()).addEntity(RepEntity.class);
        query.setLong("PACKING_LIST_ID", shipmentPackingListId);
        return query.list();
    }

    @Override
    @Trace
    public int getNextScanOrderForRep(long packingListId) {
        return ((BigDecimal) sessionFactory.getCurrentSession()
                .createSQLQuery("select nvl(max(PC.display_order_nbr), 0)+1\n" +
                        "from inventory_mgt.shipment_container shc, \n" +
                        "     inventory_mgt.storage_container sc,\n" +
                        "     inventory_mgt.scanned_container pc\n" +
                        "where shc.storage_container_id = sc.storage_container_id \n" +
                        "and sc.storage_container_id = pc.packed_in_storage_container_id \n" +
                        "and shc.shpmt_pkg_list_id = :PACKING_LIST_ID")
                .setParameter("PACKING_LIST_ID", packingListId)
                .uniqueResult()).intValue();
    }

    private String getRepsByShipmentPkgListIdSql() {
        return "select  distinct rep.* from " +
                "INVENTORY_MGT.SHIPMENT_CONTAINER shipment_container " +
                "inner join INVENTORY_MGT.STORAGE_CONTAINER STORAGE_CONTAINER on STORAGE_CONTAINER.STORAGE_CONTAINER_ID=SHIPMENT_CONTAINER.STORAGE_CONTAINER_ID " +
                "inner join INVENTORY_MGT.SHPMT_PKG_LIST packing_list on shipment_container.shpmt_pkg_list_id=packing_list.shpmt_pkg_list_id " +
                "inner join INVENTORY_MGT.scanned_container pc on pc.packed_in_storage_container_id=storage_container.storage_container_id " +
                "inner join MIDAS.PLOT plot on plot.BARCODE=pc.BARCODE_NBR " +
                "inner join Midas.BR_REP rep on rep.br_rep_id=plot.rep_id " +
                "where  packing_list.shpmt_pkg_list_id=:PACKING_LIST_ID";
    }
}
