package com.monsanto.tps.shipping.converter;

import com.monsanto.tps.shipping.dao.CountryDao;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.domain.SapOrderItemWeights;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.WeightConverter;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class SapApiOrderItemConverter {

    private static final String MIN_WEIGHT_VALUE = "0.001";
    public static final Double MIN_WEIGHT = Double.valueOf(MIN_WEIGHT_VALUE);

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Resource
    private CountryDao countryDao;

    @Autowired
    private WeightConverter weightConverter;

    public SapApiOrderItem convert(SapOrderItem itemDto, SapOrderShipmentEntity sapOrderShipment, SapOrderItemWeights weights, Long toUomId) {

        ShippingWebException.checkArgument(itemDto.getSapMaterialNumber() != null, "No SAP material found");

        InternationalStorageLocation shipFrom = internationalCompositesDao.getStorageLocation(sapOrderShipment.getSapStorageLocationCode());
        ShippingWebException.checkArgument(shipFrom != null, "Invalid Ship-From Code: " + sapOrderShipment.getSapStorageLocationCode());
        ShippingWebException.checkArgument(shipFrom.getPlant() != null, "Ship-From Plant Code was missing for: " + shipFrom.getName());

        ShippingWebException.checkArgument(itemDto.getCountryOfOrigin() != null, "Missing Country of Origin");
        String coo = countryDao.getCountry(itemDto.getCountryOfOrigin()).getIsoCode();
        ShippingWebException.checkArgument(coo != null, "Invalid Country of Origin");

        ShippingWebException.checkArgument(itemDto.getBoxNumber() != null, "Invalid box: " + itemDto.getBoxNumber());

        SapApiOrderItem item = new SapApiOrderItem();

        if (StringUtils.isNotEmpty(itemDto.getSapOrderItemNumber())) {
            item.setItemnumber(itemDto.getSapOrderItemNumber());
        } else {
            item.setItemnumber("000000");
        }

        item.setSapcoo(coo);
        item.setSapregionoforigin(StringUtils.defaultString(itemDto.getRegionOfOrigin(), " ")); // because wsdl is still not minoccurs="0"
        ShippingWebException.checkArgument(item.getSapregionoforigin().length() <= 3, "Region too long");

        item.setSapmaterialnumber(itemDto.getSapMaterialNumber());

        item.setSapstoragelocation(sapOrderShipment.getSapStorageLocationCode());
        item.setSapplant(shipFrom.getPlant());

        item.setPhytosanitaryitemtext(StringUtils.defaultString(itemDto.getPhytoNumber(), " ")); // because wsdl is still not minoccurs="0"
        item.setImportpermitnumber(itemDto.getImportPermitNumber());
        item.setImportpermitnumber(StringUtils.defaultString(item.getImportpermitnumber(), " ")); // because wsdl is still not minoccurs="0"

        if (weights == null || weights.getUomId() == null) {
            item.setOrderquantity(BigDecimal.ZERO);
            item.setBoxWeight(BigDecimal.ZERO);
            item.setUomId(null);
        } else {
            item.setOrderquantity(convert(weights.getItemWeight(), weights, toUomId));
            item.setBoxWeight(convert(weights.getBoxWeight(), weights, toUomId));
            item.setUomId(weights.getUomId());
        }
        if (item.getOrderquantity().doubleValue() < MIN_WEIGHT) {
            item.setOrderquantity(new BigDecimal(MIN_WEIGHT_VALUE));
        }

        item.setSalesunit("KG");

        item.setCustomermaterialnumber("BOX " + itemDto.getBoxNumber());

        item.setMaterialsalestext(" "); // because wsdl is still not minoccurs="0"

        item.setRegistrationnumber(" "); // because wsdl is still not minoccurs="0"
        item.setSaproute(" "); // because wsdl is still not minoccurs="0"
        item.setYyShipfromid(" "); // because wsdl is still not minoccurs="0"
        item.setReasonforrejection(" ");  // because wsdl is still not minoccurs="0"

        itemDto.setValidationError(null);

        return item;
    }

    private BigDecimal convert(Double weight, SapOrderItemWeights weights, Long toUomId) {
        BigDecimal finalWeight;
        Double converted = weightConverter.convertWeight(weight, weights.getUomId(), toUomId);
        if (converted != null) {
            finalWeight = new BigDecimal(converted.toString());
        } else {
            finalWeight = BigDecimal.ZERO;
        }
        BigDecimal formattedWeight = finalWeight.setScale(3, RoundingMode.HALF_UP);
        return  formattedWeight.equals(new BigDecimal("0.000")) ? new BigDecimal("0.001") : formattedWeight;
    }
}
