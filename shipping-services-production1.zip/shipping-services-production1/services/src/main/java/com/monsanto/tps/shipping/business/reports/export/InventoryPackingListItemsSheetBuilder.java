package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

/**
 * Created by DCENGL
 */
@Service
public class InventoryPackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Item BID", "Event", "Weight", "UOM", "Count", "Box Barcode", "Monsanto ID", "Permit"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        int currentRowIndex = 1;
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        Collection<Event> events = getPermits(packingList);
        for (ScannedContainerEntity scannedContainerEntity : contentContainerEntities) {
            String eventString = getEventString(scannedContainerEntity.getContent());
            Event event = getEventForContainer(scannedContainerEntity.getContainerId(), events);

            Row row = sheet.createRow(currentRowIndex);
            appendCell(row, defaultCellStyle, scannedContainerEntity.getScanOrder());
            appendCell(row, defaultCellStyle, scannedContainerEntity.getContent().getBarcode());
            appendCell(row, defaultCellStyle, eventString);
            appendCell(row, defaultCellStyle, scannedContainerEntity.getWeight());
            appendCell(row, defaultCellStyle, scannedContainerEntity.getWeightUOM() != null ? scannedContainerEntity.getWeightUOM().getUomRefId() : null);
            appendCell(row, defaultCellStyle, scannedContainerEntity.getQuantity());
            appendCell(row, defaultCellStyle, scannedContainerEntity.getStorageContainer().getBarcode());
            appendCell(row, defaultCellStyle, getMonsantoIdString(event));
            appendCell(row, defaultCellStyle, getPermitString(event));

            currentRowIndex++;
        }
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.INVENTORY;
    }
}
