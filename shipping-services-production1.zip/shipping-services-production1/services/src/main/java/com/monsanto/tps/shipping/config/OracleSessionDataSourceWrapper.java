package com.monsanto.tps.shipping.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DelegatingDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class OracleSessionDataSourceWrapper extends DelegatingDataSource {
    
    private static final Logger logger = LoggerFactory.getLogger(OracleSessionDataSourceWrapper.class);
    
    public OracleSessionDataSourceWrapper(DataSource targetDataSource) {
        super(targetDataSource);
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        Connection connection = super.getConnection();
        setOracleSessionParameters(connection);
        return connection;
    }
    
    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        Connection connection = super.getConnection(username, password);
        setOracleSessionParameters(connection);
        return connection;
    }
    
    private void setOracleSessionParameters(Connection connection) {
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("ALTER SESSION SET \"_optimizer_squ_bottomup\"=true");
            logger.debug("Oracle alter session parameters set for connection");
        } catch (SQLException e) {
            logger.error("Failed to set Oracle session parameters", e);
        }
    }
}