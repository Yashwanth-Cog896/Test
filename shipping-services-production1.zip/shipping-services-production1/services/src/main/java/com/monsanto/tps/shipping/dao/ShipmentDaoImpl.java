package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShippingStatus;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * User: PGADI
 */
@Repository
public class ShipmentDaoImpl implements ShipmentDao {

    private static final String[] UNDELIVERED_QUERY_STATUSES = {
        ShippingStatus.READY_FOR_PICKUP,
        ShippingStatus.IN_TRANSIT,
    };

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public void saveShipment(ShipmentEntity shipmentEntity) {
        sessionFactory.getCurrentSession().save(shipmentEntity);
    }

    @Override
    public ShipmentEntity findByBarcode(String barcode) {
        return (ShipmentEntity) sessionFactory.getCurrentSession()
            .createQuery("from ShipmentEntity se where se.shipmentBarcode = :barcode")
            .setParameter("barcode", barcode)
            .uniqueResult();
    }

    @Trace
    @Override
    public List<ShipmentEntity> getShipments(Long accountId, Date shippedDate, boolean retrieveByFromAccountId,
                                             List<String> validStatuses) {
        return sessionFactory.getCurrentSession()
            .createQuery(getShipmentsQuery(retrieveByFromAccountId))
            .setParameter("accountId", accountId)
            .setParameter("shippedDate", shippedDate)
            .setParameterList("validStatusList", validStatuses)
            .list();
    }

    @Trace
    @Override
    @SuppressWarnings("unchecked")
    public List<ShipmentEntity> getShipmentsByCountry(String country, Date shippedDate, boolean retrieveByFrom,
                                                      List<String> validStatuses) {
        return sessionFactory.getCurrentSession()
            .createQuery(getInternationalShipmentsQuery(retrieveByFrom))
            .setParameter("isoCountryCode", country)
            .setParameter("shippedDate", shippedDate)
            .setParameterList("validStatusList", validStatuses)
            .list();
    }

    @Trace
    @Override
    public ShipmentEntity load(Long shipmentId) {
        return (ShipmentEntity) sessionFactory.getCurrentSession().load(ShipmentEntity.class, shipmentId);
    }

    @Trace
    @Override
    public void delete(ShipmentEntity shipment) {
        sessionFactory.getCurrentSession().delete(shipment);
    }

    private String getShipmentsQuery(boolean displayOutgoingShipments) {
        String direction = displayOutgoingShipments ? "fromAccountId" : "toAccountId";
        return "from ShipmentEntity shipment " +
            "where shipment.shipDate >= :shippedDate " +
            "and shipment." + direction + "= :accountId " +
            "and shipment.sourceSystem.name = 'Shipping Web' " +
            "and shipment.status.name in (:validStatusList) " +
            "and shipment.sapOrderNumber is null " +
            "order by shipment.shipmentBarcode ";
    }

    private String getInternationalShipmentsQuery(boolean displayOutgoingShipments) {
        String direction = displayOutgoingShipments ? "fromAddress" : "toAddress";
        return "from ShipmentEntity shipment " +
            "where shipment.shipDate >= :shippedDate " +
            "and shipment." + direction + ".isoCountryCode= :isoCountryCode " +
            "and shipment.sourceSystem.name = 'Shipping Web' " +
            "and shipment.status.name in (:validStatusList) " +
            "and shipment.sapOrderNumber is not null " +
            "order by shipment.shipmentBarcode ";
    }


    @SuppressWarnings("unchecked")
    @Override
    public List<ShipmentEntity> getUndeliveredShipments(Long carrierId) {
        return sessionFactory.getCurrentSession().createQuery(
            "from ShipmentEntity shipment " +
                "where shipment.carrier.carrierId = :carrierId" +
                " and shipment.sourceSystem.name = 'Shipping Web'" +
                " and shipment.status in (from ShippingStatus where name in (:undeliveredStatuses))")
            .setParameter("carrierId", carrierId)
            .setParameterList("undeliveredStatuses", UNDELIVERED_QUERY_STATUSES)
            .list();
    }

}
