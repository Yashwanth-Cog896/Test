package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SourceSystem;

/**
 * User: pgadi
 */
public interface SourceSystemDao {
    SourceSystem getSourceSystemByName(String sourceSystemName);
}
