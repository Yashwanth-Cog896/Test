package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by DCENGL
 */
@Service
public class EpaSection extends AbstractChecklistSection {

    private static final String HEADER = "Additional requirements for movement of EPA governed materials";

    private final static String SECTION_1 = "Labeling";
    private final static String SECTION_1_QUESTION_1 = "EUP Stamped Master Label (including EUP shipment summary) placed in all containers of viable EUP material.";
    private final static String SECTION_1_QUESTION_2 = "Net Contents entered into the EUP shipment summary label as appropriate per event.";
    private final static String SECTION_1_QUESTION_3 = "Outermost layer of containment is labeled with the appropriate EPA EUP number(s) and address.";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_2);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_3);

        return questionsMap;
    }
}
