package com.monsanto.tps.shipping.business.compliance;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.dao.RegulatedMovementDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Set;

@Service
public class RegulatedMovementBusinessImpl implements RegulatedMovementBusiness {
    @Autowired
    private RegulatedMovementDao regulatedMovementDao;

    @Autowired
    @Qualifier("regulatedCassetteMovementUpdater")
    private RegulatedMovementUpdater cassetteMovementUpdater;

    @Autowired
    @Qualifier("regulatedScannedContainerMovementUpdater")
    private RegulatedMovementUpdater scannedContainerMovementUpdater;

    public static final Set<AgencyEnum> AGENCIES_WITH_PERMITS = Sets.newHashSet(AgencyEnum.EPA, AgencyEnum.USDA);

    @Trace
    @Override
    public void assignPermitsToRegulatedMovements(Event event) {
        if (event == null || CollectionUtils.isEmpty(event.getRegulatedMovementIds())) {
            return;
        }

        Collection<RegulatedInventoryMovementEntity> regulatedMovements = regulatedMovementDao.load(event.getRegulatedMovementIds());
        for (final AgencyEnum agencyEnum : event.getRegulatingAgencies()) {
            if (!agencyRequiresPermit(agencyEnum)) {
                continue;
            }

            Collection<RegulatedInventoryMovementEntity> agencyRegulatedMovements = getRegulatedMovementsForAgency(regulatedMovements, agencyEnum);
            if (CollectionUtils.isEmpty(agencyRegulatedMovements)) {
                throw new ShippingWebException("No existing regulated movements found for " + event + " and " + agencyEnum);
            }

            Permit permit = event.getSelectedPermit(agencyEnum);
            if (permit == null) {
                throw new ShippingWebException("Selected permit is required for " + event + " and " + agencyEnum + " but was not found.");
            }

            for (RegulatedInventoryMovementEntity agencyRegulatedMovement : agencyRegulatedMovements) {
                agencyRegulatedMovement.setMonsantoId(permit.getMonsantoId());
                agencyRegulatedMovement.setAgencyRequestLocationId(permit.getAgencyRequestLocationId());
                agencyRegulatedMovement.setEventString(permit.getEvent());

                regulatedMovementDao.save(agencyRegulatedMovement);
            }
        }
    }

    @Trace
    @Override
    public void deleteMovementsByContent(ScannedContainerEntity contentContainerEntity) {
        regulatedMovementDao.deleteRegulatedMovementsForContent(contentContainerEntity);
    }

    @Trace
    @Override
    public void deleteMovementsByPackingList(ShipmentPackingListEntity packingList) {
        regulatedMovementDao.deleteRegulatedMovementsForPackingList(packingList);
    }

    @Trace
    @Override
    public Collection<RegulatedInventoryMovementEntity> findByIds(Collection<Long> regulatedMovementIds) {
        return regulatedMovementDao.load(regulatedMovementIds);
    }

    @Trace
    @Override
    public Collection<RegulatedInventoryMovementEntity> findByAgencyFromIds(Collection<Long> regulatedMovementIds, AgencyEntity agency) {
        return regulatedMovementDao.find(agency.getAgencyId(), regulatedMovementIds);
    }

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<RegulatedInventoryMovementEntity> createRegulatedMovements(ShipmentPackingListEntity shipmentPackingList, AgencyEntity agencyEntity, Collection<ContentEntity> contentEntities, Event event) {
        if (agencyEntity != null && agencyRequiresPermit(agencyEntity.getEnumValue())) {
            RegulatedMovementUpdater regulatedMovementUpdater = getImplementation(shipmentPackingList.getShipmentType());

            return regulatedMovementUpdater.createRegulatedMovements(shipmentPackingList, contentEntities, agencyEntity, event);
        }

        return null;
    }

    private boolean agencyRequiresPermit(AgencyEnum agencyEnum) {
        return AGENCIES_WITH_PERMITS.contains(agencyEnum);
    }

    private Collection<RegulatedInventoryMovementEntity> getRegulatedMovementsForAgency(Collection<RegulatedInventoryMovementEntity> regulatedMovements, final AgencyEnum agencyEnum) {
        return Collections2.filter(regulatedMovements, new Predicate<RegulatedInventoryMovementEntity>() {
            @Override
            public boolean apply(RegulatedInventoryMovementEntity regulatedMovement) {
                return regulatedMovement.getAgency().getEnumValue() == agencyEnum;
            }
        });
    }

    private RegulatedMovementUpdater getImplementation(ShipmentTypeEntity shipmentType) {
        if (ShipmentTypeEnum.PLANTED_PLOT_INV.equals(shipmentType.getShipmentTypeEnum())) {
            return scannedContainerMovementUpdater;
        }
        switch (shipmentType.getContentType()) {
            case CASSETTE:
                return cassetteMovementUpdater;
            case INVENTORY:
            case PLOT:
            case WHOLE_PLANTS:
            case HD_TRAY:
                return scannedContainerMovementUpdater;
        }

        throw new IllegalArgumentException("Cannot update regulated movements for shipment type [ " + shipmentType.getDescription() + "]");
    }
}
