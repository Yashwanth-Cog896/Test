package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.SortedSet;

@Service
public class InventoryMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        decimalFormat.setRoundingMode(RoundingMode.UP);

        addSelectedPermitsToTable(permitsTable, events, false, font);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            String eventString = getEventString(contentContainerEntity.getContent());

            appendCellToTable(contentContainerEntity.getScanOrder(), contentsTable, font);
            appendCellToTable(contentContainerEntity.getContent().getBarcode(), contentsTable, font);
            appendCellToTable(eventString, contentsTable, font);

            Double weight = contentContainerEntity.getWeight();
            appendCellToTable(weight != null ? decimalFormat.format(weight) : "", contentsTable, font);

            UnitOfMeasureEntity uomEntity = contentContainerEntity.getWeightUOM();
            appendCellToTable(uomEntity != null ? uomEntity.getUomRefId() : "", contentsTable, font);

            Integer quantity = contentContainerEntity.getQuantity();
            appendCellToTable(quantity != null ? quantity.toString() : "", contentsTable, font);

            appendCellToTable(contentContainerEntity.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Item BID", "Event", "Weight", "UOM", "Count", "Box Barcode", "Received"},
                new float[]{15, 55, 65, 15, 10, 15, 25, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[]{120, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.INVENTORY;
    }
}
