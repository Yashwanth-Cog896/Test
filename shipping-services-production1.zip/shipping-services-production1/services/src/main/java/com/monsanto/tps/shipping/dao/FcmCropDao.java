package com.monsanto.tps.shipping.dao;

/**
 * User: pgadi
 */
public interface FcmCropDao {

    Long getMidasCropId(Long cropId);
}
