package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.converter.PackingListContainerConversion;
import com.monsanto.tps.shipping.converter.PackingListContentConverter;
import com.monsanto.tps.shipping.dao.ScannedContainerDao;
import com.monsanto.tps.shipping.dao.RepDao;
import com.monsanto.tps.shipping.dao.StorageContainerDao;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.RepEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.service.model.RepContent;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.service.validation.PackingListContentValidator;
import com.monsanto.tps.shipping.util.ContentErrorMessages;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.cxf.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkArgument;

@Service
public class RepBusinessImpl implements RepBusiness {
    public static final String BOX = "Box";

    @Autowired
    private RepDao repDao;
    @Autowired
    private StorageContainerDao storageContainerDao;
    @Autowired
    private PackingListContentValidator packingListContentValidator;
    @Autowired
    private PackingListContentConverter packingListContentConverter;
    @Autowired
    private PackingListContainerConversion containerConversion;
    @Autowired
    private PlotComparator plotComparator;
    @Autowired
    private ScannedContainerDao scannedContainerDao;
    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;


    @Override
    @Trace
    public RepContent getRepContent(String barcode, Long cropId, Long shipToProgramId,
                                    ShipmentTypeEntity shipmentType) {
        checkArgument(!StringUtils.isEmpty(barcode), "Rep/Plot barcode cannot be null");
        checkArgument(shipmentType != null, "Shipment type cannot be null for barcode validation");
        validateShipmentType(shipmentType);

        RepEntity rep = getRep(barcode);
        if (rep == null) {
            throw new ShippingWebException(ContentErrorMessages.INVALID_BARCODE);
        }
        if (cropId != null) {
            packingListContentValidator.validateCropsMatch(rep.getGrowerProgram().getCrop().getCropId(), cropId);
        }
        return getRepContent(shipToProgramId, shipmentType, rep);
    }

    @Override
    @Trace
    public List<RepContent> save(ShipmentPackingListEntity packingList, String order, List<RepContent> repContents) {
        validateShipmentType(packingList.getShipmentType());
        int scanOrder = repDao.getNextScanOrderForRep(packingList.getShipmentPackingListId());
        for (RepContent repContent : repContents) {
            RepEntity rep = repDao.findById(repContent.getRepId());
            List<PlotEntity> plots = plotComparator.sort(rep.getPlots(), order);
            StorageContainerEntity storageContainer = storageContainerDao.getById(repContent.getStorageContainerId());
            List<ScannedContainerEntity> plotContainers = Lists.newArrayList();
            scanOrder = addContentsToContainer(plots, scanOrder, storageContainer, plotContainers, packingList);
            repContent.setPackingListContents(packingListContentConverter.createPackingListContents(plotContainers, storageContainer, packingList.getShipmentType()));
        }
        return repContents;
    }

    private void validateShipmentType(ShipmentTypeEntity shipmentTypeEntity) {
        ShipmentTypeEnum shipmentType = shipmentTypeEntity.getShipmentTypeEnum();
        if (!(ContentType.PLOT.equals(shipmentType.getContentType()) || ShipmentTypeEnum.PLANTED_PLOT_INV.equals(shipmentType))) {
            throw new ShippingWebException("Invalid content type: " + shipmentTypeEntity.getDescription());
        }
    }

    @Override
    @Trace
    public List<RepContent> save(ShipmentPackingListEntity packingList, Integer plotsPerBox, Boolean continueLastBox,
                                 String order, List<RepContent> repContents) {
        List<StorageContainerEntity> boxes = getExistingBoxesForPackingList(packingList);

        if (repContents.isEmpty()) {
            return repContents;
        }

        boolean createNewBoxes = ((boxes.isEmpty()) || (boxes.size() > 1) ||
            (boxes.size() == 1 && !boxes.get(0).getContainers().isEmpty()));
        StorageContainerEntity storageContainer = null;

        if (!boxes.isEmpty() && Boolean.TRUE.equals(continueLastBox)) {
            storageContainer = boxes.get(boxes.size() - 1);
        } else if (createNewBoxes) {
            ShipmentContainerEntity shipmentContainer = createShipmentContainer(packingList);
            repContents.get(0).addContainer(containerConversion.toDto().apply(shipmentContainer));
            storageContainer = shipmentContainer.getStorageContainer();
        } else {
            storageContainer = boxes.get(0);
        }
        int plotsInBox = storageContainer.getContainers().size();
        int scanOrder = repDao.getNextScanOrderForRep(packingList.getShipmentPackingListId());
        for (RepContent repContent : repContents) {
            RepEntity rep = repDao.findById(repContent.getRepId());
            List<PlotEntity> plots = plotComparator.sort(rep.getPlots(), order);
            repContent.setPackingListContents(new ArrayList<PackingListContent>());
            for (int beginIndex = 0; beginIndex < plots.size(); ) {
                if (plotsInBox >= plotsPerBox) {
                    plotsInBox = 0;
                    ShipmentContainerEntity shipmentContainer = createShipmentContainer(packingList);
                    storageContainer = shipmentContainer.getStorageContainer();
                    repContent.addContainer(containerConversion.toDto().apply(shipmentContainer));
                }
                int endIndex = ((beginIndex + (plotsPerBox - plotsInBox)) > plots.size()) ? plots.size() :
                    beginIndex + (plotsPerBox - plotsInBox);
                List<ScannedContainerEntity> plotContainers = Lists.newArrayList();
                scanOrder = addContentsToContainer(plots.subList(beginIndex, endIndex), scanOrder, storageContainer, plotContainers, packingList);
                repContent.getPackingListContents().addAll(
                        packingListContentConverter.createPackingListContents(plotContainers, storageContainer, packingList.getShipmentType()));
                plotsInBox += endIndex - beginIndex;

                beginIndex = endIndex;
            }
        }
        return repContents;
    }

    private List<StorageContainerEntity> getExistingBoxesForPackingList(ShipmentPackingListEntity packingList) {
        List<StorageContainerEntity> boxes = new ArrayList<StorageContainerEntity>();
        for (ShipmentContainerEntity shipmentContainer : packingList.getShipmentContainers()) {
            StorageContainerEntity storageContainer = shipmentContainer.getStorageContainer();
            if (storageContainer != null && storageContainer.getStorageContainerType().getName().equals("Box")) {
                boxes.add(storageContainer);
            }
        }
        return boxes;
    }


    private ShipmentContainerEntity createShipmentContainer(ShipmentPackingListEntity packingList) {
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.createShipmentContainer(packingList.getShipmentPackingListId());
        shipmentContainerEntity.getStorageContainer().setContainers(new ArrayList<ScannedContainerEntity>());
        packingList.getShipmentContainers().add(shipmentContainerEntity);
        return shipmentContainerEntity;
    }

    private int addContentsToContainer(List<PlotEntity> plots, int scanOrder,
                                       StorageContainerEntity storageContainerEntity,
                                       List<ScannedContainerEntity> plotContainers,
                                       ShipmentPackingListEntity packingList) {

        for (PlotEntity plot : plots) {
            ScannedContainerEntity<PlotEntity> contentContainer = getNewScannedContainer(packingList.getShipmentType());

            contentContainer.setContent(plot);
            contentContainer.setScanOrder(scanOrder++);
            packingListContentValidator.validateCountryOfOrigin(plot, storageContainerEntity.getBarcode(), packingList);
            contentContainer.setStorageContainer(storageContainerEntity);
            scannedContainerDao.save(contentContainer);
            plotContainers.add(contentContainer);
        }
        storageContainerEntity.getContainers().addAll(plotContainers);

        return scanOrder;
    }

    private RepEntity getRep(String barcode) {
        if (barcode.startsWith("P")) {
            return repDao.findByPlotBarcode(barcode);
        } else {
            return repDao.findByBarcode(barcode);
        }
    }

    private RepContent getRepContent(Long shipToProgramId, ShipmentTypeEntity shipmentType, RepEntity rep) {
        RepContent repContent = new RepContent();

        if (shipToProgramId != null) {
            repContent.setIsShipToMisMatch(
                packingListContentValidator.validateShipToMisMatchForRep(shipToProgramId, shipmentType, rep));
        }

        repContent.setRepId(rep.getRepId());
        repContent.setBarcode(rep.getBarcode());
        repContent.setRepNumber(rep.getRepNumber());
        repContent.setSet(rep.getTestSet().getTestSetName());
        repContent.setTrackId(rep.getField() == null ? "" : rep.getField().getFieldName());
        repContent.setNumberOfPlots((long) rep.getPlots().size());
        if (!rep.getPlots().isEmpty()) {
            PlotEntity plot = rep.getPlots().iterator().next();
            CropEntity crop = plot.getGeneticMaterial().getGermplasm().getCrop();
            repContent.setCropId(crop.getCropId());
            repContent.setCrop(crop.getName());
        }
        return repContent;
    }

    private ScannedContainerEntity getNewScannedContainer(ShipmentTypeEntity shipmentTypeEntity) {
        if (shipmentTypeEntity.getShipmentTypeEnum().isUsingDerivedContentType()) {
            return ScannedContainerEntity.newScannedContentContainer(ContentType.PLOT);
        } else {
            return ScannedContainerEntity.newScannedContentContainer(shipmentTypeEntity.getContentType());
        }
    }
}
