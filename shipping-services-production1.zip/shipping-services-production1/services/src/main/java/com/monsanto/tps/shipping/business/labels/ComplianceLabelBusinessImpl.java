package com.monsanto.tps.shipping.business.labels;

import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.util.RegulatedStatusText;
import com.monsanto.tps.shipping.util.RegulatoryMessageHelper;
import com.monsanto.tps.shipping.util.TextUtils;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Component
public class ComplianceLabelBusinessImpl implements ComplianceLabelBusiness {
    public static final Function<Permit, String> AGENCY_NUMBER_FUNCTION = new Function<Permit, String>() {
        @Override
        public String apply(Permit input) {
            return input.getApprovalNumber();
        }
    };
    private static final Function<ExternalPermitEntity, Permit> EXTERNAL_PERMIT_FUNCTION = new Function<ExternalPermitEntity, Permit>() {
        @Override
        public Permit apply(ExternalPermitEntity input) {
            return new Permit(input.getPermitNumber());
        }
    };

    private static final Function<ExternalPermitEntity, String> EXTERNAL_AGENCY_FUNCTION = new Function<ExternalPermitEntity, String>() {
        @Override
        public String apply(ExternalPermitEntity input) {
            return input.getAgency() != null ? input.getAgency().getAbbr() : input.getOtherAgencyName();
        }
    };

    @Autowired
    private RegulatoryMessageHelper regulatoryMessageHelper;

    @Override
    public ContainerAgencyPermits getExternalPermitsByPackingList(ShipmentPackingListEntity shipmentPackingListEntity) {
        Set<Permit> permits = Sets.newHashSet();
        for (ShipmentContainerEntity shipmentContainerEntity : shipmentPackingListEntity.getShipmentContainers()) {
            ContainerAgencyPermits containerAgencyPermits = getExternalPermitsByContainer(shipmentContainerEntity);
            permits.addAll(containerAgencyPermits.getPermits());
        }
        return new ContainerAgencyPermits(permits, false, false);
    }

    @Override
    public ContainerAgencyPermits getExternalPermitsByContainer(ShipmentContainerEntity shipmentContainerEntity) {
        ContainerAgencyPermits containerAgencyPermits;
        if (CollectionUtils.isNotEmpty(shipmentContainerEntity.getExternalPermits())) {
            Collection<Permit> externalPermits = Collections2.transform(shipmentContainerEntity.getExternalPermits(), EXTERNAL_PERMIT_FUNCTION);
            containerAgencyPermits = new ContainerAgencyPermits(externalPermits, false, false);
        } else {
            containerAgencyPermits = new ContainerAgencyPermits(Lists.<Permit>newArrayList(), false, false);
        }
        return containerAgencyPermits;
    }

    @Override
    public void addExternalAgencyMessage(ShipmentPackingListEntity shipmentPackingListEntity, ContainerLabelDataSet labelDataSet) {
        Set<String> externalAgencies = Sets.newHashSet();
        for (ShipmentContainerEntity shipmentContainerEntity : shipmentPackingListEntity.getShipmentContainers()) {
            externalAgencies.addAll(getAgencies(shipmentContainerEntity.getExternalPermits()));
        }
        addAgenciesToLabelDataSet(labelDataSet, externalAgencies);
    }

    @Override
    public void addExternalAgencyMessage(ShipmentContainerEntity shipmentContainerEntity, ContainerLabelDataSet labelDataSet) {
        Collection<String> externalAgencies = getAgencies(shipmentContainerEntity.getExternalPermits());
        addAgenciesToLabelDataSet(labelDataSet, externalAgencies);
    }

    private Collection<String> getAgencies(Collection<ExternalPermitEntity> externalPermits) {
        return CollectionUtils.isEmpty(externalPermits) ? Lists.<String>newArrayList() : Sets.newTreeSet(Collections2.transform(externalPermits, EXTERNAL_AGENCY_FUNCTION));
    }

    private void addAgenciesToLabelDataSet(ContainerLabelDataSet labelDataSet, Collection<String> externalAgencies) {
        if (!CollectionUtils.isEmpty(externalAgencies)) {
            labelDataSet.put(ContainerLabelConstants.REGULATED_SUMMARY_LINE, String.format(ContainerLabelConstants.EXTERNAL_AGENCY_MESSAGE, TextUtils.getDelimitedStringWithComma(externalAgencies)));
        }
    }

    @Override
    public void addIntegratedAgencyMessage(ShipmentTypeEntity shipmentTypeEntity, ContainerAgencyPermits containerAgencyPermits, ContainerLabelDataSet data) {
        Collection<Permit> permits = containerAgencyPermits.getPermits();

        if (containerAgencyPermits.isPreEup()) {
            data.put(ContainerLabelConstants.PRE_EUP_SUMMARY_LINE, ContainerLabelConstants.PRE_EUP_MESSAGE);
        }

        if (!CollectionUtils.isEmpty(permits)) {
            String regulatoryMessage = regulatoryMessageHelper.getRegulatoryMessage(shipmentTypeEntity.getShipmentTypeEnum(), permits);
            data.put(ContainerLabelConstants.REGULATED_SUMMARY_LINE, regulatoryMessage);
        } else if (containerAgencyPermits.isStewarded()) {
            data.put(ContainerLabelConstants.REGULATED_SUMMARY_LINE, ContainerLabelConstants.getRegMessage(RegulatedStatusText.STWRDSH.getRegulatedStatusText() + "_REGULATORY_MSG"));
        }
    }

    @Override
    public void addPermitDetailsToLabelDataSet(ContainerAgencyPermits containerAgencyPermits, ContainerLabelDataSet data, int agencyNumberLimit) {
        Collection<Permit> permits = containerAgencyPermits.getPermits();

        if (!CollectionUtils.isEmpty(permits)) {
            SortedSet<String> agencyNumbers = new TreeSet<String>(Collections2.filter(Collections2.transform(permits, AGENCY_NUMBER_FUNCTION), Predicates.notNull()));
            int i = 1;
            Iterable<List<String>> partitionedAgencyNumbers = Iterables.partition(agencyNumbers, 4);
            data.put(ContainerLabelConstants.AGENCY_APPROVAL_NUMBERS, ContainerLabelConstants.AGENCY_APPROVAL_NUMBERS_LABEL);
            for (List<String> agencyNumber : partitionedAgencyNumbers) {
                if (i <= agencyNumberLimit) {
                    data.put(ContainerLabelConstants.AGENCY_NUM + i,
                            TextUtils.getDelimitedStringWithComma(agencyNumber));
                    i++;
                }
            }
        }
    }
}
