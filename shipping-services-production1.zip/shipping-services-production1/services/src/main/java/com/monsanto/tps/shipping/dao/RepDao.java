package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.RepEntity;

import java.util.List;


public interface RepDao {
    RepEntity findById(long id);

    RepEntity findByBarcode(String barcode);

    RepEntity findByPlotBarcode(String barcode);

    List<RepEntity> findRepsByShipmentPackingListId(Long shipmentPackingListId);

    int getNextScanOrderForRep(long packingListId);
}
