package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.dao.AppParameterDao;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * User: pgadi
 */
@Service
public class RegulatedCountryBusinessImpl implements RegulatedCountryBusiness {

    public static final String USDA_COUNTRY_ABBR = "usda_country_abbrs";
    public static final String STEWARDSHIP_COUNTRY_ABBR = "stewardship_country_abbrs";
    public static final String APP_NAME = "FCE";
    private static final Function<String, String> COUNTRY_FUNCTION = new Function<String, String>() {

        @Override
        public String apply(@Nullable String input) {
            return input.trim();
        }
    };

    @Autowired
    private AppParameterDao appParameterDao;

    @Override
    @Trace
    public boolean isCountryRegulatedByUsdaEpa(String country) {
        String unitedStatesCountriesList = getCountryList(USDA_COUNTRY_ABBR);

        Set<String> unitedStatesCountries = getCountries(unitedStatesCountriesList);
        String countryAbbr = lookUpCountryAbbr(country);

        return unitedStatesCountries.contains(countryAbbr);
    }

    @Override
    @Trace
    public boolean isCountryAbbrRegulatedByUsdaEpa(String countryAbbr) {
        String unitedStatesCountriesList = getCountryList(USDA_COUNTRY_ABBR);

        Set<String> unitedStatesCountries = getCountries(unitedStatesCountriesList);

        return unitedStatesCountries.contains(countryAbbr);
    }


    @Override
    @Trace
    public boolean isCountryRegulatedByStewardship(String country) {
        String stewardedCountries = getCountryList(STEWARDSHIP_COUNTRY_ABBR);

        Set<String> stewCountries = getCountries(stewardedCountries);
        String countryAbbr = lookUpCountryAbbr(country);

        return stewCountries.contains(countryAbbr);
    }

    @Override
    @Trace
    public boolean isCountryAbbrRegulatedByStewardship(String countryAbbr) {
        String stewardedCountries = getCountryList(STEWARDSHIP_COUNTRY_ABBR);

        Set<String> stewCountries = getCountries(stewardedCountries);

        return stewCountries.contains(countryAbbr);
    }


    //TODO add method cache here
    @Override
    @Trace
    public String lookUpCountryAbbr(String country) {
        return appParameterDao.getParameterValueByNameAndApplication("CNTRY_LKUP_" + country.trim().toUpperCase().replace(' ', '_'), APP_NAME);
    }

    private Set<String> getCountries(String usCountries) {
        return Sets.newHashSet(Iterables.transform(Lists.newArrayList(usCountries.split(",")), COUNTRY_FUNCTION));
    }

    private String getCountryList(String countryAbbr) {
        return appParameterDao.getParameterValueByNameAndApplication(countryAbbr, APP_NAME);
    }
}
