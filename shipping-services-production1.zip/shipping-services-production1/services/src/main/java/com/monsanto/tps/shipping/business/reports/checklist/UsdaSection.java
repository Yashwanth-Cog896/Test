package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by DCENGL
 */
@Service
public class UsdaSection extends AbstractChecklistSection {

    private static final String HEADER = "Additional requirements for movement of USDA regulated materials";

    private final static String SECTION_1 = "Documentation";
    private final static String SECTION_1_QUESTION_1 = "Movement made under a valid permit or notification number.";
    private final static String SECTION_1_QUESTION_2 = "Events/constructs moved are listed on the permit or notification.";
    private final static String SECTION_1_QUESTION_3 = "Ship from and ship to addresses are listed on the permit or notification.";
    private final static String SECTION_1_QUESTION_4 = "The permit or notification was checked for additional shipping requirements.";

    private final static String SECTION_2 = "Labeling";
    private final static String SECTION_2_QUESTION_1 = "Outermost layer of containment is labeled with the appropriate USDA notification or permit number(s).";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_2);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_3);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_4);

        questionsMap.put(SECTION_2, SECTION_2_QUESTION_1);

        return questionsMap;
    }


}
