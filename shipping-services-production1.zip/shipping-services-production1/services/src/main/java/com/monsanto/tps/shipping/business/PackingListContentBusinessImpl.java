package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.business.compliance.RegulatedMovementBusiness;
import com.monsanto.tps.shipping.dao.CassetteDao;
import com.monsanto.tps.shipping.dao.CropStandardShipInfoDao;
import com.monsanto.tps.shipping.dao.EventConstructDao;
import com.monsanto.tps.shipping.dao.HDTrayDao;
import com.monsanto.tps.shipping.dao.InventoryDao;
import com.monsanto.tps.shipping.dao.PlotDao;
import com.monsanto.tps.shipping.dao.ScannedContainerDao;
import com.monsanto.tps.shipping.dao.TissuePlateDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureConversionDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureGroupDao;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.CropStandardShipInfoEntity;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.OtherContentEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.service.validation.PackingListContentValidator;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * User: DCENGL
 */
@Service
public class PackingListContentBusinessImpl implements PackingListContentBusiness {

    public static final String UNIT_OF_MEASURE_NOT_FOUND = "Unit of measure not found with id of [%s]";
    public static final String CONTENT_NOT_FOUND = "Content not found with barcode [%s]";
    public static final String PERMIT_UNITS_UOM = "Pounds";
    public static final double CONVERSION_FACTOR_IF_UOMS_MATCH = 1.0;

    @Autowired
    private InventoryDao inventoryDao;
    @Autowired
    private PlotDao plotDao;
    @Autowired
    private TissuePlateDao tissuePlateDao;
    @Autowired
    private CassetteDao cassetteDao;
    @Autowired
    private ScannedContainerDao scannedContainerDao;
    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;
    @Autowired
    private UnitOfMeasureGroupDao unitOfMeasureGroupDao;
    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;
    @Autowired
    private ShipmentBusiness shipmentBusiness;
    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;
    @Autowired
    private RegulatedMovementBusiness regulatedMovementBusiness;
    @Autowired
    private UnitOfMeasureConversionDao unitOfMeasureConversionDao;
    @Autowired
    private CropStandardShipInfoDao cropStandardShipInfoDao;
    @Autowired
    private PackingListContentValidator packingListContentValidator;
    @Autowired
    private EventConstructDao eventConstructDao;
    @Autowired
    private HDTrayDao hdTrayDao;
    @Autowired
    private EpcBusiness epcBusiness;

    public ScannedContainerEntity getContentContainer(Long id, ContentType contentType) {
        return scannedContainerDao.load(id, contentType);
    }

    @Override
    @Trace
    public ContentEntity getContents(String barcode, ContentType contentType) {
        List<? extends ContentEntity> contentEntities = Lists.newArrayList();

        switch (contentType) {
            case INVENTORY:
                contentEntities = inventoryDao.findByBarcode(barcode);
                break;
            case PLOT:
                contentEntities = plotDao.findByBarcode(barcode);
                break;
            case TISSUE_PLATE:
                contentEntities = tissuePlateDao.findByBarcode(barcode);
                break;
            case CASSETTE:
                contentEntities = cassetteDao.findByBarcode(barcode);
                break;
            case MIXED_INV_PLOT:
                if (barcode.startsWith("I")) {
                    contentEntities = inventoryDao.findByBarcode(barcode);
                } else {
                    contentEntities = plotDao.findByBarcode(barcode);
                }
                break;
            case OTHER:
                contentEntities = createOtherContentEntities(Lists.newArrayList(barcode));
                break;
            case WHOLE_PLANTS:
                if (barcode.startsWith("E")) {
                    contentEntities = eventConstructDao.findByBarcode(barcode);
                } else if (barcode.startsWith("P")) {
                    contentEntities = plotDao.findByBarcode(barcode);
                }
                break;
            case HD_TRAY:
                contentEntities = hdTrayDao.findByTrayId(barcode);
                break;
        }

        return (contentEntities.isEmpty() ? null : contentEntities.get(0));
    }

    @Override
    @Trace
    public List<? extends ContentEntity> getContents(Set<String> barcodes, ContentType contentType) {
        List<? extends ContentEntity> contentEntities = Lists.newArrayList();

        switch (contentType) {
            case INVENTORY:
                contentEntities = inventoryDao.findByBarcode(barcodes);
                break;
            case PLOT:
                contentEntities = plotDao.findByBarcode(barcodes);
                break;
            case TISSUE_PLATE:
                contentEntities = getTissueContentsByBarcodes(barcodes);
                break;
            case CASSETTE:
                contentEntities = cassetteDao.findByBarcode(barcodes);
                break;
            case OTHER:
                contentEntities = createOtherContentEntities(barcodes);
                break;
            case MIXED_INV_PLOT:
                contentEntities = getContentsByBarcodes(barcodes);
                break;
            case WHOLE_PLANTS:
                contentEntities = getWholePlantsContentsByBarcodes(barcodes);
                break;
            case HD_TRAY:
                contentEntities = hdTrayDao.findByTrayIds(barcodes);
                break;
        }
        return contentEntities;
    }

    private List<ContentEntity> getTissueContentsByBarcodes(Set<String> barcodes) {
        List<ContentEntity> contents = new ArrayList<ContentEntity>();
        List<TissuePlateEntity> tissuePlateEntities = tissuePlateDao.findByBarcode(barcodes);
        contents.addAll(tissuePlateEntities);
        List<String> validBarcodes = Lists.transform(tissuePlateEntities, new Function<TissuePlateEntity, String>() {

            @Override
            public String apply(TissuePlateEntity input) {
                return input.getBarcode();
            }
        });
        List<String> otherBarcodes = Lists.newArrayList(barcodes);
        otherBarcodes.removeAll(validBarcodes);
        contents.addAll(createOtherContentEntities(otherBarcodes));
        return contents;
    }

    private List<OtherContentEntity> createOtherContentEntities(Collection<String> otherBarcode) {
        List<OtherContentEntity> otherContentEntities = Lists.newArrayList();
        for (String barcode : otherBarcode) {
            otherContentEntities.add(new OtherContentEntity(null, barcode));
        }

        return otherContentEntities;
    }

    private List<? extends ContentEntity> getWholePlantsContentsByBarcodes(Set<String> barcodes) {
        Set<String> eventConstructBarcodes = Sets.filter(barcodes, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return input.startsWith("E");
            }
        });
        List<ContentEntity> contents = (List<ContentEntity>) eventConstructDao.findByBarcodes(eventConstructBarcodes);

        Set<String> plots = Sets.filter(barcodes, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return input.startsWith("P");
            }
        });
        contents.addAll(plotDao.findByBarcode(plots));
        return contents;
    }

    private List<? extends ContentEntity> getContentsByBarcodes(Set<String> barcodes) {
        Set<String> inventories = Sets.filter(barcodes, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return input.startsWith("I");
            }
        });
        List<ContentEntity> contents = (List<ContentEntity>) inventoryDao.findByBarcode(inventories);
        Set<String> plots = Sets.filter(barcodes, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return input.startsWith("P");
            }
        });
        contents.addAll(plotDao.findByBarcode(plots));
        return contents;
    }

    @Trace
    @Override
    public void updatePackingListContents(StorageContainerEntity storageContainerEntity,
                                          List<PackingListContent> packingListContents,
                                          ShipmentTypeEntity shipmentTypeEntity, Long uomId,
                                          Double permitUnitsUomConversionFactor) {
        Set<String> barcodes = Sets.newHashSet(getBarcodes(packingListContents));

        List<ScannedContainerEntity> containers = Lists.newArrayListWithExpectedSize(packingListContents.size());
        Map<String, ? extends ContentEntity> barcodeContentMap = getBarcodeToContentMap(shipmentTypeEntity, barcodes);

        CropStandardShipInfoEntity cropStandardShipInfoEntity = getCropStandardShipInfo(barcodeContentMap.values());
        for (PackingListContent packingListContent : packingListContents) {
            ScannedContainerEntity<?> scannedContainerEntity = getContainerEntity(shipmentTypeEntity, barcodeContentMap, packingListContent);
            packingListContentValidator.validate(scannedContainerEntity.getContent(), packingListContent);
            setContainerEntity(storageContainerEntity, uomId, packingListContent, scannedContainerEntity, cropStandardShipInfoEntity);

            containers.add(scannedContainerEntity);
        }
        storageContainerEntity.setContainers(containers);
    }

    private CropStandardShipInfoEntity getCropStandardShipInfo(Collection<? extends ContentEntity> contents) {
        CropStandardShipInfoEntity cropStandardShipInfoEntity = null;
        if (!CollectionUtils.isEmpty(contents)) {
            ContentEntity contentEntity = contents.iterator().next();
            if (contentEntity != null && contentEntity.getGeneticMaterial() != null) {
                cropStandardShipInfoEntity = cropStandardShipInfoDao.getCropStandardShipInfoByCrop(contentEntity.getGeneticMaterial().getGermplasm().getCrop());
            }
        }
        return cropStandardShipInfoEntity;
    }

    private void seedCountToWeightConversion(ScannedContainerEntity scannedContainerEntity, CropStandardShipInfoEntity cropStandardShipInfoEntity) {
        if (cropStandardShipInfoEntity != null) {
            if (scannedContainerEntity.getWeightUOM().getId().equals(cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId())) {
                scannedContainerEntity.setWeight(scannedContainerEntity.getQuantity() * cropStandardShipInfoEntity.getPerSeedCountStandardWeight());
            } else {
                Long seedCountConversionId = cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId();
                Long packingListUomId = scannedContainerEntity.getWeightUOM().getId();
                Double toPackingListUomConversionFactor = unitOfMeasureConversionDao.getUomConversion(seedCountConversionId, packingListUomId).getConversionFactor();
                scannedContainerEntity.setWeight(scannedContainerEntity.getQuantity() * cropStandardShipInfoEntity.getPerSeedCountStandardWeight() * toPackingListUomConversionFactor);
            }
        }
    }

    private void setContainerEntity(StorageContainerEntity storageContainerEntity, Long uomId, PackingListContent packingListContent,
                                    ScannedContainerEntity scannedContainerEntity, CropStandardShipInfoEntity cropStandardShipInfoEntity) {
        scannedContainerEntity.setScanOrder(packingListContent.getScanOrder());
        scannedContainerEntity.setStorageContainer(storageContainerEntity);
        scannedContainerEntity.setWeight(packingListContent.getWeight());
        scannedContainerEntity.setQuantity(packingListContent.getSeedCount());
        scannedContainerEntity.setWeightUOM(unitOfMeasureDao.findByName(packingListContent.getWeightUOM()));
        scannedContainerEntity.setElectronicProductCode(packingListContent.getEpc());
        if (scannedContainerEntity.getWeight() == null && scannedContainerEntity.getQuantity() != null && scannedContainerEntity.getWeightUOM() != null) {
            seedCountToWeightConversion(scannedContainerEntity, cropStandardShipInfoEntity);
        }

        scannedContainerEntity.setSendVerificationDate(packingListContent.getSendVerificationDate());
        if (uomId != null) {
            UnitOfMeasureEntity uom = unitOfMeasureDao.load(uomId);
            if (uom == null) {
                throw new ShippingWebException(String.format(UNIT_OF_MEASURE_NOT_FOUND, uomId));
            }
            scannedContainerEntity.setWeightUOM(uom);
        }
    }

    private ScannedContainerEntity<?> getContainerEntity(ShipmentTypeEntity shipmentTypeEntity,
                                                         Map<String, ? extends ContentEntity> barcodeContentMap,
                                                         PackingListContent packingListContent) {
        ScannedContainerEntity scannedContainerEntity;
        if (packingListContent.getId() == null) {
            ContentEntity content = findContent(barcodeContentMap, packingListContent);
            scannedContainerEntity = getNewContentContainer(shipmentTypeEntity, content.getContentType(), packingListContent);
            scannedContainerEntity.setContent(content);
        } else {
            scannedContainerEntity = loadExistingContentContainer(shipmentTypeEntity, packingListContent);
        }
        return scannedContainerEntity;
    }

    private ScannedContainerEntity loadExistingContentContainer(ShipmentTypeEntity shipmentTypeEntity,
                                                                PackingListContent packingListContent) {
        return scannedContainerDao.load(packingListContent.getId(), shipmentTypeEntity.getContentType());
    }

    private ContentEntity findContent(Map<String, ? extends ContentEntity> barcodeContentMap,
                                      PackingListContent packingListContent) {
        ContentEntity content = barcodeContentMap.get(packingListContent.getBarcode());

        if (content == null) {
            throw new ShippingWebException(String.format(CONTENT_NOT_FOUND, packingListContent.getBarcode()));
        }
        return content;
    }

    private ScannedContainerEntity<?> getNewContentContainer(ShipmentTypeEntity shipmentTypeEntity, ContentType contentType, PackingListContent packingListContent) {
        if (shipmentTypeEntity.getShipmentTypeEnum().isUsingDerivedContentType()) {
            return ScannedContainerEntity.newScannedContentContainer(ContentType.parse(packingListContent.getBarcode()));
        } else {
            return ScannedContainerEntity.newScannedContentContainer(contentType);
        }
    }

    private Map<String, ? extends ContentEntity> getBarcodeToContentMap(ShipmentTypeEntity shipmentTypeEntity, Set<String> barcodes) {
        return buildBarcodeContentMap(getContents(barcodes, shipmentTypeEntity.getContentType()));
    }

    @Trace
    @Override
    public void deleteContent(Long contentId, Long shipmentTypeId) {
        ShipmentTypeEntity shipmentTypeEntity = shipmentBusiness.getShipmentType(shipmentTypeId);

        ScannedContainerEntity scannedContainerEntity = scannedContainerDao.load(contentId, shipmentTypeEntity.getContentType());
        deleteContainer(scannedContainerEntity);
    }

    @Trace
    @Override
    public ScannedContainerEntity savePackingListContent(PackingListContent packingListContent, ContentEntity contentEntity,
                                                         Long shipmentContainerId, ShipmentTypeEntity shipmentType) {
        ScannedContainerEntity scannedContainerEntity;
        if (packingListContent.getId() != null) {
            scannedContainerEntity = scannedContainerDao.load(packingListContent.getId(), shipmentType.getContentType());
        } else {
            scannedContainerEntity = getNewContentContainer(shipmentType, contentEntity.getContentType(), packingListContent);
            scannedContainerEntity.setContent(contentEntity);
        }

        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);
        scannedContainerEntity.setStorageContainer(shipmentContainerEntity.getStorageContainer());
        scannedContainerEntity.setWeight(packingListContent.getWeight());
        if (packingListContent.getWeightUOM() != null) {
            scannedContainerEntity.setWeightUOM(unitOfMeasureGroupDao.findByAbbreviation(packingListContent.getWeightUOM()));
        } else {
            scannedContainerEntity.setWeightUOM(null);
        }
        scannedContainerEntity.setQuantity(packingListContent.getSeedCount());
        scannedContainerEntity.setScanOrder(packingListContent.getScanOrder());
        scannedContainerEntity.setReceiveVerificationDate(packingListContent.getReceiveVerificationDate());
        scannedContainerEntity.setSendVerificationDate(packingListContent.getSendVerificationDate());
        if (scannedContainerEntity instanceof OtherContainerEntity) {
            ((OtherContainerEntity) scannedContainerEntity).setName(packingListContent.getName());
            ((OtherContainerEntity) scannedContainerEntity).setComments(packingListContent.getComments());
        }
        scannedContainerDao.save(scannedContainerEntity);
        return scannedContainerEntity;
    }

    @Trace
    @Override
    public ScannedContainerEntity saveNewPackingListContent(ContentEntity contentEntity,
                                                            ShipmentContainerEntity shipmentContainerEntity,
                                                            PackingListContent packingListContent,
                                                            ShipmentTypeEntity shipmentType,
                                                            UnitOfMeasureEntity unitOfMeasureEntity) {
        ScannedContainerEntity scannedContainerEntity = getNewContentContainer(shipmentType, contentEntity.getContentType(), packingListContent);
        scannedContainerEntity.setContent(contentEntity);
        scannedContainerEntity.setStorageContainer(shipmentContainerEntity.getStorageContainer());
        scannedContainerEntity.setWeight(packingListContent.getWeight());
        scannedContainerEntity.setQuantity(packingListContent.getSeedCount());
        scannedContainerEntity.setWeightUOM(unitOfMeasureEntity);
        scannedContainerEntity.setScanOrder(packingListContent.getScanOrder());

        if (shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.INVENTORY) {
            epcBusiness.createEpcForContent(scannedContainerEntity);
        }

        scannedContainerDao.save(scannedContainerEntity);
        return scannedContainerEntity;
    }

    @Trace
    @Override
    public void deleteContent(Collection<? extends ScannedContainerEntity> containers) {
        if (!CollectionUtils.isEmpty(containers)) {
            for (ScannedContainerEntity container : containers) {
                deleteContainer(container);
            }
        }
    }

    private void deleteContainer(ScannedContainerEntity scannedContainerEntity) {
        regulatedMovementBusiness.deleteMovementsByContent(scannedContainerEntity);
        scannedContainerDao.delete(scannedContainerEntity);
    }

    private List<String> getBarcodes(List<PackingListContent> packingListContentList) {
        return Lists.transform(packingListContentList, new Function<PackingListContent, String>() {
            public String apply(PackingListContent packingListContent) {
                return packingListContent.getBarcode();
            }
        });
    }

    private Map<String, ? extends ContentEntity> buildBarcodeContentMap(List<? extends ContentEntity> contentEntities) {
        return Maps.uniqueIndex(contentEntities, new Function<ContentEntity, String>() {
            public String apply(ContentEntity contentEntity) {
                return contentEntity.getBarcode();
            }
        });
    }

    @Trace
    @Override
    public void updateUom(Collection<Long> storageContainerIds, Long uomId) {
        scannedContainerDao.updateUom(storageContainerIds, uomId);
    }

    @Trace
    @Override
    public void updateWeight(Collection<Long> scannedContainerIds, Double amount, String uom) {
        Long midasUomId = unitOfMeasureBusiness.getUnitOfMeasureMidasId(uom);
        if (midasUomId == null) {
            throw new ShippingWebException("invalid uom: " + uom);
        }
        scannedContainerDao.updateWeight(scannedContainerIds, amount, midasUomId);
    }

    @Trace
    @Override
    public void updateName(Collection<Long> scannedContainerIds, String name) {
        scannedContainerDao.updateName(scannedContainerIds, name);
    }

    @Trace
    @Override
    public void updateComment(Collection<Long> scannedContainerIds, String comment) {
        scannedContainerDao.updateComment(scannedContainerIds, comment);
    }

    @Trace
    @Override
    public void updateSeedCount(Collection<Long> scannedContainerIds, Integer amount) {
        scannedContainerDao.updateSeedCount(scannedContainerIds, amount);
    }

    @Trace
    @Override
    public void updateSeedCountAndWeight(Collection<Long> scannedContainerIds, Integer amount, Double weight, UnitOfMeasureEntity uom) {
        scannedContainerDao.updateSeedCountWeightAndUOM(scannedContainerIds, amount, weight, uom.getId());
    }

    @Override
    public Double getPermitUnitsConversionFactor(UnitOfMeasureEntity unitOfMeasureEntity) {
        return getConversion(unitOfMeasureEntity.getId());
    }

    @Trace
    @Override
    public void verifyContent(Long scannedContainerId, Long storageContainerId, Boolean outGoing) {
        scannedContainerDao.updateVerifyTimeStamp(scannedContainerId, storageContainerId, outGoing);
    }

    @Trace
    @Override
    public void verifyMultipleContents(Collection<Long> scannedContainerIds, Long storageContainerId, Boolean outGoing) {
        scannedContainerDao.updateVerifyContentTimeStamp(scannedContainerIds, storageContainerId, outGoing);
    }

    @Trace
    @Override
    public void resetVerifiedContent(Long scannedContainerId, Boolean outGoing) {
        scannedContainerDao.resetVerifyTimeStamp(scannedContainerId, outGoing);
    }


    private Double getConversion(Long fromUom) {
        UnitOfMeasureEntity permitUnitsUom = unitOfMeasureDao.findByName(PERMIT_UNITS_UOM);
        UnitOfMeasureConversionEntity conversionEntity = unitOfMeasureConversionDao
                .getUomConversion(fromUom, permitUnitsUom.getId());
        if (conversionEntity == null && permitUnitsUom.getId().equals(fromUom)) {
            return CONVERSION_FACTOR_IF_UOMS_MATCH;
        }
        return conversionEntity == null ? null : conversionEntity.getConversionFactor();
    }

}

