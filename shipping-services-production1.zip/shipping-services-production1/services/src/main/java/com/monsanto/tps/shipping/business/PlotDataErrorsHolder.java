package com.monsanto.tps.shipping.business;

import com.google.common.collect.Sets;
import org.apache.commons.collections.CollectionUtils;

import java.util.Collection;

/**
 * @author tjm
 *
 */

public class PlotDataErrorsHolder {

    private static ThreadLocal<Collection<String>> errors = new ThreadLocal<Collection<String>>(){
        @Override
        protected Collection<String> initialValue()
        {
            // Use set to prevent duplicates
            return Sets.newHashSet();
        }
    };

    public static void addError(String errorText) {
        errors.get().add(errorText);
    }

    public static boolean hasErrors() {
        return !CollectionUtils.isEmpty(errors.get());
    }

    public static Collection<String> getErrors() {
        return errors.get();
    }

    /**
     * Be sure to call this when done with the collection
     */
    public static void clear() {
        errors.remove();
    }
}
