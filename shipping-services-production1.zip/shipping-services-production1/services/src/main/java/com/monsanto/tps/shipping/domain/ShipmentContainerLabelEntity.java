package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * User: SDCHIL
 */
@Entity
@Table(name = "SHIPMENT_CONTAINER_LABEL", schema = "INVENTORY_MGT")
public class ShipmentContainerLabelEntity {
    @Id
    @Column(name = "SHIPMENT_CONTAINER_LABEL_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    private Long shipmentContainerLabelId;
    @Column(name = "SHIPMENT_CONTAINER_ID")
    private Long shipmentContainerId;
    @Column(name = "LABEL_DATA", nullable = true)
    @Lob
    private byte[] labelData;
    @Column(name = "SHPMT_LBL_TYP_ID", nullable = false)
    private Long shipmentLabelTypeId;


    public Long getShipmentContainerLabelId() {
        return shipmentContainerLabelId;
    }

    public void setShipmentContainerLabelId(Long shipmentContainerLabelId) {
        this.shipmentContainerLabelId = shipmentContainerLabelId;
    }

    public Long getShipmentContainerId() {
        return shipmentContainerId;
    }

    public void setShipmentContainerId(Long shipmentContainerId) {
        this.shipmentContainerId = shipmentContainerId;
    }

    public byte[] getLabelData() {
        return labelData;
    }

    public void setLabelData(byte[] labelData) {
        this.labelData = labelData;
    }

    public Long getShipmentLabelTypeId() {
        return shipmentLabelTypeId;
    }

    public void setShipmentLabelTypeId(Long shipmentLabelTypeId) {
        this.shipmentLabelTypeId = shipmentLabelTypeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true;}
        if (o == null || getClass() != o.getClass()) {return false;}

        ShipmentContainerLabelEntity that = (ShipmentContainerLabelEntity) o;

        if (shipmentContainerLabelId != null ? !shipmentContainerLabelId.equals(that.shipmentContainerLabelId) : that.shipmentContainerLabelId != null){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return shipmentContainerLabelId != null ? shipmentContainerLabelId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ShipmentContainerEntity{" +
                "shipmentContainerId=" + shipmentContainerLabelId +
                '}';
    }
}