package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

/**
 * Created by DCENGL
 */
public interface PackingListItemsSheetBuilderFactory {

    PackingListItemsSheetBuilder getSheetBuilder(ShipmentPackingListEntity shipmentPackingListEntity);

}
