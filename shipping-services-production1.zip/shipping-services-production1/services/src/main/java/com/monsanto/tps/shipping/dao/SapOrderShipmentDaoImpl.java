package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SapOrderShipmentDaoImpl implements SapOrderShipmentDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public void saveSapOrderShipment(SapOrderShipmentEntity sapOrderShipmentEntity) {
        sessionFactory.getCurrentSession().save(sapOrderShipmentEntity);
    }

    @Trace
    @Override
    public List<SapOrderShipmentEntity> getAllSapOrderShipments() {
        return sessionFactory.getCurrentSession().createQuery("from SapOrderShipmentEntity").list();
    }

    @Trace
    @Override
    public SapOrderShipmentEntity findBySapOrderNumber(String orderNumber) {
        return (SapOrderShipmentEntity) (sessionFactory.getCurrentSession().createQuery(
            "from SapOrderShipmentEntity where sapOrderNumber = :orderNumber").setParameter("orderNumber", orderNumber)
            .uniqueResult());
    }

    @Trace
    @Override
    public SapOrderShipmentEntity getSapOrderShipmentById(Long sapOrderShipmentId) {
        return (SapOrderShipmentEntity) sessionFactory.getCurrentSession()
            .load(SapOrderShipmentEntity.class, sapOrderShipmentId);
    }

    @Override
    public void delete(SapOrderShipmentEntity sapOrderShipment) {
        if (sapOrderShipment != null) {
            sessionFactory.getCurrentSession().delete(sapOrderShipment);
        }
    }
}
