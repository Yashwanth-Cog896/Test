package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.CropDescription;

import java.util.List;

/**
 * User: pgadi
 */
public interface SapCropDescriptionBusiness {

    List<CropDescription> getCropDescriptions();
}
