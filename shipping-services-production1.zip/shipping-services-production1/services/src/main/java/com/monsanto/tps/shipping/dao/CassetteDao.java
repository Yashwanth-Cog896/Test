package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CassetteEntity;

import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
public interface CassetteDao {

    List<CassetteEntity> findByBarcode(String barcode);
    List<CassetteEntity> findByBarcode(Set<String> barcodes);
}
