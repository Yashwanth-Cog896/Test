package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.ShippingPreferenceDao;
import com.monsanto.tps.shipping.domain.ShippingPreferenceEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * User: DCENGL
 */
@Service
public class ShippingPreferenceBusinessImpl implements ShippingPreferenceBusiness {

    @Autowired
    private ShippingPreferenceDao shippingPreferenceDao;

    @Trace
    @Override
    public String getShippingPreferenceValue(String type, Long accountId) {
        ShippingPreferenceEntity shippingPreferenceEntity = shippingPreferenceDao.findShippingPreferenceByType(type, accountId);

        if (shippingPreferenceEntity == null) {
            return null;
        }

        return shippingPreferenceEntity.getValue();
    }
}
