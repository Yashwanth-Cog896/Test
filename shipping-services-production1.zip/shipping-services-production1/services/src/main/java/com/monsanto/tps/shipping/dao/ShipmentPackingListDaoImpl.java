package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * @author Supreet Singh (sssing5)
 */
@Repository
public class ShipmentPackingListDaoImpl implements ShipmentPackingListDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public List<ShipmentPackingListEntity> getPackingListsByProgramAndCreationDate(Long accountId,
                                                                                   Date createdAfterDate) {
        return sessionFactory.getCurrentSession()
            .createQuery("select distinct packingList " +
                " from ShipmentPackingListEntity packingList, ShippingContactViewEntity shippingContact" +
                " left outer join packingList.shipmentContainers shipmentContainer" +
                " where packingList.fromContactId = shippingContact.contactId" +
                " and shippingContact.accountId = :accountId" +
                " and packingList.creationDate >= :createdAfterDate " +
                " and shipmentContainer.shipment is null " +
                " and packingList.sapOrderShipment is null " +
                " order by packingList.creationDate desc")
            .setParameter("accountId", accountId)
            .setParameter("createdAfterDate", createdAfterDate)
            .list();
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getPackingListById(Long packingListId) {
        return (ShipmentPackingListEntity) sessionFactory.getCurrentSession()
            .load(ShipmentPackingListEntity.class, packingListId);
    }

    @Override
    public ShipmentPackingListEntity getPackingListBySapOrderShipmentId(Long sapOrderShipmentId) {
        return (ShipmentPackingListEntity)
                sessionFactory.getCurrentSession()
                        .createQuery("select packingList from ShipmentPackingListEntity packingList where packingList.sapOrderShipment.sapOrderShipmentId = :sapOrderShipmentId")
                        .setParameter("sapOrderShipmentId", sapOrderShipmentId)
                        .uniqueResult();
    }



    @Trace
    @Override
    public ShipmentPackingListEntity getPackingListByBoxBarcode(String suBarcode) {
        return (ShipmentPackingListEntity)
            sessionFactory.getCurrentSession()
                .createQuery("select packingList from ShipmentPackingListEntity packingList where (" +
                    "select shipmentContainer from ShipmentContainerEntity shipmentContainer where shipmentContainer.storageContainer = " +
                    "(select storageContainer from StorageContainerEntity storageContainer where storageContainer.barcode = :barcode)) = " +
                    "some elements (packingList.shipmentContainers)")
                .setParameter("barcode", suBarcode)
                .uniqueResult();
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getPackingListByShipmentBarcode(String shBarcode) {
        return (ShipmentPackingListEntity)
            sessionFactory.getCurrentSession()
                .createQuery("select packingList from ShipmentPackingListEntity packingList where barcode = :barcode")
                .setParameter("barcode", shBarcode)
                .uniqueResult();
    }

    @Trace
    @Override
    public void savePackingList(ShipmentPackingListEntity shipmentPackingListEntity) {
        sessionFactory.getCurrentSession().save(shipmentPackingListEntity);
    }

    @Trace
    @Override
    public void updatePackingList(ShipmentPackingListEntity shipmentPackingListEntity) {
        sessionFactory.getCurrentSession().update(shipmentPackingListEntity);
    }

    @Trace
    @Override
    public void delete(ShipmentPackingListEntity shipmentPackingListEntity) {
        if (shipmentPackingListEntity != null) {
            sessionFactory.getCurrentSession().delete(shipmentPackingListEntity);
        }
    }

    @Trace
    @Override
    @SuppressWarnings("unchecked")
    public List<ShipmentPackingListEntity> getInternationalPackingListsByCreatedDate(Date createdAfterDate,
                                                                                     List<String> contactIds) {
        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(contactIds));
        return sessionFactory.getCurrentSession()
            .createQuery("select distinct packingList " +
                " from ShipmentPackingListEntity packingList " +
                " left outer join packingList.shipmentContainers shipmentContainer " +
                " where packingList.sapOrderShipment is not null" +
                " and packingList.creationDate >= :createdAfterDate " +
                " and shipmentContainer.shipment is null " +
                " and packingList.sapOrderShipment.sapStorageLocationCode in (select tempOcdId from TempOcdTable tempTable where tempTable.sessionId = :requestId) " +
                " order by packingList.creationDate desc")
            .setParameter("createdAfterDate", createdAfterDate)
            .setParameter("requestId", requestId)
            .list();
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getPackingListBySapOrderNumber(String sapOrderNumber) {
        return (ShipmentPackingListEntity)
                sessionFactory.getCurrentSession()
                        .createQuery("select packingList from ShipmentPackingListEntity packingList where packingList.sapOrderShipment.sapOrderNumber = :sapOrderNumber")
                        .setParameter("sapOrderNumber", sapOrderNumber)
                        .uniqueResult();
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getPackingListBySapDeliveryShipmentNumber(String shipmentNumber) {
        return (ShipmentPackingListEntity)
                sessionFactory.getCurrentSession()
                        .createQuery("select packingList from ShipmentPackingListEntity packingList where packingList.sapOrderShipment.shipmentNumber = :shipmentNumber")
                        .setParameter("shipmentNumber", shipmentNumber)
                        .uniqueResult();
    }

}