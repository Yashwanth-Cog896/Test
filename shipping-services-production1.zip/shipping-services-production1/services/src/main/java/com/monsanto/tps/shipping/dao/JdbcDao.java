package com.monsanto.tps.shipping.dao;

import org.springframework.stereotype.Component;

@Component
public @interface JdbcDao {

    String value();

}
