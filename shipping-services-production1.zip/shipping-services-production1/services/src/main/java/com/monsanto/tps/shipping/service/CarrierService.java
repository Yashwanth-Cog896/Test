package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Carrier;
import javax.ws.rs.*;

import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by KERRA on 5/19/2014.
 */
@Path("/carrier")
public interface CarrierService {
    @GET
    @Path("/{carrier-id}")
    @Produces(APPLICATION_JSON)
    Carrier findCarrier(@PathParam("carrier-id") Long carrierId);

    @GET
    @Path("/account/{account-id}")
    @Produces(APPLICATION_JSON)
    List<Carrier> findCarriersByAccountId(@PathParam("account-id") Long accountId);

    @GET
    @Path("/")
    @Produces(APPLICATION_JSON)
    List<Carrier> findAllCarriers(@QueryParam("integrated") Boolean integrated);
}