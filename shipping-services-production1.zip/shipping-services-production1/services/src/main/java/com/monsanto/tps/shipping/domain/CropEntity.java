package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import java.util.List;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Cacheable
@Table(name = "CROP", schema = "MIDAS")
public class CropEntity {
    @Id
    @Column(name = "CROP_ID", nullable = false)
    private Long cropId;
    @Column(name = "NAME")
    private String name;

    @OneToMany(mappedBy="crop",fetch = FetchType.EAGER)
    @OrderBy("listOrder asc")
    private List<GenusSpeciesEntity> genusSpecies;

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<GenusSpeciesEntity> getGenusSpecies() {  return genusSpecies;  }

    public void setGenusSpecies(List<GenusSpeciesEntity> genusSpecies) { this.genusSpecies = genusSpecies;  }

    public CropEntity() {}

    public CropEntity(Long cropId, String name) {
        this.cropId = cropId;
        this.name = name;
    }

    @Override
    public String toString() {
        return "CropEntity{" +
                "cropId=" + cropId +
                ", name='" + name + '\'' +
                '}';
    }
}