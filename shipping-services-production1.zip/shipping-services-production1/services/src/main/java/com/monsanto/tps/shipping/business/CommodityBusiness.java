package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentEntity;

/**
 * User: DCENGL
 */
public interface CommodityBusiness {

    void associateCommodity(ShipmentEntity shipmentEntity);

}
