package com.monsanto.tps.shipping.service;

import com.google.common.collect.Sets;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.pipeline.util.StringUtil;
import com.monsanto.tps.shipping.business.ComplianceRegulationBusiness;
import com.monsanto.tps.shipping.business.PlotDataErrorsHolder;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.RegulatedStatusWithEvents;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Set;

/**
 * User: pgadi
 */
@Component("complianceRegulationService")
public class ComplianceRegulationServiceImpl implements ComplianceRegulationService {

    @Autowired
    private ComplianceRegulationBusiness complianceRegulationBusiness;

    @Autowired
    private EventHelper eventHelper;

    @Override
    @Transactional(noRollbackFor = ShippingWebException.class)
    @Trace
    public RegulatedStatus getRegulatedStatus(Long packingListId) {
        PlotDataErrorsHolder.clear();
        RegulatedStatus regulatedStatus = complianceRegulationBusiness.getRegulatedStatusForPackingList(packingListId);
        checkForErrors();
        return regulatedStatus;
    }

    @Trace
    @Transactional(noRollbackFor = ShippingWebException.class)
    @Override
    public RegulatedStatusWithEvents getRegulatedStatusWithEvents(Long packingListId) {
        PlotDataErrorsHolder.clear();
        RegulatedStatusWithEvents regulatedStatusWithEvents = complianceRegulationBusiness.getRegulatedStatusWithEventsForPackingList(packingListId);
        checkForErrors();
        return regulatedStatusWithEvents;
    }

    @Override
    @Transactional(noRollbackFor = ShippingWebException.class)
    @Trace
    public RegulatedStatus saveRegulatedStatus(Long packingListId) {
        PlotDataErrorsHolder.clear();
        RegulatedStatus regulatedStatus = complianceRegulationBusiness.saveRegulatedStatusForPackingList(packingListId);
        checkForErrors();
        return regulatedStatus;
    }

    @Override
    @Transactional(noRollbackFor = ShippingWebException.class)
    @Trace
    public RegulatedStatus updateRegulatedStatus(Long packingListId) {
        PlotDataErrorsHolder.clear();
        RegulatedStatus regulatedStatus = complianceRegulationBusiness.updateRegulatedStatusForPackingList(packingListId);
        checkForErrors();
        return regulatedStatus;
    }


    @Override
    @Transactional
    @Trace
    public EventDetails getEventDetails(String eventString, String countryAbbr) {
        if (StringUtils.isNullOrEmpty(countryAbbr)) {
            throw new ShippingWebException("Country Abbreviation cannot be empty.");
        }

        if (StringUtils.isNullOrEmpty(eventString)) {
            throw new ShippingWebException("Event String cannot be empty.");
        }

        Set<String> eventNames = Sets.newHashSet(StringUtil.stripWhitespace(eventString).split(","));
        return complianceRegulationBusiness.getEventDetails(eventHelper.getSortedEvent(eventNames), countryAbbr);
    }

    private static void checkForErrors() {
        if (PlotDataErrorsHolder.hasErrors()) {
            Collection<String> errorsMessages = PlotDataErrorsHolder.getErrors();
            String jsonArray = new JSONArray(errorsMessages).toString();
            PlotDataErrorsHolder.clear();
            throw new ShippingWebException(jsonArray);
        }
        PlotDataErrorsHolder.clear();
    }

}
