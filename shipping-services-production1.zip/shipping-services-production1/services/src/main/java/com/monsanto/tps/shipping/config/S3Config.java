package com.monsanto.tps.shipping.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
public class S3Config {

    @Value("${aws.region}")
    public String region;

    @Value("${aws.secret}")
    public String secret;

    @Value("${aws.key}")
    public String key;

    @Value("${aws.secretName}")
    public String secretName;

    private String s3Key;

    private String s3Secret;

    public String s3BucketName;

    public S3Client client;
    private static final Log LOGGER = LogFactory.getLog(S3Config.class);

    /*
     * Builds the S3Client that will provide the connection from the code to S3 when an operation is performed
     */
    public S3Config(){
    }

    public S3Client getClient() {
        if (client == null) {
            SecretsManagerClient secretsManagerClient = SecretsManagerClient.builder()
                    .region(Region.of(region))
                    .credentialsProvider(StaticCredentialsProvider
                            .create(AwsBasicCredentials
                                    .create(key, secret)))
                    .build();

            GetSecretValueRequest getSecretValueRequest = GetSecretValueRequest.builder()
                    .secretId(secretName)
                    .build();

            GetSecretValueResponse getSecretValueResponse;

            try {
                getSecretValueResponse = secretsManagerClient.getSecretValue(getSecretValueRequest);
            } catch (Exception e) {
                LOGGER.error(e);
                return null;
            }

            String secrets = getSecretValueResponse.secretString();

            try {
                for (Map.Entry<String, Object> set : returnSecretsAsMap(secrets).entrySet()) {
                    switch (set.getKey()) {
                        case "aws-iam.key":
                            s3Key = (String) set.getValue();
                            break;
                        case "aws-iam.secret":
                            s3Secret = (String) set.getValue();
                            break;
                        case "aws-iam.bucketName":
                            s3BucketName = (String) set.getValue();
                            break;
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            client = S3Client.builder()
                    .region(Region.of(region))
                    .credentialsProvider(StaticCredentialsProvider
                            .create(AwsBasicCredentials
                                    .create(s3Key, s3Secret)))
                    .build();
        }
        return client;
    }

    private Map<String, Object> returnSecretsAsMap(String secrets) throws IOException {
        return new ObjectMapper().readValue(secrets, HashMap.class);
    }

}
