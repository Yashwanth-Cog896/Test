package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.transfer.GlobalTradeDocument;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.support.HttpRequestWrapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * User: pgadi
 */
@Service
public class GlobalTradeDocumentBusinessImpl implements GlobalTradeDocumentBusiness {
    private static final String DOCUMENTS_LIST = "list/ShipCenterDocListServlet.srv";
    private static final String DOWNLOAD_DOCUMENT = "download/ShipCenterDownloadServlet.srv";
    public static final String DOCUMENTS_RETRIEVAL_ERROR = "Documents not available.";

    private static final Log LOG = LogFactory.getLog(GlobalTradeDocumentBusinessImpl.class);

    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Resource(name = "restOperation")
    private RestTemplate restTemplate;

    @Value("#{documentSystemXmlProperties.BASE_URL}")
    private String DATA_POWER_ADDRESS_BASE;

    @Value("#{documentSystemXmlProperties.AUTHORIZATION}")
    private String AUTHORIZATION;

    @Autowired
    private SapOrderShipmentBusiness sapOrderShipmentBusiness;

    @Override
    @Trace
    @Transactional
    public List<GlobalTradeDocument> getGlobalTradeDocumentsList(Long sapOrderShipmentId) {
        String sapShipmentNbr = sapOrderShipmentBusiness.getSapOrderShipmentById(sapOrderShipmentId).getShipmentNumber();
        setAuthHeader();
        //String sapShipmentNbr = "34123"; //for dev testing
        Map<String, Object> urlParameters = new HashMap<String, Object>();
        urlParameters.put("transactionID", sapShipmentNbr);

        String url = buildUrl(DATA_POWER_ADDRESS_BASE + DOCUMENTS_LIST, urlParameters);

        GlobalTradeDocument[] globalTradeDocuments;

        try{
            LOG.warn("About to call DP with url: " + url);
            globalTradeDocuments =  restTemplate.getForObject(url, GlobalTradeDocument[].class);
        } catch (Exception e) {
            LOG.warn(e.getMessage());
            throw new ShippingWebException(DOCUMENTS_RETRIEVAL_ERROR);
        }

        return Arrays.asList(globalTradeDocuments);
    }

    @Override
    public byte[] getGlobalTradeDocumentPdf(Long sequenceNumber, String title) {
        setAuthHeader();

        Map<String, Object> urlParameters = new HashMap<String, Object>();
        urlParameters.put("file_id", sequenceNumber);
        urlParameters.put("user", userDetailsProvider.getUserDetails().getUsername());

        String url = buildUrl(DATA_POWER_ADDRESS_BASE + DOWNLOAD_DOCUMENT, urlParameters);

        ResponseEntity<byte[]> response1 = restTemplate.getForEntity(url, byte[].class);

        return response1.getBody();
    }

    private String buildUrl(String baseUrl, Map<String, Object> urlParameters) {
        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl);
        for (Map.Entry<String, Object> entry : urlParameters.entrySet()) {
            urlBuilder.queryParam(entry.getKey(), entry.getValue());
        }
        return urlBuilder.build(false).encode().toUriString();
    }

    private void setAuthHeader() {
        restTemplate.setInterceptors(Lists.<ClientHttpRequestInterceptor>newArrayList(new ClientHttpRequestInterceptor() {
            @Override
            public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
                HttpRequestWrapper requestWrapper = new HttpRequestWrapper(request);
                requestWrapper.getHeaders().set("Authorization", AUTHORIZATION);
                return execution.execute(requestWrapper, body);
            }
        }));
    }
}
