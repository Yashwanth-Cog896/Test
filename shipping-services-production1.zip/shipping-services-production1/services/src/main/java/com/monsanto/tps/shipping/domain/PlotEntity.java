package com.monsanto.tps.shipping.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "PLOT", schema = "MIDAS")
public class PlotEntity implements ContentEntity, Serializable {
    @Id
    @Column(name = "PLOT_ID", nullable = false)
    private Long plotId;
    @Column(name = "BARCODE")
    private String barcode;
    @Column(name = "RANGE")
    private Integer range;
    @Column(name = "COLUMN_NUMBER")
    private Integer column;
    @Column(name = "ABSOLUTE_RANGE")
    private Integer absoluteRange;
    @Column(name = "ABSOLUTE_COLUMN")
    private Integer absoluteColumn;
    @Column(name = "PLOT_NUMBER")
    private Integer plotNumber;
    @Column(name = "PLANTING_DATE")
    private Date plantingDate;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INVENTORY_ID")
    private InventoryEntity inventory;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEST_SET_ENTRY_ID")
    private TestSetEntryEntity testSetEntry;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BR_FIELD_ID")
    private FieldEntity field;
    @OneToOne(optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "OPERATION_ID", referencedColumnName = "OPERATION_ID", insertable = false, updatable = false)
    private OperationOperationTypeEntity operationOperationType;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REP_ID")
    private RepEntity rep;
    @OneToOne(mappedBy = "plot", fetch = FetchType.EAGER)
    @JoinColumn(name = "PLOT_ID")
    private PlotSupplementalInfoEntity supplementalInfo; //http://stackoverflow.com/questions/18303522/jpa-hibernate-issue-with-onetoone-mappedby-annotation


    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public Integer getColumn() {
        return column;
    }

    public void setColumn(Integer column) {
        this.column = column;
    }

    public Integer getAbsoluteRange() {
        return absoluteRange;
    }

    public void setAbsoluteRange(Integer absoluteRange) {
        this.absoluteRange = absoluteRange;
    }


    public Integer getAbsoluteColumn() {
        return absoluteColumn;
    }

    public void setAbsoluteColumn(Integer absoluteColumn) {
        this.absoluteColumn = absoluteColumn;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public InventoryEntity getInventory() {
        return inventory;
    }

    public void setInventory(InventoryEntity inventory) {
        this.inventory = inventory;
    }

    public TestSetEntryEntity getTestSetEntry() {
        return testSetEntry;
    }

    public void setTestSetEntry(TestSetEntryEntity testSetEntry) {
        this.testSetEntry = testSetEntry;
    }

    public FieldEntity getField() {
        return field;
    }

    public void setField(FieldEntity field) {
        this.field = field;
    }

    public OperationOperationTypeEntity getOperationOperationType() {
        return operationOperationType;
    }

    public void setOperationOperationType(OperationOperationTypeEntity operationOperationType) {
        this.operationOperationType = operationOperationType;
    }

    public GeneticMaterialEntity getGeneticMaterial() {
        return (null == this.inventory ? null : this.inventory.getGeneticMaterial());
    }

    public Long getContentId() {
        return this.plotId;
    }

    public RepEntity getRep() {
        return rep;
    }

    public void setRep(RepEntity rep) {
        this.rep = rep;
    }

    public Integer getPlotNumber() {
        return plotNumber;
    }

    public void setPlotNumber(Integer plotNumber) {
        this.plotNumber = plotNumber;
    }

    public PlotSupplementalInfoEntity getSupplementalInfo() {
        return supplementalInfo;
    }

    public void setSupplementalInfo(PlotSupplementalInfoEntity supplementalInfo) {
        this.supplementalInfo = supplementalInfo;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.PLOT;
    }

    @Override
    public String toString() {
        return "PlotEntity{" +
            "plotId=" + plotId +
            ", barcode='" + barcode + '\'' +
            ", plotNumber='" + plotNumber +
            '}';
    }
}