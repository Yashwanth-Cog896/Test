package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by wwahme
 */
@Service
public class SeedTreatmentPPQSection extends AbstractChecklistSection {

    private static final String HEADER = "Additional requirements for the�movement of Seed Treated with Microbial Seed Treatments under PPQ Permits";

    private final static String SECTION_1 = "Labeling";
    private final static String SECTION_1_QUESTION_1 = "Outermost layer of containment is labeled with the phrase, \"Experimental Use Only\".";
    private final static String SECTION_1_QUESTION_2 = "Outermost layer of containment is labeled with the phrase, \"Do Not Use For Food or Feed\".";
    private final static String SECTION_1_QUESTION_3 = "Outermost layer of containment is labeled with the phrase, \"Contains USDA-PPQ Regulated Material\".";
    private final static String SECTION_1_QUESTION_4 = "Outermost layer of containment is labeled with the appropriate PPQ permit number(s).";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_2);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_3);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_4);

        return questionsMap;
    }
}
