package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.WhereJoinTable;
import javax.persistence.*;
import java.util.Collection;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "GERMPLASM", schema = "MIDAS")
public class GermplasmEntity {
    @Id
    @Column(name = "GERMPLASM_ID", nullable = false)
    private Long germplasmId;
    @Column(name = "EVENT_DISPLAY")
    private String eventDisplay;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CROP_ID")
    private CropEntity crop;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "GERMPLASM_EVENT_CONSTRUCT",
            schema = "MIDAS",
            joinColumns = {@JoinColumn(name = "GERMPLASM_ID")},
            inverseJoinColumns = {@JoinColumn(name = "EVENT_CONSTRUCT_ID")}
    )
    @WhereJoinTable(clause = "EVENT_CONSTRUCT_ABSENCE_DATE is null")
    private Collection<EventConstructEntity> events;

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public Collection<EventConstructEntity> getEvents() {
        return events;
    }

    public void setEvents(Collection<EventConstructEntity> events) {
        this.events = events;
    }
}