package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * User: jdvoll
 * Date: 1/13/14
 * Time: 9:21 AM
 */
@Entity
@Table(name = "TEST_SET_ENTRY", schema = "MIDAS")
public class TestSetEntryEntity {

    @Id
    @Column(name = "TEST_SET_ENTRY_ID")
    private long id;

    @Column(name = "ENTRY_NUM")
    private Double entryNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEST_SET_ID")
    private TestSetEntity testSet;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Double getEntryNumber() {
        return entryNumber < 0 ? (-entryNumber + 0.1) : entryNumber;
    }

    public void setEntryNumber(Double entryNumber) {
        this.entryNumber = entryNumber;
    }

    public TestSetEntity getTestSet() {
        return testSet;
    }

    public void setTestSet(TestSetEntity testSet) {
        this.testSet = testSet;
    }
}
