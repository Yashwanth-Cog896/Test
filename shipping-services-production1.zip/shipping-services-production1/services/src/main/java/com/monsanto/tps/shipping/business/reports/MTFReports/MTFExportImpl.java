package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.monsanto.tps.shipping.business.CropBusiness;
import com.monsanto.tps.shipping.business.PermitBusiness;
import com.monsanto.tps.shipping.business.labels.ContainerLabelConstants;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

@Component
public class MTFExportImpl implements MTFExport {

    @Autowired
    @Qualifier("MTFDetailsDocumentBuilderImpl")
    MTFDetailsDocumentBuilder mtfDetailsDocumentBuilder;

    @Autowired
    @Qualifier("MTFInternationalDetailsDocumentBuilder")
    MTFDetailsDocumentBuilder mtfInternationalDetailsDocumentBuilder;

    @Autowired
    MTFItemsDocumentBuilderFactory mtfItemsDocumentBuilderFactory;

    @Autowired
    CropBusiness cropBusiness;

    @Autowired
    private PermitBusiness permitBusiness;

    @Trace(showReturn = false)
    @Override
    public ByteArrayOutputStream getPdfReport(ShipmentPackingListEntity packingListEntity) throws IOException {
        Document document = new Document(PageSize.LETTER.rotate());
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(os, 10*1024);

        try {
            Collection<Event> permits = Lists.newArrayList();
            if (packingListEntity.getShipmentType().getContentType() != ContentType.OTHER &&
                    packingListEntity.getShipmentType().getContentType() != ContentType.TISSUE_PLATE &&
                    !packingListEntity.isInternational()) {
                permits = getPermits(packingListEntity);
            }

            PdfWriter writer = PdfWriter.getInstance(document, bufferedOutputStream);
            writer.setPageEvent(new HeaderFooter(packingListEntity, permits));

            document.open();

            if (packingListEntity.isInternational()) {
                mtfInternationalDetailsDocumentBuilder.buildDocument(writer, document, packingListEntity);
            } else {
                mtfDetailsDocumentBuilder.buildDocument(writer, document, packingListEntity);
            }

            document.newPage();
            mtfItemsDocumentBuilderFactory.getDocumentBuilder(packingListEntity).buildDocument(document, packingListEntity, permits);

            document.close();
            os.close();

            PdfReader reader = new PdfReader(os.toByteArray());

            removeEndingEmptyPage(reader);
            os = writePageNumbers(reader);

            return os;
        } catch (DocumentException e) {
            throw new ShippingWebException(e.getMessage(), e, true);
        }
    }

    Collection<Event> getPermits(ShipmentPackingListEntity packingListEntity) {
        return permitBusiness.loadAssociatedPermits(packingListEntity);
    }

    boolean removeEndingEmptyPage(PdfReader reader) throws IOException {
        int totalPages = reader.getNumberOfPages();
        String contentOfLastPage = new String(reader.getPageContent(totalPages));
        String emptyPageIndicator = "(Printed: "+ new SimpleDateFormat("dd-MMM-yyyy").format(new Date()) + ")Tj\nET\n";

        if (contentOfLastPage.endsWith(emptyPageIndicator)) {
            reader.selectPages("1-" + (totalPages - 1));
            return true;
        }
        return false;
    }
    ByteArrayOutputStream writePageNumbers(PdfReader reader) throws IOException, DocumentException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        PdfStamper stamper = new PdfStamper(reader, os);

        int totalPages = reader.getNumberOfPages();
        String totalPagesString = String.valueOf(totalPages);
        Font font = new Font();
        font.setSize(8);
        for (int i=1; i<=totalPages; ++i) {
            ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_RIGHT, new Phrase(i + " / " + totalPagesString, font), 770, 21, 0);
        }
        stamper.close();
        reader.close();

        return os;
    }

    protected class HeaderFooter extends PdfPageEventHelper {
        public static final String REGULATED_STATUS_MESSAGE = "This shipment contains Genetically Modified Plant Material which is Regulated.";
        private String monsantoCompanyHeaderText;
        private String mtfHeaderText;
        private String shipmentBarcodeText;
        private String packingListBarcode;
        private Image shipmentBarcode;

        private String packingListDescriptionFooterText;
        private String regulatedStatusFooterText;
        private String dateFooterText;

        private ColumnText columnTextCenter;
        private ColumnText columnTextDefault;
        private ColumnText columnTextBarcode;
        private Font headerFont;
        private Font footerFont;

        public HeaderFooter(ShipmentPackingListEntity packingList, Collection<Event> permits) {
            this.monsantoCompanyHeaderText = "Bayer Company";
            CropEntity cropEntity = cropBusiness.getCropEntityByPackingListWithContainers(packingList);
            String cropDescription = cropEntity != null ? cropEntity.getName() + " " : "";
            this.mtfHeaderText = cropDescription + "Material Transfer Form (" + packingList.getShipmentType().getDescription() +")";
            this.shipmentBarcodeText = "Shipment:";
            this.packingListBarcode = packingList.getBarcode();

            this.packingListDescriptionFooterText = packingList.getDescription();
            this.regulatedStatusFooterText = getRegulatedStatusMessage(permits);
            DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            this.dateFooterText = dateFormat.format(new Date());
        }

        private String getRegulatedStatusMessage(Collection<Event> permits) {
            String regulatedStatusMessage = "";
            if(isStewarded(getRegulatedAgencies(permits))){
                regulatedStatusMessage = ContainerLabelConstants.STEWARDSHIP_WARNING;
            } else if(permits.size() > 0){
                regulatedStatusMessage = REGULATED_STATUS_MESSAGE;
            }
            return regulatedStatusMessage;
        }

        private boolean isStewarded(Collection<AgencyEnum> regulatedAgencies) {
            return regulatedAgencies.contains(AgencyEnum.STEWARDSHIP) && (!regulatedAgencies.contains(AgencyEnum.EPA) && !regulatedAgencies.contains(AgencyEnum.USDA) && !regulatedAgencies.contains(AgencyEnum.USDA_EPA));
        }

        private Collection<AgencyEnum> getRegulatedAgencies(Collection<Event> permits) {
            Collection<AgencyEnum> regulatedAgencies = Sets.newHashSet();
            for (Event event : permits) {
                regulatedAgencies.addAll(event.getRegulatingAgencies());
            }
            return regulatedAgencies;
        }

        public void onStartPage(PdfWriter writer, Document document) {
            if (writer.getCurrentPageNumber() == 1) {
                columnTextCenter = new ColumnText(writer.getDirectContent());
                columnTextCenter.setAlignment(Element.ALIGN_CENTER);
                columnTextDefault = new ColumnText(writer.getDirectContent());
                columnTextBarcode = new ColumnText(writer.getDirectContent());

                headerFont = new Font();
                headerFont.setStyle(Font.UNDERLINE | Font.BOLD);
                footerFont = new Font();
                footerFont.setSize(8);

                Barcode128 barcode128 = new Barcode128();
                barcode128.setCode(packingListBarcode);
                shipmentBarcode = barcode128.createImageWithBarcode(writer.getDirectContent(), null, null);
                shipmentBarcode.scalePercent(110,110);
            }

            Rectangle pageRect = writer.getPageSize();

            try {
                // Monsanto Company text
                columnTextDefault.setSimpleColumn(pageRect.getLeft(20), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(10));
                columnTextDefault.addText(new Phrase(monsantoCompanyHeaderText, headerFont));
                columnTextDefault.go();
                // MTF form header text
                columnTextDefault.setSimpleColumn(pageRect.getLeft(240), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(10));
                columnTextDefault.addText(new Phrase(mtfHeaderText, headerFont));
                columnTextDefault.go();
                // Shipment Barcode text
                columnTextDefault.setSimpleColumn(pageRect.getLeft(560), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(10));
                columnTextDefault.addText(new Phrase(shipmentBarcodeText, headerFont));
                columnTextDefault.go();
                // Shipment barcode Image
                columnTextBarcode.setSimpleColumn(pageRect.getLeft(664), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(9));
                columnTextBarcode.addElement(shipmentBarcode);
                columnTextBarcode.go();

                columnTextDefault.setSimpleColumn(pageRect.getLeft(20), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(575));
                columnTextDefault.addText(new Phrase(getPackingListDescriptionFooterText(), footerFont));
                columnTextDefault.go();
                if (!getRegulatedStatusFooterText().isEmpty()) {
                    columnTextCenter.setSimpleColumn(pageRect.getLeft(), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(575));
                    columnTextCenter.addText(new Phrase(getRegulatedStatusFooterText(), footerFont));
                    columnTextCenter.go();
                }
                columnTextDefault.setSimpleColumn(pageRect.getLeft(615), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(575));
                columnTextDefault.addText(new Phrase("Printed: " + dateFooterText, footerFont));
                columnTextDefault.go();

                document.add(new Phrase("\n"));
            } catch (DocumentException e) {
                throw new ShippingWebException(e.getMessage(), e, true);
            }
        }

        public String getRegulatedStatusFooterText() {
            return regulatedStatusFooterText;
        }

        public String getPackingListDescriptionFooterText() {
            return packingListDescriptionFooterText;
        }
    }
}
