package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.HDTrayEntity;

import java.util.List;
import java.util.Set;

public interface HDTrayDao {

    List<HDTrayEntity> findByTrayId(String trayId);

    List<HDTrayEntity> findByTrayIds(Set<String> trayIds);
}

