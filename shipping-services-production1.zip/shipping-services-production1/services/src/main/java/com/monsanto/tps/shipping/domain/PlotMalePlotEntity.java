package com.monsanto.tps.shipping.domain;

import javax.persistence.*;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "PLOT_MALE_PLOT", schema = "MIDAS")
public class PlotMalePlotEntity {

    @Id
    @Column(name = "PLOT_MALE_PLOT_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "FEMALE_PLOT_ID", insertable = false, updatable = false)
    private PlotEntity femalePlot;

    @ManyToOne
    @JoinColumn(name = "MALE_PLOT_ID")
    private PlotEntity malePlot;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlotEntity getFemalePlot() {
        return femalePlot;
    }

    public void setFemalePlot(PlotEntity femalePlot) {
        this.femalePlot = femalePlot;
    }

    public PlotEntity getMalePlot() {
        return malePlot;
    }

    public void setMalePlot(PlotEntity malePlot) {
        this.malePlot = malePlot;
    }

    @Override
    public String toString() {
        return "PlotMalePlotEntity{" +
                "id=" + id +
                ", femalePlot=" + femalePlot +
                ", malePlot=" + malePlot +
                '}';
    }
}
