
package com.monsanto.tps.shipping.sap.documents.api.download;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the velocitydocumentintegration.integrationservices.monsanto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: velocitydocumentintegration.integrationservices.monsanto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VelocitydocumentIntegrationRequest }
     * 
     */
    public VelocitydocumentIntegrationRequest createVelocitydocumentIntegrationRequest() {
        return new VelocitydocumentIntegrationRequest();
    }

    /**
     * Create an instance of {@link VelocitydocumentIntegrationRequestType }
     * 
     */
    public VelocitydocumentIntegrationRequestType createVelocitydocumentIntegrationRequestType() {
        return new VelocitydocumentIntegrationRequestType();
    }

}
