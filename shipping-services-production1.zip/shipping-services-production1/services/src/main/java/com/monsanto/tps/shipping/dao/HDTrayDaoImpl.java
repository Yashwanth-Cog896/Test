package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.HDTrayEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
public class HDTrayDaoImpl implements HDTrayDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public List<HDTrayEntity> findByTrayId(String barcode) {
        List<HDTrayEntity> hdTrayEntities = (List<HDTrayEntity>) sessionFactory.getCurrentSession()
                .createCriteria(HDTrayEntity.class).add(Restrictions.eq("barcode", barcode)).addOrder(Order.asc("barcode")).list();
        checkValidTray(hdTrayEntities);
        return hdTrayEntities;
    }

    @Trace
    @Override
    public List<HDTrayEntity> findByTrayIds(Set<String> barcodes) {
        List<HDTrayEntity> hdTrayEntities = (List<HDTrayEntity>) sessionFactory.getCurrentSession()
                .createCriteria(HDTrayEntity.class)
                .add(Restrictions.in("barcode", barcodes)).addOrder(Order.asc("barcode")).list();

        checkValidTray(hdTrayEntities);
        return hdTrayEntities;
    }

    private void checkValidTray(List<HDTrayEntity> hdTrayEntities) {
        for(HDTrayEntity hdTrayEntity : hdTrayEntities) {
            if(hdTrayEntity.getHdTrayProjects().size() > 1) {
                hdTrayEntity.setValidTray(false);
            }
        }
    }
}

