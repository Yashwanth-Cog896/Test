package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MIDAS_USER", schema = "MIDAS")
public class MidasUserEntity {
    @Id
    @Column(name = "MIDAS_USER_ID", nullable = false)
    private Long midasUserId;
    @Column(name = "LOGIN_ID", nullable = false)
    private String loginId;
    @Column(name = "FIRST_NAME", nullable = true)
    private String firstName;
    @Column(name = "MIDDLE_NAME", nullable = true)
    private String middleName;
    @Column(name = "LAST_NAME", nullable = true)
    private String lastName;
    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type = "true_false")
    private boolean refActive;

    public Long getMidasUserId() {
        return midasUserId;
    }

    public void setMidasUserId(Long midasUserId) {
        this.midasUserId = midasUserId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    @Override
    public String toString() {
        return "MidasUserEntity{" +
                "loginId='" + loginId + '\'' +
                '}';
    }
}
