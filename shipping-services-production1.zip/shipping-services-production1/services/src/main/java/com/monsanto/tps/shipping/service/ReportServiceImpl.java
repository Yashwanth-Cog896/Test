package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.business.ReportBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Report;
import com.monsanto.tps.shipping.service.model.ReportResponse;
import com.monsanto.tps.shipping.service.model.enums.ReportEnum;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.Future;

/**
 * Created by RLCASW
 */
@Component("reportService")
public class ReportServiceImpl implements ReportService {

    private static final Log LOG = LogFactory.getLog(ReportServiceImpl.class);

    @Autowired
    private ShipmentPackingListBusiness packingListBusiness;
    @Autowired
    private ReportBusiness reportBusiness;

    @Trace
    @Override
    @Transactional(readOnly = true)
    public ReportResponse getReport(Long packingListId, String reportName) {
        ReportEnum reportEnum = ReportEnum.getByName(reportName);

        if (reportEnum == null) {
            throw new ShippingWebException("Not a valid report: " + reportName);
        }

        ShipmentPackingListEntity packingList = packingListBusiness.getShipmentPackingList(packingListId);

        try {
            Report report = reportBusiness.getReport(reportEnum, packingList);

            return new ReportResponse(report.getFilename(), report.getByteArrayOutputStream());
        } catch (Exception e) {
            throw new ShippingWebException("Error retrieving report: " + reportEnum, e, true);
        }
    }

    @Trace
    @Override
    @Transactional(readOnly = true)
    public ReportResponse getReports(Long packingListId) {
        Collection<ReportEnum> allReports = Lists.newArrayList(ReportEnum.PACKING_LIST_EXPORT, ReportEnum.MTF, ReportEnum.CHECKLIST, ReportEnum.EPA_MASTER_LABEL);
        ShipmentPackingListEntity packingList = packingListBusiness.getShipmentPackingList(packingListId);
        if (!isEPA(packingList)) {
            allReports.remove(ReportEnum.EPA_MASTER_LABEL);
        }

        return getReports(allReports, packingList);
    }

    private ReportResponse getReports(Collection<ReportEnum> reportEnums, ShipmentPackingListEntity packingList) {
            Map<ReportEnum, Future<Report>> reportMap = Maps.newHashMapWithExpectedSize(reportEnums.size());
            for (ReportEnum reportEnum : reportEnums) {
                reportMap.put(reportEnum, reportBusiness.getReportAsync(reportEnum, packingList.getShipmentPackingListId()));
            }

            String barcode = packingList.getBarcode();

            Map<String, ByteArrayOutputStream> zipFilesMap = Maps.newHashMap();
            for (ReportEnum reportEnum : reportMap.keySet()) {
                try {
                    Report report = reportMap.get(reportEnum).get();
                    if (report != null) {
                        zipFilesMap.put(report.getFilename(), report.getByteArrayOutputStream());
                    }
                } catch (Exception e) {
                    String filename = barcode + "_" + reportEnum.getName() + "_Error.txt";

                    ByteArrayOutputStream errorOutput = new ByteArrayOutputStream();

                    PrintStream printStream = new PrintStream(errorOutput);
                    e.printStackTrace(printStream);

                    zipFilesMap.put(filename, errorOutput);
                }
            }

        return new ReportResponse(barcode + "-documents.zip", zipFilesMap);
    }

    private boolean isEPA(ShipmentPackingListEntity packingList) {
        return packingList.getRegulatedStatusText() != null && packingList.getRegulatedStatusText().contains("EPA");
    }
}
