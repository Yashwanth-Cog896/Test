package com.monsanto.tps.shipping.domain;

import javax.persistence.*;

@Entity
@Cacheable
@Table(name = "GENUS_SPECIES", schema = "MIDAS")
public class GenusSpeciesEntity {
    @Id
    @Column(name = "GENUS_SPECIES_ID", nullable = false)
    private Long genusSpeciesId;

    @Column(name="GENUS", nullable=false)
    private String genus;

    @Column(name="SPECIES", nullable=false)
    private String species;

    @Column(name="LIST_ORDER",nullable=false)
    private Long listOrder;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CROP_ID")
    private CropEntity crop;

    public Long getGenusSpeciesId() {
        return genusSpeciesId;
    }

    public void setGenusSpeciesId(Long genusSpeciesId) {
        this.genusSpeciesId = genusSpeciesId;
    }

    public String getGenus() {
        return genus;
    }

    public void setGenus(String genus) {
        this.genus = genus;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }
}
