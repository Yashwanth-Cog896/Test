package com.monsanto.tps.shipping;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.ContentDisposition;

import javax.ws.rs.core.MultivaluedMap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class AttachmentUtil {

    public static Attachment getAttachment(String attachmentName, List<Attachment> attachments) {
        for (Attachment attachment : attachments) {
            MultivaluedMap<String, String> headers = attachment.getHeaders();
            if (attachmentName.equals(getContentDispositionValue(headers, "name"))) {
                return attachment;
            }
        }
        return null;
    }

    private static String getContentDispositionValue(MultivaluedMap<String, String> headers, String contentDispositionKey) {
        String value = "";
        String[] contentDisposition = headers.getFirst("Content-Disposition").split(";");
        for (String key : contentDisposition) {
            if ((key.trim().startsWith(contentDispositionKey))) {
                String[] name = key.split("=");
                value = name[1].trim().replaceAll("\"", "");
                break;
            }
        }
        return value;
    }

    public static String getFileName(Attachment attachment) {
        return getContentDispositionValue(attachment.getHeaders(), "filename");
    }

    public static List<Attachment> createCopies(Attachment attachment, String mediaType, String fileName, int numberOfCopies) {
        List<Attachment> attachments = Lists.newArrayList();
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            IOUtils.copy(attachment.getDataHandler().getDataSource().getInputStream(), baos) ;
            baos.flush();

            for (int i = 0; i < numberOfCopies; i++) {
                InputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
                attachments.add(createAttachment(inputStream, mediaType, fileName));
            }
        } catch (IOException e) {
            throw new ShippingWebException("Error reading attachment");
        }
        return attachments;
    }

    private static Attachment createAttachment(InputStream inputStream, String mediaType, String fileName) {
        return new Attachment(mediaType, inputStream, new ContentDisposition("name=\"attachment\"; filename=\"" + fileName + "\""));
    }
}
