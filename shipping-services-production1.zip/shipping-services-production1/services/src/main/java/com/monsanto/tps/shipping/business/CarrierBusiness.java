package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.CarrierEntity;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface CarrierBusiness {
    CarrierEntity findCarrier(Long carrierId);

    List<CarrierEntity> findCarriersByAccountId(Long accountId);

    List<CarrierEntity> findAllCarriers();

    List<CarrierEntity> findIntegratedCarriers();

    List<CarrierEntity> findNonIntegratedCarriers();
}
