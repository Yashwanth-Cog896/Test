package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/international/storage-location")
public interface InternationalStorageLocationService {

    @GET
    @Path("{id}")
    @Produces(APPLICATION_JSON)
    InternationalStorageLocation getStorageLocation(@PathParam("id") String id);

    @GET
    @Produces(APPLICATION_JSON)
    List<InternationalStorageLocation> getStorageLocations();
}
