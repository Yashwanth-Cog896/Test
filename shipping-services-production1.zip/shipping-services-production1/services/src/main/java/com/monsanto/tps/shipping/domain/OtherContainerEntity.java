package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.util.Collection;

@Entity
@DiscriminatorValue("OTHER")
public class OtherContainerEntity extends ScannedContainerEntity<OtherContentEntity> {

    @Column(name = "BARCODE_NBR")
    private String barcode;

    @Column(name = "OTHER_NM", nullable = true)
    private String name;

    @Column(name = "OTHER_COMMENT_TXT", nullable = true)
    private String comments;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
    
    public String getName() {
        return name;        
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public OtherContentEntity getContent() {
        return new OtherContentEntity(getScannedContainerId(), getBarcode());
    }

    @Override
    public void setContent(OtherContentEntity contentEntity) {
        setBarcode(contentEntity.getBarcode());
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.OTHER;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return null;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        // Do nothing
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        // Do nothing
    }

    @Override
    public String toString() {
        return "OtherContainerEntity{" +
                "id=" + getScannedContainerId() +
                ", scanOrder=" + getScanOrder() +
                ", barcode=" + getBarcode() +
                '}';
    }
}
