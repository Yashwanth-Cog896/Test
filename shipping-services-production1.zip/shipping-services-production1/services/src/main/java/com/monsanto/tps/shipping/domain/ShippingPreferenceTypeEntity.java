package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: DCENGL
 */
@Entity
@Table(name="SHIPPING_PREFERENCE_TYPE", schema="INVENTORY_MGT")
public class ShippingPreferenceTypeEntity {

    public static final String COST_CENTER = "Cost Center";
    public static final String TAX_IDENTIFICATION_NUMBER = "Tax Identification Number";
    public static final String FDA_REGISTRATION_NUMBER = "FDA Registration Number";

    @Id
    @Column(name = "SHIPPING_PREFERENCE_TYPE_ID")
    private long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "REF_ACTIVE")
    @Type(type="true_false")
    private boolean active;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
