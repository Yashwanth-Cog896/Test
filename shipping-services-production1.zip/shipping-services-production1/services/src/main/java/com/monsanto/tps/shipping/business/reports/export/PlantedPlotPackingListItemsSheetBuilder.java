package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

/**
 * Created by DCENGL
 */
@Service
public class PlantedPlotPackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Item BID", "Event", "Set", "Track ID", "Plot #", "Entry #", "Weight", "UOM", "Count", "Monsanto ID", "Permit", "Box Barcode"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        int currentRowIndex = 1;
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        Collection<Event> events = getPermits(packingList);

        for (ScannedContainerEntity contentContainer : contentContainerEntities) {
            PlotEntity plot = null;
            TestSetEntryEntity entry = null;
            RepEntity rep = null;
            if (contentContainer.getContentType() == ContentType.PLOT) {
                plot = (PlotEntity) contentContainer.getContent();
                entry = plot.getTestSetEntry();
                rep = plot.getRep();
            }

            String eventString = getEventString(contentContainer.getContent());
            Event event = getEventForContainer(contentContainer.getContainerId(), events);

            Row row = sheet.createRow(currentRowIndex);

            appendCell(row, defaultCellStyle, contentContainer.getScanOrder());
            appendCell(row, defaultCellStyle, contentContainer.getContent().getBarcode());
            appendCell(row, defaultCellStyle, eventString);
            appendCell(row, defaultCellStyle, rep != null && rep.getTestSet() != null ? rep.getTestSet().getTestSetName() : null);
            appendCell(row, defaultCellStyle, rep != null && rep.getField() != null ? rep.getField().getFieldName() : null);
            appendCell(row, defaultCellStyle, plot != null ? plot.getPlotNumber() : null);
            appendCell(row, defaultCellStyle, entry != null ? entry.getEntryNumber() : null);
            appendCell(row, defaultCellStyle, contentContainer.getWeight());
            appendCell(row, defaultCellStyle, contentContainer.getWeightUOM() != null ? contentContainer.getWeightUOM().getUomRefId() : null);
            appendCell(row, defaultCellStyle, contentContainer.getQuantity());
            appendCell(row, defaultCellStyle, getMonsantoIdString(event));
            appendCell(row, defaultCellStyle, getPermitString(event));
            appendCell(row, defaultCellStyle, contentContainer.getStorageContainer().getBarcode());

            currentRowIndex++;
        }
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.PLANTED_PLOT ||
                shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.PLANTED_PLOT_INV;
    }
}
