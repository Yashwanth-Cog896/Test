package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;

public interface UnitOfMeasureConversionDao {

    public UnitOfMeasureConversionEntity getUomConversion(Long fromUomId, Long toUomId);

}
