package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.CropDescription;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/sap-crop-description")
public interface SapCropDescriptionService {

    @GET
    @Produces(APPLICATION_JSON)
    public List<CropDescription> getCropDescriptions();

}
