package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Repository
public class CustomsBrokerPreferenceDaoImpl implements CustomsBrokerPreferenceDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<CustomsBrokerPreferenceEntity> loadAllActive() {
        return (Collection<CustomsBrokerPreferenceEntity>) sessionFactory.getCurrentSession()
                .createQuery("from CustomsBrokerPreferenceEntity where inactiveDateTime is null or inactiveDateTime < current_date()")
                .list();
    }

    @Trace
    @Override
    public void save(CustomsBrokerPreferenceEntity customsBrokerPreference) {
        sessionFactory.getCurrentSession().save(customsBrokerPreference);
    }
}
