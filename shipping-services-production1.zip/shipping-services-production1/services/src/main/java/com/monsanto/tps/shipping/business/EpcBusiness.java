package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;

/**
 * Created by DCENGL
 */
public interface EpcBusiness {

    void associateBarcodesFromEpc(ShipmentPackingList shipmentPackingList);

    void createEpcForContent(ScannedContainerEntity scannedContainer);

}
