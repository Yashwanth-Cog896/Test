package com.monsanto.tps.shipping.converter;

import com.google.common.base.Predicate;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.monsanto.tps.shipping.business.UnitOfMeasureBusiness;
import com.monsanto.tps.shipping.dao.ShipmentPackingListDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.domain.SapOrderItemKey;
import com.monsanto.tps.shipping.domain.SapOrderItemWeights;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.sap.client.api.DeliveryShipmentCreateRequest;
import com.monsanto.tps.shipping.sap.client.api.DeliveryShipmentData;
import com.monsanto.tps.shipping.sap.client.api.MaterialDetail;
import com.monsanto.tps.shipping.sap.client.api.SapBoxDetails;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.service.model.SapOrderShipment;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.WeightConverter;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * User: pgadi
 */
@Component
public class SapDeliveryShipmentRequestBuilder {

    public static final String TO_UOM_NAME = "Kilograms";

    @Autowired
    private ShipmentPackingListDao shipmentPackingListDao;

    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private WeightConverter weightConverter;

    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;

    public DeliveryShipmentCreateRequest getDeliveryShipmentRequest(SapOrderShipment sapOrderShipment) {
        ShipmentPackingListEntity shipmentPackingListEntity = shipmentPackingListDao.getPackingListBySapOrderShipmentId(sapOrderShipment.getSapOrderShipmentId());

        Map<SapOrderItemKey, SapOrderItemWeights> complianceKeyWeightMap = eventHelper.getComplianceKeyWeightMap(shipmentPackingListEntity);

        Multimap<String, SapOrderItem> boxBarcodeToItemMap = HashMultimap.create();
        for(SapOrderItem sapOrderItem : sapOrderShipment.getOrderItems()) {
            boxBarcodeToItemMap.put(sapOrderItem.getStorageContainerBarcode(), sapOrderItem);
        }

        List<SapBoxDetails> sapBoxDetailsList = Lists.newArrayList();

        UnitOfMeasureEntity toUnitOfMeasureEntity = unitOfMeasureDao.findByName(TO_UOM_NAME);

        Long toUomId = toUnitOfMeasureEntity.getId();
        String weightUnit = toUnitOfMeasureEntity.getUomRefId();

        Long fromUomId = unitOfMeasureBusiness.getPackingListUomId(shipmentPackingListEntity);

        for (final ShipmentContainerEntity shipmentContainerEntity : shipmentPackingListEntity.getShipmentContainers()) {
            if(!CollectionUtils.isEmpty(shipmentContainerEntity.getStorageContainer().getContainers())){
                List<SapOrderItem> sapOrderItemsPerBox = Lists.newArrayList(boxBarcodeToItemMap.get(shipmentContainerEntity.getStorageContainer().getBarcode()));
                Collection<SapOrderItemKey> sapOrderItemKeys = complianceKeyWeightMap.keySet();

                SapOrderItemKey sapOrderItemKey = Iterables.find(sapOrderItemKeys, new Predicate<SapOrderItemKey>() {
                    @Override
                    public boolean apply(SapOrderItemKey input) {
                        return input.getStorageContainerBarcode().equals(shipmentContainerEntity.getStorageContainer().getBarcode());
                    }
                });

                Double convertedGrossWeight = weightConverter.convertWeight(shipmentContainerEntity.getGrossWeight(), fromUomId, toUomId);

                SapBoxDetails sapBoxDetails = new SapBoxDetails();

                sapBoxDetails.setHandlingUnit("BOX " + sapOrderItemKey.getBoxNumber());
                sapBoxDetails.setGrossWeight(null == convertedGrossWeight ? null : getFormattedWeight(convertedGrossWeight));

                if(null != shipmentContainerEntity.getNetWeight()) {
                    Double convertedNetWeight = weightConverter.convertWeight(shipmentContainerEntity.getNetWeight(), fromUomId, toUomId);
                    sapBoxDetails.setNetWeight(null == convertedNetWeight ? null : getFormattedWeight(convertedNetWeight));
                }

                sapBoxDetails.setWeightUnit(weightUnit);

                sapBoxDetails.setMaterialDetails(getMaterialDetails(complianceKeyWeightMap, sapOrderItemsPerBox, weightUnit, toUomId));

                sapBoxDetailsList.add(sapBoxDetails);
            }
        }

        DeliveryShipmentData deliveryShipmentData = new DeliveryShipmentData();
        deliveryShipmentData.setSalesOrderNum(sapOrderShipment.getSapOrderNumber());
        deliveryShipmentData.setBoxes(sapBoxDetailsList);

        DeliveryShipmentCreateRequest deliveryShipmentCreateRequest = new DeliveryShipmentCreateRequest();
        deliveryShipmentCreateRequest.setShipCenterData(deliveryShipmentData);

        return deliveryShipmentCreateRequest;
    }

    private List<MaterialDetail> getMaterialDetails(Map<SapOrderItemKey, SapOrderItemWeights> complianceKeyWeightMap, Collection<SapOrderItem> sapOrderItemsPerBox, String weightUnit, Long toUomId) {
        List<MaterialDetail> materialDetails = Lists.newArrayList();

        for (SapOrderItem sapOrderItem : sapOrderItemsPerBox) {
            SapOrderItemWeights weights = complianceKeyWeightMap.get(new SapOrderItemKey(sapOrderItem));

            MaterialDetail materialDetail = new MaterialDetail();

            materialDetail.setItemNumber(sapOrderItem.getSapOrderItemNumber());
            materialDetail.setSapMaterialNumber(sapOrderItem.getSapMaterialNumber());
            materialDetail.setQuantityToBePacked(getFormattedWeight(weightConverter.convertWeight(weights.getItemWeight(), weights.getUomId(), toUomId)));
            materialDetail.setQuantityUnit(weightUnit);

            materialDetails.add(materialDetail);
        }

        return materialDetails;
    }

    private BigDecimal getFormattedWeight(Double weight) {
        BigDecimal finalWeight = new BigDecimal(weight).setScale(3, RoundingMode.HALF_UP);
        return  finalWeight.equals(new BigDecimal("0.000")) ? new BigDecimal("0.001") : finalWeight;
    }
}
