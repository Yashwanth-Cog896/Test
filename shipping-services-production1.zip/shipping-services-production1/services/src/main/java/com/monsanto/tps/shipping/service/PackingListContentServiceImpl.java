package com.monsanto.tps.shipping.service;

import com.google.common.base.Function;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.PackingListContentBusiness;
import com.monsanto.tps.shipping.business.ProgramBusiness;
import com.monsanto.tps.shipping.business.ShipmentContainerBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.converter.PackingListContentConverter;
import com.monsanto.tps.shipping.dao.CropStandardShipInfoDao;
import com.monsanto.tps.shipping.dao.ShipmentTypeDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureConversionDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureGroupDao;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.CropStandardShipInfoEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.service.validation.PackingListContentValidator;
import com.monsanto.tps.shipping.service.validation.PackingListValidator;
import com.monsanto.tps.shipping.util.RegulatedStatusText;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.SolrPackingListIdParam;
import com.monsanto.tps.shipping.util.aspect.Trace;
import com.monsanto.tps.shipping.util.aspect.UpdateSolrIndex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * User: DCENGL
 */
@Component("packingListContentService")
public class PackingListContentServiceImpl implements PackingListContentService {

    @Autowired
    private PackingListContentBusiness packingListContentBusiness;
    @Autowired
    private PackingListValidator packingListValidator;
    @Autowired
    private PackingListContentValidator packingListContentValidator;
    @Autowired
    private ShipmentTypeDao shipmentTypeDao;
    @Autowired
    private PackingListContentConverter packingListContentConverter;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private ProgramBusiness programBusiness;
    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;
    @Autowired
    private UnitOfMeasureGroupDao unitOfMeasureGroupDao;
    @Autowired
    private UnitOfMeasureConversionDao unitOfMeasureConversionDao;
    @Autowired
    private CropStandardShipInfoDao cropStandardShipInfoDao;

    @Trace
    @Override
    @Transactional
    @UpdateSolrIndex
    public void deleteContent(Long contentId, @SolrPackingListIdParam Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        checkIfPackingListIsEditable(packingList);

        if (!packingList.isInternational() && !RegulatedStatusText.COMPLIANCE_DISABLED.getRegulatedStatusText().equals(packingList.getRegulatedStatusText())) { //delete items should not change the status on International shipments
            packingList.setRegulatedStatusText(null);
            packingList.setComplianceConfirmedDate(null);
            packingList.setMaterialStatusText(null);
        }

        packingListContentBusiness.deleteContent(contentId, packingList.getShipmentType().getShipmentTypeId());
    }

    private void checkIfPackingListIsEditable(ShipmentPackingListEntity packingList) {
        ShippingWebException.checkArgument(packingListValidator.isEditable(packingList), "The packing list cannot be edited. A shipment has already been created from this packing list.");
    }

    @Trace
    @Override
    @Transactional
    @UpdateSolrIndex
    public PackingListContent createContent(PackingListContent packingListContent, @SolrPackingListIdParam Long packingListId,
                                            Long shipmentContainerId, Long cropId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        checkIfPackingListIsEditable(packingList);

        Long programId = null;
        if (packingList.getToContactId() != null) {
            programId = programBusiness.getProgramByContact(packingList.getToContactId()).getProgramId();
        }

        if (!RegulatedStatusText.COMPLIANCE_DISABLED.getRegulatedStatusText().equals(packingList.getRegulatedStatusText())) {
            packingList.setRegulatedStatusText(null);
            packingList.setComplianceConfirmedDate(null);
        }

        ShipmentTypeEntity shipmentType = packingList.getShipmentType();

        ContentEntity contentEntity = packingListContentValidator.validate(packingListContent, shipmentType, cropId, programId, packingList);
        ScannedContainerEntity contentContainerEntity = packingListContentBusiness.savePackingListContent(packingListContent, contentEntity, shipmentContainerId, shipmentType);
        packingListContentConverter.setPackingListContentValues(packingListContent, contentContainerEntity, shipmentType.getName());

        return packingListContent;
    }

    @Trace
    @Override
    @Transactional
    @UpdateSolrIndex
    public PackingListContent createContent(PackingListContent packingListContent, @SolrPackingListIdParam Long packingListId, Long shipmentContainerId) {
        return createContent(packingListContent, packingListId, shipmentContainerId, null);
    }

    @Trace
    @Override
    @Transactional
    @UpdateSolrIndex
    public List<PackingListContent> createContents(List<PackingListContent> packingListContents, @SolrPackingListIdParam Long packingListId,
                                                   Long shipmentContainerId, Long cropId, Boolean conversion) {
        ShipmentPackingListEntity shipmentPackingListEntity = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        checkIfPackingListIsEditable(shipmentPackingListEntity);

        Set<String> currentBarcodes = getCurrentBarcodes(shipmentPackingListEntity);
        Long programId = null;
        if (shipmentPackingListEntity.getToContactId() != null) {
            programId = programBusiness.getProgramByContact(shipmentPackingListEntity.getToContactId()).getProgramId();
        }
        ShipmentContainerEntity shipmentContainerEntity = shipmentContainerBusiness.getShipmentContainer(shipmentContainerId);

        ShipmentTypeEntity shipmentTypeEntity = shipmentPackingListEntity.getShipmentType();
        Map<String, ContentEntity> ceMap;
        try {
            ceMap = packingListContentValidator.validate(packingListContents, shipmentPackingListEntity, shipmentContainerEntity, cropId, programId);
        } catch (ShippingWebException e) {
            invalidateAllBarcodes(packingListContents, e.getMessage());
            return packingListContents;
        }

        Double conversionFactor = 1D;
        UnitOfMeasureEntity unitOfMeasureEntity = null;
        if (packingListContents.get(0).getWeightUOM() != null) {
            unitOfMeasureEntity = unitOfMeasureGroupDao.findByAbbreviation(packingListContents.get(0).getWeightUOM());
            if (conversion != null && conversion) {
                CropEntity cropEntity = ceMap.get(packingListContents.get(0).getBarcode()).getGeneticMaterial().getGermplasm().getCrop();
                conversionFactor = getSeedCountToWeightConversionFactor(unitOfMeasureEntity, cropEntity);
            }
        }
        for (PackingListContent packingListContent : packingListContents) {
            if (packingListContent.getValidBID()) {
                if (currentBarcodes.contains(packingListContent.getBarcode())) {
                    packingListContent.setIsDuplicate(true); //check for dups across entire packing list
                }
                if (conversion != null && conversion) {
                    packingListContent.setWeight(calculateWeight(packingListContent.getSeedCount(), conversionFactor));
                }
                ScannedContainerEntity contentContainerEntity = packingListContentBusiness.saveNewPackingListContent(ceMap.get(packingListContent.getBarcode()),
                        shipmentContainerEntity, packingListContent, shipmentTypeEntity, unitOfMeasureEntity);
                packingListContentConverter.setPackingListContentValues(packingListContent, contentContainerEntity, shipmentTypeEntity.getName());
            }
        }

        return packingListContents;
    }

    @Trace
    @Override
    @Transactional
    @UpdateSolrIndex
    public List<PackingListContent> createContents(List<PackingListContent> packingListContents, @SolrPackingListIdParam Long packingListId,
                                                   Long shipmentContainerId, Boolean conversion) {
        return createContents(packingListContents, packingListId, shipmentContainerId, null, conversion);
    }

    private Double getSeedCountToWeightConversionFactor(UnitOfMeasureEntity packingListUom,
                                                        CropEntity cropEntity) {
        CropStandardShipInfoEntity cropStandardShipInfoEntity = cropStandardShipInfoDao
                .getCropStandardShipInfoByCrop(cropEntity);
        Double seedCountConversionFactor = cropStandardShipInfoEntity.getPerSeedCountStandardWeight();
        Double seedCountToPackingListUomConversionFactor;
        if (packingListUom.getId().equals(cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId())) {
            seedCountToPackingListUomConversionFactor = 1D;
        } else {
            seedCountToPackingListUomConversionFactor = unitOfMeasureConversionDao
                    .getUomConversion(cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId(), packingListUom.getId())
                    .getConversionFactor();
        }
        return seedCountConversionFactor * seedCountToPackingListUomConversionFactor;
    }

    private Set<String> getCurrentBarcodes(ShipmentPackingListEntity shipmentPackingListEntity) {
        Collection<ShipmentContainerEntity> shipmentContainerEntities = shipmentPackingListEntity
                .getShipmentContainers();
        Set<String> barcodes = new HashSet<String>();
        if (shipmentContainerEntities != null) {
            for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainerEntities) {
                StorageContainerEntity storageContainerEntity = shipmentContainerEntity.getStorageContainer();
                Collection<ScannedContainerEntity> contentContainerEntities = storageContainerEntity.getContainers();
                for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
                    barcodes.add(contentContainerEntity.getContent().getBarcode());
                }
            }
        }

        return barcodes;
    }

    private void invalidateAllBarcodes(List<PackingListContent> packingListContents, String message) {
        for (PackingListContent packingListContent : packingListContents) {
            if (packingListContent.getErrorMessage() == null) { //preserve original error messaging if present
                packingListContent.setErrorMessage(message);
                packingListContent.setValidBID(false);
            }
        }
    }

    @Trace
    @Override
    @Transactional
    public PackingListContent getContent(String barcode, Long shipmentTypeId) {
        ShipmentTypeEntity shipmentTypeEntity = shipmentTypeDao.findById(shipmentTypeId);
        ContentEntity contentEntity = packingListContentBusiness.getContents(barcode, shipmentTypeEntity.getContentType());
        return packingListContentConverter.getPackingListContentFromContentEntity(contentEntity);
    }


    @Trace
    @Override
    @Transactional
    public void updateContent(Long contentId, PackingListContent packingListContent, Long shipmentTypeId,
                              Long shipmentContainerId) {
        ShipmentTypeEntity shipmentTypeEntity = shipmentTypeDao.findById(shipmentTypeId);
        ContentEntity contentEntity = packingListContentBusiness.getContents(packingListContent.getBarcode(), shipmentTypeEntity.getContentType());
        ScannedContainerEntity contentContainerEntity = packingListContentBusiness.savePackingListContent(packingListContent, contentEntity, shipmentContainerId, shipmentTypeEntity);
        packingListContentConverter.setPackingListContentValues(packingListContent, contentContainerEntity, shipmentTypeEntity.getName());
    }

    @Override
    @Trace
    @Transactional
    public List<PackingListContent> updateWeight(Long shipmentTypeId, Double amount, String uom, List<PackingListContent> packingListContents) {
        List<Long> ids = getIds(packingListContents);
        packingListContentBusiness.updateWeight(ids, amount, uom);
        return packingListContents;
    }

    @Override
    @Trace
    @Transactional
    public void updateName(List<PackingListContent> packingListContents) {
        ArrayListMultimap<String, PackingListContent> packingListContentsToNamesMultimap = ArrayListMultimap.create();
        for (PackingListContent packingListContent : packingListContents) {
            packingListContentsToNamesMultimap.put(packingListContent.getName(), packingListContent);
        }
        for (String name : packingListContentsToNamesMultimap.keySet()) {
            List<PackingListContent> packingListContentsSubSet = packingListContentsToNamesMultimap.get(name);
            List<Long> ids = getIds(packingListContentsSubSet);
            packingListContentBusiness.updateName(ids, name);
        }
    }

    @Override
    @Trace
    @Transactional
    public void updateComment(List<PackingListContent> packingListContents) {
        ArrayListMultimap<String, PackingListContent> packingListContentsToCommentsMultimap = ArrayListMultimap.create();
        for (PackingListContent packingListContent : packingListContents) {
            packingListContentsToCommentsMultimap.put(packingListContent.getComments(), packingListContent);
        }
        for (String comment : packingListContentsToCommentsMultimap.keySet()) {
            List<PackingListContent> packingListContentsSubSet = packingListContentsToCommentsMultimap.get(comment);
            List<Long> ids = getIds(packingListContentsSubSet);
            packingListContentBusiness.updateComment(ids, comment);
        }
    }

    @Override
    @Trace
    @Transactional
    public List<PackingListContent> updateSeedCount(Long shipmentTypeId, Integer amount, String uom,
                                                    List<PackingListContent> packingListContents, Boolean conversion) {
        ContentType contentType = shipmentTypeDao.findById(shipmentTypeId).getContentType();
        List<Long> ids = getIds(packingListContents);
        UnitOfMeasureEntity uomEntity = unitOfMeasureGroupDao.findByAbbreviation(uom);
        if (uomEntity != null & conversion != null && conversion.booleanValue()) {
            ScannedContainerEntity scannedContainerEntity = packingListContentBusiness.getContentContainer(ids.get(0), contentType);
            CropEntity cropEntity = scannedContainerEntity.getContent().getGeneticMaterial().getGermplasm().getCrop();
            Double conversionFactor = getSeedCountToWeightConversionFactor(uomEntity, cropEntity);
            Double weight = calculateWeight(amount, conversionFactor);
            packingListContentBusiness.updateSeedCountAndWeight(ids, amount, weight, uomEntity);
            for (PackingListContent packingListContent : packingListContents) {
                packingListContent.setWeight(weight);
                packingListContent.setWeightUOM(uomEntity.getUomRefId());
            }
        } else {
            packingListContentBusiness.updateSeedCount(ids, amount);
        }
        return packingListContents;
    }

    @Override
    @Trace
    @Transactional
    public void verifyContent(Long scannedContainerId, Long storageContainerId, Boolean outGoing) {
        checkArgument(scannedContainerId != null, "Scanned Container Id can't be null when updating verify timestamp");
        checkArgument(storageContainerId != null, "Storage Container Id can't be null when updating verify timestamp");
        checkArgument(outGoing != null, "OutGoing can't be null when updating verify timestamp");

        packingListContentBusiness.verifyContent(scannedContainerId, storageContainerId, outGoing);
    }

    @Override
    @Trace
    @Transactional
    public void verifyMultipleContents (List<Long> scannedContainerIds, Long storageContainerId,  Boolean outGoing) {
        checkArgument(scannedContainerIds.size() > 0, "Contents list cannot be empty");
        checkArgument(storageContainerId != null, "Storage Container Id can't be null when updating verify timestamp");
        checkArgument(outGoing != null, "OutGoing can't be null when updating verify timestamp");

        packingListContentBusiness.verifyMultipleContents(scannedContainerIds, storageContainerId, outGoing);
    }

    @Override
    @Trace
    @Transactional
    public void resetVerifiedContent(Long scannedContainerId, Boolean outGoing) {
        checkArgument(scannedContainerId != null, "Scanned Container Id can't be null when resetting verify timestamp");
        checkArgument(outGoing != null, "OutGoing can't be null when resetting verify timestamp");

        packingListContentBusiness.resetVerifiedContent(scannedContainerId, outGoing);
    }

    private double calculateWeight(Integer amount, Double conversionFactor) {
        return (double) Math.round(amount * conversionFactor * 1000000) / 1000000D;
    }

    private List<Long> getIds(List<PackingListContent> packingListContents) {
        return Lists.transform(packingListContents, new Function<PackingListContent, Long>() {
            @Override
            public Long apply(@Nullable PackingListContent packingListContent) {
                if (packingListContent != null) {
                    return packingListContent.getId();
                }

                return null;
            }
        });
    }


}