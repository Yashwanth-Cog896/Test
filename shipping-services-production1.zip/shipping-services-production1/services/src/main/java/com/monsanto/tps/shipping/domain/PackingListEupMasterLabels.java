package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;

import java.util.Collection;

/**
 * User: pgadi
 */
public class PackingListEupMasterLabels {

    private String barcode;
    private Collection<EupMasterLabel> eupMasterLabels = Lists.newArrayList();

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Collection<EupMasterLabel> getEupMasterLabels() {
        return eupMasterLabels;
    }

    public void setEupMasterLabels(Collection<EupMasterLabel> eupMasterLabels) {
        this.eupMasterLabels = eupMasterLabels;
    }
}
