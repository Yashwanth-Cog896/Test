package com.monsanto.tps.shipping.converter;

import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.service.model.SapOrderShipment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Component
public class SapOrderShipmentConverter {

    public SapOrderShipment convertSapOrderShipment(SapOrderShipmentEntity entity) {
        SapOrderItem item;

        SapOrderShipment shipment = new SapOrderShipment();
        shipment.setSapOrderShipmentId(entity.getSapOrderShipmentId());
        shipment.setSapOrderNumber(entity.getSapOrderNumber());
        shipment.setShipmentNumber(entity.getShipmentNumber());
        shipment.setDeliveryBlockCode(entity.getDeliveryBlockCode());
        shipment.setCarrierVendorNumber(entity.getCarrierVendorNumber());
        shipment.setBrokerId(entity.getBrokerCustomerNumber());
        List<SapOrderItem> itemList = new ArrayList<SapOrderItem>();
        Collection<SapOrderItemEntity> entityItems = entity.getOrderItems();
        for (SapOrderItemEntity entityItem : entityItems) {
            item = createOrderItem(entityItem);
            itemList.add(item);
        }
        shipment.setOrderItems(itemList);
        return shipment;
    }

    public SapOrderItem createOrderItem(SapOrderItemEntity entity) {
        SapOrderItem item = new SapOrderItem();
        item.setSapOrderItemId(entity.getSapOrderItemId());
        item.setSapOrderItemNumber(entity.getSapOrderItemNumber());
        item.setSapMaterialNumber(entity.getSapMaterialNbr());
        item.setStorageContainerBarcode(entity.getStorageContainerBarcode());
        item.setCountryOfOrigin(entity.getCountryOfOrigin());
        item.setRegionOfOrigin(entity.getRegionOfOrigin());
        item.setEventStack(entity.getEventStack());
        item.setPhytoNumber(entity.getPhytoNumber());
        item.setImportPermitNumber(entity.getImportPermitNumber());
        item.setSapCcdVal(entity.getSapCcdVal());
        item.setSeedTreatment(entity.getSeedTreatment());
        item.setErrorMessage(entity.getLcErrorMessage());
        return item;
    }

}