package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User: DCENGL
 */
@Repository
public class ProgramDaoImpl implements ProgramDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public List<ProgramEntity> findProgramsByAccountId(Long accountId) {
        StringBuilder query = getQueryForProgramsByAccountId(false);
        return sessionFactory.getCurrentSession()
                .createQuery(query.toString())
                .setLong("accountId", accountId)
                .list();
    }

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public List<ProgramEntity> getProgramsByAccountIdExcludePipelineFunctions(Long accountId) {
        StringBuilder query = getQueryForProgramsByAccountId(true);
        return sessionFactory.getCurrentSession()
                .createQuery(query.toString())
                .setLong("accountId", accountId)
                .list();
    }

    private StringBuilder getQueryForProgramsByAccountId(boolean excludePipelineFunctions) {
        StringBuilder query = new StringBuilder("from ProgramEntity p ");
        query.append("join fetch p.crop ");
        if (!excludePipelineFunctions) {
            query.append("left join fetch p.pipelineFunctions ");
        }
        query.append("where p.accountId = :accountId and p.refActive = true order by p.refId");
        return query;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<ProgramEntity> getActivePrograms() {
        return sessionFactory.getCurrentSession()
            .createQuery("from ProgramEntity where accountId is not null and refActive = true")
            .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ProgramEntity> getGrowerProgramsByPackingListId(Long packingListId) {
        return sessionFactory.getCurrentSession()
            .createSQLQuery(getProgramsByPkgListIdSql())
            .addEntity(ProgramEntity.class)
            .setParameter("packingListId", packingListId)
            .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ProgramEntity> getGrowerProgramsForMixedPlots(Long packingListId) {
        return sessionFactory.getCurrentSession()
                .createSQLQuery(getProgramsByPkgListIdSql())
                .addEntity(ProgramEntity.class)
                .setParameter("packingListId", packingListId)
                .list();
    }

    @Override
    public ProgramEntity getShipToProgramForHarvestedPlotBarcode(String barcode) {
        return (ProgramEntity) sessionFactory.getCurrentSession()
            .createSQLQuery("SELECT prog.* FROM Midas.Plot P " +
                "LEFT OUTER Join Midas.Plot_Supplemental_Info  Psi ON Psi.Plot_Id=P.Plot_Id And Psi.Ref_Active='T' AND  PSI.Shipto_Br_Prog_Id is not null " +
                "INNER JOIN Midas.Br_Rep Rep On P.Rep_Id=Rep.Br_Rep_Id  " +
                "INNER JOIN Midas.BR_PROG prog on prog.br_prog_id=Nvl(Psi.Shipto_Br_Prog_Id,Rep.Orig_Br_Prog_Id) " +
                "WHERE P.barcode=:barcode")
            .addEntity(ProgramEntity.class)
            .setParameter("barcode", barcode)
            .uniqueResult();
    }

    @Override
    public ProgramEntity getShipToProgramForToBePlantedPlotBarcode(String barcode) {
        return (ProgramEntity) sessionFactory.getCurrentSession()
            .createSQLQuery("SELECT prog.* FROM Midas.Plot P " +
                "INNER JOIN Midas.Br_Rep Rep On P.Rep_Id=Rep.Br_Rep_Id  " +
                "INNER JOIN Midas.BR_PROG prog on prog.br_prog_id=Rep.grower_br_prog_id " +
                "WHERE P.barcode=:barcode")
            .addEntity(ProgramEntity.class)
            .setParameter("barcode", barcode)
            .uniqueResult();
    }

    private String getProgramsByPkgListIdSql() {
        return "SELECT distinct bp.* " +
                "FROM inventory_mgt.shipment_container shc, " +
                "  inventory_mgt.storage_container stc, " +
                "  midas.plot p, " +
                "  inventory_mgt.scanned_container pc, " +
                "  midas.br_rep br, " +
                "  midas.br_prog bp " +
                "WHERE bp.br_prog_id          = br.grower_br_prog_id " +
                "AND br.br_rep_id             = p.rep_id " +
                "AND pc.BARCODE_NBR           = p.BARCODE " +
                "AND pc.packed_in_storage_container_id  = stc.storage_container_id " +
                "AND shc.storage_container_id = stc.storage_container_id " +
                "AND shc.shpmt_pkg_list_id    = :packingListId";
    }
}
