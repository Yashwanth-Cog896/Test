package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

/**
 * Created by DCENGL
 */
@Service
public class HarvestedPlotPackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Item BID", "Event", "Field Name (Plot)", "Set", "Track ID", "Plot #", "Entry #", "Weight", "UOM", "Count", "Monsanto ID", "Permit", "Box Barcode"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        Collection<Event> events = getPermits(packingList);

        int currentRowIndex = 1;
        for (ScannedContainerEntity contentContainer : contentContainerEntities) {

            Event event = getEventForContainer(contentContainer.getContainerId(), events);
            PlotEntity plot = (PlotEntity) contentContainer.getContent();
            String eventString = getEventStringforHVPlots(plot);

            Row row = sheet.createRow(currentRowIndex);
            appendCell(row, defaultCellStyle, contentContainer.getScanOrder());
            appendCell(row, defaultCellStyle, plot.getBarcode());
            appendCell(row, defaultCellStyle, eventString);
            appendCell(row, defaultCellStyle, getFieldName(plot));
            appendCell(row, defaultCellStyle, getSet(plot.getRep()));
            appendCell(row, defaultCellStyle, getTrackId(plot.getRep()));
            appendCell(row, defaultCellStyle, plot.getPlotNumber());
            appendCell(row, defaultCellStyle, getEntryNumber(plot));
            appendCell(row, defaultCellStyle, contentContainer.getWeight());
            appendCell(row, defaultCellStyle, getUOM(contentContainer));
            appendCell(row, defaultCellStyle, contentContainer.getQuantity());
            appendCell(row, defaultCellStyle, getMonsantoIdString(event));
            appendCell(row, defaultCellStyle, getPermitString(event));
            appendCell(row, defaultCellStyle, contentContainer.getStorageContainer().getBarcode());

            currentRowIndex++;
        }
    }

    private Double getEntryNumber(PlotEntity plot) {
        return plot.getTestSetEntry() != null ? plot.getTestSetEntry().getEntryNumber() : null;
    }

    private String getUOM(ScannedContainerEntity contentContainer) {
        return contentContainer.getWeightUOM() != null ? contentContainer.getWeightUOM().getUomRefId() : null;
    }

    private String getTrackId(RepEntity rep) {
        return rep != null && rep.getField() != null ? rep.getField().getFieldName() : null;
    }

    private String getSet(RepEntity rep) {
        return rep != null && rep.getTestSet() != null ? rep.getTestSet().getTestSetName() : null;
    }

    private String getFieldName(PlotEntity plot) {
        return plot.getField() != null ? plot.getField().getFieldName() : null;
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.HARVESTED_PLOT;
    }
}
