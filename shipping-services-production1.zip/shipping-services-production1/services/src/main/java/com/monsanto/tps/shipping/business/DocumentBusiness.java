package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.enums.DocumentEnum;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;

import java.util.List;
import java.util.concurrent.Future;

public interface DocumentBusiness {

    List<String> saveAttachments(DocumentEnum documentEnum, Long id, List<Attachment> attachment);
    List<String> retrieveFileNames(DocumentEnum documentEnum, Long id);
    void delete(DocumentEnum documentEnum, Long id, String fileName);
    void deleteAsync(DocumentEnum documentEnum, Long id);
    byte[] retrieveAttachment(DocumentEnum documentEnum, Long id, String fileName);
    Future<byte[]> retrieveAttachmentAsync(DocumentEnum documentEnum, Long id, String fileName);
    boolean pathExists(DocumentEnum documentEnum, Long id);
}
