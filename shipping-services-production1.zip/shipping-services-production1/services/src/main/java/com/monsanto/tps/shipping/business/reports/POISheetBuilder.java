package com.monsanto.tps.shipping.business.reports;

import org.apache.poi.ss.usermodel.*;

/**
 * Created by DCENGL
 */
public abstract class POISheetBuilder {

    protected Cell appendCell(Row row, String value) {
        return appendCell(row, null, value);
    }

    protected Cell appendCell(Row row, Integer value) {
        return appendCell(row, null, value);
    }

    protected Cell appendCell(Row row, Long value) {
        return appendCell(row, null, value);
    }

    protected Cell appendCell(Row row, Double value) {
        return appendCell(row, null, value);
    }

    protected Cell appendCell(Row row, CellStyle cellStyle, String value) {
        Cell cell = getCell(row, cellStyle);

        if (value != null) {
            cell.setCellValue(value);
        }

        return cell;
    }

    protected Cell appendCell(Row row, CellStyle cellStyle, Integer value) {
        Cell cell = getCell(row, cellStyle);

        cell.setCellStyle(cellStyle);
        if (value != null) {
            cell.setCellValue(value);
        }

        return cell;
    }

    protected Cell appendCell(Row row, CellStyle cellStyle, Long value) {
        Cell cell = getCell(row, cellStyle);

        if (value != null) {
            cell.setCellValue(value);
        }

        return cell;
    }

    protected Cell appendCell(Row row, CellStyle cellStyle, Double value) {
        Cell cell = getCell(row, cellStyle);

        if (value != null) {
            cell.setCellValue(value);
        }

        return cell;
    }

    private Cell getCell(Row row, CellStyle cellStyle) {
        short lastCellNum = row.getLastCellNum() < 0 ? 0 : row.getLastCellNum();
        Cell cell = row.createCell(lastCellNum);

        if (cellStyle != null) {
            cell.setCellStyle(cellStyle);
        }
        return cell;
    }

    protected CellStyle buildDefaultStyle(Workbook workbook) {
        CellStyle defaultStyle = workbook.createCellStyle();
        defaultStyle.setAlignment(CellStyle.ALIGN_CENTER);

        return defaultStyle;
    }

    protected CellStyle buildHeaderStyle(Workbook workbook) {
        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
        headerStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
        headerStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderRight(CellStyle.BORDER_THIN);
        headerStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderTop(CellStyle.BORDER_THIN);
        headerStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setAlignment(CellStyle.ALIGN_CENTER);

        return headerStyle;
    }

    protected Sheet newSheet(Workbook workbook, String title) {
        return workbook.createSheet(title);
    }

    protected void addHeader(Sheet sheet, CellStyle cellStyle, String... headerValues) {
        Row itemsSheetHeaderRow = sheet.createRow(0);
        for (String headerValue : headerValues) {
            appendCell(itemsSheetHeaderRow, cellStyle, headerValue);
        }
    }

    protected void autoSizeColumns(Sheet sheet, int length) {
        for (int i = 0; i < length; i++) {
            sheet.autoSizeColumn(i);
        }
    }
}
