package com.monsanto.tps.shipping.domain;


import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AGENCY", schema = "MIDAS")
public class AgencyEntity {

    private Long agencyId;
    private String agencyReferenceId;
    private AgencyEnum agencyEnumRefId;
    private boolean refActive;

    public AgencyEntity() {
    }

    public AgencyEntity(AgencyEnum agencyEnumRefId) {
        this.agencyEnumRefId = agencyEnumRefId;
    }

    @Id
    @Column(name = "AGENCY_ID", nullable = false)
    public Long getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Long agencyId) {
        this.agencyId = agencyId;
    }

    @Column(name = "AGENCY_REF_ID", nullable = false)
    public String getAbbr() {
        return agencyReferenceId;
    }

    public void setAbbr(String agencyRefId) {
        this.agencyReferenceId = agencyRefId;
        this.agencyEnumRefId = AgencyEnum.fromAbbr(agencyRefId);
    }

    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type = "true_false")
    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }


    @Transient
    public AgencyEnum getEnumValue() {
        return agencyEnumRefId;
    }

    @Override
    public String toString() {
        return "AgencyEntity{" +
                "agencyRefId=" + agencyEnumRefId +
                '}';
    }
}
