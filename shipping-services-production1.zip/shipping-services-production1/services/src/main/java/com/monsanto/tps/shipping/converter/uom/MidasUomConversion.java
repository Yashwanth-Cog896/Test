package com.monsanto.tps.shipping.converter.uom;

import com.google.common.base.Function;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.UnitOfMeasure;
import org.springframework.stereotype.Service;

@Service
public class MidasUomConversion {

    private Function<UnitOfMeasureEntity, UnitOfMeasure> toUnitOfMeasure = new Function<UnitOfMeasureEntity, UnitOfMeasure>() {
        @Override
        public UnitOfMeasure apply(UnitOfMeasureEntity entity) {
            if (entity == null) {
                return null;
            }
            return new UnitOfMeasure(entity.getUomRefId().toLowerCase());
        }
    };

    public Function<UnitOfMeasureEntity, UnitOfMeasure> toUnitOfMeasureFromEntity() {
        return toUnitOfMeasure;
    }
}
