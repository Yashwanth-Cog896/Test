package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierEntity;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface CarrierDao {
    CarrierEntity findCarrier(Long carrierEntityId);
    List<CarrierEntity> findAllCarriers();
    List<CarrierEntity> findCarriersByAccountId(Long accountId);
    List<CarrierEntity> findCarriersByIntegration(boolean integrated);
}
