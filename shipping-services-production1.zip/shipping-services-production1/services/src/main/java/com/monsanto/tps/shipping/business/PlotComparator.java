package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.PlotEntity;

import java.util.Collection;
import java.util.List;

public interface PlotComparator {
    public static final String PLOT="plot";
    public static final String REP_RANGE_AND_COLUMN="repRangeAndColumn";
    public static final String ABS_REP_RANGE_AND_COLUMN="absoluteRepRangeAndColumn";
    public static final String ENTRY_NUMBER = "entryNumber";
    public List<PlotEntity> sort(Collection<PlotEntity> plots, String order);
}
