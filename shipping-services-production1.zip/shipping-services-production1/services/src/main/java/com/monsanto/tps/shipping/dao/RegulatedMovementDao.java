package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

import java.util.Collection;

public interface RegulatedMovementDao {
    Collection<RegulatedInventoryMovementEntity> find(Long agencyId, Collection<Long> ids);

    void save(RegulatedInventoryMovementEntity regulatedMovement);

    int deleteRegulatedMovementsForContent(ScannedContainerEntity<?> contentContainerEntity);

    int deleteRegulatedMovementsForPackingList(ShipmentPackingListEntity packingList);

    Collection<RegulatedInventoryMovementEntity> load(Collection<Long> regulatedMovementIds);
}
