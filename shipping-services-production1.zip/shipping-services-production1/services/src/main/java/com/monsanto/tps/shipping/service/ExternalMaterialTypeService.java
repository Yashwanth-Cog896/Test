package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.ExternalMaterialType;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/external-material-type")
public interface ExternalMaterialTypeService {

    @GET
    @Produces(APPLICATION_JSON)
    Collection<ExternalMaterialType> getExternalMaterialTypes();

}
