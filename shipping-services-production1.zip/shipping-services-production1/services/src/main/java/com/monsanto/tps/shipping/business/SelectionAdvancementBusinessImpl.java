package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.dao.SelectionAdvancementDao;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.SelectionAdvancementEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Map;

/**
 * User: DCENGL
 */
@Service
public class SelectionAdvancementBusinessImpl implements SelectionAdvancementBusiness {

    public static final String UNARY_FEMALE_WITH_MALES = "Unary female with males in selection advancement";
    public static final String BINARY_FEMALE_NO_OPERATION = "Binary female without an operation in selection advancement";
    public static final String BINARY_FEMALE_NO_MALES = "Binary female with no males in selection advancement";

    @Autowired
    private SelectionAdvancementDao selectionAdvancementDao;

    /**
     * Finds valid male plots from selection advancements for the provided male plots
     * Removes processed female plots from the input collection so they will not be processed further
     */
    @Trace
    @Override
    public Map<PlotEntity, PlotEntity> getMalePlotsForFemalePlotsWithBinaryOperations(Collection<PlotEntity> femalePlots) {
        Map<PlotEntity, PlotEntity> malePlotByFemalePlots = Maps.newHashMap();

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }
        Collection<SelectionAdvancementEntity> binaryFemaleSelectionAdvancements = selectionAdvancementDao.findBinarySelectionAdvancementForFemalePlots(getPlotIds(femalePlots));
        removeProcessedFemalePlots(femalePlots, binaryFemaleSelectionAdvancements);
        for (SelectionAdvancementEntity binaryFemaleSelectionAdvancement : binaryFemaleSelectionAdvancements) {
            malePlotByFemalePlots.put(binaryFemaleSelectionAdvancement.getFemalePlot(), binaryFemaleSelectionAdvancement.getSelectionAdvancementMalePlot().getMalePlot());
        }

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }
        Collection<SelectionAdvancementEntity> unaryFemaleSelectionAdvancements = selectionAdvancementDao.findUnarySelectionAdvancementsForFemalePlots(getPlotIds(femalePlots));
        removeProcessedFemalePlots(femalePlots, unaryFemaleSelectionAdvancements);

        //Error checking calls
        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<SelectionAdvancementEntity> unaryFemaleSelectionAdvancementsWithMalePlots = selectionAdvancementDao.findUnarySelectionAdvancementsWithMalePlots(getPlotIds(femalePlots));
        processErrors(femalePlots, unaryFemaleSelectionAdvancementsWithMalePlots, UNARY_FEMALE_WITH_MALES);

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<SelectionAdvancementEntity> binaryFemaleSelectionAdvancementsWithoutMalePlots = selectionAdvancementDao.findBinarySelectionAdvancementsWithNoMalePlots(getPlotIds(femalePlots));
        processErrors(femalePlots, binaryFemaleSelectionAdvancementsWithoutMalePlots, BINARY_FEMALE_NO_MALES);

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<SelectionAdvancementEntity> binaryFemaleSelectionAdvancementsWithoutOperation = selectionAdvancementDao.findBinarySelectionAdvancementsWithNoOperation(getPlotIds(femalePlots));
        processErrors(femalePlots, binaryFemaleSelectionAdvancementsWithoutOperation, BINARY_FEMALE_NO_OPERATION);

        return malePlotByFemalePlots;
    }

    private Collection<Long> getPlotIds(Collection<PlotEntity> plots) {
        return Collections2.transform(plots, new Function<PlotEntity, Long>() {
            @Override
            public Long apply(@Nullable PlotEntity plotEntity) {
                return plotEntity.getPlotId();
            }
        });
    }

    private void processErrors(Collection<PlotEntity> femalePlots, Collection<SelectionAdvancementEntity> selectionAdvancementsWithError, final String errorString) {
        if (!CollectionUtils.isEmpty(selectionAdvancementsWithError)) {
            PlotDataErrorsHolder.addError(errorString);
        }

        Collection<PlotEntity> femalePlotsWithError = Collections2.transform(selectionAdvancementsWithError, new Function<SelectionAdvancementEntity, PlotEntity>() {
            @Override
            public PlotEntity apply(@Nullable SelectionAdvancementEntity selectionAdvancementEntity) {
                return selectionAdvancementEntity.getFemalePlot();
            }
        });
        removeProcessedPlots(femalePlots, femalePlotsWithError);
    }

    private void removeProcessedFemalePlots(Collection<PlotEntity> femalePlots, Collection<SelectionAdvancementEntity> processedSelectionAdvancements) {
        removeProcessedPlots(femalePlots, Collections2.transform(processedSelectionAdvancements, new Function<SelectionAdvancementEntity, PlotEntity>() {
            @Override
            public PlotEntity apply(@Nullable SelectionAdvancementEntity selectionAdvancementEntity) {
                return selectionAdvancementEntity.getFemalePlot();
            }
        }));
    }

    private void removeProcessedPlots(Collection<PlotEntity> sourcePlots, Collection<PlotEntity> processedPlots) {
        sourcePlots.removeAll(processedPlots);
    }

}
