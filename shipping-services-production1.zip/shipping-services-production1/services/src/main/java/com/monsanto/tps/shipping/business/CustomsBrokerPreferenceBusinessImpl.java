package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.CustomsBrokerPreferenceDao;
import com.monsanto.tps.shipping.domain.CustomsBrokerPreferenceEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Service
public class CustomsBrokerPreferenceBusinessImpl implements CustomsBrokerPreferenceBusiness {

    @Autowired
    private CustomsBrokerPreferenceDao customsBrokerPreferenceDao;

    @Trace
    @Override
    public Collection<CustomsBrokerPreferenceEntity> loadAll() {
        return customsBrokerPreferenceDao.loadAllActive();
    }

    @Trace
    @Override
    public void save(CustomsBrokerPreferenceEntity customsBrokerPreference) {
        customsBrokerPreferenceDao.save(customsBrokerPreference);
    }
}
