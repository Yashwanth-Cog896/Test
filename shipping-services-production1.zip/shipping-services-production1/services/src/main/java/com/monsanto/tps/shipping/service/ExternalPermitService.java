package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.ExternalPermit;

import javax.ws.rs.*;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/external-permit")
public interface ExternalPermitService {

    @GET
    @Path("/packing-list/{packingListId}")
    @Produces(APPLICATION_JSON)
    Collection<ExternalPermit> getAssociatedExternalPermits(@PathParam("packingListId") Long packingListId);
    
    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    public ExternalPermit save(ExternalPermit externalPermit);

    @PUT
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    public ExternalPermit update(ExternalPermit externalPermit);

    @DELETE
    @Path("/{external-permit-id}")
    public void delete(@PathParam("external-permit-id") Long externalPermitId);
}
