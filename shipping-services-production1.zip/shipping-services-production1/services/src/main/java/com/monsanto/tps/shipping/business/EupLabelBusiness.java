package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.PackingListEupMasterLabels;
import com.monsanto.tps.shipping.util.ShippingWebException;


public interface EupLabelBusiness {
    PackingListEupMasterLabels getEupMasterLabels(Long packingListId) throws ShippingWebException;
}
