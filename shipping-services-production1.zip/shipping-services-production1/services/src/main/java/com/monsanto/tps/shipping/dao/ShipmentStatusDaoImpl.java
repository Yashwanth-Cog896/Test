package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShippingStatus;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

/**
 * User: pgadi
 */
@Repository
public class ShipmentStatusDaoImpl implements ShipmentStatusDao{
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public ShippingStatus getByName(String status) {
       return (ShippingStatus) sessionFactory.getCurrentSession().
               createCriteria(ShippingStatus.class).add(Restrictions.eq("name",status)).
               uniqueResult();
    }
}
