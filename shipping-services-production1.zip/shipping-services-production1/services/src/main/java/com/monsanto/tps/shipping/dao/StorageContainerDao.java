package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.StorageContainerEntity;

/**
 * User: jdvoll
 * Date: 1/6/14
 * Time: 1:49 PM
 */
public interface StorageContainerDao {

    StorageContainerEntity getById(long storageContainerId);
}
