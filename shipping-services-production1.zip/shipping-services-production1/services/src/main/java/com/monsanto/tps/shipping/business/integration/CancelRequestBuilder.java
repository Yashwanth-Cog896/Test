package com.monsanto.tps.shipping.business.integration;

import com.monsanto.shipping.common.request.CancelRequest;
import com.monsanto.tps.shipping.domain.ShipmentEntity;

/**
 * User: DCENGL
 */
public interface CancelRequestBuilder {

    CancelRequest buildCancelRequest(ShipmentEntity shipmentEntity);

}
