package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


/**
 * User: DCENGL
 */
@Repository
public class ShipmentContainerDaoImpl implements ShipmentContainerDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public void delete(ShipmentContainerEntity shipmentContainerEntity) {
        sessionFactory.getCurrentSession().delete(shipmentContainerEntity);
    }

    @Trace
    @Override
    public ShipmentContainerEntity load(long shipmentContainerId) {
        return (ShipmentContainerEntity) sessionFactory.getCurrentSession().load(ShipmentContainerEntity.class, shipmentContainerId);
    }

    @Trace
    @Override
    public void save(ShipmentContainerEntity shipmentContainerEntity) {
        sessionFactory.getCurrentSession().save(shipmentContainerEntity);
    }

    @Trace
    @Override
    public void updateUom(long packingListId, long uomId) {
        sessionFactory.getCurrentSession().createSQLQuery("UPDATE INVENTORY_MGT.SHIPMENT_CONTAINER SET WEIGHT_UOM_ID = :uomId WHERE SHPMT_PKG_LIST_ID = :packingListId")
                .setParameter("uomId", uomId)
                .setParameter("packingListId", packingListId)
                .executeUpdate();
    }

    //TODO this merged in an unusual way.  does it still need to be here?
//    @Trace
//    @Override
//    public Long getContainerIndex(long shipmentContainerId) {
//        return ((BigDecimal) sessionFactory.getCurrentSession().createSQLQuery("select containers.containerIndex\n" +
//                "from (\n" +
//                "select c.barcode, rownum as containerIndex, a.*\n" +
//                "from INVENTORY_MGT.SHIPMENT_CONTAINER a, INVENTORY_MGT.SHPMT_PKG_LIST b, inventory_mgt.storage_container c\n" +
//                "where A.SHPMT_PKG_LIST_ID = B.SHPMT_PKG_LIST_ID\n" +
//                "and A.STORAGE_CONTAINER_ID = C.STORAGE_CONTAINER_ID\n" +
//                "and B.SHPMT_PKG_LIST_ID = (\n" +
//                "select SC.SHPMT_PKG_LIST_ID\n" +
//                "from inventory_mgt.shipment_container sc\n" +
//                "where SC.SHIPMENT_CONTAINER_ID = :SHIPMENT_CONTAINER_ID)\n" +
//                "order by c.barcode) containers\n" +
//                "where containers.shipment_container_id = :SHIPMENT_CONTAINER_ID")
//                .setParameter("SHIPMENT_CONTAINER_ID", shipmentContainerId)
//                .uniqueResult()).longValue();
//    }
}
