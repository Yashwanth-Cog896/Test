
package com.monsanto.tps.shipping.sap.client.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MaterialDetail", propOrder = {
    "itemNumber",
    "sapMaterialNumber",
    "quantityToBePacked",
    "quantityUnit"
})
public class MaterialDetail {

    @XmlElement(name = "item_number", required = true)
    private String itemNumber;
    @XmlElement(name = "sap_material_number", required = true)
    private String sapMaterialNumber;
    @XmlElement(name = "quantity_to_be_packed", required = true)
    private BigDecimal quantityToBePacked;
    @XmlElement(name = "quantity_unit", required = true)
    private String quantityUnit;


    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String value) {
        this.itemNumber = value;
    }

    public String getSapMaterialNumber() {
        return sapMaterialNumber;
    }

    public void setSapMaterialNumber(String value) {
        this.sapMaterialNumber = value;
    }

    public BigDecimal getQuantityToBePacked() {
        return quantityToBePacked;
    }

    public void setQuantityToBePacked(BigDecimal value) {
        this.quantityToBePacked = value;
    }

    public String getQuantityUnit() {
        return quantityUnit;
    }

    public void setQuantityUnit(String value) {
        this.quantityUnit = value;
    }

}
