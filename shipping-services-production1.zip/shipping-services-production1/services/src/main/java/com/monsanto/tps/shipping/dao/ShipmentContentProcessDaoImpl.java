package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentContentProcessedStateEntity;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;


/**
 * User: PGADI
 */
@Repository
public class ShipmentContentProcessDaoImpl implements ShipmentContentProcessDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public Long getShipmentContentProcessId(String processingStatusCode) {

        return (Long) sessionFactory.getCurrentSession().
                createCriteria(ShipmentContentProcessedStateEntity.class).
                setProjection(Projections.property("shipmentContentProcessedStatusId")).
                add(Restrictions.eq("processingStatusCode", processingStatusCode)).
                uniqueResult();
    }
}
