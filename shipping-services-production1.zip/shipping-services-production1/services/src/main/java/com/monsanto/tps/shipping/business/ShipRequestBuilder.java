package com.monsanto.tps.shipping.business;

import com.monsanto.shipping.common.request.ShipRequest;
import com.monsanto.tps.shipping.domain.ShipmentEntity;

/**
 * User: SDCHIL
 */
public interface ShipRequestBuilder {

    ShipRequest buildShipRequest(ShipmentEntity shipmentEntity);
}
