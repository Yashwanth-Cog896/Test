package com.monsanto.tps.shipping.domain;


/**
 * User: sdchil
 * Date: 9/17/13
 */
public interface ContentEntity {

    Long getContentId();

    String getBarcode();

    GeneticMaterialEntity getGeneticMaterial();

    InventoryEntity getInventory();

    ContentType getContentType();

}
