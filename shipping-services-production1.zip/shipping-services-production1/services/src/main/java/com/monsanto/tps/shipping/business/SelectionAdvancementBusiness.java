package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.PlotEntity;

import java.util.Collection;
import java.util.Map;

/**
 * User: DCENGL
 */
public interface SelectionAdvancementBusiness {

    Map<PlotEntity, PlotEntity> getMalePlotsForFemalePlotsWithBinaryOperations(Collection<PlotEntity> femalePlots);
}
