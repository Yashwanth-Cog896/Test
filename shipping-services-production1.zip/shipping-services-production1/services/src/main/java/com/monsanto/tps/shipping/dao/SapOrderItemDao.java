package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;

import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
public interface SapOrderItemDao {

    void save(SapOrderItemEntity sapOrderItemEntity);

    SapOrderItemEntity load(Long sapOrderItemId);

    void delete(SapOrderItemEntity sapOrderItemEntity);

    List<SapOrderItemEntity> findBySapOrderShipmentAndItemNumber(SapOrderShipmentEntity sapOrderShipment,
                                                                 Collection<String> itemNumbers);

}
