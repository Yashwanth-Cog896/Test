package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.SortedSet;

@Service
public class HarvestedPlotMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        decimalFormat.setRoundingMode(RoundingMode.UP);

        addSelectedPermitsToTable(permitsTable, events, true, font);

        for (ScannedContainerEntity contentContainer : contentContainerEntities) {
            PlotEntity plot = (PlotEntity) contentContainer.getContent();
            String eventString = getEventStringforHVPlots(plot);

            RepEntity rep = plot == null ? null : plot.getRep();

            appendCellToTable(contentContainer.getScanOrder(), contentsTable, font);
            appendCellToTable(getBarcode(plot), contentsTable, font);
            appendCellToTable(eventString, contentsTable, font);
            appendCellToTable(getFieldName(plot), contentsTable, font);
            appendCellToTable(getSet(rep), contentsTable, font);
            appendCellToTable(getTrackId(rep), contentsTable, font);
            appendCellToTable(getPlotNum(plot), contentsTable, font);
            appendCellToTable(getEntryNum(plot), contentsTable, font);
            appendCellToTable(getWeight(decimalFormat, contentContainer), contentsTable, font);
            appendCellToTable(getUOM(contentContainer), contentsTable, font);
            appendCellToTable(getQty(contentContainer), contentsTable, font);
            appendCellToTable(contentContainer.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    private String getQty(ScannedContainerEntity contentContainer) {
        return contentContainer.getQuantity() != null ? contentContainer.getQuantity().toString() : "";
    }

    private String getUOM(ScannedContainerEntity contentContainer) {
        return contentContainer.getWeightUOM() != null ? contentContainer.getWeightUOM().getUomRefId() : "";
    }

    private String getWeight(DecimalFormat decimalFormat, ScannedContainerEntity contentContainer) {
        return contentContainer.getWeight() != null ? decimalFormat.format(contentContainer.getWeight()) : "";
    }

    private String getEntryNum(PlotEntity plot) {
        TestSetEntryEntity entry = plot == null ? null : plot.getTestSetEntry();
        return entry != null && entry.getEntryNumber() != null ?  String.valueOf(entry.getEntryNumber().intValue()) : "";
    }

    private String getPlotNum(PlotEntity plot) {
        return plot != null && plot.getPlotNumber() != null ? plot.getPlotNumber().toString() : "";
    }

    private String getTrackId(RepEntity rep) {
        return rep != null && rep.getField() != null ? rep.getField().getFieldName() : "";
    }

    private String getSet(RepEntity rep) {
        return rep != null && rep.getTestSet() != null ? rep.getTestSet().getTestSetName() : "";
    }

    private String getFieldName(PlotEntity plot) {
        return plot != null && plot.getField() != null ? plot.getField().getFieldName() : "";
    }

    private String getBarcode(PlotEntity plot) {
        return plot != null ? plot.getBarcode() : "";
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Item BID", "Event", "Field Name (Plot)", "Set", "Track ID", "Plot #", "Entry #", "Weight", "UOM", "Count", "Box Barcode", "Received"},
                new float[] {15, 60, 55, 20, 25, 20, 15, 15, 15, 15, 15, 25, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Female Event", "Male Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[] {100, 100, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.HARVESTED_PLOT;
    }
}
