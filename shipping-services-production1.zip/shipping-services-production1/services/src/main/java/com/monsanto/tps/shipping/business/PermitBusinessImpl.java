package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.business.compliance.RegulatedMovementBusiness;
import com.monsanto.tps.shipping.dao.ShipmentPackingListDao;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.AgencyRequestEntity;
import com.monsanto.tps.shipping.domain.AgencyRequestLocation;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.service.model.PermitAssociationDetails;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.AgencyRequestStatusCodeEnum;
import com.monsanto.tps.shipping.util.EventErrorConstants;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * User: DCENGL
 */
@Service
public class PermitBusinessImpl implements PermitBusiness {
    private static final Log LOG = LogFactory.getLog(PermitBusinessImpl.class);

    @Autowired
    private RegulatedEventBusiness regulatedEventBusiness;
    @Autowired
    private ContactBusiness contactBusiness;
    @Autowired
    private UsdaBusiness usdaBusiness;
    @Autowired
    private EpaBusiness epaBusiness;
    @Autowired
    private CropBusiness cropBusiness;
    @Autowired
    private PackingListContentBusiness contentBusiness;
    @Autowired
    private EventErrorBusiness eventErrorBusiness;
    @Autowired
    private ShipmentPackingListDao shipmentPackingListDao;
    @Autowired
    private RegulatedMovementBusiness regulatedMovementBusiness;
    @Autowired
    private AgencyRequestBusiness agencyRequestBusiness;

    private static final Predicate<Permit> USDA_PERMITS = new Predicate<Permit>() {
        @Override
        public boolean apply(@Nullable Permit permit) {
            return permit.getAgency().equals(AgencyEnum.USDA);
        }
    };

    private static final Predicate<Permit> EPA_PERMITS = new Predicate<Permit>() {
        @Override
        public boolean apply(@Nullable Permit permit) {
            return permit.getAgency().equals(AgencyEnum.EPA);
        }
    };

    private static final Function<Permit, String> APPROVAL_NUMBER_FUNCTION = new Function<Permit, String>() {
        @Override
        public String apply(@Nullable Permit input) {
            return input.getApprovalNumber();
        }
    };

    public static final String NON_COMPLIANT = "NON_COMPLIANT";

    @Trace
    @Override
    public Collection<Permit> getPermitsByPackingList(ShipmentPackingListEntity packingList, Map<AgencyEnum, Collection<Event>> regulatedEventsByAgency) {
        Collection<Permit> permits = Lists.newArrayList();

        if (packingList.getToContactId() == null) {
            LOG.warn("Packing list does not have a to contact id: " + packingList);
            return permits;
        }

        if (!regulatedEventsByAgency.isEmpty()) {
            Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());
            Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
            Long cropId = cropBusiness.getCropEntityByPackingListWithContainers(packingList).getCropId();
            permits.addAll(usdaBusiness.getPermits(toContact.getCountry(), fromContact.getContactId(), toContact.getContactId(), regulatedEventsByAgency.get(AgencyEnum.USDA), cropId));
            permits.addAll(epaBusiness.getPermits(regulatedEventsByAgency.get(AgencyEnum.EPA), cropId, toContact.getState()));
        }

        return permits;
    }

    public Collection<Permit> getPermitsByPackingList(ShipmentPackingListEntity packingList, Collection<Event> regulatedEvents) {
        Collection<Permit> permits = Lists.newArrayList();

        if (packingList.getToContactId() == null) {
            LOG.warn("Packing list does not have a to contact id: " + packingList);
            return permits;
        }

        if (!CollectionUtils.isEmpty(regulatedEvents)) {
            Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());
            Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
            Long cropId = cropBusiness.getCropEntityByPackingListWithContainers(packingList).getCropId();

            Collection<Event> usdaOnlyEvents = filterByAgency(regulatedEvents, Sets.newHashSet(AgencyEnum.USDA, AgencyEnum.USDA_EPA));
            Collection<Event> epaOnlyEvents = filterByAgency(regulatedEvents, Sets.newHashSet(AgencyEnum.EPA, AgencyEnum.USDA_EPA));

            permits.addAll(usdaBusiness.getPermits(toContact.getCountry(), fromContact.getContactId(), toContact.getContactId(), usdaOnlyEvents, cropId));
            permits.addAll(epaBusiness.getPermits(epaOnlyEvents, cropId, toContact.getState()));
        }

        return permits;
    }

    private Collection<Event> filterByAgency(Collection<Event> regulatedEvents, final Collection<AgencyEnum> agencies) {
        return Collections2.filter(regulatedEvents, new Predicate<Event>() {
            @Override
            public boolean apply(@Nullable Event input) {
                return CollectionUtils.containsAny(input.getRegulatingAgencies(), agencies);
            }
        });
    }


    @Trace
    @Override
    public Collection<Event> getRegulatedEvents(ShipmentPackingListEntity packingList) {
        Collection<Event> events = Sets.newHashSet();
        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingList);
        loadPermits(packingList, regulatedEvents);
        //TODO Client should be changed to load assigned permits separately
        loadAssociatedPermitsForEvents(packingList, regulatedEvents);

        for (Map.Entry<AgencyEnum, Collection<Event>> entry : regulatedEvents.entrySet()) {
            events.addAll(entry.getValue());
        }

        boolean errorFlag = eventErrorBusiness.rollupPermitErrors(events);

        if (errorFlag) {
            packingList.setMaterialStatusText(NON_COMPLIANT);
        } else {
            packingList.setMaterialStatusText(null);
        }
        shipmentPackingListDao.updatePackingList(packingList);

        for (Event event : events) {
            if (CollectionUtils.isEmpty(event.getSelectedPermits())) {
                event.setSelectedPermits(new ArrayList<Permit>());
                for (AgencyEnum agencyEnum : event.getRegulatingAgencies()) {
                    Permit permit = Permit.findFirst(event.getPermits(), agencyEnum);
                    if (permit != null) {
                        permit.setEvent(event.getEventString());
                        event.getSelectedPermits().add(permit);
                    }
                }
            } else {
                Collection<String> monsantoIds = Collections2.transform(event.getPermits(), new Function<Permit, String>() {
                    @Override
                    public String apply(@Nullable Permit permit) {
                        return permit.getMonsantoId();
                    }
                });

                //Add selected permit to the permits collection if it is not present (i.e. filtered out due to pipeline function)
                for (Permit selectedPermit : event.getSelectedPermits()) {
                    if (!monsantoIds.contains(selectedPermit.getMonsantoId()) && (CollectionUtils.isEmpty(selectedPermit.getErrors())  || isPipelineFunctionError(selectedPermit))) {
                        event.addPermit(selectedPermit);
                    }
                }
            }
        }

        return events;
    }

    @Trace
    @Override
    public void setPermitsOnEvents(ShipmentPackingListEntity packingList, Collection<Event> events) {
        loadPermits(packingList, events);

        // Errors are flagged when loading permits
        boolean errorFlag = eventErrorBusiness.rollupPermitErrors(events);

        if (errorFlag) {
            packingList.setMaterialStatusText(NON_COMPLIANT);
        } else {
            packingList.setMaterialStatusText(null);
        }
        shipmentPackingListDao.updatePackingList(packingList);

        for (Event event : events) {
            if (CollectionUtils.isEmpty(event.getSelectedPermits())) {
                event.setSelectedPermits(new ArrayList<Permit>());
                for (AgencyEnum agencyEnum : event.getRegulatingAgencies()) {
                    Permit permit = Permit.findFirst(event.getPermits(), agencyEnum);
                    if (permit != null) {
                        permit.setEvent(event.getEventString());
                        event.getSelectedPermits().add(permit);
                    }
                }
            } else {
                Collection<String> monsantoIds = Collections2.transform(event.getPermits(), new Function<Permit, String>() {
                    @Override
                    public String apply(@Nullable Permit permit) {
                        return permit.getMonsantoId();
                    }
                });

                //Add selected permit to the permits collection if it is not present (i.e. filtered out due to pipeline function)
                for (Permit selectedPermit : event.getSelectedPermits()) {
                    if (!monsantoIds.contains(selectedPermit.getMonsantoId()) && (CollectionUtils.isEmpty(selectedPermit.getErrors())  || isPipelineFunctionError(selectedPermit))) {
                        event.addPermit(selectedPermit);
                    }
                }
            }
        }
    }

    @Trace
    @Override
    public void associatePermits(ShipmentPackingListEntity packingList, Collection<Event> events) {
        if (!hasContent(packingList)) {
            throw new ShippingWebException("Packing List is empty, could not associate permits");
        }

        for (Event event : events) {
            regulatedMovementBusiness.assignPermitsToRegulatedMovements(event);
        }
    }

    @Trace
    @Override
    public Collection<Event> loadAssociatedPermits(ShipmentPackingListEntity packingList) {
        Collection<Event> events = Sets.newHashSet();

        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingList);

        loadAssociatedPermitsForEvents(packingList, regulatedEvents);

        for (Map.Entry<AgencyEnum, Collection<Event>> entry : regulatedEvents.entrySet()) {
            events.addAll(entry.getValue());
        }

        return events;
    }

    private void loadAssociatedPermitsForEvents(ShipmentPackingListEntity packingList, Map<AgencyEnum, Collection<Event>> regulatedEvents) {
        usdaBusiness.loadAssociatedPermits(packingList, regulatedEvents.get(AgencyEnum.USDA));

        Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
        Long cropId = cropBusiness.getCropEntityByPackingListWithContainers(packingList).getCropId();

        Collection<Permit> permits = Lists.newArrayList();
        if(!CollectionUtils.isEmpty(regulatedEvents.get(AgencyEnum.USDA))){
            for(Event event : regulatedEvents.get(AgencyEnum.USDA)){
                if(event.getSelectedPermits()!=null){
                    permits.addAll(event.getSelectedPermits());
                }
            }
            eventErrorBusiness.addUsdaPermitErrors(permits,cropId,fromContact.getContactId(),packingList.getToContactId());
            eventErrorBusiness.rollupPermitErrors(regulatedEvents.get(AgencyEnum.USDA));
        }
        epaBusiness.loadAssociatedPermits(packingList, regulatedEvents.get(AgencyEnum.EPA));
    }

    @Override
    public ContainerAgencyPermits loadAssociatedPermits(ShipmentPackingListEntity packingList, ShipmentContainerEntity container) {
        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingList, container.getStorageContainer().getContainers());
        Map<String, Permit> permitsByMonsantoId = mapPermits(loadPermits(packingList, regulatedEvents));
        Collection<Long> eventContents = getContainerIds(container.getStorageContainer().getContainers());
        return new ContainerAgencyPermits(loadAssociatedPermits(packingList.getShipmentType().getContentType(), eventContents, permitsByMonsantoId).values()
                , regulatedEvents.containsKey(AgencyEnum.STEWARDSHIP), regulatedEvents.containsKey(AgencyEnum.PRE_EUP));
    }

    @Override
    public ContainerAgencyPermits loadAssociatedPermitsForPackingListLabel(ShipmentPackingListEntity packingList) {
        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingList);
        Map<String, Permit> permitsByMonsantoId = mapPermits(loadPermits(packingList, regulatedEvents));

        Collection<ScannedContainerEntity> contents = getContentContainersForPackingList(packingList);

        return new ContainerAgencyPermits(getAssociatedPermits(contents, permitsByMonsantoId).values(), regulatedEvents.containsKey(AgencyEnum.STEWARDSHIP), regulatedEvents.containsKey(AgencyEnum.PRE_EUP));
    }

    private Map<String, Permit> getAssociatedPermits(Collection<ScannedContainerEntity> contents, Map<String, Permit> permitsByMonsantoId) {
        Map<String, Permit> selectedPermits = Maps.newHashMap();

        if (!CollectionUtils.isEmpty(contents)) {
            for (ScannedContainerEntity item : contents) {
                addSelectedPermitOfContentToList(permitsByMonsantoId, selectedPermits, item);
            }
        }

        return selectedPermits;
    }

    private void addSelectedPermitOfContentToList(Map<String, Permit> permitsByMonsantoId, Map<String, Permit> selectedPermits, ScannedContainerEntity<?> item) {
        for (RegulatedInventoryMovementEntity movement : item.getRegulatedMovements()) {
            Permit permit = permitsByMonsantoId.get(movement.getMonsantoId());

            if (permit != null) {
                selectedPermits.put(permit.getMonsantoId(), permit);
            } else {
                throw new ShippingWebException("Could not find valid permit with monsantoId: " + movement.getMonsantoId() + " for: " + item.getContent().getBarcode());
            }
        }
    }

    private Collection<ScannedContainerEntity> getContentContainersForPackingList(ShipmentPackingListEntity shipmentPackingList) {
        Collection<ScannedContainerEntity> scannedContainers = Lists.newArrayList();
        for (ShipmentContainerEntity shipmentContainer : shipmentPackingList.getShipmentContainers()) {
            scannedContainers.addAll(shipmentContainer.getStorageContainer().getContainers());
        }

        return scannedContainers;
    }

    private Collection<Long> getContainerIds(Collection<? extends ScannedContainerEntity> items) {
        Collection<Long> list = Sets.newHashSet();
        for (ScannedContainerEntity contentContainerEntity : items) {
            list.add(contentContainerEntity.getContainerId());
        }
        return list;
    }

    private Map<String, Permit> mapPermits(Collection<Permit> allPermits) {
        Map<String, Permit> permitsByMonsantoId = new HashMap<String, Permit>();
        for (Permit permit : allPermits) {
            permitsByMonsantoId.put(permit.getMonsantoId(), permit);
        }
        return permitsByMonsantoId;
    }

    private Map<String, Permit> loadAssociatedPermits(ContentType type, Collection<Long> eventContents, Map<String, Permit> permitsByMonsantoId) {
        Map<String, Permit> selectedPermits = Maps.newHashMap();
        if (eventContents != null) {
            for (Long id : eventContents) {
                ScannedContainerEntity item = contentBusiness.getContentContainer(id, type);
                addSelectedPermitOfContentToList(permitsByMonsantoId, selectedPermits, item);
            }
        }
        return selectedPermits;
    }

    private Collection<Permit> loadPermits(ShipmentPackingListEntity packingList, Map<AgencyEnum, Collection<Event>> regulatedEvents) {
        if (!hasContent(packingList)) {
            return Collections.emptyList();
        }

        Collection<Permit> permits = getPermitsByPackingList(packingList, regulatedEvents);
        if (CollectionUtils.isEmpty(permits)) {
            return permits;
        }

        associatePermitsToEvents(regulatedEvents, permits);

        return permits;
    }

    private Collection<Permit> loadPermits(ShipmentPackingListEntity packingList, Collection<Event> regulatedEvents) {

        if (!hasContent(packingList)) {
            return Collections.emptyList();
        }

        Collection<Permit> permits = getPermitsByPackingList(packingList, regulatedEvents);
        if (CollectionUtils.isEmpty(permits)) {
            return permits;
        }

        associatePermitsToEvents(regulatedEvents, permits);

        return permits;
    }


    private void associatePermitsToEvents(Map<AgencyEnum, Collection<Event>> regulatedEvents, Collection<Permit> permits) {
        for (Permit permit : permits) {
            Collection<Event> eventWithEventStrings = getEventsByEventString(permit, regulatedEvents);

            for (Event event : eventWithEventStrings) {
                if (!hasPermitWithMonsantoId(event.getPermits(), permit.getMonsantoId())) {
                    event.addPermit(permit);
                }
            }
        }
    }

    private void associatePermitsToEvents(Collection<Event> regulatedEvents, Collection<Permit> permits) {
        for (Permit permit : permits) {
            Collection<Event> eventWithEventStrings = getEventsByEventString(permit, regulatedEvents);

            for (Event event : eventWithEventStrings) {
                if (!hasPermitWithMonsantoId(event.getPermits(), permit.getMonsantoId())) {
                    event.addPermit(permit);
                }
            }
        }
    }

    private boolean hasPermitWithMonsantoId(Collection<Permit> permits, String monsantoId) {
        if (CollectionUtils.isEmpty(permits)) {
            return false;
        }

        for (Permit permit : permits) {
            if (monsantoId.equals(permit.getMonsantoId())) {
                return true;
            }
        }

        return false;
    }

    private Collection<Event> getEventsByEventString(Permit permit, Collection<Event> regulatedEvents) {
        Collection<Event> eventsWithEventString = Sets.newHashSetWithExpectedSize(2);

        for (Event event : regulatedEvents) {
            if(permitHasEvent(permit, event)) {
                eventsWithEventString.add(event);
            }
        }

        return eventsWithEventString;
    }


    private Collection<Event> getEventsByEventString(Permit permit, Map<AgencyEnum, Collection<Event>> regulatedEvents) {
        Collection<Event> eventsWithEventString = Sets.newHashSetWithExpectedSize(2);

        for (Collection<Event> eventSet : regulatedEvents.values()) {
            for (Event event : eventSet) {
                if(permitHasEvent(permit, event)) {
                    eventsWithEventString.add(event);
                }

            }
        }

        return eventsWithEventString;
    }

    private boolean permitHasEvent(Permit permit, Event event) {
        if (AgencyEnum.EPA.equals(permit.getAgency())) {
            if (new Event(permit.getEvent(), permit.getMaleEvent()).equals(event)) {
                return true;
            }
        } else if (permit.getEvent().equals(event.getEventString()) || permit.getEvent().equals(event.getMaleEventString())) {
            return true;
        }

        return false;
    }

    private boolean hasContent(ShipmentPackingListEntity packingList) {
        if (CollectionUtils.isEmpty(packingList.getShipmentContainers())) {
            return false;
        }
        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            StorageContainerEntity storageContainer = shipmentContainerEntity.getStorageContainer();
            if (!CollectionUtils.isEmpty(storageContainer.getContainers())) {
                return true;
            }
        }
        return false;
    }

    @Trace
    @Override
    public Collection<Permit> validatePermitForEvent(ShipmentPackingListEntity packingList, Event regulatedEvent) {
        Collection<Permit> permits = Lists.newArrayList();

        if (packingList.getToContactId() == null) {
            LOG.warn("Packing list does not have a to contact id: " + packingList);
            return permits;
        }

        Contact toContact = contactBusiness.getPartyContact(packingList.getToContactId());
        Contact fromContact = contactBusiness.getPartyContact(packingList.getFromContactId());
        Long cropId = cropBusiness.getCropEntityByPackingListWithContainers(packingList).getCropId();
        Collection<Event> events = Lists.newArrayList(regulatedEvent);
        permits.addAll(usdaBusiness.getPermits(toContact.getCountry(), fromContact.getContactId(), toContact.getContactId(), events, cropId));

        Collection<Permit> validPermits = Lists.newArrayList();
        for (Permit permit : permits) {
            if (CollectionUtils.isEmpty(permit.getErrors()) || isPipelineFunctionError(permit)) {
                validPermits.add(permit);
            }
        }
        return validPermits;
    }

    private boolean isPipelineFunctionError(Permit permit) {
        if (permit.getErrors() != null && permit.getErrors().size() == 1) {
            if ((permit.getErrors().iterator().next()).getError().equals(EventErrorConstants.USDA_OUTSIDE_PIPELINE_FUNCTION.getError())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isComplianceValid(Collection<Event> validEvents) {

        for (Event validEvent : validEvents) {
            Collection<AgencyEnum> agencies = validEvent.getRegulatingAgencies();
            Collection<Permit> permits = validEvent.getPermits();

            if (agencies.isEmpty()) {
                return true;
            }

            AgencyEnum regulatedAgencyEnum = getRegulatedAgenciesForEvent(agencies);
            if (regulatedAgencyEnum == null) {
                return true;
            }

            Collection<Permit> epaPermits = Lists.newArrayList();
            Collection<Permit> usdaPermits = Lists.newArrayList();

            if (regulatedAgencyEnum.equals(AgencyEnum.USDA_EPA)) {
                epaPermits = Collections2.filter(permits, EPA_PERMITS);
                usdaPermits = Collections2.filter(permits, USDA_PERMITS);
            } else if (regulatedAgencyEnum.equals(AgencyEnum.EPA)) {
                epaPermits = Collections2.filter(permits, EPA_PERMITS);
            } else if (regulatedAgencyEnum.equals(AgencyEnum.USDA)) {
                usdaPermits = Collections2.filter(permits, USDA_PERMITS);
            }
            if (isEmptyPermits(regulatedAgencyEnum, epaPermits, usdaPermits)) {
                return false;
            } else {
                for (Permit permit : validEvent.getSelectedPermits()) {
                    if (checkSelectedPermit(validEvent, permit)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    @Override
    public Collection<Permit> findPermitsForEvent(String eventStack) {
        return null;
    }

    @Trace
    @Override
    public PermitAssociationDetails findPermitAssociations(AgencyRequestEntity agencyRequestEntity) {
        PermitAssociationDetails permitAssociationDetails = new PermitAssociationDetails();

        Permit permit = new Permit();
        permit.setAgency(AgencyEnum.fromAbbr(agencyRequestEntity.getAgencyAcronym()));
        permit.setApprovalNumber(agencyRequestEntity.getAgencyApprovalNumber());
        permit.setEffectiveDate(agencyRequestEntity.getEffectiveDate());
        permit.setExpirationDate(agencyRequestEntity.getExpirationDate());
        permit.setMonsantoId(agencyRequestEntity.getMonsantoId());
        permit.setPipelineFunction(agencyRequestEntity.getPipelineFunction());
        permit.setStatus(AgencyRequestStatusCodeEnum.getByCode(agencyRequestEntity.getStatusCode()));

        permitAssociationDetails.setPermit(permit);

        if (AgencyEnum.EPA == permit.getAgency()) {
            permitAssociationDetails.setEpaStateAssociations(agencyRequestBusiness.findStatesCoveredByEUP(agencyRequestEntity.getAgencyApprovalNumber()));
        }

        if (AgencyEnum.USDA == permit.getAgency()) {
            Collection<AgencyRequestLocation> agencyRequestLocations = agencyRequestEntity.getLocations();

            Collection<Long> toIrdContacts = agencyRequestBusiness.getIrdContactIds(Collections2.filter(agencyRequestLocations, AgencyRequestBusinessImpl.DESTINATION_FILTER));
            Collection<Long> fromIrdContacts = agencyRequestBusiness.getIrdContactIds(Collections2.filter(agencyRequestLocations, AgencyRequestBusinessImpl.ORIGIN_FILTER));

            Collection<Long> allContactIds = Sets.newHashSet(toIrdContacts);
            allContactIds.addAll(fromIrdContacts);

            Collection<ShipmentContact> allContacts = contactBusiness.getContacts(allContactIds);

            Collection<ShipmentContact> toContacts = Lists.newArrayList();
            Collection<ShipmentContact> fromContacts = Lists.newArrayList();
            for (ShipmentContact irdContact : allContacts) {
                if (toIrdContacts.contains(irdContact.getId())) {
                    toContacts.add(irdContact);
                }
                if (fromIrdContacts.contains(irdContact.getId())) {
                    fromContacts.add(irdContact);
                }
            }

            permitAssociationDetails.setToUsdaContacts(toContacts);
            permitAssociationDetails.setFromUsdaContacts(fromContacts);
        }

        return permitAssociationDetails;
    }

    private boolean checkSelectedPermit(Event validEvent, Permit permit) {
            Collection<String> approvalNumbers = Collections2.transform(validEvent.getPermits(), APPROVAL_NUMBER_FUNCTION);
            if (!approvalNumbers.contains(permit.getApprovalNumber())) {
                return true;
            }
        return false;
    }

    private boolean isEmptyPermits(AgencyEnum regulatedAgencyEnum, Collection<Permit> epaPermits, Collection<Permit> usdaPermits) {
        if (regulatedAgencyEnum.equals(AgencyEnum.USDA_EPA)) {
            return epaPermits.isEmpty() || usdaPermits.isEmpty();
        } else if (regulatedAgencyEnum.equals(AgencyEnum.EPA)) {
            return epaPermits.isEmpty();
        } else {
            return usdaPermits.isEmpty();
        }
    }

    private AgencyEnum getRegulatedAgenciesForEvent(Collection<AgencyEnum> agencies) {
        if (agencies.contains(AgencyEnum.USDA) && agencies.contains(AgencyEnum.EPA)) {
            return AgencyEnum.USDA_EPA;
        } else if (agencies.contains(AgencyEnum.EPA)) {
            return AgencyEnum.EPA;
        } else if (agencies.contains(AgencyEnum.USDA)) {
            return AgencyEnum.USDA;
        }
        return null;
    }

}
