package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.StorageContainerTypeEntity;

/**
 * Created with IntelliJ IDEA.
 * User: TBMCKAY
 * Date: 1/28/13
 * Time: 3:12 PM
 */
public interface StorageContainerTypeDao {

    public StorageContainerTypeEntity getByName(String name);
}
