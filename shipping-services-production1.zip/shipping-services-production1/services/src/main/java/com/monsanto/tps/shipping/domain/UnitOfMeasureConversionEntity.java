/*
 Copyright:  Copyright © 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="UOM_CONVERSION", schema="MIDAS")
public class UnitOfMeasureConversionEntity {
    @Id
    @Column(name="UOM_CONVERSION_ID")
    private Long uomConversionId;

    @ManyToOne
    @JoinColumn(name="FROM_UOM_ID")
    private UnitOfMeasureEntity fromUom;

    @ManyToOne
    @JoinColumn(name="TO_UOM_ID")
    private UnitOfMeasureEntity toUom;

    @Type(type="true_false")
    @Column(name="REF_ACTIVE")
    private boolean refActive;

    @Column(name="CONVERSION_FACTOR")
    private Double conversionFactor;

    public Long getUomConversionId() {
        return uomConversionId;
    }

    public void setUomConversionId(Long uomConversionId) {
        this.uomConversionId = uomConversionId;
    }

    public UnitOfMeasureEntity getFromUom() {
        return fromUom;
    }

    public void setFromUom(UnitOfMeasureEntity fromUom) {
        this.fromUom = fromUom;
    }

    public UnitOfMeasureEntity getToUom() {
        return toUom;
    }

    public void setToUom(UnitOfMeasureEntity toUom) {
        this.toUom = toUom;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public Double getConversionFactor() {
        return conversionFactor;
    }

    public void setConversionFactor(Double conversionFactor) {
        this.conversionFactor = conversionFactor;
    }
}