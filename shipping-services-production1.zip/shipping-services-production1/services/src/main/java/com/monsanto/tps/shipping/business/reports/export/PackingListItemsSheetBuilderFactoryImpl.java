package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Service
public class PackingListItemsSheetBuilderFactoryImpl implements PackingListItemsSheetBuilderFactory {

    @Autowired
    private Collection<PackingListItemsSheetBuilder> sheetBuilders;

    @Override
    public PackingListItemsSheetBuilder getSheetBuilder(ShipmentPackingListEntity shipmentPackingListEntity) {

        ShipmentTypeEntity shipmentType = shipmentPackingListEntity.getShipmentType();

        for (PackingListItemsSheetBuilder sheetBuilder : sheetBuilders) {
            if (sheetBuilder.canBuild(shipmentType)) {
                return sheetBuilder;
            }
        }

        throw new IllegalArgumentException("Cannot build spreadsheet for: " + shipmentType.getName());
    }
}
