package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.monsanto.tps.shipping.business.ProgramBusiness;
import com.monsanto.tps.shipping.business.ShipmentBusiness;
import com.monsanto.tps.shipping.business.UnitOfMeasureBusiness;
import com.monsanto.tps.shipping.business.reports.ITextDocumentBuilder;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 * Created by DCENGL
 */
public abstract class AbstractMTFDetailsDocumentBuilder extends ITextDocumentBuilder implements MTFDetailsDocumentBuilder {

    @Autowired
    private ProgramBusiness programBusiness;

    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;

    @Autowired
    private ShipmentBusiness shipmentBusiness;

    protected void appendContact(AbstractContact contact, StringBuilder contactStringBuilder) {

        if (contact == null) {
            return;
        }


        if (contact.getName() != null) {
            contactStringBuilder.append(contact.getName()).append("\n");
        }

        String addressLine1 = contact.getAddressLine1();
        if (!StringUtils.isEmpty(addressLine1)) {
            contactStringBuilder.append(addressLine1).append("\n");
        }
        String addressLine2 = contact.getAddressLine2();
        if (!StringUtils.isEmpty(addressLine2)) {
            contactStringBuilder.append(addressLine2).append("\n");
        }
        String addressLine3 = contact.getAddressLine3();
        if (!StringUtils.isEmpty(addressLine3)) {
            contactStringBuilder.append(addressLine3).append("\n");
        }

        String zipFour = contact.getZipFour();
        contactStringBuilder.append(contact.getCity()).append(", ").append(contact.getState()).append(" ").append(contact.getZip()).append(zipFour != null ? "-" + zipFour : "").append("\n");
        contactStringBuilder.append(contact.getPhoneNumber() == null || contact.getPhoneNumber().equals("0") ? "-Phone Number Unavailable-\n" : contact.getPhoneNumber() + "\n");

        if (contact.getAccountId() != null) {
            ProgramEntity fromProgram = programBusiness.getProgramByAccount(contact.getAccountId());
            // Uncomment this temporarily if MTF form needs to be generated without the program name.
            if (fromProgram != null && fromProgram.getRefId() != null) {
                contactStringBuilder.append("Program: ").append(fromProgram.getRefId());
            } 
        }
    }

    protected String getCarrierAndTrackingIdString(ShipmentPackingListEntity packingList) {
        ShipmentEntity shipment = shipmentBusiness.getShipment(packingList.getBarcode());
        String carrierName = "";
        String trackingNumber = "";
        if (shipment != null) {
            CarrierEntity carrier = shipment.getCarrier();
            if (carrier != null) {
                carrierName = carrier.getName() != null ? carrier.getName() : "";
            }
            trackingNumber = shipment.getTrackingNumber();
            trackingNumber = trackingNumber != null ? trackingNumber : "";
        }

        return "Carrier:  " + carrierName + "\n" + "Tracking ID:  " + trackingNumber;
    }

    protected String getBoxSummaryString(ShipmentPackingListEntity packingList) {
        int numBoxes = 0;
        double netWeight = 0;
        double grossWeight = 0;
        for (ShipmentContainerEntity shipmentContainerEntity : packingList.getShipmentContainers()) {
            numBoxes++;
            Double netWeightDouble = shipmentContainerEntity.getNetWeight();
            netWeight += netWeightDouble != null ? netWeightDouble : 0;
            Double grossWeightDouble = shipmentContainerEntity.getGrossWeight();
            grossWeight += grossWeightDouble != null ? grossWeightDouble : 0;
        }
        String uomString = "";
        Long uomId = unitOfMeasureBusiness.getPackingListUomId(packingList);
        if (uomId != null) {
            UnitOfMeasureEntity uom = unitOfMeasureBusiness.getUnitOfMeasure(uomId);
            if (uom != null) {
                uomString = uom.getUomRefId();
            }
        }

        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        decimalFormat.setRoundingMode(RoundingMode.UP);
        return ("Number of Boxes:  " + numBoxes + "\n" +
                "Net Weight of Shipment:  " + decimalFormat.format(netWeight) + " " + uomString + "\n" +
                "Gross Weight of Shipment:  " + decimalFormat.format(grossWeight) + " " + uomString);
    }

    protected String getShipperInformationString() {
        return ("\n\n\nPrint Name:\n\n\nSignature:\n\n\nVerified By:\n\n\nDate Shipped:\n\n\n" +
                "Storing Conditions on Receipt:\n\n\nComments:");
    }

    protected String getReceiverInformationString() {
        return ("\n\nUpon receipt please complete the enclosed checklist and sign and " +
                "confirm the good condition and receipt of this shipment.\n\n\nPrint Name:\n\n\nSignature:\n\n\n" +
                "Date Received:\n\n\nCondition on Receipt:\n\n\nComments:");
    }



}
