package com.monsanto.tps.shipping.business.reports.export;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.business.PermitBusiness;
import com.monsanto.tps.shipping.business.reports.POISheetBuilder;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.util.EventHelper;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Comparator;
import java.util.SortedSet;

/**
 * Created by DCENGL
 */
public abstract class AbstractPackingListItemsSheetBuilder extends POISheetBuilder implements PackingListItemsSheetBuilder {

    @Autowired
    private PermitBusiness permitBusiness;
    @Autowired
    private EventHelper eventHelper;

    @Override
    public Sheet buildSheet(Workbook workbook, ShipmentPackingListEntity packingList) {
        Sheet sheet = newSheet(workbook, "Items");
        String[] header = getHeader();

        CellStyle defaultCellStyle = buildDefaultStyle(workbook);
        CellStyle headerStyle = buildHeaderStyle(workbook);

        addHeader(sheet, headerStyle, header);

        addItemRows(sheet, defaultCellStyle, packingList);

        autoSizeColumns(sheet, header.length);

        return sheet;
    }

    protected abstract String[] getHeader();
    protected abstract void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList);

    protected Event getEventForContainer(Long containerId, Collection<Event> events) {
        for (Event event : events) {
            if (!org.apache.commons.collections.CollectionUtils.isEmpty(event.getContentContainerIds()) && event.getContentContainerIds().contains(containerId)) {
                return event;
            }
        }

        return null;
    }


    protected String getMonsantoIdString(Event event) {
        StringBuilder monsantoIds = new StringBuilder();

        if (event != null && !CollectionUtils.isEmpty(event.getSelectedPermits())) {
            for (Permit permit : event.getSelectedPermits()) {
                if (monsantoIds.length() == 0) {
                    monsantoIds.append(permit.getMonsantoId());
                } else {
                    monsantoIds.append(", " + permit.getMonsantoId());
                }
            }
            return monsantoIds.toString();
        }

        return "";
    }

    protected String getPermitString(Event event) {
        StringBuilder approvalNumbers = new StringBuilder();

        if (event != null && !CollectionUtils.isEmpty(event.getSelectedPermits())) {
            for (Permit permit : event.getSelectedPermits()) {
                if (approvalNumbers.length() == 0) {
                    approvalNumbers.append(permit.getApprovalNumber());
                } else {
                    approvalNumbers.append(", " + permit.getApprovalNumber());
                }
            }
            return approvalNumbers.toString();
        }

        return "";
    }

    protected SortedSet<ScannedContainerEntity> getSortedContentContainerEntities(ShipmentPackingListEntity packingListEntity) {
        SortedSet<ScannedContainerEntity> contentContainerEntities = Sets.newTreeSet(new Comparator<ScannedContainerEntity>() {
            @Override
            public int compare(ScannedContainerEntity o1, ScannedContainerEntity o2) {
                return o1.getScanOrder() - o2.getScanOrder();
            }
        });
        for (ShipmentContainerEntity shipmentContainerEntity : packingListEntity.getShipmentContainers()) {
            for (ScannedContainerEntity contentContainerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
                contentContainerEntities.add(contentContainerEntity);
            }
        }
        return contentContainerEntities;
    }

    protected Collection<Event> getPermits(ShipmentPackingListEntity packingListEntity) {
        if (packingListEntity.isInternational()) {
            return Lists.newArrayList();
        }

        return permitBusiness.loadAssociatedPermits(packingListEntity);
    }

    protected String getEventString(ContentEntity content) {
        if (content == null) {
            return "";
        }

        return eventHelper.getEventString(content);
    }
    protected  String getEventStringforHVPlots(ContentEntity content){
        if (content == null) {
            return "";
        }
        return eventHelper.getEventStringForHVPlots(content);
    }
}
