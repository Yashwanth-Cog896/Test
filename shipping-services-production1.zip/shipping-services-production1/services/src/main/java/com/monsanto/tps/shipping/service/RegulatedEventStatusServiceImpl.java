package com.monsanto.tps.shipping.service;

import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.net.URI;
import java.util.*;
import java.util.concurrent.CountDownLatch;

@Component("regulatedEventStatus")
public class RegulatedEventStatusServiceImpl implements RegulatedEventStatusService {

    private static final Log LOG = LogFactory.getLog(RegulatedEventStatusServiceImpl.class);

    @Resource(name="regulatedStatusCheckTaskExecutor")
    ThreadPoolTaskExecutor regulatedStatusCheckTaskExecutor;

    @Resource(name = "restOperation")
    private RestTemplate restTemplate;

    @Value("#{regulatedEventStatusXmlProperties.EVENT_STATUS_URL}")
    private String EVENT_STATUS_URL;

    @Trace
    @Override
    public Set<String> getUsdaValidatedEvents(Collection<String> eventStrings) {
        Set<String> events = Sets.newHashSet();

        List<RegulatedAPIResponse> responseMap = getRegulatedAPIResponses(eventStrings);
        for(RegulatedAPIResponse response : responseMap) {
            if(response.getCountries() != null) {
                for(RegulatedAPIResponse.Country country : response.getCountries()) {
                    if(country.getAgencies() != null) {
                        for(RegulatedAPIResponse.Country.Agency agency : country.getAgencies()) {
                            if(agency.getAgency().equals("USDA") && agency.getStatusInfo() != null
                                    && "Regulated".equals(agency.getStatusInfo().getStatus())) {
                                events.add(response.getEvent());
                            }
                        }
                    }
                }
            }
        }

        return events;
    }

    @Trace
    @Override
    public List<RegulatedAPIResponse> getEPAValidatedEvents(Collection<String> eventStrings) {
        List<RegulatedAPIResponse> responseMap = getRegulatedAPIResponses(eventStrings);
        return responseMap;
    }

    @Trace
    @Override
    public List<RegulatedAPIResponse> getRegulatedAPIResponses(Collection<String> eventStrings) {
        int size = eventStrings.size();
        final CountDownLatch latch = new CountDownLatch(size);
        List<RegulatedAPIResponse> responseMap =
                Collections.synchronizedList(new ArrayList<RegulatedAPIResponse>());

        regulatedStatusCheckTaskExecutor.setMaxPoolSize(25);
        regulatedStatusCheckTaskExecutor.setKeepAliveSeconds(60);
        for(String eventString : eventStrings) {
            regulatedStatusCheckTaskExecutor.execute(new RegulatedAPIWorkerThread(eventString, responseMap, latch));
        }

        try{
            latch.await();  //main thread is waiting on CountDownLatch to finish
        }catch(InterruptedException ie){
            LOG.error(ie);
        }

        return responseMap;
    }

    private class RegulatedAPIWorkerThread implements Runnable {
        private final String eventString;
        private final List<RegulatedAPIResponse> responseMap;
        private final CountDownLatch latch;

        public RegulatedAPIWorkerThread(String eventString,
                                        List<RegulatedAPIResponse> responseMap, CountDownLatch latch) {
            this.eventString = eventString;
            this.responseMap = responseMap;
            this.latch = latch;
        }

        @Override
        public void run() {
            URI targetUrl= UriComponentsBuilder.fromUriString(EVENT_STATUS_URL)
                    .queryParam("eventName", eventString.replaceAll(" ", ""))
                    .queryParam("countries", "US")
                    .build()
                    .toUri();
            RegulatedAPIResponse response = restTemplate.getForObject(targetUrl.toString(), RegulatedAPIResponse.class);
            responseMap.add(response);
            latch.countDown(); //reduce count of CountDownLatch by 1
        }
    }
}
