package com.monsanto.tps.shipping.business.compliance;

import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;

import java.util.Collection;

public interface RegulatedMovementBusiness {
    void assignPermitsToRegulatedMovements(Event event);

    void deleteMovementsByContent(ScannedContainerEntity contentContainerEntity);

    void deleteMovementsByPackingList(ShipmentPackingListEntity packingList);

    Collection<RegulatedInventoryMovementEntity> createRegulatedMovements(ShipmentPackingListEntity shipmentPackingList, AgencyEntity agencyEntity, Collection<ContentEntity> contentEntities, Event event);

    Collection<RegulatedInventoryMovementEntity> findByIds(Collection<Long> regulatedMovementIds);

    Collection<RegulatedInventoryMovementEntity> findByAgencyFromIds(Collection<Long> regulatedMovementIds, AgencyEntity agency);
}
