package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipOptionTypeEntity;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface ShipOptionTypeBusiness {
    ShipOptionTypeEntity findShipOptionType(long shipOptionTypeId);
    void saveShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity);
    List<ShipOptionTypeEntity> findAllShipOptionTypes();
}
