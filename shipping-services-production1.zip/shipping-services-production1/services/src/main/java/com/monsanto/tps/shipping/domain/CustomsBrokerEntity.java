
/**
 * Created by TMILB on 7/8/14.
 */
package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Sets;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "CUSTOMS_BROKER", schema = "INVENTORY_MGT")
public class CustomsBrokerEntity {
    @Id
    @Column(name = "CUSTOMS_BROKER_ID", nullable = false)
    private Long customsBrokerId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "COUNTRY_NAME")
    private String countryName;
    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;
    @Column(name = "TAX_ID_NUMBER")
    private String taxIdNumber;
    @Column(name = "COMPANY_NAME")
    private String companyName;
    @Column(name = "STREET_ADDRESS1")
    private String address1;
    @Column(name = "STREET_ADDRESS2")
    private String address2;
    @Column(name = "CITY")
    private String city;
    @Column(name = "STATE_PROV")
    private String stateProvince;
    @Column(name = "COUNTRY_CODE")
    private String countryCode;
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;
    @Column(name = "PAGER_NUMBER")
    private String pagerNumber;
    @Column(name = "FAX_NUMBER")
    private String faxNumber;
    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;
    @Column(name = "COMMENTS")
    private String comments;
    @Column(name = "INACTIVE_DTTM")
    private Date inactiveDateTime;
    @Column(name = "MODIFIED_DTTM")
    private Date modifiedDateTime;
    @OneToMany(mappedBy="customsBroker", fetch= FetchType.LAZY)
    private Set<CustomsBrokerPreferenceEntity> preferences = Sets.newHashSet();

    public Long getCustomsBrokerId() {
        return customsBrokerId;
    }

    public void setCustomsBrokerId(Long customsBrokerId) {
        this.customsBrokerId = customsBrokerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getTaxIdNumber() {
        return taxIdNumber;
    }

    public void setTaxIdNumber(String taxIdNumber) {
        this.taxIdNumber = taxIdNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPagerNumber() {
        return pagerNumber;
    }

    public void setPagerNumber(String pagerNumber) {
        this.pagerNumber = pagerNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getInactiveDateTime() {
        return inactiveDateTime;
    }

    public void setInactiveDateTime(Date inactiveDateTime) {
        this.inactiveDateTime = inactiveDateTime;
    }

    public Date getModifiedDateTime() {
        return modifiedDateTime;
    }

    public void setModifiedDateTime(Date modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }

    public Set<CustomsBrokerPreferenceEntity> getPreferences() {
        return preferences;
    }

    public void setPreferences(Set<CustomsBrokerPreferenceEntity> preferences) {
        this.preferences = preferences;
    }
}
