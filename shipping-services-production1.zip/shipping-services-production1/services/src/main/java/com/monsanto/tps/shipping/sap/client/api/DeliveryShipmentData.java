
package com.monsanto.tps.shipping.sap.client.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeliveryShipmentData", propOrder = {
    "salesOrderNum",
    "boxes"
})
public class DeliveryShipmentData {

    @XmlElement(name = "SalesOrderNum", required = true)
    private String salesOrderNum;
    @XmlElementWrapper(name = "CollectnBoxes")
    @XmlElement(name = "item", required = true)
    private List<SapBoxDetails> boxes;

    public String getSalesOrderNum() {
        return salesOrderNum;
    }

    public void setSalesOrderNum(String value) {
        this.salesOrderNum = value;
    }

    public List<SapBoxDetails> getBoxes() { return boxes; }

    public void setBoxes(List<SapBoxDetails> boxes) { this.boxes = boxes; }
}
