package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.GlobalTradeDocumentBusiness;
import com.monsanto.tps.shipping.transfer.GlobalTradeDocument;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.io.IOException;
import java.util.List;

/**
 * User: pgadi
 */
@Component("globalTradeDocumentService")
public class GlobalTradeDocumentServiceImpl implements GlobalTradeDocumentService {

    public static final String NO_DOCUMENTS_FOUND = "No documents found";

    @Autowired
    private GlobalTradeDocumentBusiness globalTradeDocumentBusiness;

    @Context
    private HttpServletResponse response;

    @Override
    public List<GlobalTradeDocument> getGlobalTradeDocumentsList(Long sapOrderShipmentId) {
        return globalTradeDocumentBusiness.getGlobalTradeDocumentsList(sapOrderShipmentId);
    }

    @Override
    public HttpServletResponse getGlobalTradeDocumentPdf(Long sequenceNumber, String title) {
        Cookie cookie = new Cookie("fileDownload", "true");
        cookie.setPath("/");

        response.setHeader("Content-Disposition", "attachment; filename=\""+ title + ".pdf");
        response.addCookie(cookie);

        byte[] responsePdf = globalTradeDocumentBusiness.getGlobalTradeDocumentPdf(sequenceNumber, title);

        try {
            if(responsePdf.length > 0) {
                response.getOutputStream().write(responsePdf);
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, NO_DOCUMENTS_FOUND);
            }
        } catch (IOException e) {
            throw new ShippingWebException("Error downloading " + title + " document" , e);
        }

        return response;
    }
}
