package com.monsanto.tps.shipping.business.reports;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public abstract class ITextDocumentBuilder {
    protected void addStringAtCoordinates(String value, float x, float y, PdfWriter writer, Font font) throws DocumentException {
        Rectangle pageRect = writer.getPageSize();

        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setSimpleColumn(pageRect.getLeft(x), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(y));
        columnText.addText(new Phrase(value, font));

        columnText.go();
    }
    protected void addStringCenteredAtY(String value, float y, PdfWriter writer, Font font) throws DocumentException {
        Rectangle pageRect = writer.getPageSize();

        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setAlignment(Element.ALIGN_CENTER);
        columnText.setSimpleColumn(pageRect.getLeft(), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(y));
        columnText.addText(new Phrase(value, font));

        columnText.go();
    }
    protected void addBoxesWithTextVerticallyAtCoordinates(String[] values, float x, float y, float boxWidth, PdfWriter writer, Font font) {
        Rectangle pageRect = writer.getPageSize();

        PdfPTable table = new PdfPTable(1);
        table.setTotalWidth(boxWidth);

        for (String value : values) {
            PdfPCell cell = new PdfPCell(new Phrase(value, font));
            cell.setPadding(5);
            table.addCell(cell);
            table.completeRow();
        }

        table.writeSelectedRows(0,-1, pageRect.getLeft(x),pageRect.getTop(y), writer.getDirectContent());
    }
    protected void addBoxesWithTextCenteredHorizontallyAtY(String[] values, float y, float boxHeight, PdfWriter writer, Font font) throws DocumentException {
        Rectangle pageRect = writer.getPageSize();

        ColumnText columnText = new ColumnText(writer.getDirectContent());
        columnText.setSimpleColumn(pageRect.getLeft(), pageRect.getBottom(), pageRect.getRight(), pageRect.getTop(y));

        PdfPTable table = new PdfPTable(values.length);
        table.setWidthPercentage(95);
        for (String value : values) {
            PdfPCell cell = new PdfPCell(new Phrase(value, font));
            cell.setFixedHeight(boxHeight);
            table.addCell(cell);
        }
        table.completeRow();

        columnText.addElement(table);
        columnText.go();
    }
    protected PdfPTable createTableWithHeader(String[] headerValues, float[] columnWidths, Font headerFont) throws DocumentException {
        PdfPTable table = new PdfPTable(headerValues.length);
        table.setHeaderRows(1);
        table.setTotalWidth(500);
        table.setWidthPercentage(104);

        for (String headerValue : headerValues) {
            PdfPCell cell = new PdfPCell(new Phrase(headerValue, headerFont));
            cell.setFixedHeight(30);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            table.addCell(cell);
        }
        table.completeRow();
        table.setWidths(columnWidths);

        return table;
    }
    protected void appendCellToTable(String value, PdfPTable table, Font font) {
        table.addCell(new PdfPCell(new Phrase(value, font)));
    }
    protected void appendCellToTable(Integer value, PdfPTable table, Font font) {
        table.addCell(new PdfPCell(new Phrase(value.toString(), font)));
    }

    protected Font buildDefaultFont(float fontSize) {
        Font defaultFont = new Font();
        defaultFont.setSize(fontSize);
        return defaultFont;
    }
    protected Font buildBoldFont(float fontSize) {
        Font boldFont = new Font();
        boldFont.setStyle(Font.BOLD);
        boldFont.setSize(fontSize);
        return boldFont;
    }
    protected Font buildBoldUnderlineFont(float fontSize) {
        Font boldUnderlineFont = new Font();
        boldUnderlineFont.setStyle(Font.UNDERLINE | Font.BOLD);
        boldUnderlineFont.setSize(fontSize);
        return boldUnderlineFont;
    }

}
