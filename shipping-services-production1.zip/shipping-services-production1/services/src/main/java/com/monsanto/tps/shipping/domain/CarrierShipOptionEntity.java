package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by KERRA on 5/19/2014.
 */
@Entity
@Table(name = "CARRIER_SHIP_OPTION", schema = "INVENTORY_MGT")
public class CarrierShipOptionEntity {
    @Id
    @Column(name = "CARRIER_SHIP_OPTION_ID")
    private Long carrierShipOptionId;

    @Column(name = "SHIP_OPTION_ID", nullable = true)
    private Long shipOptionId;

    @ManyToOne
    @JoinColumn(name = "SHIP_OPTION_TYPE_ID", nullable = false)
    private ShipOptionTypeEntity shipOptionTypeEntity;

    @Column(name = "SHIP_OPTION", nullable = false)
    private String shipOption;

    @Column(name = "SHIP_OPTION_REF_ID", nullable = false)
    private String shipOptionRefId;

    @Column(name = "REF_ACTIVE", nullable = false)
    @Type(type="true_false")
    private boolean refActive;

    @ManyToOne(optional = false)
    @JoinColumn(name = "CARRIER_ID")
    private CarrierEntity carrierEntity;

    public Long getCarrierShipOptionId() {
        return carrierShipOptionId;
    }

    public void setCarrierShipOptionId(Long carrierShipOptionId) {
        this.carrierShipOptionId = carrierShipOptionId;
    }

    public Long getShipOptionId() {
        return shipOptionId;
    }

    public void setShipOptionId(Long shipOptionId) {
        this.shipOptionId = shipOptionId;
    }

    public ShipOptionTypeEntity getShipOptionTypeEntity() {
        return shipOptionTypeEntity;
    }

    public void setShipOptionTypeEntity(ShipOptionTypeEntity shipOptionTypeEntity) {
        this.shipOptionTypeEntity = shipOptionTypeEntity;
    }

    public String getShipOption() {
        return shipOption;
    }

    public void setShipOption(String shipOption) {
        this.shipOption = shipOption;
    }

    public String getShipOptionRefId() {
        return shipOptionRefId;
    }

    public void setShipOptionRefId(String shipOptionRefId) {
        this.shipOptionRefId = shipOptionRefId;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public CarrierEntity getCarrierEntity() {
        return carrierEntity;
    }

    public void setCarrierEntity(CarrierEntity carrierEntity) {
        this.carrierEntity = carrierEntity;
    }
}
