package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.dao.CropStandardShipInfoDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureConversionDao;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.CassetteContainerEntity;
import com.monsanto.tps.shipping.domain.CassetteEntity;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.CropStandardShipInfoEntity;
import com.monsanto.tps.shipping.domain.EupEventWeight;
import com.monsanto.tps.shipping.domain.EventWeight;
import com.monsanto.tps.shipping.domain.GermplasmEntity;
import com.monsanto.tps.shipping.domain.InventoryEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.SeedTrayCellEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.ReportServiceImpl;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.util.EventHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User: pgadi
 */
@Service
public class EupEventWeightLabelBusinessImpl implements EupEventWeightLabelBusiness {

    private static final Log LOG = LogFactory.getLog(EupEventWeightLabelBusinessImpl.class);

    @Autowired
    private RegulatedEventBusiness regulatedEventBusiness;
    @Autowired
    private EpaBusiness epaBusiness;
    @Autowired
    private PackingListContentBusiness packingListContentBusiness;
    @Autowired
    private UnitOfMeasureConversionDao unitOfMeasureConversionDao;
    @Autowired
    private CropStandardShipInfoDao cropStandardShipInfoDao;
    @Autowired
    private EventHelper eventHelper;

    @Override
    public Collection<EupEventWeight> getEupEventWeightSummary(ShipmentPackingListEntity packingList) {

        Map<AgencyEnum, Collection<Event>> regulatedEvents = regulatedEventBusiness.getRegulatedEvents(packingList);
        if(regulatedEvents.isEmpty()) {
            return Lists.newArrayList();
        }

        epaBusiness.loadAssociatedPermits(packingList, regulatedEvents.get(AgencyEnum.EPA));

        Collection<Event> events = regulatedEvents.get(AgencyEnum.EPA);
        if(CollectionUtils.isEmpty(events)) {
            return Lists.newArrayList();
        }

        Map<String, EupEventWeight> monsantoIdToEupEventWeightMap = new HashMap<String, EupEventWeight>();
        for (Event event : events) {
            List<ScannedContainerEntity> scannedContainerEntities = getContentContainerByIds(packingList, event.getContentContainerIds());
            Permit selectedEpaPermit = Permit.findFirst(event.getSelectedPermits(), AgencyEnum.EPA);

            String eventString = "";
            if (event.getEventString() != null) {
                eventString = event.getEventString();
            }

            if (event.getMaleEventString() != null) {
                if (event.getEventString() != null) {
                    eventString = eventString.concat("," + event.getMaleEventString());
                }
                if (event.getEventString() == null) {
                    eventString = eventString.concat(event.getMaleEventString());
                }
            }
            eventString = eventString.replace(",", ", ");

            String monsantoId = selectedEpaPermit.getMonsantoId();
            if (!monsantoIdToEupEventWeightMap.containsKey(monsantoId)) {
                EupEventWeight eupEventWeight = new EupEventWeight();
                eupEventWeight.setMonsantoId(monsantoId);
                eupEventWeight.setAgencyNumber(selectedEpaPermit.getApprovalNumber());
                eupEventWeight.getEventWeightCollection().add(getEventWeight(scannedContainerEntities, eventString));

                monsantoIdToEupEventWeightMap.put(monsantoId, eupEventWeight);
            } else {
                monsantoIdToEupEventWeightMap.get(monsantoId).getEventWeightCollection().add(getEventWeight(scannedContainerEntities, eventString));
            }
        }

        return monsantoIdToEupEventWeightMap.values();
    }

    private EventWeight getEventWeight(List<ScannedContainerEntity> scannedContainerEntities, String eventString) {
        Double weight = 0D;
        for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
            Double permitConversionFactor = scannedContainerEntity.getWeightUOM() == null ? null : packingListContentBusiness.getPermitUnitsConversionFactor(scannedContainerEntity.getWeightUOM());
            Double scannedContainerEntityWeight = getWeight(scannedContainerEntity, eventString);
            Double shippedQuantity = getWeightInPermitUnits(permitConversionFactor, scannedContainerEntityWeight);
            weight += (null != shippedQuantity) ? shippedQuantity : 0;
        }

        return new EventWeight(eventString, Math.round(weight*1000000)/1000000D);
    }

    private Double getWeight(ScannedContainerEntity scannedContainerEntity, String eventString) {
        Double weight = 0D;
        if (scannedContainerEntity instanceof CassetteContainerEntity) {
            CassetteEntity cassetteEntity = ((CassetteContainerEntity) scannedContainerEntity).getCassette();
            for (SeedTrayCellEntity seedTrayCellEntity : cassetteEntity.getSeedTrayCells()) {
                if (seedTrayCellEntity.getActualQuantity() != null && scannedContainerEntity.getWeightUOM() != null) {
                    InventoryEntity inventoryEntity = seedTrayCellEntity.getInventory();
                    if (inventoryEntity.getGeneticMaterial() != null && inventoryEntity.getGeneticMaterial().getGermplasm() != null) {
                        GermplasmEntity germplasm = inventoryEntity.getGeneticMaterial().getGermplasm();
                        if (null != germplasm && StringUtils.equalsIgnoreCase(eventHelper.getEventString(germplasm.getEvents()), eventString)) {
                            Double seedCountWeight = getSeedCountToWeightConversionFactor(scannedContainerEntity.getWeightUOM(), germplasm.getCrop());
                            weight += seedTrayCellEntity.getActualQuantity() * seedCountWeight;
                        }
                    }
                }
            }
        } else {
            weight = scannedContainerEntity.getWeight();
        }
        return weight;
    }

    private Double getSeedCountToWeightConversionFactor(UnitOfMeasureEntity packingListUom, CropEntity cropEntity) {
        CropStandardShipInfoEntity cropStandardShipInfoEntity = cropStandardShipInfoDao.getCropStandardShipInfoByCrop(cropEntity);
        Double seedCountConversionFactor = cropStandardShipInfoEntity.getPerSeedCountStandardWeight();
        Double seedCountToPackingListUomConversionFactor;
        if (packingListUom.getId().equals(cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId())) {
            seedCountToPackingListUomConversionFactor = 1D;
        } else {
            seedCountToPackingListUomConversionFactor = unitOfMeasureConversionDao.getUomConversion(
                    cropStandardShipInfoEntity.getWeightUnitOfMeasure().getId(), packingListUom.getId()).getConversionFactor();
        }
        return seedCountConversionFactor * seedCountToPackingListUomConversionFactor;
    }

    private Double getWeightInPermitUnits(Double permitUnitsUomConversionFactor, Double weight) {
        return permitUnitsUomConversionFactor == null ? null : convertWeight(permitUnitsUomConversionFactor, weight);
    }

    private Double convertWeight(Double conversionFactor, Double weight) {
        return null != weight ? Math.round((weight * conversionFactor)*1000000)/1000000D : null;
    }

    private List<ScannedContainerEntity> getContentContainerByIds(ShipmentPackingListEntity packingList, Collection<Long> contentContainerIds) {
        List<ScannedContainerEntity> contentContainers = Lists.newArrayList();
        for (ShipmentContainerEntity shipmentContainer : packingList.getShipmentContainers()) {
            for (ScannedContainerEntity contentContainer : shipmentContainer.getStorageContainer().getContainers()) {
                if (contentContainerIds.contains(contentContainer.getContainerId())) {
                    contentContainers.add(contentContainer);
                }
            }
        }

        return contentContainers;
    }
}
