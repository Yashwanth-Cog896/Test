package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.business.ExternalPermitBusiness;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.SortedSet;

@Service
public class OtherMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Autowired
    private ExternalPermitBusiness externalPermitBusiness;

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> eventStringToEventMap, Font font) throws DocumentException {
        if (packingList.hasExternalPermits() != null && packingList.hasExternalPermits()) {
            Collection<ExternalPermitEntity> externalPermits = externalPermitBusiness.getExternalPermitsForPackingList(packingList);

            if (!CollectionUtils.isEmpty(externalPermits)) {
                for (ExternalPermitEntity externalPermit : externalPermits) {
                    ShipmentContainerEntity storageContainerEntity = externalPermit.getShipmentContainer();
                    appendCellToTable(storageContainerEntity.getStorageContainer().getBarcode(), permitsTable, font);
                    appendCellToTable(externalPermit.getPermitNumber(), permitsTable, font);
                    appendCellToTable(dateFormat.format(externalPermit.getExpirationDate()), permitsTable, font);

                    String agencyString;
                    AgencyEntity agency = externalPermit.getAgency();
                    if (agency != null) {
                        agencyString = agency.getAbbr();
                    } else {
                        agencyString = "Other: [" + externalPermit.getOtherAgencyName() + "]";
                    }

                    appendCellToTable(agencyString, permitsTable, font);
                    appendCellToTable(externalPermit.getExternalMaterialType().getDescription(), permitsTable, font);
                    appendCellToTable(externalPermit.getMaterialDescription(), permitsTable, font);
                    appendCellToTable(externalPermit.getConstructName(), permitsTable, font);
                    appendCellToTable(externalPermit.getEventName(), permitsTable, font);

                    permitsTable.completeRow();
                }
            }
        }

        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        decimalFormat.setRoundingMode(RoundingMode.UP);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            OtherContainerEntity otherContainer = (OtherContainerEntity) contentContainerEntity;

            appendCellToTable(otherContainer.getScanOrder(), contentsTable, font);
            appendCellToTable(otherContainer.getBarcode(), contentsTable, font);
            appendCellToTable(otherContainer.getName(), contentsTable, font);
            appendCellToTable(otherContainer.getComments(), contentsTable, font);

            Double weight = otherContainer.getWeight();
            appendCellToTable(weight != null ? decimalFormat.format(weight) : "", contentsTable, font);

            UnitOfMeasureEntity uomEntity = otherContainer.getWeightUOM();
            appendCellToTable(uomEntity != null ? uomEntity.getUomRefId() : "", contentsTable, font);

            Integer quantity = otherContainer.getQuantity();
            appendCellToTable(quantity != null ? quantity.toString() : "", contentsTable, font);

            appendCellToTable(otherContainer.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Item BID", "Name", "Comments", "Weight", "UOM", "Count", "Box Barcode", "Received"},
                new float[]{15, 55, 35, 65, 15, 10, 15, 25, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Box Barcode", "Permit", "Expiration Date", "Agency", "Material ID", "Description", "Construct", "Event"},
                new float[]{30,25,30,30,25,50,40,70}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.OTHER;
    }
}
