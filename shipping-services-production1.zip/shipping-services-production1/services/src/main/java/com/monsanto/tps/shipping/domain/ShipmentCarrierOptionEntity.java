package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "SHIPMENT_CARRIER_OPTION", schema = "INVENTORY_MGT")
public class ShipmentCarrierOptionEntity {

    @Id
    @Column(name = "SHIPMENT_CARRIER_OPTION_ID")
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    private Long id;

    @ManyToOne
    @JoinColumn(name = "SHIPMENT_ID")
    private ShipmentEntity shipment;

    @ManyToOne
    @JoinColumn(name = "CARRIER_SHIP_OPTION_ID", nullable = false)
    private CarrierShipOptionEntity carrierShipOption;

    @ManyToOne
    @JoinColumn(name = "SHIP_OPTION_TYPE_ID", nullable = false)
    private ShipOptionTypeEntity shipOptionType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ShipmentEntity getShipment() {
        return shipment;
    }

    public void setShipment(ShipmentEntity shipment) {
        this.shipment = shipment;
    }

    public CarrierShipOptionEntity getCarrierShipOption() {
        return carrierShipOption;
    }

    public void setCarrierShipOption(CarrierShipOptionEntity carrierShipOption) {
        this.carrierShipOption = carrierShipOption;
    }

    public ShipOptionTypeEntity getShipOptionType() {
        return shipOptionType;
    }

    public void setShipOptionType(ShipOptionTypeEntity shipOptionType) {
        this.shipOptionType = shipOptionType;
    }
}
