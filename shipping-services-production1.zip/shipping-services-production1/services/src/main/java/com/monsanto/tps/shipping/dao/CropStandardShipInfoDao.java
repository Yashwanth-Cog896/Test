package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.CropStandardShipInfoEntity;

public interface CropStandardShipInfoDao {

    public CropStandardShipInfoEntity getCropStandardShipInfoByCrop(CropEntity crop);
}