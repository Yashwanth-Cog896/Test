package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.dao.ProgramUserDao;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.domain.ProgramUserEntity;
import com.monsanto.tps.shipping.service.model.Program;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * User: DCENGL
 */
@Service
public class ProgramUserBusinessImpl implements ProgramUserBusiness {

    @Autowired
    private ProgramUserDao programUserDao;

    @Trace
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    @Override
    public List<Program> getProgramsForLoginId(String loginId) {
        return new ArrayList<Program>(transformProgramEntities(getProgramEntities(loginId)));
    }

    private List<ProgramEntity> getProgramEntities(String loginId) {
        List<ProgramUserEntity> programUsers = programUserDao.findByLoginId(loginId);
        return Lists.transform(programUsers, new Function<ProgramUserEntity, ProgramEntity>() {
            @Override
            public ProgramEntity apply(ProgramUserEntity programUserEntity) {
                return programUserEntity.getProgram();
            }
        });
    }

    private List<Program> transformProgramEntities(List<ProgramEntity> programEntities) {
        return Lists.transform(programEntities, new Function<ProgramEntity, Program>() {
            @Override
            public Program apply(ProgramEntity programEntity) {
                Program program = new Program();
                program.setId(programEntity.getProgramId());
                program.setReferenceId(programEntity.getRefId());
                program.setName(programEntity.getName());
                program.setAccountId(programEntity.getAccountId());
                program.setCropId(programEntity.getCrop().getCropId());
                program.setCropName(programEntity.getCrop().getName());
                return program;
            }
        });
    }
}
