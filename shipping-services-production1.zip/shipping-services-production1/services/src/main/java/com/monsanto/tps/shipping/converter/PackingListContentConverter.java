package com.monsanto.tps.shipping.converter;

import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.GeneticMaterialEntity;
import com.monsanto.tps.shipping.domain.HDTrayEntity;
import com.monsanto.tps.shipping.domain.OtherContainerEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateEntity;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.TextUtils;
import com.monsanto.tps.shipping.util.aspect.DynamicColumnInterceptor;
import net.sf.cglib.proxy.Enhancer;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
@Component
public class PackingListContentConverter {

    private static final double ROUNDING_FACTOR_SIX_DECIMALS = 1000000.0;
    private static final Logger log = LogManager.getLogger(PackingListContentConverter.class);

    @Autowired
    private EventHelper eventHelper;
    @Autowired
    private AutowireCapableBeanFactory beanFactory;
    @Autowired
    private CassetteContentConverter cassetteContentConverter;

    public List<PackingListContent> createPackingListContents(Collection<? extends ScannedContainerEntity> contentContainerEntities,
                                                              StorageContainerEntity storageContainer, ShipmentTypeEntity shipmentTypeEntity) {
        List<PackingListContent> packingListContents = new ArrayList<PackingListContent>();
        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            PackingListContent content = new PackingListContent();
            content.setContainerBarcode(storageContainer.getBarcode());
            content.setShipmentTypeId(shipmentTypeEntity.getShipmentTypeId());
            setPackingListContentValues(content, contentContainerEntity, shipmentTypeEntity.getName());
            packingListContents.add(content);
        }
        return packingListContents;
    }

    public boolean checkContentAndEntity(ScannedContainerEntity scannedContainerEntity){
        return scannedContainerEntity.getContent() instanceof PlotEntity &&
                scannedContainerEntity.getStorageContainer().getShipmentContainer().getShipmentPackingList().getShipmentType().getDescription().equalsIgnoreCase("Harvested Plots");
    }

    public void setPackingListContentValues(PackingListContent packingListContent, ScannedContainerEntity scannedContainerEntity, String shipmentTypeName) {
        ContentEntity contentEntity = scannedContainerEntity.getContent();
        GeneticMaterialEntity geneticMaterialEntity = contentEntity.getGeneticMaterial();
        PackingListContent packingListContentProxy = proxy(shipmentTypeName, packingListContent);
        packingListContentProxy.setId(scannedContainerEntity.getContainerId());
        packingListContentProxy.setBarcode(contentEntity.getBarcode());
        if (geneticMaterialEntity != null) {
            if(checkContentAndEntity(scannedContainerEntity)){
                packingListContentProxy.setEventDisplay(eventHelper.getEventStringForHVPlots(contentEntity));
            }
            else {
                packingListContentProxy.setEventDisplay(eventHelper.getEventString(contentEntity));
            }
            packingListContentProxy.setCropId(geneticMaterialEntity.getGermplasm().getCrop().getCropId());
            packingListContentProxy.setCrop(geneticMaterialEntity.getGermplasm().getCrop().getName());
            packingListContentProxy.setSourcePlotNumber(geneticMaterialEntity.getSourcePlotNumber());
            packingListContentProxy.setCountryOfOrigin(geneticMaterialEntity.getCountryOfOrigin());
        }

        packingListContentProxy.setType(scannedContainerEntity.getContentType().name());
        packingListContentProxy.setWeight(formatWeightUpToSixDecimalPlaces(scannedContainerEntity.getWeight()));
        packingListContentProxy.setSeedCount(scannedContainerEntity.getQuantity());
        packingListContentProxy.setScanOrder(scannedContainerEntity.getScanOrder());
        packingListContentProxy.setEpc(scannedContainerEntity.getElectronicProductCode());

        ContentType contentType = contentEntity.getContentType();
        PlotEntity plotEntity = null;
        if (contentType.equals(ContentType.PLOT)) {
            plotEntity = setValuesForPlot((PlotEntity) contentEntity, packingListContentProxy);
        } else if (contentType.equals(ContentType.CASSETTE)) {
            plotEntity = setValuesForCassette(contentEntity, packingListContentProxy);
        } else if (contentType.equals(ContentType.TISSUE_PLATE)) {
            plotEntity = setValuesForTissuePlate(contentEntity, packingListContentProxy);
        } else if (contentType.equals(ContentType.OTHER)) {
            OtherContainerEntity otherContainerEntity = OtherContainerEntity.class.cast(scannedContainerEntity);
            packingListContentProxy.setName(otherContainerEntity.getName());
            packingListContentProxy.setComments(otherContainerEntity.getComments());
        } else if (ContentType.WHOLE_PLANTS.equals(contentType)){
            packingListContent.setEventDisplay(eventHelper.getEventString(contentEntity));
        } else if (contentType.equals(ContentType.HD_TRAY)) {
            setValuesForHDTray(contentEntity, packingListContentProxy);
        }

        setPlotSpecificValues(packingListContentProxy, plotEntity);

        if (scannedContainerEntity.getWeightUOM() != null) {
            packingListContentProxy.setWeightUOM(scannedContainerEntity.getWeightUOM().getUomRefId());
        }
        packingListContentProxy.setReceiveVerificationDate(scannedContainerEntity.getReceiveVerificationDate());
        packingListContentProxy.setSendVerificationDate(scannedContainerEntity.getSendVerificationDate());
    }

    public PackingListContent getPackingListContentFromContentEntity(ContentEntity contentEntity) {
        PackingListContent packingListContent = new PackingListContent();
        if(null == contentEntity){
            return packingListContent;
        }

        packingListContent.setBarcode(contentEntity.getBarcode());
        setValuesFromGeneticMaterial(contentEntity, packingListContent);

        ContentType contentType = contentEntity.getContentType();
        packingListContent.setType(contentType.name());

        PlotEntity plotEntity = null;
        if (contentType.equals(ContentType.PLOT)) {
            plotEntity = setValuesForPlot((PlotEntity) contentEntity, packingListContent);
        } else if (contentType.equals(ContentType.CASSETTE)) {
            plotEntity = setValuesForCassette(contentEntity, packingListContent);
        } else if (contentType.equals(ContentType.TISSUE_PLATE)) {
            plotEntity = setValuesForTissuePlate(contentEntity, packingListContent);
        } else if (ContentType.WHOLE_PLANTS.equals(contentType)){
            packingListContent.setEventDisplay(eventHelper.getEventString(contentEntity));
        }  else if (ContentType.HD_TRAY.equals(contentType)) {
            setValuesForHDTray(contentEntity, packingListContent);
        }

        setPlotSpecificValues(packingListContent, plotEntity);
        return packingListContent;
    }

    private Double formatWeightUpToSixDecimalPlaces(Double weight) {
        return weight != null ? Math.round(weight * ROUNDING_FACTOR_SIX_DECIMALS) / ROUNDING_FACTOR_SIX_DECIMALS : null;
    }

    private PackingListContent proxy(String shipmentTypeName, PackingListContent packingListContent) {
        DynamicColumnInterceptor interceptor = new DynamicColumnInterceptor(shipmentTypeName, packingListContent);
        Enhancer e = new Enhancer();
        e.setSuperclass(packingListContent.getClass());
        beanFactory.autowireBean(interceptor);
        e.setCallback(interceptor);
        return (PackingListContent) e.create();
    }

    private void setPlotSpecificValues(PackingListContent packingListContentProxy, PlotEntity plotEntity) {
        if (plotEntity != null) {
            packingListContentProxy.setEntryNumber(null == plotEntity.getTestSetEntry() ? null : plotEntity.getTestSetEntry().getEntryNumber());
            packingListContentProxy.setTrackId(
                    null == plotEntity.getRep() || null == plotEntity.getRep().getField() ? null :
                            plotEntity.getRep().getField().getFieldName());
            packingListContentProxy.setField(null == plotEntity.getField() ? null : plotEntity.getField().getFieldName());
            packingListContentProxy.setSeason(null == plotEntity.getField() ? null : plotEntity.getField().getSeason().getName());
            packingListContentProxy.setRep(null == plotEntity.getRep() ? null : plotEntity.getRep().getRepNumber());
            packingListContentProxy.setRepBarcode(null == plotEntity.getRep() ? null : plotEntity.getRep().getBarcode());
            packingListContentProxy.setPlotNumber(plotEntity.getPlotNumber());
            packingListContentProxy.setAbsoluteColumn(plotEntity.getAbsoluteColumn());
            packingListContentProxy.setAbsoluteRange(plotEntity.getAbsoluteRange());
            packingListContentProxy.setColumn(plotEntity.getColumn());
            packingListContentProxy.setRange(plotEntity.getRange());
        }
    }

    private void setValuesFromGeneticMaterial(ContentEntity contentEntity, PackingListContent packingListContent) {
        GeneticMaterialEntity geneticMaterialEntity = contentEntity.getGeneticMaterial();
        if (geneticMaterialEntity != null) {
            packingListContent.setEventDisplay(eventHelper.getEventString(contentEntity));
            packingListContent.setCropId(geneticMaterialEntity.getGermplasm().getCrop().getCropId());
            packingListContent.setCrop(geneticMaterialEntity.getGermplasm().getCrop().getName());
            packingListContent.setSourcePlotNumber(geneticMaterialEntity.getSourcePlotNumber());
            packingListContent.setCountryOfOrigin(geneticMaterialEntity.getCountryOfOrigin());
        }
    }

    private void setValuesForHDTray(ContentEntity contentEntity, PackingListContent packingListContent) {
        HDTrayEntity hdTrayEntity = HDTrayEntity.class.cast(contentEntity);
        packingListContent.setLimsId(hdTrayEntity.getLimsId());
        packingListContent.setProjectName(hdTrayEntity.getProjectName());
        packingListContent.setHdTrayInvBarcode(hdTrayEntity.getInventoryBarCodes());
        packingListContent.setEventDisplay(eventHelper.getEventString(contentEntity));
    }

    private PlotEntity setValuesForTissuePlate(ContentEntity contentEntity, PackingListContent packingListContent) {
        PlotEntity plotEntity;TissuePlateEntity tissuePlateEntity = TissuePlateEntity.class.cast(contentEntity);
        packingListContent.setLimsId(tissuePlateEntity.getLimsId());
        packingListContent.setWellNumber(tissuePlateEntity.getWellNumber());
        packingListContent.setPlateType(tissuePlateEntity.getPlateType());
        packingListContent.setProjectName(tissuePlateEntity.getProjectName());

        plotEntity = tissuePlateEntity.getPlot();
        if (plotEntity != null) {
            packingListContent.setTissuePlotBarcode(plotEntity.getBarcode());
        }
        return plotEntity;
    }

    private PlotEntity setValuesForCassette(ContentEntity contentEntity, PackingListContent packingListContent) {
        PlotEntity plotEntity;
        plotEntity = cassetteContentConverter.getFirstPlotFromCassette(contentEntity);
        Collection<String> testSets = cassetteContentConverter.getTestSetNames(contentEntity);
        String commaSeparatedTestSets = TextUtils.getDelimitedStringWithComma(testSets);
        packingListContent.setSet(commaSeparatedTestSets);
        return plotEntity;
    }

    private PlotEntity setValuesForPlot(PlotEntity contentEntity, PackingListContent packingListContentProxy) {
        PlotEntity plotEntity;
        plotEntity = (PlotEntity) contentEntity;
        packingListContentProxy.setSet(null == plotEntity.getTestSetEntry() ? null : plotEntity.getTestSetEntry().getTestSet().getTestSetName());
        return plotEntity;
    }
}
