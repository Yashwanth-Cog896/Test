package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.Permit;

import java.util.Collection;
import java.util.Set;

/**
 * User: pgadi
 */
public interface EpaBusiness {

    Collection<Event> getEpaEvents(Collection<Event> events, Set<String> allEventStrings);

    void addEpaEventDetails(EventDetails eventDetails);

    Collection<Permit> getPermits(Collection<Event> epaValidatedEvents, Long cropId, String stateCode);

    void loadAssociatedPermits(ShipmentPackingListEntity packingList, Collection<Event> events);
}
