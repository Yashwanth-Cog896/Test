package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * Created by DCENGL
 */
public interface PackingListItemsSheetBuilder {

    Sheet buildSheet(Workbook workbook, ShipmentPackingListEntity packingList);

    boolean canBuild(ShipmentTypeEntity shipmentType);
}
