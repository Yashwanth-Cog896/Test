package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ExternalMaterialTypeEntity;

import java.util.Collection;

public interface ExternalMaterialTypeBusiness {

    Collection<ExternalMaterialTypeEntity> getAllActive();

}
