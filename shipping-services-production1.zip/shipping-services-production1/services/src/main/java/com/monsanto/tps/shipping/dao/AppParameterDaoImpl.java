package com.monsanto.tps.shipping.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

/**
 * User: pgadi
 */
@Repository
public class AppParameterDaoImpl implements AppParameterDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public String getParameterValueByNameAndApplication(String paramName, String appName) {
        return (String) sessionFactory.getCurrentSession().createSQLQuery(
                "select parameter_value from MIDAS.APPLICATION_PARAMETER where parameter_name = :paramName and application_name=:appName")
                .setParameter("paramName", paramName)
                .setParameter("appName", appName)
                .uniqueResult();
    }
}
