package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by wwahme
 */
@Service
public class SeedTreatmentNonPPQSection extends AbstractChecklistSection {

    private static final String HEADER = "Additional Requirements for the�movement of Seed Treated with Regulated/Unregistered Seed Treatments (including microbial treatments not under PPQ permit)";

    private final static String SECTION_1 = "Labeling";
    private final static String SECTION_1_QUESTION_1 = "Outermost layer of containment is labeled with the phrase, \"Experimental Use Only\".";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);

        return questionsMap;
    }
}
