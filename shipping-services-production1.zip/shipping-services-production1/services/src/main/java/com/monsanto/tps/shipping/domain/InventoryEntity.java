package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "INVENTORY", schema = "MIDAS")
public class InventoryEntity implements ContentEntity, Serializable {
    @Id
    @Column(name = "INVENTORY_ID", nullable = false)
    private Long inventoryId;
    @Column(name = "BARCODE")
    private String barcode;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GENETIC_MATERIAL_ID")
    private GeneticMaterialEntity geneticMaterial;

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public GeneticMaterialEntity getGeneticMaterial() {
        return geneticMaterial;
    }

    @Override
    public InventoryEntity getInventory() {
        return this;
    }

    public void setGeneticMaterial(GeneticMaterialEntity geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public Long getContentId() {
        return this.inventoryId;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.INVENTORY;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}

        if (o == null || !getClass().isAssignableFrom(o.getClass())) {
            return false;
        }

        InventoryEntity that = (InventoryEntity) o;

        return !(getContentId() != null ? !getContentId().equals(that.getContentId()) : that.getContentId() != null);
    }

    @Override
    public int hashCode() {
        return inventoryId != null ? inventoryId.hashCode() : 0;
    }
}