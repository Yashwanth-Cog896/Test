package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;

import java.util.List;

public interface SapOrderShipmentDao {

    void saveSapOrderShipment(SapOrderShipmentEntity sapOrderShipmentEntity);

    List<SapOrderShipmentEntity> getAllSapOrderShipments();

    SapOrderShipmentEntity findBySapOrderNumber(String orderNumber);

    SapOrderShipmentEntity getSapOrderShipmentById(Long sapOrderShipmentId);

    void delete(SapOrderShipmentEntity sapOrderShipment);
}
