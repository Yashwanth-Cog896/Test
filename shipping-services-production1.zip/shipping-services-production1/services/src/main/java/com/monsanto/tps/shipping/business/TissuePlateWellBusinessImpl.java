package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.dao.TissuePlateWellDao;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateWellEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by DCENGL
 */
@Service
public class TissuePlateWellBusinessImpl implements TissuePlateWellBusiness {

    private final Comparator<TissuePlateWellEntity> TISSUE_PLATE_WELL_COMPARATOR = new Comparator<TissuePlateWellEntity>() {
        @Override
        public int compare(TissuePlateWellEntity o1, TissuePlateWellEntity o2) {
            ScannedContainerEntity scannedContainer1 = o1.getScannedContainer();
            ScannedContainerEntity scannedContainer2 = o2.getScannedContainer();
            if (scannedContainer1.getScannedContainerId().equals(scannedContainer2.getScannedContainerId())) {
                return WELL_NUMBER_COMPARATOR.compare(o1.getWellNumber(), o2.getWellNumber());
            }

            return scannedContainer1.getScanOrder() - scannedContainer2.getScanOrder();
        }
    };

    private final Pattern WELL_NUMBER_PATTERN = Pattern.compile("([a-zA-Z]+)(\\d+)");

    private final Comparator<String> WELL_NUMBER_COMPARATOR = new Comparator<String>() {
        @Override
        public int compare(String o1, String o2) {
            Matcher matcher1 = WELL_NUMBER_PATTERN.matcher(o1);
            Matcher matcher2 = WELL_NUMBER_PATTERN.matcher(o2);

            if (matcher1.matches() && matcher2.matches()) {
                String chars1 = matcher1.group(1);
                String chars2 = matcher2.group(1);

                if (chars1.compareToIgnoreCase(chars2) == 0) {
                    Integer number1 = new Integer(matcher1.group(2));
                    Integer number2 = new Integer(matcher2.group(2));

                    return number1.compareTo(number2);
                } else {
                    if (chars1.length() == chars2.length()) {
                        return chars1.compareToIgnoreCase(chars2);
                    }

                    return chars1.length() - chars2.length();
                }
            }

            return 0;
        }
    };


    @Autowired
    private TissuePlateWellDao tissuePlateWellDao;

    @Override
    public List<TissuePlateWellEntity> getTissuePlateWells(ShipmentPackingListEntity packingListEntity) {
        if (packingListEntity.getShipmentType().getContentType() == ContentType.TISSUE_PLATE) {

            List<ScannedContainerEntity> tissuePlateContainerEntities = Lists.newArrayList();
            List<ScannedContainerEntity> otherContainerEntities = Lists.newArrayList();
            Collection<ShipmentContainerEntity> shipmentContainers = packingListEntity.getShipmentContainers();

            for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
                StorageContainerEntity storageContainerEntity = shipmentContainer.getStorageContainer();
                List<ScannedContainerEntity> scannedContainerEntities = storageContainerEntity.getContainers();
                for (ScannedContainerEntity scannedContainerEntity : scannedContainerEntities) {
                    if(ContentType.TISSUE_PLATE.equals(scannedContainerEntity.getContentType())){
                        tissuePlateContainerEntities.add(scannedContainerEntity);
                    } else if(ContentType.OTHER.equals(scannedContainerEntity.getContentType())){
                        otherContainerEntities.add(scannedContainerEntity);
                    }
                }
            }

            List<TissuePlateWellEntity> tissuePlateWells = Lists.newArrayList(tissuePlateWellDao.getTissuePlateWells(tissuePlateContainerEntities));

            for (ScannedContainerEntity otherContainerEntity : otherContainerEntities) {
                tissuePlateWells.add(new TissuePlateWellEntity(otherContainerEntity, ""));
            }

            Collections.sort(tissuePlateWells, TISSUE_PLATE_WELL_COMPARATOR);
            return tissuePlateWells;
        }
        return null;
    }
}
