package com.monsanto.tps.shipping.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.CommodityEntity;
import com.monsanto.tps.shipping.domain.ProgramEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Service
public class CommodityBusinessImpl implements CommodityBusiness {

    public static final double DEFAULT_CUSTOMS_VALUE = 20.00;
    @Autowired
    private ProgramBusiness programBusiness;


    @Trace
    @Override
    public void associateCommodity(ShipmentEntity shipmentEntity) {

        String toIsoCountryCode = shipmentEntity.getToAddress().getIsoCountryCode();
        String fromIsoCountryCode = shipmentEntity.getFromAddress().getIsoCountryCode();

        if (!toIsoCountryCode.equals(fromIsoCountryCode)) {
            CommodityEntity commodityEntity = new CommodityEntity();

            commodityEntity.setDescription(buildDescription(shipmentEntity.getFromAccountId()));
            commodityEntity.setCountryOfManufactureISOCode(fromIsoCountryCode);
            commodityEntity.setCustomsValue(DEFAULT_CUSTOMS_VALUE);
            commodityEntity.setQuantity(getContentCount(shipmentEntity.getShipmentContainers()));
            commodityEntity.setWeight(shipmentEntity.getWeight());
            commodityEntity.setUnitOfMeasureId(shipmentEntity.getWeightUOMId());
            commodityEntity.setShipment(shipmentEntity);

            shipmentEntity.setCommodities(Lists.newArrayList(commodityEntity));
        }
    }

    private String buildDescription(Long fromAccountId) {
        ProgramEntity programEntity = programBusiness.getProgramByAccount(fromAccountId);

        return programEntity.getCrop().getName() + " - " + programEntity.getRefId();
    }

    private Integer getContentCount(Collection<ShipmentContainerEntity> shipmentContainers) {
        int totalContent = 0;

        for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
            totalContent += shipmentContainer.getStorageContainer().getContainers().size();
        }

        return totalContent;
    }
}
