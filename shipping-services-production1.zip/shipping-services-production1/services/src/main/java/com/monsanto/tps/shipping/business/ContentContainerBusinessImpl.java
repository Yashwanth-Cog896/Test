package com.monsanto.tps.shipping.business;

import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.MultiContentContainerEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Service
public class ContentContainerBusinessImpl implements ContentContainerBusiness {

    @Trace
    @Override
    public Collection<ScannedContainerEntity> getAllContentContainers(ShipmentPackingListEntity packingList) {

        Collection<ScannedContainerEntity> contentContainers = Sets.newHashSet();

        if (CollectionUtils.isEmpty(packingList.getShipmentContainers())) {
            return contentContainers;
        }

        for (ShipmentContainerEntity shipmentContainer : packingList.getShipmentContainers()) {
            if (shipmentContainer.getStorageContainer() != null) {
                for (ScannedContainerEntity contentContainerEntity : shipmentContainer.getStorageContainer().getContainers()) {
                    contentContainers.add(contentContainerEntity);
                }
            }
        }

        return contentContainers;
    }

    @Trace
    @Override
    public Collection<ScannedContainerEntity> getAllContentContainersWithContent(ShipmentPackingListEntity packingList, ContentEntity content) {
        Collection<ScannedContainerEntity> contentContainersWithContent = Sets.newHashSet();

        Collection<ScannedContainerEntity> allContentContainers = getAllContentContainers(packingList);

        for (ScannedContainerEntity contentContainer : allContentContainers) {

            if (contentContainer instanceof MultiContentContainerEntity) {
                if (((MultiContentContainerEntity) contentContainer).getContents().contains(content)) {
                    contentContainersWithContent.add(contentContainer);
                }
            } else {
                if (contentContainer.getContent().equals(content)) {
                    contentContainersWithContent.add(contentContainer);
                }
            }
        }

        return contentContainersWithContent;
    }
}
