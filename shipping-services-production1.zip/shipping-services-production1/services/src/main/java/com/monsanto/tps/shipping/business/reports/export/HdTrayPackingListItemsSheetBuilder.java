package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.HDTrayEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

@Service
public class HdTrayPackingListItemsSheetBuilder extends AbstractPackingListItemsSheetBuilder {

    private final static String[] HEADER = {"Item #", "Tray ID", "Lims ID", "Project Name", "Inv BIDs", "Events", "Box Barcode", "Monsanto ID", "Permit"};

    @Override
    protected String[] getHeader() {
        return HEADER;
    }

    @Override
    protected void addItemRows(Sheet sheet, CellStyle defaultCellStyle, ShipmentPackingListEntity packingList) {
        int currentRowIndex = 1;
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedContentContainerEntities(packingList);
        Collection<Event> events = getPermits(packingList);
        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            HDTrayEntity content = (HDTrayEntity) contentContainerEntity.getContent();
            String eventString = getEventString(content);
            Event event = getEventForContainer(contentContainerEntity.getContainerId(), events);

            Row row = sheet.createRow(currentRowIndex);
            appendCell(row, defaultCellStyle, contentContainerEntity.getScanOrder());
            appendCell(row, defaultCellStyle, content.getBarcode());
            appendCell(row, defaultCellStyle, content.getLimsId());
            appendCell(row, defaultCellStyle, content.getProjectName());
            appendCell(row, defaultCellStyle, content.getInventoryBarCodes());
            appendCell(row, defaultCellStyle, eventString);
            appendCell(row, defaultCellStyle, contentContainerEntity.getStorageContainer().getBarcode());
            appendCell(row, defaultCellStyle, getMonsantoIdString(event));
            appendCell(row, defaultCellStyle, getPermitString(event));

            currentRowIndex++;
        }
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.HD_TRAY;
    }
}

