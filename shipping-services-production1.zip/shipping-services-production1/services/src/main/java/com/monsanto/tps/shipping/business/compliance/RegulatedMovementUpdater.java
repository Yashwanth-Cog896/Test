package com.monsanto.tps.shipping.business.compliance;

import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;

import java.util.Collection;
import java.util.List;

public interface RegulatedMovementUpdater<T> {

    Collection<RegulatedInventoryMovementEntity> createRegulatedMovements(ShipmentPackingListEntity packingList, Collection<T> contents, AgencyEntity agencyEntity, Event event);

}
