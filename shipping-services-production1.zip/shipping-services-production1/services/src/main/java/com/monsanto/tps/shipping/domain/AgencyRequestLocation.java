package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Created by slaks on 2/24/14.
 */
@Entity
@Table(name = "AGENCY_REQUEST_LOCATION", schema = "FCM")
public class AgencyRequestLocation {

    @Id
    @Column(name = "LOCATION_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "AGENCY_REQUEST_ID")
    private AgencyRequestEntity agencyRequest;

    @Column(name = "CONTACT_ID")
    private Long contactId;

    @Type(type = "true_false")
    @Column(name = "ORIGIN_FLAG")
    private Boolean originFlag;

    @Type(type = "true_false")
    @Column(name = "DESTINATION_FLAG")
    private Boolean destinationFlag;

    public Boolean isDestinationFlag() {
        return destinationFlag;
    }

    public void setDestinationFlag(Boolean destinationFlag) {
        this.destinationFlag = destinationFlag;
    }

    public Boolean isOriginFlag() {
        return originFlag;
    }

    public void setOriginFlag(Boolean originFlag) {
        this.originFlag = originFlag;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    @Transient
    public Long getAgencyRequestId() {
        return agencyRequest.getId();
    }

    public AgencyRequestEntity getAgencyRequest() {
        return agencyRequest;
    }

    public void setAgencyRequest(AgencyRequestEntity agencyRequest) {
        this.agencyRequest = agencyRequest;
    }

    @Override
    public String toString() {
        return "AgencyRequestLocation{" +
                ", locationId='" + id + '\'' +
                ", agencyRequestId='" + getAgencyRequestId() + '\'' +
                ", contactId=" + contactId +
                ", originFlag=" + originFlag +
                ", destinationFlag='" + destinationFlag + '\'' +
                '}';
    }
}
