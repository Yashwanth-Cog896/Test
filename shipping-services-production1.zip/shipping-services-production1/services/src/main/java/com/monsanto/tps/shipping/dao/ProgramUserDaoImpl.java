package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ProgramUserEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User: DCENGL
 */
@Repository
public class ProgramUserDaoImpl implements ProgramUserDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public List<ProgramUserEntity> findByLoginId(String userName) {
        return sessionFactory.getCurrentSession()
                .createQuery("from ProgramUserEntity " +
                        "where upper(user.loginId) = :userId " +
                        "and program.accountId is not null " +
                        "and refActive = true")
                .setParameter("userId", userName.toUpperCase())
                .list();

    }
}
