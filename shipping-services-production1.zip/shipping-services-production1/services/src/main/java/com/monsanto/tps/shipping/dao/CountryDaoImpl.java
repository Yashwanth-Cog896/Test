package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CountryEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.or;

/**
 * User: pgadi
 */
@Repository
public class CountryDaoImpl implements CountryDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public CountryEntity getCountry(String countryAbbr) {
        return (CountryEntity) sessionFactory.getCurrentSession()
                .createCriteria(CountryEntity.class)
                .add(or(eq("countryAbbr", countryAbbr), eq("isoCode", countryAbbr)))
                .uniqueResult();
    }
}
