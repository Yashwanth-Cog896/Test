package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;

import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface RegulatedStatusCheck {
    List<RegulatedAPIResponse> checkRegulatedStatus(Collection<Event> events, Set<String> allEventStrings);
    Collection<Event> getEpaEvents(Collection<Event> events, List<RegulatedAPIResponse> responseMap);
    Collection<Event> getRegulatedEvents(Collection<Event> events, List<RegulatedAPIResponse> responseMap);
    Collection<Event> getStewardshipEvents(ShipmentPackingListEntity packingListEntity, Collection<Event> events,
                                           Collection<String> eventStrings, List<RegulatedAPIResponse> responseMap);
}
