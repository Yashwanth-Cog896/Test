package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.InternationalCompositesBusiness;
import com.monsanto.tps.shipping.service.model.InternationalCarrier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * User: pgadi
 */
@Component("internationalCarrierService")
public class InternationalCarrierServiceImpl implements InternationalCarrierService {

    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    @Override
    @Transactional
    public List<InternationalCarrier> getCarriers() {
        return internationalCompositesBusiness.getCarriers();
    }
}
