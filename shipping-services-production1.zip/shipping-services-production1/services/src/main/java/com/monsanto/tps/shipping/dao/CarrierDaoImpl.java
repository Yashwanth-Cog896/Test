package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Repository
public class CarrierDaoImpl implements CarrierDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    @Cacheable("METHOD_CACHE")
    public CarrierEntity findCarrier(Long carrierId) {
        return (CarrierEntity)sessionFactory.getCurrentSession().load(CarrierEntity.class, carrierId);
    }

    @Trace
    @Override
    @SuppressWarnings("unchecked")
    public List<CarrierEntity> findCarriersByAccountId(Long accountId) {
        return sessionFactory.getCurrentSession().createQuery("select cci.carrier from CarrierCurrInstructEntity cci " +
                "where cci.irdAcct = :accountId and cci.carrier.refActive = true").setLong("accountId", accountId).list();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public List<CarrierEntity> findAllCarriers() {
        return sessionFactory.getCurrentSession().createQuery("from CarrierEntity ce where ce.refActive = true").list();
    }

    @Override
    public List<CarrierEntity> findCarriersByIntegration(boolean integrated) {
        return sessionFactory.getCurrentSession().createQuery(
                "from CarrierEntity ce where ce.refActive = true and ce.supportIntegratedShipping = :integrated").setBoolean("integrated", integrated).list();
    }
 }