package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ProgramEntity;

import java.util.List;

/**
 * User: DCENGL
 */
public interface ProgramDao {

    List<ProgramEntity> findProgramsByAccountId(Long accountId);

    List<ProgramEntity> getActivePrograms();

    List<ProgramEntity> getGrowerProgramsByPackingListId(Long packingListId);

    List<ProgramEntity> getGrowerProgramsForMixedPlots(Long packingListId);

    ProgramEntity getShipToProgramForHarvestedPlotBarcode(String barcode);

    ProgramEntity getShipToProgramForToBePlantedPlotBarcode(String barcode);

    List<ProgramEntity> getProgramsByAccountIdExcludePipelineFunctions(Long accountId);

}
