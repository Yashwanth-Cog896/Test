package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;

import java.util.Collection;
import java.util.List;

/**
 * User: sdchil
 * Date: 9/18/13
 */
public interface PlotDao {

    List<? extends ContentEntity> findByBarcode(String barcode);

    List<? extends ContentEntity> findByBarcode(Collection<String> barcodes);

    Collection<PlotEntity> findBinaryFemalePlotWithNoMalePlots(Collection<Long> femalePlotIds);

    Collection<PlotEntity> findPlotsWithoutAnOperation(Collection<Long> femalePlotIds);
}
