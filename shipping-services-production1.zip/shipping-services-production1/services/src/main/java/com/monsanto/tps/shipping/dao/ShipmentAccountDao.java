package com.monsanto.tps.shipping.dao;

/**
 * User: PGADI
 */
public interface ShipmentAccountDao {
    Long getAccountIdByProgramRefId(String programRefId);
}
