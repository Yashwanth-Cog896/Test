package com.monsanto.tps.shipping.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author tnava1
 */
@Entity
@Table(name = "PIPELINE_FUNCTION", schema = "MIDAS")
public class PipelineFunctionEntity {
    @Id
    @Column(name = "PIPELINE_FUNCTION_ID", nullable = false)
    private Long pipelineFunctionId;

    @Column(name = "REF_ID")
    private String refId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "INACTIVE_DTTM")
    private Date inactiveDttm;

    public PipelineFunctionEntity() {}

    public PipelineFunctionEntity(String refId) {
        this.refId = refId;
    }

    public Long getPipelineFunctionId() {
        return pipelineFunctionId;
    }

    public void setPipelineFunctionId(Long pipelineFunctionId) {
        this.pipelineFunctionId = pipelineFunctionId;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    @Override
    public String toString() {
        return "PipelineFunctionEntity{" +
                "pipelineFunctionId=" + pipelineFunctionId +
                ", refId='" + refId + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", inactiveDttm='" + inactiveDttm + '\'' +
                '}';
    }
}
