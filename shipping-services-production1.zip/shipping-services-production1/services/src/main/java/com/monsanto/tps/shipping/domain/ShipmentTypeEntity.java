package com.monsanto.tps.shipping.domain;

import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

/**
 * User: pgadi
 */
@Entity
@Table(name="SHIPMENT_TYPE", schema="INVENTORY_MGT")
public class ShipmentTypeEntity {
    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    @Column(name="SHIPMENT_TYPE_ID")
    private Long shipmentTypeId;

    @Column(name="NAME")
    private String name;

    @Column(name="DESCRIPTION")
    private String description;

    @Column(name="HARVESTED_TYPE")
    @Type(type="true_false")
    private boolean harvested;

    @Column(name="WEIGHT_REQUIRED")
    @Type(type="true_false")
    private boolean weightRequired;

    @Column(name="INACTIVE_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date inactiveDateTime;

    @Column(name="INTENT_REQUIRED")
    @Type(type="true_false")
    private boolean intentRequired;

    @ManyToOne
    @JoinColumn(name="SOURCE_SYSTEM_ID")
    private SourceSystem sourceSystem;

    public ShipmentTypeEntity() { }  // required for hibernate

    public ShipmentTypeEntity(String name) {
        this.name = name;
    }

    public Long getShipmentTypeId() {
        return shipmentTypeId;
    }

    public void setShipmentTypeId(Long shipmentTypeId) {
        this.shipmentTypeId = shipmentTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isHarvested() {
        return harvested;
    }

    public void setHarvested(boolean harvested) {
        this.harvested = harvested;
    }

    public boolean isWeightRequired() {
        return weightRequired;
    }

    public void setWeightRequired(boolean weightRequired) {
        this.weightRequired = weightRequired;
    }

    public Date getInactiveDateTime() {
        return inactiveDateTime;
    }

    public void setInactiveDateTime(Date inactiveDateTime) {
        this.inactiveDateTime = inactiveDateTime;
    }

    public boolean isIntentRequired() {
        return intentRequired;
    }

    public void setIntentRequired(boolean intentRequired) {
        this.intentRequired = intentRequired;
    }

    public SourceSystem getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(SourceSystem sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public ContentType getContentType() {
        return getShipmentTypeEnum().getContentType();
    }

    public ShipmentTypeEnum getShipmentTypeEnum() {
        return ShipmentTypeEnum.getInstance(getName());
    }

    @Override
    public String toString() {
        return "ShipmentTypeEntity{" +
                "name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ShipmentTypeEntity that = (ShipmentTypeEntity) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }
}
