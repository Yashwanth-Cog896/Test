package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.transfer.GlobalTradeDocuments;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/global-trade-documents")
public interface GlobalTradeDocumentsService {

    @GET
    @Produces(APPLICATION_JSON)
    @Path("/list/sap-order-shipment-id/{sap-order-shipment-id}")
    public List<GlobalTradeDocuments> getGlobalTradeDocumentsList(@PathParam("sap-order-shipment-id") Long sapOrderShipmentId);

    @GET
    @Produces("application/pdf")
    @Path("/download/file/{encodedDocumentUrl}/title/{encodedTitle}")
    public HttpServletResponse getGlobalTradeDocumentPdf(@PathParam("encodedDocumentUrl") String encodedDocumentUrl,
                                                         @PathParam("encodedTitle") String encodedTitle);

}
