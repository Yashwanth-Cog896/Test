package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Sets;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * User: pgadi
 */
@Entity
@Table(name = "SHIPMENT", schema = "INVENTORY_MGT")
public class ShipmentEntity {
    @Id
    @Column(name = "SHIPMENT_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    private Long shipmentId;
    @Column(name= "BARCODE", nullable = false)
    private String shipmentBarcode;
    @ManyToOne
    @JoinColumn(name = "SOURCE_SYSTEM_ID", nullable = false)
    private SourceSystem sourceSystem;
    @ManyToOne
    @JoinColumn(name = "SHIPMENT_TYPE_ID")
    private ShipmentTypeEntity shipmentType;
    @ManyToOne
    @JoinColumn(name = "SHIPPING_STATUS_ID", nullable = false)
    private ShippingStatus status;
    @Column(name = "ACCT_ID_FROM")
    private Long fromAccountId;
    @Column(name= "SHPMT_CONTENT_PRCSG_STAT_ID")
    private Long shipmentContentProcessedStateId;
    @Column(name = "ACCT_ID_TO")
    private Long toAccountId;
    @Column(name = "COMMENTS")
    private String comments;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CONTACT_ID_FROM", nullable = false)
    private ShipmentContactEntity fromContact;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "shipment", fetch = FetchType.LAZY)
    private Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptions = Sets.newHashSet();
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CONTACT_ID_TO", nullable = false)
    private ShipmentContactEntity toContact;
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "ADDRESS_ID_FROM")
    private ShipmentAddressEntity fromAddress;
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "ADDRESS_ID_TO")
    private ShipmentAddressEntity toAddress;
    @Column(name = "BILL_TO_ACCT_ID")
    private Long billToAccountId;
    @Column(name = "WEIGHT")
    private Double weight;
    @Column(name = "WEIGHT_UOM_ID")
    private Long weightUOMId;
    @Column(name = "INSURED_VALUE")
    private Double insuredValue;
    @Column(name = "DECLARED_VALUE")
    private Double declaredValue;
    @Column(name = "CURRENCY_ID")
    private Long currencyId;
    @Column(name = "SHIPMENT_COST")
    private Double shipmentCost;
    @Column(name= "SENDER_ACCT_NUM")
    private String senderAccountNumber;
    @Column(name= "METER_NUM")
    private String meterNumber;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CARRIER_ID")
    private CarrierEntity carrier;
    @Column(name = "CARRIER_TRACKING_ID")
    private String trackingNumber;
    @Column(name = "CONTACT_EMAIL_ADDRESS_TXT")
    private String notificationEmails;
    @Type(type = "true_false")
    @Column(name = "RECEIVED_IN_GOOD_CONDITION_IND")
    private Boolean receivedInGoodCondition;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "shipment", fetch = FetchType.LAZY)
    private Collection<CommodityEntity> commodities;
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "shipment")
    private Collection<ShipmentContainerEntity> shipmentContainers;
    @Formula("(select min(ssh.status_date)\n" +
            "from INVENTORY_MGT.SHIPMENT_STATUS_HISTORY ssh, inventory_mgt.shipping_status ss\n" +
            "where SSH.SHIPPING_STATUS_ID = SS.SHIPPING_STATUS_ID\n" +
            "and SSH.SHIPPING_STATUS_ID = SS.SHIPPING_STATUS_ID\n" +
            "and SSH.SHIPMENT_ID = SHIPMENT_ID\n" +
            "and ss.name in ('Ready for Pickup', 'In Transit'))")
    private Date shipDate;
    @Formula(" (select sap.SAP_ORDER_NBR from INVENTORY_MGT.SHPMT_PKG_LIST pl join INVENTORY_MGT.SAP_ORDER_SHIPMENT sap on pl.SAP_ORDER_SHIPMENT_ID =sap.SAP_ORDER_SHIPMENT_ID where pl.SHIPMENT_BARCODE = BARCODE) ")
    private String sapOrderNumber;
    @Transient
    private boolean brokerCheckRequired;

    public Long getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(Long shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getShipmentBarcode() {
        return shipmentBarcode;
    }

    public void setShipmentBarcode(String shipmentBarcode) {
        this.shipmentBarcode = shipmentBarcode;
    }

    public SourceSystem getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(SourceSystem sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public ShipmentTypeEntity getShipmentType() {
        return shipmentType;
    }

    public void setShipmentType(ShipmentTypeEntity shipmentType) {
        this.shipmentType = shipmentType;
    }

    public ShippingStatus getStatus() {
        return status;
    }

    public void setStatus(ShippingStatus status) {
        this.status = status;
    }

    public Long getFromAccountId() {
        return fromAccountId;
    }

    public void setFromAccountId(Long fromAccountId) {
        this.fromAccountId = fromAccountId;
    }

    public Long getShipmentContentProcessedStateId() {
        return shipmentContentProcessedStateId;
    }

    public void setShipmentContentProcessedStateId(Long shipmentContentProcessedStateId) {
        this.shipmentContentProcessedStateId = shipmentContentProcessedStateId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Long getToAccountId() {
        return toAccountId;
    }

    public void setToAccountId(Long toAccountId) {
        this.toAccountId = toAccountId;
    }

    public ShipmentContactEntity getFromContact() {
        return fromContact;
    }

    public void setFromContact(ShipmentContactEntity fromContact) {
        this.fromContact = fromContact;
    }

    public void setToContact(ShipmentContactEntity toContact) {
        this.toContact = toContact;
    }

    public ShipmentContactEntity getToContact() {
        return toContact;
    }

    public void setFromAddress(ShipmentAddressEntity fromAddress) {
        this.fromAddress = fromAddress;
    }

    public ShipmentAddressEntity getFromAddress() {
        return fromAddress;
    }

    public void setToAddress(ShipmentAddressEntity toAddress) {
        this.toAddress = toAddress;
    }

    public ShipmentAddressEntity getToAddress() {
        return toAddress;
    }


    public void setBillToAccountId(Long billToAccountId) {
        this.billToAccountId = billToAccountId;
    }

    public Long getBillToAccountId() {
        return billToAccountId;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeightUOMId(Long weightUOMId) {
        this.weightUOMId = weightUOMId;
    }

    public Long getWeightUOMId() {
        return weightUOMId;
    }

    public Double getInsuredValue() {
        return insuredValue;
    }

    public void setInsuredValue(Double insuredValue) {
        this.insuredValue = insuredValue;
    }

    public Double getDeclaredValue() {
        return declaredValue;
    }

    public void setDeclaredValue(Double declaredValue) {
        this.declaredValue = declaredValue;
    }

    public Long getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(Long currencyId) {
        this.currencyId = currencyId;
    }

    public Double getShipmentCost() {
        return shipmentCost;
    }

    public void setShipmentCost(Double shipmentCost) {
        this.shipmentCost = shipmentCost;
    }

    public CarrierEntity getCarrier() {
        return carrier;
    }

    public void setCarrier(CarrierEntity carrier) {
        this.carrier = carrier;
    }

    public String getSenderAccountNumber() {
        return senderAccountNumber;
    }

    public void setSenderAccountNumber(String senderAccountNumber) {
        this.senderAccountNumber = senderAccountNumber;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public Collection<ShipmentCarrierOptionEntity> getShipmentCarrierOptions() {
        return shipmentCarrierOptions;
    }

    public void setShipmentCarrierOptions(Collection<ShipmentCarrierOptionEntity> shipmentCarrierOption) {
        this.shipmentCarrierOptions = shipmentCarrierOption;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public Collection<ShipmentContainerEntity> getShipmentContainers() {
        return shipmentContainers;
    }

    public void setShipmentContainers(Collection<ShipmentContainerEntity> shipmentContainers) {
        this.shipmentContainers = shipmentContainers;
    }

    public Date getShipDate() {
        return shipDate;
    }

    public void setShipDate(Date shipDate) {
        this.shipDate = shipDate;
    }

    public String getNotificationEmails() {
        return notificationEmails;
    }

    public void setNotificationEmails(String notificationEmails) {
        this.notificationEmails = notificationEmails;
    }

    private List<?> identityValues() {
        return Arrays.asList(shipmentId, shipmentBarcode);
    }

    public Boolean getReceivedInGoodCondition() {
        return receivedInGoodCondition;
    }

    public void setReceivedInGoodCondition(Boolean receivedInGoodCondition) {
        this.receivedInGoodCondition = receivedInGoodCondition;
    }

    public Collection<CommodityEntity> getCommodities() {
        return commodities;
    }

    public void setCommodities(Collection<CommodityEntity> commodities) {
        this.commodities = commodities;
    }

    public boolean isBrokerCheckRequired() { return brokerCheckRequired; }

    public void setBrokerCheckRequired(boolean brokerCheckRequired) { this.brokerCheckRequired = brokerCheckRequired; }

    public String getSapOrderNumber() {
        return sapOrderNumber;
    }

    public void setSapOrderNumber(String sapShipmentNumber) {
        this.sapOrderNumber = sapShipmentNumber;
    }

    @Override
    public boolean equals(Object object) {
        return object == this || (object instanceof ShipmentEntity && equalsImpl((ShipmentEntity) object));
    }

    private boolean equalsImpl(ShipmentEntity shipment) {
        return identityValues().equals(shipment.identityValues());
    }

    @Override
    public int hashCode() {
        return identityValues().hashCode();
    }

    @Override
    public String toString() {
        return shipmentBarcode;
    }
}
