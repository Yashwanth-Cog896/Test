package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.AgencyBusiness;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.service.model.Agency;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Component("agencyService")
public class AgencyServiceImpl implements AgencyService {

    @Autowired
    private AgencyBusiness agencyBusiness;

    @Trace
    @Transactional(readOnly = true)
    @Override
    public Collection<Agency> getAgencies() {
        Collection<AgencyEntity> agencyEntities = agencyBusiness.getAllActive();

        return toTransferObject(agencyEntities);
    }

    private Collection<Agency> toTransferObject(Collection<AgencyEntity> agencyEntities) {
        Collection<Agency> agencies = Lists.newArrayList();
        for (AgencyEntity agencyEntity : agencyEntities) {
            Agency agency = new Agency();
            agency.setId(agencyEntity.getAgencyId());
            agency.setReferenceId(agencyEntity.getAbbr());

            agencies.add(agency);
        }

        return agencies;
    }
}
