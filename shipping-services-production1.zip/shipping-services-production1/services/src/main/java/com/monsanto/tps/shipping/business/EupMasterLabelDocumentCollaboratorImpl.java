package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.tps.compliance.epa.EpaLabelDocument;
import com.monsanto.tps.compliance.epa.services.EpaDocumentService;
import com.monsanto.tps.shipping.domain.EupEventWeight;
import com.monsanto.tps.shipping.domain.EupMasterLabel;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class EupMasterLabelDocumentCollaboratorImpl implements EupMasterLabelDocumentCollaborator {
    @Resource
    private EpaDocumentService epaDocumentService;
    @Resource
    private EupMasterLabelSummaryBuilder eupMasterLabelSummaryBuilder;

    private static final Function<? super EupEventWeight, ? extends String> MONSANTO_IDS_FROM_EUP_LABEL_RESPONSE_FUNCTION = new Function<EupEventWeight, String>() {
        @Override
        public String apply(@Nullable EupEventWeight eupEventWeight) {
            return eupEventWeight.getMonsantoId();
        }
    };

    private static final Function<? super EpaLabelDocument, ? extends String> EUP_NUMBER_FROM_EPA_LABEL_DOCUMENT_FUNCTION = new Function<EpaLabelDocument, String>() {
        @Override
        public String apply(EpaLabelDocument epaLabelDocument) {
            return epaLabelDocument.getEupNumber();
        }
    };

    @Override
    public Collection<EupMasterLabel> fetchEupMasterLabels(Collection<EupEventWeight> eupEventWeights) throws ShippingWebException {
        Set<String> monsantoIds = getDistinctMonsantoIds(eupEventWeights);
        if (CollectionUtils.isEmpty(monsantoIds)) {
            return new ArrayList<EupMasterLabel>();
        }

        return concatenateMasterLabelAndWeightSummary(eupEventWeights, monsantoIds);
    }

    private Collection<EupMasterLabel> concatenateMasterLabelAndWeightSummary(Collection<EupEventWeight> eupEventWeights, Set<String> monsantoIds) throws ShippingWebException {
        Collection<EupMasterLabel> epaMasterLabels = new ArrayList<EupMasterLabel>();

        Map<String, EpaLabelDocument> epaMasterLabelMap = buildEpaMasterLabelMap(monsantoIds);

        for (EupEventWeight eupEventWeight : eupEventWeights) {
            String monsantoId = eupEventWeight.getMonsantoId();
            EpaLabelDocument epaLabel = epaMasterLabelMap.get(monsantoId);
            if (epaLabel.getEpaLabel() != null) {
                ByteArrayOutputStream concatenatedLabel = eupMasterLabelSummaryBuilder.concatenateDocuments(eupEventWeight.getEventWeightCollection(), getEpaLabelOutputStream(epaLabel), eupEventWeight.getAgencyNumber());
                epaMasterLabels.add(createEupMasterLabel(eupEventWeight.getAgencyNumber(), concatenatedLabel));
            }
        }

        return epaMasterLabels;
    }

    private EupMasterLabel createEupMasterLabel(String agencyNumber, ByteArrayOutputStream concatenatedLabel) {
        EupMasterLabel eupMasterLabel = new EupMasterLabel();
        eupMasterLabel.setAgencyApprovalNumber(agencyNumber);
        eupMasterLabel.setLabelStream(concatenatedLabel);
        return eupMasterLabel;
    }

    private Set<String> getDistinctMonsantoIds(Collection<EupEventWeight> eupLabelResponseList) {
        Set<String> monsantoIds = new HashSet<String>();
        if (!CollectionUtils.isEmpty(eupLabelResponseList)) {
            monsantoIds.addAll(Collections2.transform(eupLabelResponseList, MONSANTO_IDS_FROM_EUP_LABEL_RESPONSE_FUNCTION));
        }

        return monsantoIds;
    }

    private Map<String, EpaLabelDocument> buildEpaMasterLabelMap(Set<String> monsantoIds) {
        return Maps.uniqueIndex(retrieveLabels(monsantoIds), new Function<EpaLabelDocument, String>() {
            @Override
            public String apply(EpaLabelDocument input) {
                return input.getEupNumber();
            }
        });
    }

    private List<EpaLabelDocument> retrieveLabels(Set<String> epaMonsantoId) {
        List<EpaLabelDocument> epaLabels = callDocumentServiceAndRetrieveLabels(Lists.newArrayList(epaMonsantoId));

        if (CollectionUtils.isEmpty(epaLabels)) {
            throw new ShippingWebException("Epa Master Labels not found for monsanto ids: " + epaMonsantoId);
        }

        List<String> epaIdsWithLabels = Lists.transform(epaLabels, EUP_NUMBER_FROM_EPA_LABEL_DOCUMENT_FUNCTION);

        for (String epaId : epaMonsantoId) {
            if (!epaIdsWithLabels.contains(epaId)) {
                epaLabels.add(new EpaLabelDocument(epaId, null));
            }
        }
        return epaLabels;
    }

    private List<EpaLabelDocument> callDocumentServiceAndRetrieveLabels(List<String> epaIds) {
        List<EpaLabelDocument> epaLabels = epaDocumentService.getEpaLabels(epaIds);
        if (epaLabels != null) {
            return epaLabels;
        }
        return new ArrayList<EpaLabelDocument>();
    }

    private ByteArrayOutputStream getEpaLabelOutputStream(EpaLabelDocument epaLabel) throws ShippingWebException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        try {
            epaLabel.getEpaLabel().getDataHandler().writeTo(stream);
        } catch (IOException e) {
            throw new ShippingWebException(e);
        }
        return stream;
    }
}