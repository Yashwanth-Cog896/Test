package com.monsanto.tps.shipping.service;


import com.monsanto.tps.shipping.service.model.ReportResponse;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 * Created by RLCASW on 5/11/14.
 */
@Path("/report")
@Api(value = "/report", description = "Operations for downloading reports for packing lists and shipments")
public interface ReportService {

    @GET
    @Path("/{reportName}/packing-list/{packingListId}")
    @Produces({"application/json", "application/xls", "application/pdf", "application/zip"})
    public ReportResponse getReport(@PathParam("packingListId") Long packingListId, @PathParam("reportName") String reportName);

    @GET
    @Path("/packing-list/{packingListId}")
    @Produces({"application/json", "application/zip"})
    @ApiOperation(value = "Get multiple reports all at once and bundle in a zip file")
    public ReportResponse getReports(@PathParam("packingListId") Long packingListId);
}
