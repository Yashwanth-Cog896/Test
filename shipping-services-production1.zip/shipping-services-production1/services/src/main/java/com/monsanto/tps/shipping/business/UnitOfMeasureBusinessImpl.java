package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.UnitOfMeasureConversionDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureGroupDao;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * User: pgadi
 */
@Service
public class UnitOfMeasureBusinessImpl implements UnitOfMeasureBusiness {

    @Autowired
    private UnitOfMeasureGroupDao unitOfMeasureGroupDao;
    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;
    @Autowired
    private UnitOfMeasureConversionDao unitOfMeasureConversionDao;

    public List<UnitOfMeasureEntity> getUnitOfMeasuresList() {
        return unitOfMeasureGroupDao.getValidUnitOfMeasuresForShippingGroup();
    }

    @Override
    public UnitOfMeasureEntity getUnitOfMeasure(Long uomId) {
        return unitOfMeasureDao.load(uomId);
    }

    @Override
    public UnitOfMeasureEntity getUnitOfMeasure(String refId) {
        return unitOfMeasureGroupDao.findByAbbreviation(refId);
    }

    @Override
    public UnitOfMeasureEntity getUnitOfMeasureByName(String name) {
        return unitOfMeasureDao.findByName(name);
    }

    @Override
    public UnitOfMeasureConversionEntity getUomConversion(Long fromUomId, Long toUomId) {
        return unitOfMeasureConversionDao.getUomConversion(fromUomId, toUomId);
    }

    @Override
    public Long getUnitOfMeasureMidasId(String refId) {
        Long uomId = null;
        UnitOfMeasureEntity uom = getUnitOfMeasure(refId);
        if (uom != null) {
            uomId = uom.getId();
        }
        return uomId;
    }

    @Override
    public Long convertInventoryMgtUomIdToMidasId(Long inventoryMgtUomId) {
        if (inventoryMgtUomId == null) {
            return null;
        }
        String uom = unitOfMeasureDao.getAbbreviationFromInventoryMgtUomId(inventoryMgtUomId);
        if (uom == null) {
            return null;
        }
        UnitOfMeasureEntity uomEntity = getUnitOfMeasure(uom);
        if (uomEntity == null) {
            return null;
        }
        return uomEntity.getId();
    }

    @Trace
    @Override
    public Long getPackingListUomId(ShipmentPackingListEntity shipmentPackingListEntity) {
        for (ShipmentContainerEntity shipmentContainer : shipmentPackingListEntity.getShipmentContainers()) {
            for (ScannedContainerEntity<?> scannedContainer : shipmentContainer.getStorageContainer().getContainers()) {
                if (scannedContainer.getWeightUOM() != null) {
                    return scannedContainer.getWeightUOM().getId();
                }
            }
        }
        // fallback to container
        for (ShipmentContainerEntity shipmentContainer : shipmentPackingListEntity.getShipmentContainers()) {
            if (shipmentContainer.getUomId() != null) {
                Long uomId = convertInventoryMgtUomIdToMidasId(shipmentContainer.getUomId());
                if (uomId != null) {
                    return uomId;
                }
            }
        }
        return null;
    }

    @Trace
    @Override
    public Long getInventoryMgtUomIdFromAbbreviation(String refId) {
        return unitOfMeasureDao.getInventoryMgtUomIdFromAbbreviation(refId);
    }
}
