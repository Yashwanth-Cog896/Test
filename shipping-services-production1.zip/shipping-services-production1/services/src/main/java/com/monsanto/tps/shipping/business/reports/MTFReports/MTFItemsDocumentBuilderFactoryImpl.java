package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class MTFItemsDocumentBuilderFactoryImpl implements MTFItemsDocumentBuilderFactory {

    @Autowired
    private Collection<MTFItemsDocumentBuilder> pageBuilders;

    @Override
    public MTFItemsDocumentBuilder getDocumentBuilder(ShipmentPackingListEntity shipmentPackingListEntity) {

        ShipmentTypeEntity shipmentType = shipmentPackingListEntity.getShipmentType();

        for (MTFItemsDocumentBuilder pageBuilder : pageBuilders) {
            if (pageBuilder.canBuild(shipmentType)) {
                return pageBuilder;
            }
        }

        throw new IllegalArgumentException("Cannot build MTF .pdf for: " + shipmentType.getName());
    }
}
