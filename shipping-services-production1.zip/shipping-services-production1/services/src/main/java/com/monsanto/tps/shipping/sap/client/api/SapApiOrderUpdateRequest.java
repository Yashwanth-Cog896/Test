
package com.monsanto.tps.shipping.sap.client.api;

import com.monsanto.tps.shipping.sap.client.api.model.SapApiError;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiErrorTabBapi;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiInfoTabItem;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "errorTab",
    "errorTabBapi",
    "infoTab",
    "itItems",
    "brokerid",
    "consoignee",
    "sapdeliveryblock",
    "registrationNumber",
    "phytosanitaryhrdtext",
    "importpermitnumber",
    "endUse",
    "gtmcontact",
    "freightforwarder",
    "importphytosummary",
    "shippingconditions",
    "notifyarrival",
    "sapordernumber",
    "shipcenteruserid",
    "sapshiptonumber",
    "yySoldtoNum",
    "salestexthdr"
})
@XmlRootElement(name = "YSdgtmChangeSoIb")
public class SapApiOrderUpdateRequest implements SapApiOrderRequest{

    @XmlElementWrapper(name = "ErrorTab")
    @XmlElement(name = "item")
    private List<SapApiError> errorTab;
    @XmlElementWrapper(name = "ErrorTabBapi")
    @XmlElement(name = "item")
    private List<SapApiErrorTabBapi> errorTabBapi;
    @XmlElementWrapper(name = "InfoTab")
    @XmlElement(name = "item")
    private List<SapApiInfoTabItem> infoTab;
    @XmlElementWrapper(name = "ItItems")
    @XmlElement(name = "item")
    private List<SapApiOrderItem> itItems;

    private String brokerid;
    private String consoignee;
    private String sapdeliveryblock;
    @XmlElement(name = "registration_number")
    private String registrationNumber;
    private String phytosanitaryhrdtext;
    private String importpermitnumber;
    @XmlElement(name = "end_use")
    private String endUse;
    private String gtmcontact;
    private String freightforwarder;
    private String importphytosummary;
    @XmlElement(name = "shipping_conditions")
    private String shippingconditions;
    private String notifyarrival;
    @XmlElement(required = true)
    private String sapordernumber;
    @XmlElement(required = true)
    private String shipcenteruserid;
    private String sapshiptonumber;
    @XmlElement(name = "YySoldtoNum")
    private String yySoldtoNum;
    private String salestexthdr;

    public List<SapApiError> getErrorTab() {
        return errorTab;
    }

    public void setErrorTab(List<SapApiError> errorTab) {
        this.errorTab = errorTab;
    }

    public List<SapApiErrorTabBapi> getErrorTabBapi() {
        return errorTabBapi;
    }

    public void setErrorTabBapi(List<SapApiErrorTabBapi> errorTabBapi) {
        this.errorTabBapi = errorTabBapi;
    }

    public List<SapApiInfoTabItem> getInfoTab() {
        return infoTab;
    }

    public void setInfoTab(List<SapApiInfoTabItem> infoTab) {
        this.infoTab = infoTab;
    }

    public List<SapApiOrderItem> getItItems() {
        return itItems;
    }

    public void setItItems(List<SapApiOrderItem> itItems) {
        this.itItems = itItems;
    }

    public String getBrokerid() {
        return brokerid;
    }

    public void setBrokerid(String brokerid) {
        this.brokerid = brokerid;
    }

    public String getConsoignee() {
        return consoignee;
    }

    public void setConsoignee(String consoignee) {
        this.consoignee = consoignee;
    }

    public String getSapdeliveryblock() {
        return sapdeliveryblock;
    }

    public void setSapdeliveryblock(String sapdeliveryblock) {
        this.sapdeliveryblock = sapdeliveryblock;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getPhytosanitaryhrdtext() {
        return phytosanitaryhrdtext;
    }

    public void setPhytosanitaryhrdtext(String phytosanitaryhrdtext) {
        this.phytosanitaryhrdtext = phytosanitaryhrdtext;
    }

    public String getImportpermitnumber() {
        return importpermitnumber;
    }

    public void setImportpermitnumber(String importpermitnumber) {
        this.importpermitnumber = importpermitnumber;
    }

    public String getEndUse() {
        return endUse;
    }

    public void setEndUse(String endUse) {
        this.endUse = endUse;
    }

    public String getGtmcontact() {
        return gtmcontact;
    }

    public void setGtmcontact(String gtmcontact) {
        this.gtmcontact = gtmcontact;
    }

    public String getFreightforwarder() {
        return freightforwarder;
    }

    public void setFreightforwarder(String freightforwarder) {
        this.freightforwarder = freightforwarder;
    }

    public String getImportphytosummary() {
        return importphytosummary;
    }

    public void setImportphytosummary(String importphytosummary) {
        this.importphytosummary = importphytosummary;
    }

    public String getShippingconditions() {
        return shippingconditions;
    }

    public void setShippingconditions(String shippingconditions) {
        this.shippingconditions = shippingconditions;
    }

    public String getNotifyarrival() {
        return notifyarrival;
    }

    public void setNotifyarrival(String notifyarrival) {
        this.notifyarrival = notifyarrival;
    }

    public String getSapordernumber() {
        return sapordernumber;
    }

    public void setSapordernumber(String sapordernumber) {
        this.sapordernumber = sapordernumber;
    }

    public String getShipcenteruserid() {
        return shipcenteruserid;
    }

    public void setShipcenteruserid(String shipcenteruserid) {
        this.shipcenteruserid = shipcenteruserid;
    }

    public String getSapshiptonumber() {
        return sapshiptonumber;
    }

    public void setSapshiptonumber(String sapshiptonumber) {
        this.sapshiptonumber = sapshiptonumber;
    }

    @XmlTransient
    @Override
    public void setSapsoldtonumber(String value) {
        this.yySoldtoNum = value;
    }

    public String getYySoldtoNum() {
        return yySoldtoNum;
    }

    public void setYySoldtoNum(String yySoldtoNum) {
        this.yySoldtoNum = yySoldtoNum;
    }

    public String getSalestexthdr() {
        return salestexthdr;
    }

    public void setSalestexthdr(String salestexthdr) {
        this.salestexthdr = salestexthdr;
    }

    @Override
    public void addItItem(SapApiOrderItem item) {
        if (itItems == null) {
            itItems = new ArrayList<SapApiOrderItem>();
        }
        itItems.add(item);
    }

}
