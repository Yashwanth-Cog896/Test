package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * User: pgadi
 */
@Repository
public class ShipmentTypeDaoImpl implements ShipmentTypeDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public ShipmentTypeEntity findById(Long shipmentTypeId) {
        return (ShipmentTypeEntity) sessionFactory.getCurrentSession().createQuery("from ShipmentTypeEntity st where st.sourceSystem.name='Shipping Web' " +
                "and st.shipmentTypeId = :shipmentTypeId ").setParameter("shipmentTypeId", shipmentTypeId).uniqueResult();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public ShipmentTypeEntity findByName(String shipmentTypeName) {
        return (ShipmentTypeEntity) sessionFactory.getCurrentSession().createQuery("from ShipmentTypeEntity st where st.sourceSystem.name='Shipping Web' " +
                "and st.name =:shipmentTypeName ").setParameter("shipmentTypeName", shipmentTypeName).uniqueResult();
    }

    @Override
    @Cacheable("METHOD_CACHE")
    public List<ShipmentTypeEntity> findShipmentTypes() {
        return sessionFactory.getCurrentSession().createQuery("from ShipmentTypeEntity st where st.sourceSystem.name='Shipping Web' ").list();
    }
}
