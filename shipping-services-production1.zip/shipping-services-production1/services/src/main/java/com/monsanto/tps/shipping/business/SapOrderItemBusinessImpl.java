package com.monsanto.tps.shipping.business;

import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.converter.SapOrderShipmentConverter;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.dao.MidasUserDao;
import com.monsanto.tps.shipping.dao.SapOrderItemDao;
import com.monsanto.tps.shipping.dao.SapSpecieCropXrefDao;
import com.monsanto.tps.shipping.domain.CropEntity;
import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderItemKey;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.domain.SapSpecieCropXrefEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.SapOrderItem;
import com.monsanto.tps.shipping.util.EventHelper;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * User: pgadi
 */
@Service
public class SapOrderItemBusinessImpl implements SapOrderItemBusiness {

    public static final String CANNOT_FIND_VALID_MATERIAL_NBR = "SAP Material Mismatch";

    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private SapOrderShipmentConverter orderShipmentConverter;

    @Autowired
    private SapOrderItemDao sapOrderItemDao;

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Autowired
    private MidasUserDao midasUserDao;

    @Autowired
    private SapSpecieCropXrefDao sapSpecieCropXrefDao;

    @Autowired
    private CropBusiness cropBusiness;

    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Trace
    @Override
    public List<SapOrderItem> deriveSapOrderItems(Long sapOrderShipmentId) {
        SapOrderItem itemDto;
        SapOrderItemEntity itemEntity;

        ShipmentPackingListEntity packingListEntity = shipmentPackingListBusiness
            .getShipmentPackingListForSapOrderShipmentId(sapOrderShipmentId);
        MidasUserEntity userEntity = packingListEntity.getLastModifiedBy();

        Collection<SapOrderItemKey> validKeys = eventHelper.getComplianceActionKeys(packingListEntity);
        List<SapOrderItem> itemList = new ArrayList<SapOrderItem>();
        if (packingListEntity.isInternational()) {
            SapOrderShipmentEntity sapOrder = packingListEntity.getSapOrderShipment();
            Collection<SapOrderItemEntity> sapOrderItems = sapOrder.getOrderItems();
            Set<SapOrderItemEntity> orphanItems = new HashSet<SapOrderItemEntity>();
            orphanItems.addAll(sapOrderItems);
            for (SapOrderItemKey validKey : validKeys) {
                itemEntity = sapOrder.findOrderItem(validKey);
                if (itemEntity != null) {
                    itemDto = orderShipmentConverter.createOrderItem(itemEntity);
                    itemDto.setBoxNumber(validKey.getBoxNumber());
                    orphanItems.remove(itemEntity);
                } else {
                    itemEntity = createNewOrderItemEntity(validKey, sapOrder, userEntity);
                    sapOrder.addOrderItem(itemEntity);
                    itemDto = new SapOrderItem(validKey);
                    itemDto.setSapOrderItemId(itemEntity.getSapOrderItemId());
                }
                itemList.add(itemDto);
            }
            for (SapOrderItemEntity orphanItem : orphanItems) {
                sapOrder.removeOrderItem(orphanItem);
            }
        }
        return itemList;
    }

    private SapOrderItemEntity createNewOrderItemEntity(SapOrderItemKey itemKey, SapOrderShipmentEntity orderShipment,
                                                        MidasUserEntity userEntity) {
        SapOrderItemEntity entity = new SapOrderItemEntity(itemKey);
        entity.setSapOrderShipment(orderShipment);
        Date currentDate = new Date();
        entity.setCreatedBy(userEntity);
        entity.setCreationDate(currentDate);
        entity.setModifiedBy(userEntity);
        entity.setLastModifiedDate(currentDate);
        sapOrderItemDao.save(entity);
        return entity;
    }

    @Trace
    @Override
    public void saveSapOrderItem(SapOrderItem sapOrderItem) {
        SapOrderItemEntity sapOrderItemEntity = sapOrderItemDao.load(sapOrderItem.getSapOrderItemId());

        String sapCcdValBeforeChange = sapOrderItemEntity.getSapCcdVal();
        ShipmentPackingListEntity packingListEntity = shipmentPackingListBusiness
                .getShipmentPackingListForSapOrderShipmentId(sapOrderItemEntity.getSapOrderShipment().getSapOrderShipmentId());
        CropEntity cropEntity = cropBusiness.getCropByPackingList(packingListEntity);

        sapOrderItemEntity.setSapOrderItemNumber(sapOrderItem.getSapOrderItemNumber());
        sapOrderItemEntity.setPhytoNumber(sapOrderItem.getPhytoNumber());
        sapOrderItemEntity.setImportPermitNumber(sapOrderItem.getImportPermitNumber());
        sapOrderItemEntity.setCountryOfOrigin(sapOrderItem.getCountryOfOrigin());
        sapOrderItemEntity.setRegionOfOrigin(sapOrderItem.getRegionOfOrigin());
        sapOrderItemEntity
            .setEventStack(StringUtils.isEmpty(sapOrderItem.getEventStack()) ? null : sapOrderItem.getEventStack());
        sapOrderItemEntity.setSapCcdVal(sapOrderItem.getSapCcdVal());
        sapOrderItemEntity.setSapMaterialNbr(getSapMaterialNbr(sapOrderItem, sapCcdValBeforeChange, cropEntity));
        sapOrderItemEntity.setSeedTreatment(sapOrderItem.getSeedTreatment());
        sapOrderItemEntity.setStorageContainerBarcode(sapOrderItem.getStorageContainerBarcode());
        sapOrderItemEntity.setLastModifiedDate(new Date());
        sapOrderItemEntity.setModifiedBy(getCurrentUser());

        sapOrderItemDao.save(sapOrderItemEntity);
        sapOrderItem.setSapOrderItemId(sapOrderItemEntity.getSapOrderItemId());
    }

    @Trace
    @Override
    public void deleteSapOrderItem(Collection<SapOrderItemEntity> sapOrderItems) {
        for (SapOrderItemEntity sapOrderItemEntity : sapOrderItems) {
            sapOrderItemDao.delete(sapOrderItemEntity);
        }
    }

    private String getSapMaterialNbr(SapOrderItem sapOrderItem, String sapCcdVal, CropEntity cropEntity) {
        SapSpecieCropXrefEntity sapSpecieCropXrefEntity = sapSpecieCropXrefDao.getSapSpecieCropEntityByCropSubclassId(cropEntity.getCropId());

        String sapMaterialNbr = sapOrderItem.getSapMaterialNumber();

        if (sapOrderItem.getSapMaterialNumber() == null ||
            (null != sapCcdVal && !sapCcdVal.equalsIgnoreCase(sapOrderItem.getSapCcdVal()))) {
            sapMaterialNbr = internationalCompositesDao.getMaterialNbrForOrderItem(sapOrderItem, sapSpecieCropXrefEntity.getSapSpecieCode());

            if (null == sapMaterialNbr) {
                sapOrderItem.setValidationError(CANNOT_FIND_VALID_MATERIAL_NBR);
            } else {
                sapOrderItem.setSapMaterialNumber(sapMaterialNbr);
            }
        }

        return sapMaterialNbr;
    }

    private MidasUserEntity getCurrentUser() {
        String userName = getUserName();
        return midasUserDao.getByUserId(userName);
    }

    private String getUserName() {
        UserDetails userDetails = userDetailsProvider.getUserDetails();
        return (userDetails != null) ? userDetails.getUsername() : System.getProperty("user.name");
    }

}
