package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierAccountInstructionEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * User: SDCHIL
 */
@Repository
public class CarrierAccountInstructionDaoImpl implements CarrierAccountInstructionDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public CarrierAccountInstructionEntity findByCarrierAcountContact(Long carrierId, Long irdAccountId, Long contactId) {
        return (CarrierAccountInstructionEntity) sessionFactory.getCurrentSession()
                .createQuery("from CarrierAccountInstructionEntity ca"+
                " where ca.carrierId = :carrierId" +
                " and ca.irdAccountId = :irdAccountId" +
                " and ( ca.contactId = :contactId or ca.contactId is null)" +
                " order by ca.contactId ASC")
                .setParameter("carrierId", carrierId)
                .setParameter("irdAccountId", irdAccountId)
                .setParameter("contactId", contactId)
                .setMaxResults(1)
                .uniqueResult();
    }
}
