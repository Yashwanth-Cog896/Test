
package com.monsanto.tps.shipping.sap.documents.api.retrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ImShipmentNumber" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "imShipmentNumber"
})
@XmlRootElement(name = "YgtmWsinbSendVttkDocLink")
public class YgtmWsinbSendVttkDocLink {

    @XmlElement(name = "ImShipmentNumber", required = true)
    protected String imShipmentNumber;

    /**
     * Gets the value of the imShipmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImShipmentNumber() {
        return imShipmentNumber;
    }

    /**
     * Sets the value of the imShipmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImShipmentNumber(String value) {
        this.imShipmentNumber = value;
    }

}
