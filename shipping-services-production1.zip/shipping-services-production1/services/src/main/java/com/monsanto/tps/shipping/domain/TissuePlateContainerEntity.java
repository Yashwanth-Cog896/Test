package com.monsanto.tps.shipping.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Collection;

/**
 * User: DCENGL
 */
@Entity
@DiscriminatorValue("TISSUE_PLATE")
public class TissuePlateContainerEntity extends ScannedContainerEntity<TissuePlateEntity> {

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BARCODE_NBR")
    private TissuePlateEntity tissuePlateEntity;

    @Override
    public TissuePlateEntity getContent() {
        return tissuePlateEntity;
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public void setContent(TissuePlateEntity contentEntity) {
        this.tissuePlateEntity = contentEntity;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.TISSUE_PLATE;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return null;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        // Do nothing
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        // Do nothing
    }

    @Override
    public String toString() {
        return "TissuePlateContainerEntity{" +
                "id=" + getScannedContainerId() +
                ", scanOrder=" + getScanOrder() +
                ", tissuePlateEntity=" + tissuePlateEntity +
                '}';
    }
}
