package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierNoShipDate;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * User: SDCHIL
 */
@Repository
public class CarrierNoShipDateDaoImpl implements CarrierNoShipDateDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    @Cacheable("METHOD_CACHE")
    public List<CarrierNoShipDate> findAll() {
        return sessionFactory.getCurrentSession().createQuery("from CarrierNoShipDate").list();
    }
}
