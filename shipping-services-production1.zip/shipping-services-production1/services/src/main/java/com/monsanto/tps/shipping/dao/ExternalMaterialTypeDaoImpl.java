package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ExternalMaterialTypeEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ExternalMaterialTypeDaoImpl implements ExternalMaterialTypeDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public ExternalMaterialTypeEntity findById(Long id) {
        return (ExternalMaterialTypeEntity) sessionFactory.getCurrentSession().load(ExternalMaterialTypeEntity.class, id);
    }

    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public ExternalMaterialTypeEntity findByDesc(String description) {
        return (ExternalMaterialTypeEntity) sessionFactory.getCurrentSession()
                .createQuery("from ExternalMaterialTypeEntity a where a.description = :description and a.refActive = true")
                .setString("description", description)
                .uniqueResult();
    }

    @Trace
    @SuppressWarnings("unchecked")
    @Cacheable("METHOD_CACHE")
    @Override
    public Collection<ExternalMaterialTypeEntity> findAllActive() {
        return sessionFactory.getCurrentSession().createQuery("from ExternalMaterialTypeEntity a where a.refActive = true").list();
    }
}
