package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ExternalPermitEntity;
import com.monsanto.tps.shipping.service.model.ExternalPermit;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ExternalPermitDaoImpl implements ExternalPermitDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public ExternalPermitEntity load(long externalPermitId) {
        return (ExternalPermitEntity) sessionFactory.getCurrentSession().load(ExternalPermitEntity.class, externalPermitId);
    }

    @Override
    public ExternalPermitEntity findByExternalPermit(ExternalPermit externalPermit) {
        return (ExternalPermitEntity) sessionFactory.getCurrentSession().createQuery(
                "from ExternalPermitEntity ep where ep.shipmentContainer.shipmentContainerId = :shipmentContainerId" +
                        " and ep.permitNumber = :permitName" +
                        " and (ep.agency.agencyId = :agencyId and ep.otherAgencyName = null) or (ep.agency.agencyId = null and ep.otherAgencyName = :otherAgencyName)")
                .setParameter("shipmentContainerId", externalPermit.getShipmentContainerId())
                .setParameter("permitName", externalPermit.getPermitName())
                .setParameter("agencyId", externalPermit.getAgencyId())
                .setParameter("otherAgencyName", externalPermit.getAgency())
                .uniqueResult();
    }

    @Override
    public void save(ExternalPermitEntity externalPermitEntity) {
        sessionFactory.getCurrentSession().save(externalPermitEntity);
    }

    @Override
    public void delete(ExternalPermitEntity externalPermitEntity) {
        sessionFactory.getCurrentSession().delete(externalPermitEntity);
    }
}
