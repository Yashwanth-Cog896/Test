package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;

import java.util.List;

/**
 * User: pgadi
 */
public interface UnitOfMeasureGroupDao {
    List<UnitOfMeasureEntity> getValidUnitOfMeasuresForShippingGroup();

    UnitOfMeasureEntity findByAbbreviation(String abbreviation);
}
