package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Sets;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "HD_TRAYS_VW", schema = "INVENTORY_MGT")
public class HDTrayEntity implements ContentEntity, Serializable {

    @Id
    @Column(name = "HD_TRAY_ID")
    private String barcode;

    @Transient
    private String projectName;

    @Transient
    private Integer projectId;

    @Transient
    private String limsId;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "HD_TRAY_ID")
    private Collection<HDTrayInventory> hdTrayInventories = new ArrayList<HDTrayInventory>();

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "HD_TRAY_ID")
    private Collection<HDTrayProject> hdTrayProjects = new ArrayList<HDTrayProject>();

    @Transient
    private List<InventoryEntity> inventoryEntityList = new ArrayList<InventoryEntity>();

    @Transient
    private List<EventConstructEntity> eventsList = new ArrayList<EventConstructEntity>();

    @Transient
    private boolean isValidTray = true;

    public Collection<HDTrayProject> getHdTrayProjects() {
        return hdTrayProjects;
    }

    public void setHdTrayProjects(Collection<HDTrayProject> hdTrayProjects) {
        this.hdTrayProjects = hdTrayProjects;
    }

    public Collection<HDTrayInventory> getHdTrayInventories() {
        return hdTrayInventories;
    }

    public void setHdTrayInventories(Collection<HDTrayInventory> hdTrayInventories) {
        this.hdTrayInventories = hdTrayInventories;
    }

    public void setEventsList(List<EventConstructEntity> eventsList) {
        this.eventsList = eventsList;
    }

    public String getProjectName() {
        if(this.projectName == null){
            populateTransientValues();
        }
        return this.projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getProjectId() {
        if(this.projectId == null){
            populateTransientValues();
        }
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getLimsId() {
        if(this.limsId == null){
            populateTransientValues();
        }
        return this.limsId;
    }

    public void setLimsId(String limsId) {
        this.limsId = limsId;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    @Override
    public Long getContentId() {
        return null;
    }

    @Override
    public String getBarcode() {
        return this.barcode;
    }

    @Override
    public GeneticMaterialEntity getGeneticMaterial() {
        return null;
    }

    @Override
    public InventoryEntity getInventory() {
        return null;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.HD_TRAY;
    }

    public void setInventoryEntityList(List<InventoryEntity> inventoryEntityList) {
        this.inventoryEntityList = inventoryEntityList;
    }

    public List<InventoryEntity> getInventoryEntityList() {
        if (CollectionUtils.isEmpty(inventoryEntityList)) {
            populateTransientValues();
        }
        return this.inventoryEntityList;
    }

    public List<EventConstructEntity> getEventsList() {
        if (CollectionUtils.isEmpty(eventsList)) {
            populateTransientValues();
        }
        return this.eventsList;
    }

    public String getInventoryBarCodes() {
        if (CollectionUtils.isEmpty(inventoryEntityList)) {
            populateTransientValues();
        }

        Set<String> barcodes = Sets.newHashSet();
        for (InventoryEntity inventoryEntity : inventoryEntityList) {
            barcodes.add(inventoryEntity.getBarcode());
        }
        return StringUtils.collectionToCommaDelimitedString(barcodes);
    }

    private void populateTransientValues() {
        setProjectId(((List<HDTrayProject>) hdTrayProjects).get(0).getProjectId());
        setLimsId(((List<HDTrayProject>) hdTrayProjects).get(0).getLimsId());
        setProjectName(((List<HDTrayProject>) hdTrayProjects).get(0).getProjectName());

        List<EventConstructEntity> eventConstructs = new ArrayList<EventConstructEntity>();
        List<InventoryEntity> inventoryEntities = new ArrayList<InventoryEntity>();

        for (HDTrayInventory hdTrayInventory : this.getHdTrayInventories()) {
            inventoryEntities.add(hdTrayInventory.getInventory());
            eventConstructs.addAll(hdTrayInventory.getInventory().getGeneticMaterial().getGermplasm().getEvents());
        }
        this.setEventsList(eventConstructs);
        this.setInventoryEntityList(inventoryEntities);
    }

    public boolean isValidTray() {
        return isValidTray;
    }

    public void setValidTray(boolean isValidTray) {
        this.isValidTray = isValidTray;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HDTrayEntity that = (HDTrayEntity) o;

        if (!barcode.equals(that.barcode)) return false;
        if (!hdTrayInventories.equals(that.hdTrayInventories)) return false;
        if (limsId != null ? !limsId.equals(that.limsId) : that.limsId != null) return false;
        if (projectId != null ? projectId != that.projectId : that.projectId != null) return false;
        if (!projectName.equals(that.projectName)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = barcode.hashCode();
        result = 31 * result + projectId.hashCode();
        result = 31 * result + projectName.hashCode();
        result = 31 * result + (limsId != null ? limsId.hashCode() : 0);
        result = 31 * result + hdTrayInventories.hashCode();
        return result;
    }
}


