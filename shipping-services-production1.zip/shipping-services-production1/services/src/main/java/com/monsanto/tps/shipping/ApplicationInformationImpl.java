package com.monsanto.tps.shipping;

import com.monsanto.tps.aop.metric.ApplicationInformation;

/**
 * User: pgadi
 */
public class ApplicationInformationImpl implements ApplicationInformation {
    private final String version;
    private final String name;

    public ApplicationInformationImpl(String name, String version) {
        this.version = version;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getVersion() {
        return version;
    }
}
