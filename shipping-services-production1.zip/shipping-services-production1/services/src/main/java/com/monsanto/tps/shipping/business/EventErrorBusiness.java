package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface EventErrorBusiness {

    boolean rollupPermitErrors(Collection<Event> events);

    void addUsdaPermitErrors(Collection<Permit> permits, long cropId, long fromContactId, long toContactId);

}
