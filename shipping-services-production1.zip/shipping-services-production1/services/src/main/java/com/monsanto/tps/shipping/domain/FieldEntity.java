package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "BR_FIELD", schema = "MIDAS")
public class FieldEntity {

    @Id
    @Column(name = "BR_FIELD_ID", nullable = false)
    private Long id;

    @Type(type = "true_false")
    @Column(name = "NURS_BR_ICB_MALE")
    private Boolean icbField;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ICB_GENETIC_MATERIAL_ID")
    private GeneticMaterialEntity icbGeneticMaterial;

    @Column(name = "NAME")
    private String fieldName;

    @Column(name = "PLANTING_DATE")
    private Date plantingDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GR_SEASON_ID", referencedColumnName = "GR_SEASON_ID", insertable = false, updatable = false)
    private SeasonEntity season;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIcbField() {
        return icbField;
    }

    public boolean isIcb() {
        return icbField != null && icbField;
    }

    public void setIcbField(Boolean icbField) {
        this.icbField = icbField;
    }

    public GeneticMaterialEntity getIcbGeneticMaterial() {
        return icbGeneticMaterial;
    }

    public void setIcbGeneticMaterial(GeneticMaterialEntity icbGeneticMaterial) {
        this.icbGeneticMaterial = icbGeneticMaterial;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public SeasonEntity getSeason() {
        return season;
    }

    public void setSeason(SeasonEntity season) {
        this.season = season;
    }

    @Override
    public String toString() {
        return "FieldEntity{" +
                "id=" + id +
                ", icbField=" + icbField +
                ", icbGeneticMaterial=" + icbGeneticMaterial +
                '}';
    }
}
