package com.monsanto.tps.shipping.business;

import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.dao.CountryDao;
import com.monsanto.tps.shipping.domain.CountryEntity;
import com.monsanto.tps.shipping.domain.ShipmentAddressEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import static org.apache.commons.lang.StringUtils.isEmpty;

/**
 * User: DCENGL
 */
@Service
public class ShipmentAddressBusinessImpl implements ShipmentAddressBusiness {

    @Resource
    private CountryDao countryDao;

    @Override
    public ShipmentAddressEntity buildShipmentAddress(Contact contact) {
        ShipmentAddressEntity shipmentAddress = new ShipmentAddressEntity();

        shipmentAddress.setAddressLine1(contact.getAddressLine1());
        shipmentAddress.setAddressLine2(contact.getAddressLine2());
        shipmentAddress.setAddressLine3(contact.getAddressLine3());
        shipmentAddress.setCity(contact.getCity());
        shipmentAddress.setState(contact.getState());
        shipmentAddress.setIsoCountryCode(contact.getIsoCountryCode());
        shipmentAddress.setCountry(contact.getCountry());

        if(!isEmpty(contact.getZipCode4())) {
            shipmentAddress.setPostalCode(contact.getZipCode() + "-" + contact.getZipCode4());
        } else {
            shipmentAddress.setPostalCode(contact.getZipCode());
        }

        return shipmentAddress;
    }

    @Override
    public ShipmentAddressEntity buildShipmentAddress(AbstractContact contact) {
        ShipmentAddressEntity shipmentAddress = new ShipmentAddressEntity();

        shipmentAddress.setAddressLine1(contact.getAddressLine1());
        shipmentAddress.setAddressLine2(contact.getAddressLine2());
        shipmentAddress.setAddressLine3(contact.getAddressLine3());
        shipmentAddress.setCity(contact.getCity());
        shipmentAddress.setState(contact.getState());
        CountryEntity country = countryDao.getCountry(contact.getIsoCountryCode());
        if (country != null) {
            shipmentAddress.setIsoCountryCode(country.getIsoCode());
            shipmentAddress.setCountry(country.getCountryName());
        } else {
            throw new ShippingWebException("Invalid country code: " + contact.getIsoCountryCode());
        }

        shipmentAddress.setPostalCode(contact.getZip());

        return shipmentAddress;
    }
}
