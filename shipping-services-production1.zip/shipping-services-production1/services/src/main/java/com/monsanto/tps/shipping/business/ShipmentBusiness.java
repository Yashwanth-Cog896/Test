package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Shipment;
import com.monsanto.tps.shipping.service.model.ShipmentAcknowledgement;

import java.util.Date;
import java.util.List;

/**
 * User: pgadi
 */
public interface ShipmentBusiness {

    ShipmentEntity createShipment(ShipmentPackingListEntity packingList, Shipment shipment, String createdBy);

    public ShipmentEntity getShipment(String shBarcode);

    public ShipmentEntity getShipment(Long shipmentId);

    void acknowledge(ShipmentEntity shipment, ShipmentPackingListEntity packingList, ShipmentAcknowledgement acknowledgement);

    void saveStatus(ShipmentEntity shipmentEntity, String status);

    void saveStatus(String shBarcode, String status);

    List<ShipmentTypeEntity> getShipmentTypeList();

    ShipmentTypeEntity getShipmentType(Long shipmentTypeId);

    List<ShipmentEntity> getShipmentsByAccountIdAndShippedDate(Long accountId, Date shippedAfterDate, String shipmentDirection);

    List<ShipmentEntity> getShipmentsByCountryAndShippedDate(String countryCode, Date shippedAfterDate, String shipmentDirection);

    void cancelShipment(Long shipmentId);

    void updateUndeliveredShipmentStatuses();
}
