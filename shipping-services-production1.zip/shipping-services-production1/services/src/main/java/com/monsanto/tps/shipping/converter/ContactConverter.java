package com.monsanto.tps.shipping.converter;

import com.monsanto.tps.shipping.domain.ShipmentAddressEntity;
import com.monsanto.tps.shipping.domain.ShipmentContactEntity;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import org.springframework.stereotype.Component;

/**
 * Created by slaks on 6/30/2014.
 */
@Component
public class ContactConverter {

    public ShipmentContact setContactDetails(ShipmentAddressEntity shipmentAddressEntity, ShipmentContactEntity contactEntity) {
        ShipmentContact shipmentContact = buildContacts(shipmentAddressEntity);
        shipmentContact.setName(contactEntity.getFirstName() + " " + contactEntity.getLastName());
        shipmentContact.setCompanyName(contactEntity.getCompanyName());
        return shipmentContact;
    }

    private ShipmentContact buildContacts(ShipmentAddressEntity shipmentAddressEntity){
        ShipmentContact shipmentContact = new ShipmentContact();
        shipmentContact.setAddressLine1(shipmentAddressEntity.getAddressLine1());
        shipmentContact.setAddressLine2(shipmentAddressEntity.getAddressLine2());
        shipmentContact.setAddressLine3(shipmentAddressEntity.getAddressLine3());
        shipmentContact.setCity(shipmentAddressEntity.getCity());
        shipmentContact.setState(shipmentAddressEntity.getState());
        shipmentContact.setZip(shipmentAddressEntity.getPostalCode());
        shipmentContact.setIsoCountryCode(shipmentAddressEntity.getIsoCountryCode());
        shipmentContact.setCountry(shipmentAddressEntity.getCountry());
        return shipmentContact;
    }
}
