package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "GENETIC_MATERIAL", schema = "MIDAS")
public class GeneticMaterialEntity {
    @Id
    @Column(name = "GENETIC_MATERIAL_ID", nullable = false)
    private Long geneticMaterialId;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "GERMPLASM_ID")
    private GermplasmEntity germplasm;
    @Column(name = "SRC_PLOT_NUMBER")
    private Integer sourcePlotNumber;
    @Column(name = "SRC_ORIG_COUNTRY")
    private String countryOfOrigin;

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public Integer getSourcePlotNumber() {
        return sourcePlotNumber;
    }

    public void setSourcePlotNumber(Integer sourcePlotNumber) {
        this.sourcePlotNumber = sourcePlotNumber;
    }
}