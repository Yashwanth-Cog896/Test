package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

/**
 * User: sdchil
 * Date: 9/18/13
 */

@Repository
public class PlotDaoImpl implements PlotDao {

    @Resource
    private TempOcdTableDao tempOcdTableDao;
    @Autowired
    private SessionFactory sessionFactory;


    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<PlotEntity> findByBarcode(String barcode) {
        return sessionFactory.getCurrentSession()
                .createQuery("select e from PlotEntity e " +
                        "join fetch e.field " +
                        "left join fetch e.rep rp " +
                        "join fetch e.inventory i " +
                        "join fetch i.geneticMaterial g " +
                        "join fetch g.germplasm gr " +
                        "join fetch gr.crop " +
                        "left join fetch e.testSetEntry t " +
                        "left join fetch t.testSet " +
                        "left join fetch rp.growerProgram " +
                        "left join fetch rp.field " +
                        "where e.barcode = :barcode")
                .setParameter("barcode", barcode).list();
    }

    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<PlotEntity> findByBarcode(Collection<String> barcodes) {
        // TODO: need to determine best number to do 'in' query for performance - for now just 1
        if (CollectionUtils.isNotEmpty(barcodes) && barcodes.size() == 1) {
            return findByBarcode(barcodes.iterator().next());
        }
        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(barcodes));

        return sessionFactory.getCurrentSession()
                .createQuery(
                        "from PlotEntity e " +
                                "where e.barcode in (select tempOcdId from TempOcdTable tempTable where tempTable.sessionId = :requestId)")
                .setParameter("requestId", requestId).list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<PlotEntity> findBinaryFemalePlotWithNoMalePlots(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select plot from PlotEntity plot, TempOcdTable tmp "+
                "where tmp.sessionId = :requestId " +
                "  and plot.plotId = tmp.tempOcdNumber " +
                "  and upper(plot.operationOperationType.operationType.operationTypeName) = upper('Binary') " +
                "  and not exists(select 1 from PlotMalePlotEntity plotMalePlot where plotMalePlot.femalePlot.plotId = plot.plotId) ")
                .setParameter("requestId", requestId)
                .list();

    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<PlotEntity> findPlotsWithoutAnOperation(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

    /*
        SELECT p.plot_id as plotId, p.operation_id, oot.*
                FROM midas.plot p, midas.OPERATION_OPERATION_TYPE oot
        WHERE p.OPERATION_ID = oot.OPERATION_ID (+)
        AND p.rep_id IS NOT NULL AND p.test_set_entry_id IS NOT NULL
        AND oot.OPERATION_ID IS NULL
        AND p.PLOT_ID = 811945913483265
        AND (
                EXISTS (SELECT * FROM midas.plot_male_plot pmp WHERE p.plot_id = pmp.female_plot_id) OR (
                NOT EXISTS (SELECT * FROM midas.plot_male_plot pmp WHERE p.plot_id = pmp.female_plot_id) AND
                NOT EXISTS (SELECT * FROM midas.plot_male_plot pmp WHERE p.plot_id = pmp.male_plot_id)
        )
        );

      */
        return sessionFactory.getCurrentSession().createQuery("select plot from PlotEntity plot, TempOcdTable tmp "+
                " left join plot.operationOperationType oot "+
                "where tmp.sessionId = :requestId " +
                "  and plot.plotId = tmp.tempOcdNumber " +
                "  and plot.rep is not null " +
                "  and plot.testSetEntry is not null " +
                "  and oot.operationId is null " +
                "  and ( " +
                "       exists (select 1 from PlotMalePlotEntity plotMalePlot where plotMalePlot.femalePlot.plotId = plot.plotId) " +
                "       or (not exists (select 1 from PlotMalePlotEntity plotMalePlot where plotMalePlot.femalePlot.plotId = plot.plotId)" +
                "           and not exists (select 1 from PlotMalePlotEntity plotMalePlot where plotMalePlot.malePlot.plotId = plot.plotId))" +
                ")")
                .setParameter("requestId", requestId)
                .list();
    }
}
