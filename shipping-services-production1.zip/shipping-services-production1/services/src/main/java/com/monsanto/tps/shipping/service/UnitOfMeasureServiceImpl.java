package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.UnitOfMeasureBusiness;
import com.monsanto.tps.shipping.converter.uom.MidasUomConversion;
import com.monsanto.tps.shipping.service.model.UnitOfMeasure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * User: pgadi
 */
@Component("unitOfMeasureService")
public class UnitOfMeasureServiceImpl implements UnitOfMeasureService {
    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;

    @Autowired
    private MidasUomConversion uomConversion;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<UnitOfMeasure> getUnitOfMeasures() {
        return Lists.transform(unitOfMeasureBusiness.getUnitOfMeasuresList(), uomConversion.toUnitOfMeasureFromEntity());
    }
}
