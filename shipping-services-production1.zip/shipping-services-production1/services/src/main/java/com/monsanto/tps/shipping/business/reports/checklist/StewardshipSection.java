package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

/**
 * Created by DCENGL
 */
@Service
public class StewardshipSection extends AbstractChecklistSection {

    private static final String HEADER = "Special requirements for movement of Bayer stewardship materials";

    private final static String SECTION_1 = "Labeling";
    private final static String SECTION_1_QUESTION_1 = "Outermost layer of containment is labeled with the phrase, Product not approved for commerce.";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        //Do Nothing
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);

        return questionsMap;
    }
}
