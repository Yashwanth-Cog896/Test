package com.monsanto.tps.shipping.security;

import com.monsanto.tps.architecture.security.common.user.IDMUserAttributes;
import com.monsanto.tps.security.authorization.GrantedAuthorityProvider;
import com.monsanto.tps.security.userdetails.DefaultUserDetailsService;
import com.monsanto.tps.security.userdetails.EnhancedUser;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import javax.annotation.Resource;
import java.util.Collection;


public class ShippingCloudUserDetailsService extends DefaultUserDetailsService {

    @Resource
    private GrantedAuthorityProvider compositeGrantedAuthorityProvider;

    @Override
    public EnhancedUserDetails loadUserDetails(Authentication token) throws UsernameNotFoundException {
        Collection<GrantedAuthority> authorities = buildGrantedAuthorities(compositeGrantedAuthorityProvider.getGrantedAuthorities(token));
        IDMUserAttributes userAttributes = new IDMUserAttributes(token.getName());
        return new EnhancedUser(token.getName(), "password", true, true, true, true,authorities, userAttributes);
    }
}
