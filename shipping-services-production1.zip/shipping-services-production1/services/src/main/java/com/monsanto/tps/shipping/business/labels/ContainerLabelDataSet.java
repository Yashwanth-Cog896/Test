package com.monsanto.tps.shipping.business.labels;

import com.monsanto.tps.labelprinting.common.LabelDataSet;

import java.util.Properties;

/**
 * User: pgadi
 */
public class ContainerLabelDataSet implements LabelDataSet {

    private Properties labelDataProperties = new Properties();

    public void put(String key, String value) {
        labelDataProperties.put(key, value);
    }

    public ContainerLabelDataSet putAll(Properties properties) {
        labelDataProperties.putAll(properties);
        return this;
    }

    @Override
    public String getValue(String property) {
        return labelDataProperties.getProperty(property);
    }

    public Properties getProperties() {
        return labelDataProperties;
    }
}
