package com.monsanto.tps.shipping.domain;

/**
 * Created by SLAKS on 2/27/14.
 */
public class IrdContactXref {

    private long irdContactId;
    private long fcmContactId;

    public IrdContactXref() {
    }

    public IrdContactXref(String fcmContactId, String irdContactId) {
        this.irdContactId = Long.parseLong(irdContactId,10);
        this.fcmContactId = Long.parseLong(fcmContactId,10);
    }

    public long getFcmContactId() {
        return fcmContactId;
    }

    public void setFcmContactId(long fcmContactId) {
        this.fcmContactId = fcmContactId;
    }

    public long getIrdContactId() {

        return irdContactId;
    }

    public void setIrdContactId(long irdContactId) {
        this.irdContactId = irdContactId;
    }
}
