package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Collection;

/**
 * @author Supreet Singh (sssing5)
 */
@Entity
@Table(name = "SHIPMENT_CONTAINER", schema = "INVENTORY_MGT")
public class ShipmentContainerEntity {
    @Id
    @Column(name = "SHIPMENT_CONTAINER_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    private Long shipmentContainerId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SHIPMENT_ID")
    private ShipmentEntity shipment;
    @Column(name = "BOX_NUMBER")
    private Long boxNumber;
    @Column(name = "CARRIER_TRACKING_ID", nullable = true)
    private String carrierTrackingId;
    @ManyToOne
    @JoinColumn(name = "SHIPPING_STATUS_ID")
    private ShippingStatus status;
    @Column(name = "DISPLAY_ORDER")
    private Integer displayOrder;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SHPMT_PKG_LIST_ID")
    private ShipmentPackingListEntity shipmentPackingList;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "STORAGE_CONTAINER_ID")
    private StorageContainerEntity<? extends ScannedContainerEntity> storageContainer;
    @Column(name = "WEIGHT", nullable = true)
    private Double grossWeight;
    @Column(name = "NET_WEIGHT", nullable = true)
    private Double netWeight;
    @Column(name = "WEIGHT_UOM_ID", nullable = true)
    private Long uomId;
    @Column(name = "HEIGHT", nullable = true)
    private Double height;
    @Column(name = "WIDTH", nullable = true)
    private Double width;
    @Column(name = "LENGTH", nullable = true)
    private Double length;
    @Column(name = "DIMENSION_UOM_ID", nullable = true)
    private Long dimensionUnitOfMeasureId;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "shipmentContainerId")
    private Collection<ShipmentContainerLabelEntity> shipmentContainerLabels;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "shipmentContainer")
    private Collection<ExternalPermitEntity> externalPermits;
    @Transient
    private String countryOfOrigin;

    public Long getShipmentContainerId() {
        return shipmentContainerId;
    }

    public void setShipmentContainerId(Long shipmentContainerId) {
        this.shipmentContainerId = shipmentContainerId;
    }

    public ShipmentEntity getShipment() {
        return shipment;
    }

    public void setShipment(ShipmentEntity shipment) {
        this.shipment = shipment;
    }

    public Long getBoxNumber() {
        return boxNumber;
    }

    public void setBoxNumber(Long boxNumber) {
        this.boxNumber = boxNumber;
    }

    public String getCarrierTrackingId() {
        return carrierTrackingId;
    }

    public void setCarrierTrackingId(String carrierTrackingId) {
        this.carrierTrackingId = carrierTrackingId;
    }

    public ShippingStatus getStatus() {
        return status;
    }

    public void setStatus(ShippingStatus status) {
        this.status = status;
    }

    public Integer getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }

    public ShipmentPackingListEntity getShipmentPackingList() {
        return shipmentPackingList;
    }

    public void setShipmentPackingList(ShipmentPackingListEntity shipmentPackingList) {
        this.shipmentPackingList = shipmentPackingList;
    }

    public StorageContainerEntity<? extends ScannedContainerEntity> getStorageContainer() {
        return storageContainer;
    }

    public void setStorageContainer(StorageContainerEntity<? extends ScannedContainerEntity> storageContainer) {
        this.storageContainer = storageContainer;
    }

    public Double getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Double grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public Double getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(Double netWeight) {
        this.netWeight = netWeight;
    }

    public Double getHeight() {
        return height;
    }

    public void setHeight(Double height) {
        this.height = height;
    }

    public Double getWidth() {
        return width;
    }

    public void setWidth(Double width) {
        this.width = width;
    }

    public Double getLength() {
        return length;
    }

    public void setLength(Double length) {
        this.length = length;
    }

    public Long getDimensionUnitOfMeasureId() {
        return dimensionUnitOfMeasureId;
    }

    public void setDimensionUnitOfMeasureId(Long dimensionUnitOfMeasure) {
        this.dimensionUnitOfMeasureId = dimensionUnitOfMeasure;
    }

    public Collection<ShipmentContainerLabelEntity> getShipmentContainerLabels() {
        return shipmentContainerLabels;
    }

    public void setShipmentContainerLabels(Collection<ShipmentContainerLabelEntity> shipmentContainerLabels) {
        this.shipmentContainerLabels = shipmentContainerLabels;
    }

    public Collection<ExternalPermitEntity> getExternalPermits() {
        return externalPermits;
    }

    public void setExternalPermits(Collection<ExternalPermitEntity> externalPermits) {
        this.externalPermits = externalPermits;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true;}
        if (o == null || getClass() != o.getClass()) {return false;}

        ShipmentContainerEntity that = (ShipmentContainerEntity) o;

        if (shipmentContainerId != null ? !shipmentContainerId.equals(that.shipmentContainerId) : that.shipmentContainerId != null){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return shipmentContainerId != null ? shipmentContainerId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ShipmentContainerEntity{" +
                "shipmentContainerId=" + shipmentContainerId +
                ", shipmentId=" + shipment +
                '}';
    }
}