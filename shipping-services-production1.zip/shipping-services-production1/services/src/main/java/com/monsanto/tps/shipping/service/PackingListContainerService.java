package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.PackingListContainer;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/packing-list-container")
public interface PackingListContainerService {

    @POST
    @Path("/packing-list/{packing-list-id}")
    @Produces(APPLICATION_JSON)
    public PackingListContainer createShipmentContainer(@PathParam("packing-list-id") Long packingListId);

    @POST
    @Path("/staging-container/packing-list/{packing-list-id}")
    @Produces(APPLICATION_JSON)
    public PackingListContainer createStagingContainer(@PathParam("packing-list-id") Long packingListId);

    @DELETE
    @Path("/{container-id}")
    public void deleteShipmentContainer(@PathParam("container-id") Long shipmentContainerId);

    @PUT
    @Path("/{container-id}")
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    public void save(@PathParam("container-id") Long shipmentContainerId, PackingListContainer container);

}
