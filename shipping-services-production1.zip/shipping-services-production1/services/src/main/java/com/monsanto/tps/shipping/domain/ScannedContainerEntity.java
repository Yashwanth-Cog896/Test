package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Collection;
import java.util.Date;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYPE_DESC", discriminatorType = DiscriminatorType.STRING)
@Table(name = "SCANNED_CONTAINER", schema = "INVENTORY_MGT")
public abstract class ScannedContainerEntity<T extends ContentEntity> {
    @Id
    @Column(name = "SCANNED_CONTAINER_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    private Long scannedContainerId;

    @Column(name = "display_order_nbr")
    private Integer scanOrder;

    @Column(name = "RECEIVE_VERIFY_SCAN_TSP", nullable = true)
    private Date receiveVerificationDate;

    @Column(name = "SEND_VERIFY_SCAN_TSP", nullable = true)
    private Date sendVerificationDate;

    @Column(name = "SHIPPED_WEIGHT_QTY")
    private Double weight;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SHIPPED_WEIGHT_QTY_UOM_ID", referencedColumnName = "UOM_ID")
    private UnitOfMeasureEntity weightUOM;

    @Column(name = "CONTENT_PIECES_QTY ", nullable = true)
    private Integer contentPiecesQuantity;

    @Column(name = "ELECTRONIC_PRODUCT_CD", nullable = true)
    private String electronicProductCode;

    @ManyToOne(fetch = FetchType.EAGER)  //TODO do we need -> cascade = CascadeType.PERSIST
    @JoinColumn(name = "packed_in_storage_container_id")
    private StorageContainerEntity storageContainer;

    public StorageContainerEntity getStorageContainer() {
        return storageContainer;
    }

    public void setStorageContainer(StorageContainerEntity storageContainer) {
        this.storageContainer = storageContainer;
    }

    public Long getScannedContainerId() {
        return scannedContainerId;
    }

    public void setScannedContainerId(Long scannedContainerId) {
        this.scannedContainerId = scannedContainerId;
    }

    public String getElectronicProductCode() {
        return electronicProductCode;
    }

    public void setElectronicProductCode(String electronicProductCode) {
        this.electronicProductCode = electronicProductCode;
    }

    public Long getContainerId() {
        return scannedContainerId;
    }

    public Integer getScanOrder() {
        return scanOrder;
    }

    public void setScanOrder(Integer scanOrder) {
        this.scanOrder = scanOrder;
    }

    public Date getReceiveVerificationDate() {
        return receiveVerificationDate;
    }

    public void setReceiveVerificationDate(Date date) {
        receiveVerificationDate = date;
    }

    public Date getSendVerificationDate() {
        return sendVerificationDate;
    }

    public void setSendVerificationDate(Date date) {
        sendVerificationDate = date;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public UnitOfMeasureEntity getWeightUOM() {
        return weightUOM;
    }

    public void setWeightUOM(UnitOfMeasureEntity weightUOM) {
        this.weightUOM = weightUOM;
    }

    public Integer getQuantity() {
        return contentPiecesQuantity;
    }

    public void setQuantity(Integer quantity) {
        this.contentPiecesQuantity = quantity;
    }

    public static ScannedContainerEntity newScannedContentContainer(ContentType contentType) {
        if (contentType == null) {
            throw new IllegalArgumentException("Unsupported content type: null");
        }
        switch (contentType) {
            case INVENTORY:
                return new InventoryScannedContainerEntity();
            case PLOT:
                return new PlotScannedContainerEntity();
            case TISSUE_PLATE:
                return new TissuePlateContainerEntity();
            case CASSETTE:
                return new CassetteContainerEntity();
            case OTHER:
                return new OtherContainerEntity();
            case WHOLE_PLANTS:
                return new EventConstructContainerEntity();
            case HD_TRAY:
                return new HDTrayContainerEntity();
            default:
                throw new IllegalArgumentException("Unsupported content type: " + contentType);
        }
    }

    public abstract T getContent();

    public abstract void setContent(T contentEntity);

    public abstract ContentType getContentType();

    public abstract Long getIdForRegulatedMovement();

    public abstract Collection<RegulatedInventoryMovementEntity> getRegulatedMovements();

    public abstract void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement);

    public abstract void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements);

    @Override
    public String toString() {
        return "ScannedContainer{" +
                "id=" + scannedContainerId +
                ", scanOrder=" + scanOrder +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ScannedContainerEntity that = (ScannedContainerEntity) o;

        return !(scannedContainerId != null ? !scannedContainerId.equals(that.scannedContainerId) : that.scannedContainerId != null);

    }

    @Override
    public int hashCode() {
        return scannedContainerId != null ? scannedContainerId.hashCode() : 0;
    }
}
