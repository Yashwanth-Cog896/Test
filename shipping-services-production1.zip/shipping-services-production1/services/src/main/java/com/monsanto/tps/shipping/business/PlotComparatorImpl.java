package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.TestSetEntryEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


@Service
public class PlotComparatorImpl implements PlotComparator {
    private static final Comparator<Object[] > PLOT_NUMBER_COMPARATOR = new Comparator<Object[] >( ) {

        @Override
        public int compare(Object[] input1, Object[] input2) {
            Integer index1=(Integer)input1[0];
            Integer plotNumber1 = ((PlotEntity)input1[1]).getPlotNumber();
            Integer index2=(Integer)input2[0];
            Integer plotNumber2 = ((PlotEntity)input2[1]).getPlotNumber();
            return compareObjects(index1, index2, plotNumber1, plotNumber2);
        }
    };

    private static final Comparator<Object[] > ENTRY_NUMBER_COMPARATOR = new Comparator<Object[] >( ) {

        @Override
        public int compare(Object[] input1, Object[] input2) {
            Integer index1=(Integer)input1[0];
            Double entry1 = getEntryNumber((PlotEntity)input1[1]);
            Integer index2=(Integer)input2[0];
            Double entry2 = getEntryNumber((PlotEntity)input2[1]);
            return compareObjects(index1, index2, entry1, entry2);
        }

        private Double getEntryNumber(PlotEntity p) {
            TestSetEntryEntity testSetEntry = p.getTestSetEntry();
            return testSetEntry!=null?testSetEntry.getEntryNumber():null;
        }
    };

    private static final Comparator<Object[] > REP_RANGE_COLUMN_COMPARATOR = new Comparator<Object[] >( ) {

        @Override
        public int compare(Object[] input1, Object[] input2) {
            Integer index1=(Integer)input1[0];
            Integer index2=(Integer)input2[0];
            Integer range1 = getRangesTall((PlotEntity)input1[1]);
            Integer range2 = getRangesTall((PlotEntity)input2[1]);
            Integer column1 = getColumnsWide((PlotEntity)input1[1]);
            Integer column2 =  getColumnsWide((PlotEntity)input2[1]);

            int rangeResults = range1==null?(range2==null?0:1):(range2==null)?-1:range1.compareTo(range2);
            return (rangeResults!=0)?rangeResults:compareObjects(index1,index2,column1,column2);
        }

        private Integer getRangesTall(PlotEntity plot) {
            return plot.getRange();
        }

        private Integer getColumnsWide(PlotEntity plot) {
            return plot.getColumn();
        }
    };
    private static final Comparator<Object[] > ABS_REP_RANGE_COLUMN_COMPARATOR = new Comparator<Object[] >( ) {

        @Override
        public int compare(Object[] input1, Object[] input2) {
            Integer index1=(Integer)input1[0];
            Integer index2=(Integer)input2[0];
            Integer range1 = ((PlotEntity)input1[1]).getAbsoluteRange();
            Integer range2 = ((PlotEntity)input2[1]).getAbsoluteRange();
            Integer column1 = ((PlotEntity)input1[1]).getAbsoluteColumn();
            Integer column2  = ((PlotEntity)input2[1]).getAbsoluteColumn();

            int rangeResults = range1==null?(range2==null?0:1):(range2==null)?-1:range1.compareTo(range2);
            return (rangeResults!=0)?rangeResults:compareObjects(index1,index2,column1,column2);
        }
    };

    private static int compareObjects(Integer index1, Integer index2, Number value1, Number value2) {
        if (value1 == null) {
            return (value2 == null) ? index1.compareTo(index2) : 1;
        } else if (value1 instanceof Integer) {
            return (value2 == null) ? -1 : Integer.valueOf(value1.intValue()).compareTo(value2.intValue());
        } else {
            return (value2 == null) ? -1 : Double.valueOf(value1.doubleValue()).compareTo(value2.doubleValue());
        }
    }

    @Override
    public List<PlotEntity> sort(Collection<PlotEntity> plots, String order) {
        Comparator<Object[]> comparator = PLOT_NUMBER_COMPARATOR;
        if(PlotComparator.REP_RANGE_AND_COLUMN.equals(order)){
             comparator=REP_RANGE_COLUMN_COMPARATOR;
        }
        else  if(PlotComparator.ABS_REP_RANGE_AND_COLUMN.equals(order)){
            comparator=ABS_REP_RANGE_COLUMN_COMPARATOR;
        }
        else if(PlotComparator.ENTRY_NUMBER.equals(order)){
            comparator=ENTRY_NUMBER_COMPARATOR;
        }
        return sortPlots(plots, comparator);
    }

    private List<PlotEntity> sortPlots(Collection<PlotEntity> unsortedPlots, Comparator<Object[]> comparator) {
        int numPlots = unsortedPlots.size();
        List <Object[]> plotTuples = new ArrayList(numPlots);
        int plotIndex=0;
        for(PlotEntity plot: unsortedPlots){
           plotTuples.add(new Object[]{plotIndex,plot});
           plotIndex++;
        }

        Collections.sort(plotTuples, comparator);
        return Lists.transform(plotTuples, new Function<Object[], PlotEntity>() {
            @Override
            public PlotEntity apply(Object[] input) {
                return (PlotEntity) input[1];
            }
        });
    }
}
