package com.monsanto.tps.shipping.business;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.monsanto.tps.party.transfer.Contact;
import com.monsanto.tps.shipping.domain.AgencyEnum;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.RegulatedEventStatusService;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;
import com.monsanto.tps.shipping.util.EventHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RegulatedStatusCheckImpl implements RegulatedStatusCheck {
    private static final Log LOG = LogFactory.getLog(RegulatedStatusCheckImpl.class);

    public static final String COMMA = ",";
    public static final String PUERTO_RICO = "PUERTO RICO";
    public static final String UNITED_STATES = "UNITED STATES";

    @Autowired
    private RegulatedCountryBusiness regulatedCountryBusiness;
    @Autowired
    private EventHelper eventHelper;
    @Autowired
    private RegulatedEventStatusService regulatedEventStatusService;
    @Autowired
    private ContactBusiness contactBusiness;

    @Override
    public List<RegulatedAPIResponse> checkRegulatedStatus(Collection<Event> events, Set<String> allEventStrings) {
        Long st_time = System.currentTimeMillis();
        List<RegulatedAPIResponse> responseMap = regulatedEventStatusService.getRegulatedAPIResponses(allEventStrings);

        Long end_time = System.currentTimeMillis() - st_time;
        LOG.info("****** Elapsed Time for checkRegulatedStatus= "+(end_time)+" msecs");
        return responseMap;
    }

    @Override
    public Collection<Event> getEpaEvents(Collection<Event> events, List<RegulatedAPIResponse> responseMap) {
        Long st_time = System.currentTimeMillis();
        Set<Event> epaEvents = Sets.newHashSet();

        List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites = getEpaValidatedEventsAPI(responseMap);
        if (!CollectionUtils.isEmpty(epaAgencyInfoComposites)) {
            for (Event event : events) {

                boolean malePreEup = false;
                boolean maleEpaRegulated = false;
                EpaAgencyInfoCompositeAPI maleEpaAgencyInfoComposite = getMatchingAgencyInfoCompositeAPI(epaAgencyInfoComposites, event.getMaleEventString());
                if (maleEpaAgencyInfoComposite != null) {
                    if (maleEpaAgencyInfoComposite.isRegulated()) {
                        event.setRegulatedByMale(true);
                        maleEpaRegulated = true;
                    } else if (maleEpaAgencyInfoComposite.isPreEup()) {
                        malePreEup = true;
                    }
                }

                EpaAgencyInfoCompositeAPI epaAgencyInfoComposite = getMatchingAgencyInfoCompositeAPI(epaAgencyInfoComposites, event.getEventString());

                if ((epaAgencyInfoComposite != null && epaAgencyInfoComposite.isRegulated()) || maleEpaRegulated) {
                    event.getRegulatingAgencies().add(AgencyEnum.EPA);
                    epaEvents.add(event);
                }

                if ((epaAgencyInfoComposite != null && epaAgencyInfoComposite.isPreEup()) || malePreEup) {
                    event.getRegulatingAgencies().add(AgencyEnum.PRE_EUP);
                    epaEvents.add(event);
                }
            }
        }

        Long end_time = System.currentTimeMillis() - st_time;
        LOG.info("****** Elapsed Time for getEpaEvents= " + (end_time) + " msecs");
        return epaEvents;
    }

    @Override
    public Collection<Event> getRegulatedEvents(Collection<Event> events, List<RegulatedAPIResponse> responseMap) {
        Collection<Event> usdaRegulatedEvents = Lists.newArrayList();

        Set<String> usdaValidatedEventStrings = getUsdaValidatedEvents(responseMap);
        if (usdaValidatedEventStrings != null) {
            for (Event event : events) {
                boolean regulatedByMale  = event.getMaleEventString() != null && usdaValidatedEventStrings.contains(event.getMaleEventString());

                if (usdaValidatedEventStrings.contains(event.getEventString()) || regulatedByMale) {
                    event.getRegulatingAgencies().add(AgencyEnum.USDA);
                    //if the passed in event is already regulatedByMale then we don't want to set it to false if the male isn't usda regulated
                    if (regulatedByMale) {
                        event.setRegulatedByMale(true);
                    }
                    usdaRegulatedEvents.add(event);
                }
            }
        }
        return usdaRegulatedEvents;
    }

    @Override
    public Collection<Event> getStewardshipEvents(ShipmentPackingListEntity packingListEntity, Collection<Event> events,
                                                  Collection<String> eventStrings, List<RegulatedAPIResponse> responseMap) {

        Contact toContact = contactBusiness.getPartyContact(packingListEntity.getToContactId());
        String country = toContact.getCountry();

        Collection<Event> stewardedEvents = Lists.newArrayList();

        if (!regulatedCountryBusiness.isCountryRegulatedByStewardship(country)) {
            return stewardedEvents;
        }

        Collection<StewardshipEvent> stewardshipEvents = processStewardshipResponse(eventStrings, responseMap);
        Multimap<String, String> countryCodeToEventsMap = HashMultimap.create();
        String toCountryCodeOfPackingList = regulatedCountryBusiness.lookUpCountryAbbr(country);

        for(StewardshipEvent stewardshipEvent : stewardshipEvents) {
            Set<String> eventNames = Sets.newHashSet(stewardshipEvent.getEvent());
            String country1 = stewardshipEvent.getCountry();
            //Hack API returns "US" not "USA"
            if("US".equalsIgnoreCase(country1)) {
                country1 = "USA";
            }
            countryCodeToEventsMap.put(country1, eventHelper.getSortedEvent(eventNames));
        }

        Set<String> regulatedEvents = Sets.newHashSet(countryCodeToEventsMap.get(isPuertoRico(toCountryCodeOfPackingList) ? getUsaAbbr() : toCountryCodeOfPackingList));
        if (regulatedEvents != null) {
            for (Event event : events) {
                boolean regulatedByMale = event.getMaleEventString() != null && regulatedEvents.contains(event.getMaleEventString());
                // Because of the event stack change in 2024, we need this to allow stewardship to handle event stacks and not just single events
                String eventStack = eventHelper.getCombinedEventString(event);
                if (regulatedEvents.contains(eventStack) || regulatedByMale) {
                    if (event.getRegulatingAgencies().isEmpty()) {
                        event.getRegulatingAgencies().add(AgencyEnum.STEWARDSHIP);
                        //if the passed in event is already regulatedByMale then we don't want to set it to false if the male isn't stewarded
                        if (regulatedByMale) {
                            event.setRegulatedByMale(true);
                        }
                        stewardedEvents.add(event);
                    }
                }
            }
        }

        return stewardedEvents;
    }

    private Collection<StewardshipEvent> processStewardshipResponse(Collection<String> eventStrings, List<RegulatedAPIResponse> responseMap) {
        Collection<StewardshipEvent> stewardshipEvents = Lists.newArrayList();
        for(RegulatedAPIResponse regulatedAPIResponse : responseMap) {
            String event = regulatedAPIResponse.getEvent();
            if(regulatedAPIResponse.getCountries() != null) {
                for(RegulatedAPIResponse.Country country : regulatedAPIResponse.getCountries()) {
                    String countryCode = country.getCountry();
                    if(country.getAgencies() != null) {
                        for(RegulatedAPIResponse.Country.Agency agency : country.getAgencies()) {
                            if("STWRDSH".equals(agency.getAgency()) && agency.getStatusInfo() != null
                                    && "Stewarded".equals(agency.getStatusInfo().getStatus())) {
                                stewardshipEvents.add(new StewardshipEvent(event, countryCode));
                            }
                        }
                    }
                }
            }
        }
        return stewardshipEvents;
    }

    private String getUsaAbbr() {
        return regulatedCountryBusiness.lookUpCountryAbbr(UNITED_STATES);
    }

    private boolean isPuertoRico(String toCountryCodeOfPackingList) {
        return toCountryCodeOfPackingList.equalsIgnoreCase(regulatedCountryBusiness.lookUpCountryAbbr(PUERTO_RICO));
    }

    private List<EpaAgencyInfoCompositeAPI> getEpaValidatedEventsAPI(List<RegulatedAPIResponse> regulatedAPIResponses) {
        List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites = Lists.newArrayList();
        for(RegulatedAPIResponse regulatedAPIResponse : regulatedAPIResponses) {
            if(regulatedAPIResponse.getCountries() != null) {
                for(RegulatedAPIResponse.Country country : regulatedAPIResponse.getCountries()) {
                    if("US".equals(country.getCountry())) {
                        epaAgencyInfoComposites.add(new EpaAgencyInfoCompositeAPI(regulatedAPIResponse.getEvent(), country.getAgencies()));
                        break;
                    }
                }
            }
        }
        return epaAgencyInfoComposites;
    }

    private EpaAgencyInfoCompositeAPI getMatchingAgencyInfoCompositeAPI(List<EpaAgencyInfoCompositeAPI> epaAgencyInfoComposites,
                                                                        String eventString) {
        if (StringUtils.isEmpty(eventString)) {
            return null;
        }

        for (EpaAgencyInfoCompositeAPI epaAgencyInfoComposite : epaAgencyInfoComposites) {
            if (eventString.equals(epaAgencyInfoComposite.getEventStackString())) {
                return epaAgencyInfoComposite;
            }
        }
        return null;
    }

    private Set<String> getUsdaValidatedEvents(List<RegulatedAPIResponse> responseMap) {
        Set<String> events = Sets.newHashSet();

        for(RegulatedAPIResponse response : responseMap) {
            if(response.getCountries() != null) {
                for(RegulatedAPIResponse.Country country : response.getCountries()) {
                    if(country.getAgencies() != null) {
                        for(RegulatedAPIResponse.Country.Agency agency : country.getAgencies()) {
                            if(agency.getAgency().equals("USDA") && agency.getStatusInfo() != null
                                    && "Regulated".equals(agency.getStatusInfo().getStatus())) {
                                events.add(response.getEvent());
                            }
                        }
                    }
                }
            }
        }
        return events;
    }

    private class StewardshipEvent {
        private String country;
        private String event;

        public StewardshipEvent(String event, String country) {
            this.event = event;
            this.country = country;
        }

        public String getCountry() {
            return country;
        }

        public String getEvent() {
            return event;
        }

        @Override
        public String toString() {
            return "StewardshipEvent{" +
                    "country='" + country + '\'' +
                    ", event='" + event + '\'' +
                    '}';
        }
    }

    private class EpaAgencyInfoCompositeAPI {
        private static final String USDA_REGULATED = "Regulated";
        private static final String USDA_DE_REGULATED = "Deregulated";
        private static final String EPA_PRE_REGISTERED = "Pre-Registration";
        private static final String EPA_DISCOVERY_RELEASE = "Discovery-Release";
        private static final String EPA_REGISTERED = "Registered";

        private EpaAgencyInfoCompositeAPI(String eventStackString, Collection<RegulatedAPIResponse.Country.Agency> agencies) {
            this.eventStackString = eventStackString;
            this.agencies = agencies;

            this.findMostAccuratePipStack();
        }

        private String eventStackString;
        private Collection<RegulatedAPIResponse.Country.Agency> agencies;
        private RegulatedAPIResponse.Country.Agency pipStack;

        public String getEventStackString() {
            return eventStackString;
        }

        public boolean isRegulated() {
            boolean isRegulated = false;
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if((agency.getAgency().equals(AgencyEnum.EPA.getAbbr()) && agency.getStatusInfo() != null
                        && EPA_PRE_REGISTERED.equals(agency.getStatusInfo().getStatus()))) {
                    isRegulated = true;
                    break;
                }
            }
            return  isRegulated;
        }

        public boolean isPreEup() {
            boolean isRegulated = !isRegulated();
            boolean isPreEup = false;
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getAgency().equals(AgencyEnum.EPA.getAbbr()) && agency.getStatusInfo() != null
                        && EPA_DISCOVERY_RELEASE.equals(agency.getStatusInfo().getStatus())) {
                    isPreEup = true;
                    break;
                }
            }
            return isRegulated && isPreEup;
        }

        private void findMostAccuratePipStack() {
            Set<String> singles = getSinglePips(); //Find matching events strings that are not stacks (single)

            String eventStack = getPipStackString(singles);
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                String matchedEvents = "";
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
                if(eventStack.equals(matchedEvents))
                    pipStack = agency;
            }
        }

        private String getPipStackString(Set<String> singles) {
            StringBuilder pipStack = new StringBuilder();
            for (String single : singles) {
                pipStack.append(single);
                pipStack.append(",");
            }
            pipStack.deleteCharAt(pipStack.lastIndexOf(","));
            return pipStack.toString();
        }

        public String getPipStackString() {
            String matchedEvents = "";
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
            }
            return matchedEvents;
        }

        private Set<String> getSinglePips() {
            Set<String> singles = new TreeSet<String>();
            String matchedEvents = "";
            for(RegulatedAPIResponse.Country.Agency agency : agencies) {
                if(agency.getStatusInfo() != null && agency.getStatusInfo().getRegulatedEvents() != null)
                    matchedEvents = agency.getStatusInfo().getRegulatedEvents();
                else if(agency.getStatusInfo() != null && agency.getStatusInfo().getReducedPipEvent() != null)
                    matchedEvents = agency.getStatusInfo().getReducedPipEvent();
                singles.addAll(Arrays.asList(matchedEvents.split(",")));
            }
            return singles;
        }
    }
}
