package com.monsanto.tps.shipping.converter;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.domain.CassetteEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.SeedTrayCellEntity;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class CassetteContentConverter {

    public PlotEntity getFirstPlotFromCassette(ContentEntity contentEntity) {
        return Iterables.find(((CassetteEntity) contentEntity).getSeedTrayCells(), new Predicate<SeedTrayCellEntity>() {
            @Override
            public boolean apply(SeedTrayCellEntity seedTrayCellEntity) {
                return seedTrayCellEntity.getPlot() != null;
            }
        }, new SeedTrayCellEntity()).getPlot();
    }

    public Collection<PlotEntity> getPlotsFromCassette(ContentEntity contentEntity) {
        return Sets.newHashSet(Iterables.filter(Collections2.transform(((CassetteEntity) contentEntity).getSeedTrayCells(), new Function<SeedTrayCellEntity, PlotEntity>() {
            @Override
            public PlotEntity apply(SeedTrayCellEntity seedTrayCellEntity) {
                return seedTrayCellEntity.getPlot();
            }
        }), Predicates.notNull()));
    }

    public Collection<String> getTestSetNames(ContentEntity contentEntity) {
        return Sets.newHashSet(Iterables.filter(Collections2.transform(((CassetteEntity) contentEntity).getSeedTrayCells(), new Function<SeedTrayCellEntity, String>() {
            @Override
            public String apply(SeedTrayCellEntity seedTrayCellEntity) {
                PlotEntity plot = seedTrayCellEntity.getPlot();
                return plot != null && null != plot.getTestSetEntry() ? plot.getTestSetEntry().getTestSet().getTestSetName() : null;
            }
        }), Predicates.notNull()));
    }
}
