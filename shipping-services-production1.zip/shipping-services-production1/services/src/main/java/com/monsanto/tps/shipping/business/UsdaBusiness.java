package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.EventDetails;
import com.monsanto.tps.shipping.service.model.Permit;

import java.util.Collection;
import java.util.Set;

/**
 * User: DCENGL
 */
public interface UsdaBusiness {

    Collection<Event> getRegulatedEvents(Collection<Event> events, Set<String> allEventStrings);

    Collection<Permit> getPermits(String country,  Long fromContactId, Long toContactId, Collection<Event> validUsdaEvents, Long cropId);

    void loadAssociatedPermits(ShipmentPackingListEntity packingList, Collection<Event> events);

    void addUsdaEventDetails(EventDetails eventDetails);
}
