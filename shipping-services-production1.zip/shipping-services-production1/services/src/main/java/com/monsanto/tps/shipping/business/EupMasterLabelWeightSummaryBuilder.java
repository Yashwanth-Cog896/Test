package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.EventWeight;

import java.io.ByteArrayOutputStream;
import java.util.Collection;

/**
 * Created with IntelliJ IDEA.
 * User: tbmckay
 * Date: 5/23/14
 * Time: 3:18 PM
 */
public interface EupMasterLabelWeightSummaryBuilder {
    ByteArrayOutputStream createWeightSummaryPage(String eupNumber, Collection<EventWeight> eventWeights) throws Exception;
}
