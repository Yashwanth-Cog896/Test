package com.monsanto.tps.shipping.service;

import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.business.ProgramBusiness;
import com.monsanto.tps.shipping.business.ProgramUserBusiness;
import com.monsanto.tps.shipping.service.model.Program;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.http.HTTPException;
import java.util.List;

/**
 * User: DCENGL
 */
@Component("programService")
public class ProgramServiceImpl implements ProgramService {

    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Autowired
    private ProgramUserBusiness programUserBusiness;

    @Autowired
    private ProgramBusiness programBusiness;

    @Trace
    @Override
    public List<Program> getPrograms() {
        return programBusiness.getPrograms();
    }

    @Override
    public List<Program> getAllForUser() {
        return programUserBusiness.getProgramsForLoginId(getUsername());
    }

    @Override
    public Program getProgramByAccount(Long accountId) {
        return programBusiness.getProgramByAccountId(accountId);
    }

    @Trace
    @Override
    public List<Program> getGrowerProgramsForPackingList(Long packingListId, String shipmentType) {
        return programBusiness.getGrowerProgramsForPackingList(packingListId, ShipmentTypeEnum.getInstance(shipmentType));
    }

    @Transactional(readOnly = true)
    @Override
    public Program getShipToProgramByPlot(String relationship,String plotBarcode) {
        Program program =   null;
        if("harvested".equals(relationship)){
            program = programBusiness.getShipToProgramForHarvestedPlotBarcode(plotBarcode);
        }
        else {
            program = programBusiness.getShipToProgramForToBePlantedPlotBarcode(plotBarcode);
        }
        if(program==null){
            throw new HTTPException(HttpServletResponse.SC_NOT_FOUND);
        }
        return program;
    }




    private String getUsername() {
        UserDetails userDetails = userDetailsProvider.getUserDetails();
        return userDetails != null ? userDetails.getUsername() : "Could not identify user";
    }

}
