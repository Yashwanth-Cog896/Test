package com.monsanto.tps.shipping.business.labels;


import com.google.common.base.Charsets;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.tps.infrastructure.iot.service.PrinterService;
import com.monsanto.tps.infrastructure.iot.transfer.LabelInformation;
import com.monsanto.tps.labelprinting.common.LabelTemplate;
import com.monsanto.tps.labelprinting.common.StreamPrinter;
import com.monsanto.tps.shipping.business.PrintingTemplateBusiness;
import com.monsanto.tps.shipping.domain.ShipmentContainerComparator;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.PrintOptions;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * User: pgadi
 */

@Service
public class LabelBusinessImpl implements LabelBusiness {

    private static final Log LOG = LogFactory.getLog(LabelBusinessImpl.class);

    public static final String SHIPMENT_PERMITS_MESSAGE = "Shipment Permits";
    public static final String CONTAINMENT_LAYER_LABEL = "Outer Containment";
    public static final String OUTER = "Outer";

    public static final String WITHOUT_COMPLIANCE = "_NO_COMPLIANCE";

    private static ImmutableMap<String, String> containmentLabelsMap = ImmutableMap.<String, String>builder()
            .put("large", "SW_CONTAINMENT_LABEL")
            .put("small", "SW_CONTAINMENT_LABEL_SMALL")
            .build();

    private static ImmutableMap<String, String> permitLabelsMap = ImmutableMap.<String, String>builder()
            .put("large", "SW_SHIPMENT_PERMIT_LABEL")
            .put("small", "SW_SHIPMENT_PERMIT_LABEL_SMALL")
            .build();

    @Autowired
    private PrintingTemplateBusiness templateBusiness;

    @Resource(name = "printerService")
    @SuppressWarnings("SpringJavaAutowiringInspection")
    private PrinterService printerService;

    @Autowired
    private ContainerLabelDataSetBuilder containerLabelDataSetBuilder;
    @Autowired
    private PackingListLabelDataSetBuilder packingListLabelDataSetBuilder;

    @Trace
    @Override
    public void printContainmentLabels(ShipmentContainerEntity shipmentContainerEntity, Long printerId, PrintOptions printOptions) {
        ShipmentPackingListEntity shipmentPackingList = shipmentContainerEntity.getShipmentPackingList();

        ContainerLabelDataSet packingListInfoLabelDataSet = containerLabelDataSetBuilder.buildPackingListSpecificData(shipmentPackingList);
        printContainerLabel(shipmentContainerEntity, printOptions, printerId, packingListInfoLabelDataSet);
        printShipmentPermitLabels(printerId, printOptions, shipmentPackingList, packingListInfoLabelDataSet);
    }

    @Trace
    @Override
    public void printAllContainmentLabels(ShipmentPackingListEntity packingList, Long printerId, PrintOptions printOptions) {
        ContainerLabelDataSet packingListInfoLabelDataSet = containerLabelDataSetBuilder.buildPackingListSpecificData(packingList);

        List<ShipmentContainerEntity> shipmentContainers = Lists.newArrayList(packingList.getShipmentContainers());
        Collections.sort(shipmentContainers, new ShipmentContainerComparator());
        printContainmentLabels(printerId, printOptions, packingListInfoLabelDataSet, shipmentContainers);
        printShipmentPermitLabels(printerId, printOptions, packingList, packingListInfoLabelDataSet);
    }

    @Trace
    @Override
    public void printCarrierLabels(Collection<ShipmentContainerEntity> shipmentContainerEntities, Long printerId) {
        List<LabelInformation> labels = Lists.newArrayList();
        for (ShipmentContainerEntity shipmentContainer : shipmentContainerEntities) {
            Collection<ShipmentContainerLabelEntity> shipmentContainerLabels = shipmentContainer.getShipmentContainerLabels();
            if (CollectionUtils.isNotEmpty(shipmentContainerLabels)) {
                labels.add(getLabelInformation(shipmentContainerLabels));
            }
        }

        if (CollectionUtils.isNotEmpty(labels)) {
            printerService.print(printerId, labels);
        }
    }

    private LabelInformation getLabelInformation(Collection<ShipmentContainerLabelEntity> shipmentContainerLabels) {
        LabelInformation labelInformation = new LabelInformation();
        ShipmentContainerLabelEntity label = Iterables.get(shipmentContainerLabels, 0);
        labelInformation.setData(new String(label.getLabelData(), Charsets.UTF_8));

        return labelInformation;
    }

    private void printContainmentLabels(Long printerId, PrintOptions printOptions, ContainerLabelDataSet packingListInfoLabelDataSet, List<ShipmentContainerEntity> shipmentContainers) {
        for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainers) {
            if (!CollectionUtils.isEmpty(shipmentContainerEntity.getStorageContainer().getContainers())) {
                printContainerLabel(shipmentContainerEntity, printOptions, printerId, packingListInfoLabelDataSet);
            } else {
                LOG.info("Label(s) for the box with barcode, " + shipmentContainerEntity.getStorageContainer().getBarcode() + " , are not printed as the box is empty");
            }
        }
    }

    private void printShipmentPermitLabels(Long printerId, PrintOptions printOptions, ShipmentPackingListEntity packingList, ContainerLabelDataSet packingListInfoLabelDataSet) {
        if (printOptions.isPrintShipmentPermitsRequested()) {
            LabelTemplate permitTemplate = getShipmentPermitTemplate(printOptions.isLargeSize());

            ContainerLabelDataSet packingListPermitsLabelDataSet = packingListLabelDataSetBuilder.buildPermitsLabel(packingList);
            packingListInfoLabelDataSet.put(ContainerLabelConstants.CONTAINMENT_LAYER, SHIPMENT_PERMITS_MESSAGE);

            printShipmentPermitLabel(printerId, permitTemplate, packingListInfoLabelDataSet, packingListPermitsLabelDataSet);
        }
    }

    private void printShipmentPermitLabel(Long printerId, LabelTemplate labelTemplate, ContainerLabelDataSet... labelDataSets) {
        LabelInformation labelInfo = new LabelInformation();
        ContainerLabelDataSet containerLabelDataSet = new ContainerLabelDataSet();
        for (ContainerLabelDataSet labelDataSet : labelDataSets) {
            containerLabelDataSet.putAll(labelDataSet.getProperties());
        }
        labelInfo.setData(new StreamPrinter().bindDataToTemplate(labelTemplate, containerLabelDataSet));
        printerService.print(printerId, Lists.newArrayList(labelInfo));
    }

    private LabelTemplate getContainmentLabelTemplate(boolean largeSize, boolean isComplianceNeeded) {
        String template = largeSize ? containmentLabelsMap.get("large") : containmentLabelsMap.get("small");

        if(!isComplianceNeeded){
            template += WITHOUT_COMPLIANCE;
        }

        return templateBusiness.getTemplateByName(template);
    }

    private LabelTemplate getShipmentPermitTemplate(boolean largeSize) {
        return templateBusiness.getTemplateByName(largeSize ? permitLabelsMap.get("large") : permitLabelsMap.get("small"));
    }

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, String> viewLabel(ShipmentPackingListEntity packingList, String containmentLayer, Integer boxNumber, boolean printTotalBoxes) {

        ShipmentContainerEntity shipmentContainerEntity = Lists.newArrayList(packingList.getShipmentContainers()).get(boxNumber - 1);

        ContainerLabelDataSet packingListInfoDataSet = containerLabelDataSetBuilder.buildPackingListSpecificData(packingList);

        ContainerLabelDataSet labelDataSet;

        if (containmentLayer.equals(OUTER)) {
            labelDataSet = containerLabelDataSetBuilder.buildContainerLabelDataSet(shipmentContainerEntity, printTotalBoxes);
            packingListInfoDataSet.put(ContainerLabelConstants.CONTAINMENT_LAYER, CONTAINMENT_LAYER_LABEL);
        } else {
            labelDataSet = packingListLabelDataSetBuilder.buildPermitsLabel(packingList);
            packingListInfoDataSet.put(ContainerLabelConstants.CONTAINMENT_LAYER, SHIPMENT_PERMITS_MESSAGE);
        }

        return (Map) new ContainerLabelDataSet()
                .putAll(packingListInfoDataSet.getProperties())
                .putAll(labelDataSet.getProperties())
                .getProperties();
    }

    private void printContainerLabel(ShipmentContainerEntity shipmentContainerEntity, PrintOptions printOptions, Long printerId,
                                     ContainerLabelDataSet packingListInfoLabelDataSet) {
        Collection<String> containmentLayers = printOptions.getContainmentLayers();
        if (!CollectionUtils.isEmpty(containmentLayers)) {
            ContainerLabelDataSet containerLabelDataSet = containerLabelDataSetBuilder.buildContainerLabelDataSet(shipmentContainerEntity,
                    printOptions.isDisplayTotalBoxesRequested());

            boolean complianceRequired = containerLabelDataSet.getProperties().containsKey(ContainerLabelConstants.AGENCY_APPROVAL_NUMBERS);
            LabelTemplate template = getContainmentLabelTemplate(printOptions.isLargeSize(), complianceRequired);

            for (String containmentLayer : containmentLayers) {
                containerLabelDataSet.put(ContainerLabelConstants.CONTAINMENT_LAYER, containmentLayer);
                LabelInformation labelInfo = new LabelInformation();
                labelInfo.setData(new StreamPrinter().bindDataToTemplate(template, new ContainerLabelDataSet()
                        .putAll(packingListInfoLabelDataSet.getProperties())
                        .putAll(containerLabelDataSet.getProperties())));

                printerService.print(printerId, Lists.newArrayList(labelInfo));
            }
        }
    }
}