package com.monsanto.tps.shipping.dao.primarykey;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerationException;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InventoryMgtIdGenerator implements IdentifierGenerator {
    private static final String GET_ID_SQL = "select column_value as id from table(Inventory_Mgt.Get_Nextid())";

    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        PreparedStatement preparedStatement = null;//NOPMD - separate close method
        ResultSet resultSet = null;//NOPMD - separate close method
        try {
            preparedStatement = session.getBatcher().prepareSelectStatement(GET_ID_SQL);
            resultSet = preparedStatement.executeQuery();
            resultSet.next();
            return resultSet.getLong(1);
        } catch (Exception e) {
            throw new IdentifierGenerationException("Unable to retrieve Inventory_Mgt.Get_Nextid()", e);
        } finally {
            close(resultSet);
            close(preparedStatement);
        }
    }

    private void close(ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
        } catch (SQLException ignored) {
        }
    }

    private void close(PreparedStatement preparedStatement) {
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
        } catch (SQLException ignored) {
        }
    }
}
