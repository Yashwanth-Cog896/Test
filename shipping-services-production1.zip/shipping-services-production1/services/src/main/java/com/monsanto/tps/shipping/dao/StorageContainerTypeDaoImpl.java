package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.StorageContainerTypeEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
public class StorageContainerTypeDaoImpl implements StorageContainerTypeDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public StorageContainerTypeEntity getByName(String name) {
        return (StorageContainerTypeEntity) sessionFactory.getCurrentSession()
                .createQuery("from StorageContainerTypeEntity where name = :name ")
                .setParameter("name", name).uniqueResult();
    }
}
