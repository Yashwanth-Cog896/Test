package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.InternationalCompositesBusiness;
import com.monsanto.tps.shipping.service.model.InternationalVendor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("internationalVendorService")
public class InternationalVendorServiceImpl implements InternationalVendorService {

    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    @Override
    public List<InternationalVendor> getGtmContacts() {
        return internationalCompositesBusiness.getGtmContacts();
    }
}
