package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.InternationalCompositesBusiness;
import com.monsanto.tps.shipping.service.model.InternationalStorageLocation;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("internationalStorageLocationService")
public class InternationalStorageLocationServiceImpl implements InternationalStorageLocationService {

    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;

    @Trace
    @Transactional(readOnly = true)
    @Override
    public InternationalStorageLocation getStorageLocation(String id) {
        return internationalCompositesBusiness.getStorageLocation(id);
    }

    @Trace
    @Transactional(readOnly = true)
    @Override
    public List<InternationalStorageLocation> getStorageLocations() {
        return internationalCompositesBusiness.getStorageLocations();
    }

}
