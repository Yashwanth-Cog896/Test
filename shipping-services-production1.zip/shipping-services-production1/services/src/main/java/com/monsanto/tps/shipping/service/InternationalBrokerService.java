package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.InternationalCustomer;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * User: pgadi
 */
@Path("/international/broker")
public interface InternationalBrokerService {

    @GET
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    @Path("/{broker-id}")
    public InternationalCustomer getInternationalBroker(@PathParam("broker-id") String id);

    @GET
    @Produces(APPLICATION_JSON)
    public List<InternationalCustomer> getInternationalBrokers();
}
