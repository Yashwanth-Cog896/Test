package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * User: SDCHIL
 */
@Entity
@Table(name = "CARRIER_NO_SHIP_DATE", schema = "INVENTORY_MGT")
public class CarrierNoShipDate {

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(name = "inventory-mgt-uuid", strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator")
    @Column(name = "CARRIER_NO_SHIP_DATE_ID", nullable = false)
    private Long carrierNoShipDateId;

    @Column(name = "CARRIER_ID")
    private Long carrierId;

    @Column(name = "NO_SHIP_DATE")
    private Date noShipDate;

    public Long getCarrierNoShipDateId() {
        return carrierNoShipDateId;
    }

    public void setCarrierNoShipDateId(Long carrierNoShipDateId) {
        this.carrierNoShipDateId = carrierNoShipDateId;
    }

    public Long getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(Long carrierId) {
        this.carrierId = carrierId;
    }

    public Date getNoShipDate() {
        return noShipDate;
    }

    public void setNoShipDate(Date noShipDate) {
        this.noShipDate = noShipDate;
    }
}
