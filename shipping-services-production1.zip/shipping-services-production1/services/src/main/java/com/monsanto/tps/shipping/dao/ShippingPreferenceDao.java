package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShippingPreferenceEntity;

/**
 * User: DCENGL
 */
public interface ShippingPreferenceDao {

    ShippingPreferenceEntity findShippingPreferenceByType(String name, Long accountId);

}
