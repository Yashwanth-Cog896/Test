package com.monsanto.tps.shipping.business.labels;

import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.PrintOptions;

import java.util.Collection;
import java.util.Map;

/**
 * User: pgadi
 */
public interface LabelBusiness {

    void printContainmentLabels(ShipmentContainerEntity shipmentContainerEntity, Long printerId, PrintOptions printOptions);

    void printAllContainmentLabels(ShipmentPackingListEntity packingList, Long printerId, PrintOptions printOptions);

    void printCarrierLabels(Collection<ShipmentContainerEntity> shipmentContainerEntities, Long printerId);

    Map<String, String> viewLabel(ShipmentPackingListEntity packingList, String containmentLayer, Integer boxNumber, boolean printTotalBoxes);
}
