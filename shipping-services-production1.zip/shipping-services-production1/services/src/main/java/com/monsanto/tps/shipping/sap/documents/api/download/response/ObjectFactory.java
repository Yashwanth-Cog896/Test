
package com.monsanto.tps.shipping.sap.documents.api.download.response;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the generic.integrationservices.com.monsanto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SharepointDocument_QNAME = new QName("http://monsanto.com.integrationservices.generic", "SharepointDocument");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generic.integrationservices.com.monsanto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SharepointDocumentType }
     * 
     */
    public SharepointDocumentType createSharepointDocumentType() {
        return new SharepointDocumentType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SharepointDocumentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://monsanto.com.integrationservices.generic", name = "SharepointDocument")
    public JAXBElement<SharepointDocumentType> createSharepointDocument(SharepointDocumentType value) {
        return new JAXBElement<SharepointDocumentType>(_SharepointDocument_QNAME, SharepointDocumentType.class, null, value);
    }

}
