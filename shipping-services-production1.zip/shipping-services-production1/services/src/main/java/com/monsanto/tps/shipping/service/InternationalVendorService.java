package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.InternationalVendor;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/international/vendor")
public interface InternationalVendorService {

    @GET
    @Path("/gtm")
    @Produces(APPLICATION_JSON)
    List<InternationalVendor> getGtmContacts();
}
