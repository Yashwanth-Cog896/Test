package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "SHIPMENT_COMMODITY", schema = "INVENTORY_MGT")
public class CommodityEntity {

    @Id
    @Column(name = "SHIPMENT_COMMODITY_ID", nullable = false)
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    private Long id;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "COMMODITY_MANF_COUNTRY_NAME")
    private String countryOfManufactureISOCode;

    @Column(name = "QUANTITY")
    private Integer quantity;

    @Column(name = "WEIGHT")
    private Double weight;

    @Column(name = "WEIGHT_UOM_ID")
    private Long unitOfMeasureId;

    @Column(name = "CUSTOMS_VALUE")
    private Double customsValue;

    @ManyToOne
    @JoinColumn(name = "SHIPMENT_ID")
    private ShipmentEntity shipment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCountryOfManufactureISOCode() {
        return countryOfManufactureISOCode;
    }

    public void setCountryOfManufactureISOCode(String countryOfManufactureISOCode) {
        this.countryOfManufactureISOCode = countryOfManufactureISOCode;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Long getUnitOfMeasureId() {
        return unitOfMeasureId;
    }

    public void setUnitOfMeasureId(Long unitOfMeasureId) {
        this.unitOfMeasureId = unitOfMeasureId;
    }

    public Double getCustomsValue() {
        return customsValue;
    }

    public void setCustomsValue(Double customsValue) {
        this.customsValue = customsValue;
    }

    public ShipmentEntity getShipment() {
        return shipment;
    }

    public void setShipment(ShipmentEntity shipment) {
        this.shipment = shipment;
    }
}
