package com.monsanto.tps.shipping.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * User: pgadi
 */
@Repository
public class FcmCropDaoImpl implements FcmCropDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @Cacheable("METHOD_CACHE")
    public Long getMidasCropId(Long cropId) {
        return ((BigDecimal) sessionFactory.getCurrentSession()
                .createSQLQuery("select MIDAS_CROP_ID from FCM.CROP where CROP_ID = :cropId")
                .setParameter("cropId", cropId)
                .uniqueResult()).longValue();
    }
}
