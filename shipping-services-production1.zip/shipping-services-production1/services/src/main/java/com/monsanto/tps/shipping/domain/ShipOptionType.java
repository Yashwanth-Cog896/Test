package com.monsanto.tps.shipping.domain;

/**
 * User: DCENGL
 */
public enum ShipOptionType {

    PACKAGING("Packaging"),
    SERVICE_TYPE("Service Types"),
    SIGN_OPTION("Sign Options");

    private final String name;

    ShipOptionType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static ShipOptionType fromName(String name) {
        for (ShipOptionType shipOptionType : values()) {
            if (shipOptionType.getName().equals(name)) {
                return shipOptionType;
            }
        }
        return null;
    }


}
