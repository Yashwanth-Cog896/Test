package com.monsanto.tps.shipping.dao;

/**
 * User: pgadi
 */
public interface AppParameterDao {
    String getParameterValueByNameAndApplication(String paramName, String appName);
}
