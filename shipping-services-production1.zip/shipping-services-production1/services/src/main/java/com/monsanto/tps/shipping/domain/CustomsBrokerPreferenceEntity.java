
/**
 * Created by TMILB on 7/8/14.
 *
 * This isn't so much a "preferences" table as it is a "mapping" table between a broker, and the country he services
 */

package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "CUSTOMS_BROKER_PREFERENCE", schema = "INVENTORY_MGT")
public class CustomsBrokerPreferenceEntity {
    @Id
    @Column(name = "CUSTOMS_BROKER_PREFERENCE_ID", nullable = false)
    private Long customsBrokerPreferenceId;
    @Column(name = "ACCT_ID", nullable = false)
    private long accountId;
    @Column(name = "COUNTRY_NAME")
    private String countryName;
    @Column(name = "INACTIVE_DTTM")
    private Date inactiveDateTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CUSTOMS_BROKER_ID")
    private CustomsBrokerEntity customsBroker;

    public Long getCustomsBrokerPreferenceId() {
        return customsBrokerPreferenceId;
    }

    public void setCustomsBrokerPreferenceId(Long customsBrokerPreferenceId) {
        this.customsBrokerPreferenceId = customsBrokerPreferenceId;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public CustomsBrokerEntity getCustomsBroker() {
        return customsBroker;
    }

    public void setCustomsBroker(CustomsBrokerEntity customsBroker) {
        this.customsBroker = customsBroker;
    }

    public Date getInactiveDateTime() {
        return inactiveDateTime;
    }

    public void setInactiveDateTime(Date inactiveDateTime) {
        this.inactiveDateTime = inactiveDateTime;
    }
}
