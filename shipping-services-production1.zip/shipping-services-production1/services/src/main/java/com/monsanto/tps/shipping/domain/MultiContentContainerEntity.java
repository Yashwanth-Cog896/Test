package com.monsanto.tps.shipping.domain;

import java.util.List;

public interface MultiContentContainerEntity {
    List<? extends ContentEntity> getContents();
    CropEntity getCrop();
}
