package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;

/**
 * User: DCENGL
 */
public interface ShipmentContainerDao {

    void delete(ShipmentContainerEntity shipmentContainerEntity);

    ShipmentContainerEntity load(long shipmentContainerId);

    void save(ShipmentContainerEntity shipmentContainerEntity);

    void updateUom(long packingListId, long uomId);
}
