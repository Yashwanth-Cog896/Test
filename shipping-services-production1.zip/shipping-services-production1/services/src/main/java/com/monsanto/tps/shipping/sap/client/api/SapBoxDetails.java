
package com.monsanto.tps.shipping.sap.client.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapBoxDetails", propOrder = {
    "handlingUnit",
    "grossWeight",
    "netWeight",
    "weightUnit",
    "materialDetails"
})
public class SapBoxDetails {

    @XmlElement(name = "HandlingUnit", required = true)
    private String handlingUnit;
    @XmlElement(name = "GrossWeight", required = true)
    private BigDecimal grossWeight;
    @XmlElement(name = "NetWeight", required = true)
    private BigDecimal netWeight;
    @XmlElement(name = "WeightUnit", required = true)
    private String weightUnit;
    @XmlElement(name = "item")
    @XmlElementWrapper(name = "MaterialDetail")
    private List<MaterialDetail> materialDetails;

    public String getHandlingUnit() {
        return handlingUnit;
    }

    public void setHandlingUnit(String value) {
        this.handlingUnit = value;
    }

    public BigDecimal getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(BigDecimal value) {
        this.grossWeight = value;
    }

    public BigDecimal getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(BigDecimal value) {
        this.netWeight = value;
    }

    public String getWeightUnit() {
        return weightUnit;
    }

    public void setWeightUnit(String value) {
        this.weightUnit = value;
    }

    public List<MaterialDetail> getMaterialDetails() { return materialDetails; }

    public void setMaterialDetails(List<MaterialDetail> materialDetails) { this.materialDetails = materialDetails; }
}
