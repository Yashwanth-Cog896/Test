package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.MidasUserEntity;

public interface MidasUserDao {

    public MidasUserEntity getByUserId(String userId);
}
