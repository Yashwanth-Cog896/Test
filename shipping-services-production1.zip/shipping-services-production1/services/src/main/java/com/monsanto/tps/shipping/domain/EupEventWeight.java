package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;

import java.util.Collection;

/**
 * User: pgadi
 */
public class EupEventWeight {

    private Collection<EventWeight> eventWeightCollection =  Lists.newArrayList();
    private String monsantoId;
    private String agencyNumber;

    public String getMonsantoId() {
        return monsantoId;
    }

    public void setMonsantoId(String monsantoId) {
        this.monsantoId = monsantoId;
    }

    public Collection<EventWeight> getEventWeightCollection() {
        return eventWeightCollection;
    }

    public void setEventWeightCollection(Collection<EventWeight> eventWeightCollection) {
        this.eventWeightCollection = eventWeightCollection;
    }

    public String getAgencyNumber() { return agencyNumber; }

    public void setAgencyNumber(String agencyNumber) { this.agencyNumber = agencyNumber; }
}
