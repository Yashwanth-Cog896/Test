package com.monsanto.tps.shipping.business;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.BadPdfFormatException;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;
import com.monsanto.tps.shipping.domain.EventWeight;
import com.monsanto.tps.shipping.util.ShippingWebException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.regex.Pattern;

@Service
public class EupMasterLabelSummaryBuilderImpl implements EupMasterLabelSummaryBuilder {

    private static final Pattern AMENDMENT_REGEX = Pattern.compile("-A[0-9]+$");

    @Resource
    private EupMasterLabelWeightSummaryBuilder eupMasterLabelWeightSummaryBuilder;

    @Override
    public ByteArrayOutputStream concatenateDocuments(Collection<EventWeight> eventWeights, ByteArrayOutputStream eupMasterLabelStream, String approvalNumber) throws ShippingWebException{
        ByteArrayOutputStream eupWeightSummaryStream = new ByteArrayOutputStream();

        String approvalNumberWithoutAmendment = AMENDMENT_REGEX.matcher(approvalNumber).replaceAll("");

        try {
            eupWeightSummaryStream = eupMasterLabelWeightSummaryBuilder.createWeightSummaryPage(approvalNumberWithoutAmendment, eventWeights);
            return concatenate(new ByteArrayOutputStream[]{eupMasterLabelStream, eupWeightSummaryStream});
        } catch (Exception e) {
            throw new ShippingWebException(e);
        } finally {
            close(eupWeightSummaryStream);
            close(eupMasterLabelStream);
        }
    }

    private ByteArrayOutputStream concatenate(ByteArrayOutputStream[] streams) throws DocumentException, IOException {
        Document document = new Document();
        ByteArrayOutputStream combinedStream = new ByteArrayOutputStream();
        try {
            PdfCopy copy = new PdfCopy(document, combinedStream);
            document.open();
            for (ByteArrayOutputStream stream : streams) {
                PdfReader reader = new PdfReader(stream.toByteArray());
                addPages(copy, reader);
                copy.freeReader(reader);
                reader.close();
            }

            return combinedStream;
        } finally {
            document.close();
            close(combinedStream);
        }
    }

    private void addPages(PdfCopy copy, PdfReader reader) throws IOException, BadPdfFormatException {
        for (int page = 0; page < reader.getNumberOfPages(); ) {
            copy.addPage(copy.getImportedPage(reader, ++page));
        }
    }

    private void close(ByteArrayOutputStream stream) throws ShippingWebException {
        try {
            stream.close();
        } catch (Exception e) {
            throw new ShippingWebException(e);
        }
    }
}
