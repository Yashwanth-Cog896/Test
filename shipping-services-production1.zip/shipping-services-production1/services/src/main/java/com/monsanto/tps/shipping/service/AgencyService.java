package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.Agency;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by DCENGL
 */
@Path("/agency")
public interface AgencyService {

    @GET
    @Produces(APPLICATION_JSON)
    Collection<Agency> getAgencies();

}
