package com.monsanto.tps.shipping.business.labels;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.monsanto.tps.shipping.business.PermitBusiness;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.ContainerAgencyPermits;
import com.monsanto.tps.shipping.util.TextUtils;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
@Component
public class PackingListLabelDataSetBuilder {

    private static final Function<ShipmentContainerEntity, String> STORAGE_CONTAINER_BARCODE_FUNCTION = new Function<ShipmentContainerEntity, String>() {
        @Override
        public String apply(ShipmentContainerEntity input) {
            return input.getStorageContainer().getBarcode();
        }
    };

    private static final int AGENCY_NUMBER_LIMIT = 16;
    private static final int STORAGE_CONTAINER_BARCODE_LIMIT = 7;


    @Autowired
    private PermitBusiness permitBusiness;
    @Autowired
    private ComplianceLabelBusiness complianceLabelBusiness;

    public ContainerLabelDataSet buildPermitsLabel(ShipmentPackingListEntity packingList){
        ContainerLabelDataSet data = new ContainerLabelDataSet();

        setContainersInfo(data, packingList.getShipmentContainers());

        ContainerAgencyPermits containerAgencyPermits;
        if (!packingList.getShipmentType().getContentType().equals(ContentType.OTHER)) {
            containerAgencyPermits = permitBusiness.loadAssociatedPermitsForPackingListLabel(packingList);
            complianceLabelBusiness.addIntegratedAgencyMessage(packingList.getShipmentType(), containerAgencyPermits, data);
        } else {
            containerAgencyPermits = complianceLabelBusiness.getExternalPermitsByPackingList(packingList);
            if(CollectionUtils.isNotEmpty(containerAgencyPermits.getPermits())){
                complianceLabelBusiness.addExternalAgencyMessage(packingList, data);
            }
        }

        complianceLabelBusiness.addPermitDetailsToLabelDataSet(containerAgencyPermits, data, AGENCY_NUMBER_LIMIT);

        return data;
    }

    private void setContainersInfo(ContainerLabelDataSet data, Collection<ShipmentContainerEntity> shipmentContainers) {
        Collection<String> containerBarcodes = Collections2.transform(shipmentContainers, STORAGE_CONTAINER_BARCODE_FUNCTION);

        Iterable<List<String>> partitionedStorageContainerBarcodes = Iterables.partition(containerBarcodes, 5);

        int i =1;
        for (List<String> storageContainerBarcodes : partitionedStorageContainerBarcodes) {
            if (i <= STORAGE_CONTAINER_BARCODE_LIMIT) {
                data.put(ContainerLabelConstants.CONTAINERS + i, TextUtils.getDelimitedStringWithComma(storageContainerBarcodes));
                i++;
            }
        }
    }
}
