package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: pgadi
 */
@Entity
@Table(name = "COUNTRY", schema = "LEXICON")
public class CountryEntity {
    @Id
    @Column(name = "COUNTRY_ID", nullable = false)
    private Long countryId;

    @Column(name = "COUNTRY_ABBR")
    private String countryAbbr;

    @Column(name = "ISO_CODE")
    private String isoCode;

    @Column(name = "COUNTRY_NAME")
    private String countryName;

    public CountryEntity() {
    }

    public CountryEntity(String countryAbbr, String isoCode, String countryName) {
        this.countryAbbr = countryAbbr;
        this.isoCode = isoCode;
        this.countryName = countryName;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getCountryAbbr() {
        return countryAbbr;
    }

    public void setCountryAbbr(String countryAbbr) {
        this.countryAbbr = countryAbbr;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
