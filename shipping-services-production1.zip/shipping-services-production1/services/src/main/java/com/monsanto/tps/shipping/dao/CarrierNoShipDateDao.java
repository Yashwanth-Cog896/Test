package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierNoShipDate;

import java.util.List;

/**
 * User: SDCHIL
 */
public interface CarrierNoShipDateDao {

    public List<CarrierNoShipDate> findAll();
}
