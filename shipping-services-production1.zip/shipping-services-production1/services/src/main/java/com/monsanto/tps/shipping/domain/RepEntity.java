package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Sets;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Set;

/**
 * User: pgadi
 */
@Entity
@Table(name = "BR_REP", schema = "MIDAS")
public class RepEntity {
    @Id
    @Column(name = "BR_REP_ID", nullable = false)
    private Long repId;
    @Column(name = "BARCODE")
    private String barcode;
    @Column(name = "REP_NUMBER")
    private Integer repNumber;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TRACKING_BR_FIELD_ID")
    private FieldEntity field;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ORIG_BR_PROG_ID", nullable = false)
    private ProgramEntity originatorProgram;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GROWER_BR_PROG_ID", nullable = false)
    private ProgramEntity growerProgram;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEST_SET_ID", nullable = false)
    private TestSetEntity testSet;

    @OneToMany(mappedBy = "rep", fetch = FetchType.LAZY)
    private Set<PlotEntity> plots = Sets.newHashSet();

    public Long getRepId() {
        return repId;
    }

    public void setRepId(Long repId) {
        this.repId = repId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Integer getRepNumber() {
        return repNumber;
    }

    public void setRepNumber(Integer repNumber) {
        this.repNumber = repNumber;
    }

    public FieldEntity getField() {
        return field;
    }

    public void setField(FieldEntity field) {
        this.field = field;
    }

    public ProgramEntity getGrowerProgram() {
        return growerProgram;
    }

    public void setGrowerProgram(ProgramEntity growerProgram) {
        this.growerProgram = growerProgram;
    }

    public ProgramEntity getOriginatorProgram() {
        return originatorProgram;
    }

    public void setOriginatorProgram(ProgramEntity originatorProgram) {
        this.originatorProgram = originatorProgram;
    }

    public TestSetEntity getTestSet() {
        return testSet;
    }

    public void setTestSet(TestSetEntity testSet) {
        this.testSet = testSet;
    }

    public Set<PlotEntity> getPlots() {
        return plots;
    }

    public void setPlots(Set<PlotEntity> plots) {
        this.plots = plots;
    }
}
