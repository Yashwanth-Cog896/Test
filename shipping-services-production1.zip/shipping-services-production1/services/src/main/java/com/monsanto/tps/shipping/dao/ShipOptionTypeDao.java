package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipOptionTypeEntity;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface ShipOptionTypeDao {
    ShipOptionTypeEntity getShipOptionType(Long shipOptionTypeId);
    void saveShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity);
    void deleteShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity);
    List<ShipOptionTypeEntity> findAllShipOptionTypes();
}
