package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SourceSystem;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import static org.hibernate.criterion.Restrictions.and;
import static org.hibernate.criterion.Restrictions.eq;

/**
 * User: pgadi
 */
@Repository
public class SourceSystemDaoImpl implements SourceSystemDao {
    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public SourceSystem getSourceSystemByName(String sourceSystemName) {

        return (SourceSystem) sessionFactory.getCurrentSession()
                .createCriteria(SourceSystem.class)
                .add(and(eq("name", sourceSystemName), eq("active", true)))
                .uniqueResult();
    }
 }