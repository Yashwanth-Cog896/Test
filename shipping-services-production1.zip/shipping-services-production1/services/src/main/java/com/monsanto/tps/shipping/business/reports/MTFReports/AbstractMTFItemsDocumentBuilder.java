package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.business.reports.ITextDocumentBuilder;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.Permit;
import com.monsanto.tps.shipping.util.EventHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public abstract class AbstractMTFItemsDocumentBuilder extends ITextDocumentBuilder implements MTFItemsDocumentBuilder {
    protected static DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

    @Autowired
    private EventHelper eventHelper;

    @Override
    public void buildDocument(Document document, ShipmentPackingListEntity packingList, Collection<Event> permits) throws DocumentException {
        Font font = buildDefaultFont(9);

        PdfPTable contentsTable = createContentsTable(font);
        PdfPTable permitsTable = createPermitsTable(font);

        addItemRows(contentsTable, permitsTable, packingList, permits, font);

        if (permitsTable != null && permitsTable.getRows().size() > 1) {
            document.add(permitsTable);
            document.add(new Phrase("\n\n"));
        }

        document.add(contentsTable);
    }

    protected abstract PdfPTable createContentsTable(Font font) throws DocumentException;
    protected abstract PdfPTable createPermitsTable(Font font) throws DocumentException;

    protected abstract void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> permits, Font font) throws DocumentException;

    protected Event getEvent(Long contentContainerId, Collection<Event> events) {
        for (Event event : events) {
            if (event.getContentContainerIds() != null && event.getContentContainerIds().contains(contentContainerId)) {
                return event;
            }
        }

        return null;
    }

    protected SortedSet<ScannedContainerEntity> getSortedScannedContainerEntities(ShipmentPackingListEntity packingListEntity) {
        SortedSet<ScannedContainerEntity> contentContainerEntities = Sets.newTreeSet(new Comparator<ScannedContainerEntity>() {
            @Override
            public int compare(ScannedContainerEntity o1, ScannedContainerEntity o2) {
                return o1.getScanOrder() - o2.getScanOrder();
            }
        });
        for (ShipmentContainerEntity shipmentContainerEntity : packingListEntity.getShipmentContainers()) {
            for (ScannedContainerEntity scannedContainerEntity : shipmentContainerEntity.getStorageContainer().getContainers()) {
                contentContainerEntities.add(scannedContainerEntity);
            }
        }
        return contentContainerEntities;
    }

    protected String getEventString(ContentEntity content) {
        if (content == null) {
            return "";
        }

        return eventHelper.getEventString(content);
    }
    protected  String getEventStringforHVPlots(ContentEntity content){
        if (content == null) {
            return "";
        }
        return eventHelper.getEventStringForHVPlots(content);
    }

    protected void addSelectedPermitsToTable(PdfPTable permitsTable, Collection<Event> events, boolean showMaleEvent, Font font) throws DocumentException {
        if (CollectionUtils.isEmpty(events)) {
            return;
        }

        List<Event> sortedEvents = Lists.newArrayList(events);
        Collections.sort(sortedEvents, new Comparator<Event>() {
            @Override
            public int compare(Event event1, Event event2) {

                String compare1 = event1.getEventString();
                String compare2 = event2.getEventString();

                if (StringUtils.isEmpty(compare1) && StringUtils.isEmpty(compare2)) {
                    compare1 = event1.getMaleEventString();
                    compare2 = event2.getMaleEventString();
                }

                if (!StringUtils.isEmpty(compare1) && !StringUtils.isEmpty(compare2)) {
                    return compare1.compareTo(compare2);
                }

                if (StringUtils.isEmpty(compare1)) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });

        for (Event event : sortedEvents) {
            Collection<Permit> selectedPermits = event.getSelectedPermits();
            if (!CollectionUtils.isEmpty(selectedPermits)) {
                for (Permit selectedPermit : selectedPermits) {
                    appendCellToTable(event.getEventString(), permitsTable, font);
                    if (showMaleEvent) {
                        appendCellToTable(event.getMaleEventString(), permitsTable, font);
                    }
                    appendCellToTable(selectedPermit.getApprovalNumber(), permitsTable, font);
                    appendCellToTable(selectedPermit.getAgency().getAbbr(), permitsTable, font);
                    Date expirationDate = selectedPermit.getExpirationDate();
                    appendCellToTable(expirationDate != null ? dateFormat.format(expirationDate) : "", permitsTable, font);

                    permitsTable.completeRow();
                }
            }
        }
    }

}
