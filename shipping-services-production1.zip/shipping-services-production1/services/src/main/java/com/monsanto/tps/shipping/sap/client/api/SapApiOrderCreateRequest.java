
package com.monsanto.tps.shipping.sap.client.api;

import com.monsanto.tps.shipping.sap.client.api.model.SapApiError;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiErrorTabBapi;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiInfoTabItem;
import com.monsanto.tps.shipping.sap.client.api.model.SapApiOrderItem;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "errorTab",
    "errorTabBapi",
    "infoTab",
    "itItems",
    "itemsTab",
    "brokerid",
    "consoignee",
    "sapdeliveryblock",
    "registrationnumber",
    "phytosanitaryhrdtext",
    "importpermitnumber",
    "endUse",
    "gtmcontact",
    "freightforwarder",
    "importphytosummary",
    "shippingConditions",
    "notifyarrival",
    "shipcenterordernum",
    "shipcenteruserid",
    "sapshiptonumber",
    "sapsoldtonumber",
    "salestexthdr"
})
@XmlRootElement(name = "YSdgtmCreateSoIb")
public class SapApiOrderCreateRequest implements SapApiOrderRequest {

    @XmlElementWrapper(name = "ErrorTab")
    @XmlElement(name = "item")
    private List<SapApiError> errorTab;
    @XmlElementWrapper(name = "ErrorTabBapi")
    @XmlElement(name = "item")
    private List<SapApiErrorTabBapi> errorTabBapi;
    @XmlElementWrapper(name = "InfoTab")
    @XmlElement(name = "item")
    private List<SapApiInfoTabItem> infoTab;
    @XmlElementWrapper(name = "ItItems")
    @XmlElement(name = "item")
    private List<SapApiOrderItem> itItems;
    @XmlElementWrapper(name = "ItemsTab")
    @XmlElement(name = "item")
    private List<SapApiOrderItem> itemsTab;

    private String brokerid;
    private String consoignee;
    private String sapdeliveryblock;
    private String registrationnumber;
    private String phytosanitaryhrdtext;
    private String importpermitnumber;
    @XmlElement(name = "enduse")
    private String endUse;
    private String gtmcontact;
    private String freightforwarder;
    private String importphytosummary;
    @XmlElement(name = "shipping_conditions")
    private String shippingConditions;
    private String notifyarrival;
    @XmlElement(required = true)
    private String shipcenterordernum;
    @XmlElement(required = true)
    private String shipcenteruserid;
    @XmlElement(required = true)
    private String sapshiptonumber;
    @XmlElement(required = true)
    private String sapsoldtonumber;
    private String salestexthdr;

    public List<SapApiError> getErrorTab() {
        return errorTab;
    }

    public void setErrorTab(List<SapApiError> errorTab) {
        this.errorTab = errorTab;
    }

    public List<SapApiErrorTabBapi> getErrorTabBapi() {
        return errorTabBapi;
    }

    public void setErrorTabBapi(List<SapApiErrorTabBapi> errorTabBapi) {
        this.errorTabBapi = errorTabBapi;
    }

    public List<SapApiInfoTabItem> getInfoTab() {
        return infoTab;
    }

    public void setInfoTab(List<SapApiInfoTabItem> infoTab) {
        this.infoTab = infoTab;
    }

    public List<SapApiOrderItem> getItItems() {
        return itItems;
    }

    public void setItItems(List<SapApiOrderItem> itItems) {
        this.itItems = itItems;
    }

    public List<SapApiOrderItem> getItemsTab() {
        return itemsTab;
    }

    public void setItemsTab(List<SapApiOrderItem> itemsTab) {
        this.itemsTab = itemsTab;
    }

    public String getBrokerid() {
        return brokerid;
    }

    public void setBrokerid(String brokerid) {
        this.brokerid = brokerid;
    }

    public String getConsoignee() {
        return consoignee;
    }

    public void setConsoignee(String consoignee) {
        this.consoignee = consoignee;
    }

    public String getSapdeliveryblock() {
        return sapdeliveryblock;
    }

    public void setSapdeliveryblock(String sapdeliveryblock) {
        this.sapdeliveryblock = sapdeliveryblock;
    }

    public String getRegistrationnumber() {
        return registrationnumber;
    }

    public void setRegistrationnumber(String registrationnumber) {
        this.registrationnumber = registrationnumber;
    }

    public String getPhytosanitaryhrdtext() {
        return phytosanitaryhrdtext;
    }

    public void setPhytosanitaryhrdtext(String phytosanitaryhrdtext) {
        this.phytosanitaryhrdtext = phytosanitaryhrdtext;
    }

    public String getImportpermitnumber() {
        return importpermitnumber;
    }

    public void setImportpermitnumber(String importpermitnumber) {
        this.importpermitnumber = importpermitnumber;
    }

    public String getGtmcontact() {
        return gtmcontact;
    }

    public void setGtmcontact(String gtmcontact) {
        this.gtmcontact = gtmcontact;
    }

    public String getFreightforwarder() {
        return freightforwarder;
    }

    public void setFreightforwarder(String freightforwarder) {
        this.freightforwarder = freightforwarder;
    }

    public String getImportphytosummary() {
        return importphytosummary;
    }

    public void setImportphytosummary(String importphytosummary) {
        this.importphytosummary = importphytosummary;
    }

    public String getShippingConditions() {
        return shippingConditions;
    }

    public void setShippingConditions(String shippingConditions) {
        this.shippingConditions = shippingConditions;
    }

    public String getNotifyarrival() {
        return notifyarrival;
    }

    public void setNotifyarrival(String notifyarrival) {
        this.notifyarrival = notifyarrival;
    }

    public String getShipcenterordernum() {
        return shipcenterordernum;
    }

    public void setShipcenterordernum(String shipcenterordernum) {
        this.shipcenterordernum = shipcenterordernum;
    }

    public String getShipcenteruserid() {
        return shipcenteruserid;
    }

    public void setShipcenteruserid(String shipcenteruserid) {
        this.shipcenteruserid = shipcenteruserid;
    }

    public String getSapshiptonumber() {
        return sapshiptonumber;
    }

    public void setSapshiptonumber(String sapshiptonumber) {
        this.sapshiptonumber = sapshiptonumber;
    }

    public String getSapsoldtonumber() {
        return sapsoldtonumber;
    }

    public void setSapsoldtonumber(String sapsoldtonumber) {
        this.sapsoldtonumber = sapsoldtonumber;
    }

    @Override
    public void addItItem(SapApiOrderItem item) {
        if (itItems == null) {
            itItems = new ArrayList<SapApiOrderItem>();
        }
        itItems.add(item);
    }

    public String getEndUse() {
        return endUse;
    }

    public void setEndUse(String endUse) {
        this.endUse = endUse;
    }

    public String getSalestexthdr() {
        return salestexthdr;
    }

    public void setSalestexthdr(String salestexthdr) {
        this.salestexthdr = salestexthdr;
    }
}
