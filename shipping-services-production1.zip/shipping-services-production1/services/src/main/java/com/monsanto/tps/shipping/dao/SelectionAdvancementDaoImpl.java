package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SelectionAdvancementEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * User: DCENGL
 */
@Repository
public class SelectionAdvancementDaoImpl implements SelectionAdvancementDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;

    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementForFemalePlots(Collection<Long> femalePlotIds) {

        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select selectionAdvancement from SelectionAdvancementEntity selectionAdvancement, TempOcdTable tmp " +
                "inner join fetch selectionAdvancement.selectionAdvancementMalePlot " +
                "where tmp.sessionId = :requestId " +
                "  and selectionAdvancement.femalePlot.plotId = tmp.tempOcdNumber " +
                "  and upper(selectionAdvancement.operationOperationType.operationType.operationTypeName) = upper('Binary') ")
                .setParameter("requestId", requestId)
                .list();
    }

    /**
     * Finds selection advancements where binary female plots erroneously have no associated male plots
     */
    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<SelectionAdvancementEntity> findUnarySelectionAdvancementsForFemalePlots(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select selectionAdvancement from SelectionAdvancementEntity selectionAdvancement, TempOcdTable tmp " +
                "where tmp.sessionId = :requestId " +
                "  and selectionAdvancement.femalePlot.plotId = tmp.tempOcdNumber " +
                "  and upper(selectionAdvancement.operationOperationType.operationType.operationTypeName) = upper('Unary') " +
                "  and selectionAdvancement.inactiveDttm is null " +
                "  and not exists (" +
                "    select 1 from SelectionAdvancementMalePlotEntity selectionAdvancementMalePlot where selectionAdvancementMalePlot.selectionAdvancement.id = selectionAdvancement.id)")
                .setParameter("requestId", requestId)
                .list();
    }


    /**
     * Finds selection advancements where unary female plots erroneously have associated male plots
     */
    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<SelectionAdvancementEntity> findUnarySelectionAdvancementsWithMalePlots(Collection<Long> femalePlotIds) {

        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select selectionAdvancement from SelectionAdvancementEntity selectionAdvancement, TempOcdTable tmp " +
                "inner join fetch selectionAdvancement.selectionAdvancementMalePlot " +
                "where tmp.sessionId = :requestId " +
                "  and selectionAdvancement.femalePlot.plotId = tmp.tempOcdNumber " +
                "  and upper(selectionAdvancement.operationOperationType.operationType.operationTypeName) = upper('Unary') " +
                "  and selectionAdvancement.inactiveDttm is null")
                .setParameter("requestId", requestId)
                .list();
    }

    /**
     * Finds selection advancements where binary female plots erroneously have no associated male plots
     */
    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementsWithNoMalePlots(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select selectionAdvancement from SelectionAdvancementEntity selectionAdvancement, TempOcdTable tmp " +
                "where tmp.sessionId = :requestId " +
                "  and selectionAdvancement.femalePlot.plotId = tmp.tempOcdNumber " +
                "  and upper(selectionAdvancement.operationOperationType.operationType.operationTypeName) = upper('Binary') " +
                "  and selectionAdvancement.inactiveDttm is null " +
                "  and not exists (" +
                "    select 1 from SelectionAdvancementMalePlotEntity selectionAdvancementMalePlot where selectionAdvancementMalePlot.selectionAdvancement.id = selectionAdvancement.id)")
                .setParameter("requestId", requestId)
                .list();
    }

    /**
     * Finds selection advancements where female plots erroneously have no operation
     */
    @SuppressWarnings("unchecked")
    @Trace
    @Override
    public Collection<SelectionAdvancementEntity> findBinarySelectionAdvancementsWithNoOperation(Collection<Long> femalePlotIds) {
        long requestId = tempOcdTableDao.insertLongs(femalePlotIds);

        return sessionFactory.getCurrentSession().createQuery("select selectionAdvancement from SelectionAdvancementEntity selectionAdvancement, TempOcdTable tmp " +
                "where tmp.sessionId = :requestId " +
                "  and selectionAdvancement.femalePlot.plotId = tmp.tempOcdNumber " +
                "  and selectionAdvancement.operationOperationType is null " +
                "  and selectionAdvancement.inactiveDttm is null ")
                .setParameter("requestId", requestId)
                .list();
    }


}
