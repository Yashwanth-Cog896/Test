package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.AgencyDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Service
public class AgencyBusinessImpl implements AgencyBusiness {

    @Autowired
    private AgencyDao agencyDao;

    @Trace
    @Override
    public Collection<AgencyEntity> getAllActive() {
        return agencyDao.findAllActive();
    }

    @Trace
    @Override
    public AgencyEntity findByAbbreviation(String abbreviation){
        return agencyDao.findByAbbr(abbreviation);
    }
}
