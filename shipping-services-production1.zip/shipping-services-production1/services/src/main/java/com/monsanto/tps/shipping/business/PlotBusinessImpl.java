package com.monsanto.tps.shipping.business;


import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.dao.PlotDao;
import com.monsanto.tps.shipping.dao.PlotMalePlotDao;
import com.monsanto.tps.shipping.domain.PlotEntity;
import com.monsanto.tps.shipping.domain.PlotMalePlotEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Date;
import java.util.Map;

/**
 * User: DCENGL
 */
@Service
public class PlotBusinessImpl implements PlotBusiness {

    public static final String UNARY_FEMALE_WITH_MALES = "Unary female with males in plot male plot";
    public static final String BINARY_FEMALE_NO_OPERATION = "Binary female without an operation in plot male plot";
    public static final String BINARY_FEMALE_NO_MALES = "Binary female with no males in plot male plot";

    @Autowired
    private PlotMalePlotDao plotMalePlotDao;

    @Autowired
    private PlotDao plotDao;

    @Trace
    @Override
    public Map<PlotEntity, PlotEntity> getMalePlotsForFemalePlotsWithBinaryOperations(Collection<PlotEntity> femalePlots) {
        Map<PlotEntity, PlotEntity> malePlotByFemalePlots = Maps.newHashMap();

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<PlotMalePlotEntity> binaryFemaleWithMalePlots = plotMalePlotDao.findBinaryPlotMalePlotsForFemalePlots(getPlotIds(femalePlots));
        for (PlotMalePlotEntity binaryFemaleWithMalePlot : binaryFemaleWithMalePlots) {
            malePlotByFemalePlots.put(binaryFemaleWithMalePlot.getFemalePlot(), binaryFemaleWithMalePlot.getMalePlot());
        }

        removeProcessedPlots(femalePlots, malePlotByFemalePlots.keySet());

        //Error checking calls
        Collection<PlotMalePlotEntity> unaryFemaleWithMalePlots = plotMalePlotDao.findUnaryPlotMalePlotsWithMalePlots(getPlotIds(femalePlots));
        processPlotMalePlotErrors(femalePlots, unaryFemaleWithMalePlots, UNARY_FEMALE_WITH_MALES);

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<PlotEntity> femalePlotsWithoutOperation = plotDao.findPlotsWithoutAnOperation(getPlotIds(femalePlots));
        processPlotErrors(femalePlots, femalePlotsWithoutOperation, BINARY_FEMALE_NO_OPERATION);

        if (CollectionUtils.isEmpty(femalePlots)) {
            return malePlotByFemalePlots;
        }

        Collection<PlotEntity> binaryFemalePlotsWithoutMalePlots = plotDao.findBinaryFemalePlotWithNoMalePlots(getPlotIds(femalePlots));
        processPlotErrors(femalePlots, binaryFemalePlotsWithoutMalePlots, BINARY_FEMALE_NO_MALES);

        //return the male plots from the valid selection advancements
        return malePlotByFemalePlots;
    }

    @Override
    public Date getPlantingDate(PlotEntity plotEntity) {
        return plotEntity.getPlantingDate() != null ? plotEntity.getPlantingDate() : plotEntity.getField().getPlantingDate();
    }

    private void processPlotMalePlotErrors(Collection<PlotEntity> femalePlots, Collection<PlotMalePlotEntity> plotMalePlotsWithError, final String errorString) {
        if (!CollectionUtils.isEmpty(plotMalePlotsWithError)) {
            PlotDataErrorsHolder.addError(errorString);
        }

        Collection<PlotEntity> femalePlotsWithError = Collections2.transform(plotMalePlotsWithError, new Function<PlotMalePlotEntity, PlotEntity>() {
            @Override
            public PlotEntity apply(@Nullable PlotMalePlotEntity plotMalePlotEntity) {
                return plotMalePlotEntity.getFemalePlot();
            }
        });

        removeProcessedPlots(femalePlots, femalePlotsWithError);
    }

    private void processPlotErrors(Collection<PlotEntity> femalePlots, Collection<PlotEntity> plotsWithError, final String errorString) {
        if(!CollectionUtils.isEmpty(plotsWithError)) {
            PlotDataErrorsHolder.addError(errorString);
        }

        removeProcessedPlots(femalePlots, plotsWithError);
    }

    private Collection<Long> getPlotIds(Collection<PlotEntity> plots) {
        return Collections2.transform(plots, new Function<PlotEntity, Long>() {
            @Override
            public Long apply(@Nullable PlotEntity plotEntity) {
                return plotEntity.getPlotId();
            }
        });
    }

    private void removeProcessedPlots(Collection<PlotEntity> sourcePlots, Collection<PlotEntity> processedPlots) {
        sourcePlots.removeAll(processedPlots);
    }

}
