package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.InventoryEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */

@Repository
public class InventoryDaoImpl implements InventoryDao {

    @Resource
    private TempOcdTableDao tempOcdTableDao;
    @Autowired
    private SessionFactory sessionFactory;


    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<InventoryEntity> findByBarcode(String barcode) {
        return sessionFactory.getCurrentSession()
                .createQuery("from InventoryEntity i " +
                        "join fetch i.geneticMaterial g " +
                        "join fetch g.germplasm gr " +
                        "join fetch gr.crop " +
                        "where i.barcode = :barcode")
                .setParameter("barcode", barcode).list();
    }

    @SuppressWarnings("unchecked")
    @Override
    @Trace
    public List<InventoryEntity> findByBarcode(Collection<String> barcodes) {
        // TODO: need to determine best number to do 'in' query for performance - for now just 1
        if (CollectionUtils.isNotEmpty(barcodes) && barcodes.size() == 1) {
            return findByBarcode(barcodes.iterator().next());
        }

        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(barcodes));

        return sessionFactory.getCurrentSession()
                .createQuery("from InventoryEntity i " +
                        "where i.barcode in (select tempOcdId from TempOcdTable tempTable where tempTable.sessionId = :requestId)")
                .setParameter("requestId", requestId).list();
    }
}
