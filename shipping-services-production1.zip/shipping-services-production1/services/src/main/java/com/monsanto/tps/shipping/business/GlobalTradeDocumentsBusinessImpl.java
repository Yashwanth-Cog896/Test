package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.sap.documents.api.download.VelocitydocumentIntegrationPortType;
import com.monsanto.tps.shipping.sap.documents.api.download.VelocitydocumentIntegrationRequest;
import com.monsanto.tps.shipping.sap.documents.api.download.VelocitydocumentIntegrationRequestType;
import com.monsanto.tps.shipping.sap.documents.api.download.response.SharepointDocumentType;
import com.monsanto.tps.shipping.sap.documents.api.retrieve.YESINBGTMSHPMNTDOCLINKS;
import com.monsanto.tps.shipping.sap.documents.api.retrieve.YgtmStVelocityShpmntLink;
import com.monsanto.tps.shipping.sap.documents.api.retrieve.YgtmTtVelocityShpmntLink;
import com.monsanto.tps.shipping.transfer.GlobalTradeDocuments;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

@Service
public class GlobalTradeDocumentsBusinessImpl implements GlobalTradeDocumentsBusiness {

    public static final String DOCUMENTS_RETRIEVAL_ERROR = "Documents not available.";
    public static final String DOCUMENTS_DOWNLOAD_ERROR = "Document not available for download.";

    private static final Log LOG = LogFactory.getLog(GlobalTradeDocumentsBusinessImpl.class);

    @Resource(name = "globalTradeDocumentsRetrieve")
    private JaxWsProxyFactoryBean globalTradeDocumentsRetrieveFactory;

    @Resource(name = "globalTradeDocumentsDownload")
    private JaxWsProxyFactoryBean globalTradeDocumentsDownloadFactory;

    @Autowired
    private SapOrderShipmentBusiness sapOrderShipmentBusiness;

    @Override
    @Trace
    @Transactional
    public List<GlobalTradeDocuments> getGlobalTradeDocumentsList(Long sapOrderShipmentId) {
        String sapShipmentNbr = sapOrderShipmentBusiness.getSapOrderShipmentById(sapOrderShipmentId).getShipmentNumber();
        // TODO Use this for dev testing purpose only: String sapShipmentNbr = "38731";
        List<GlobalTradeDocuments> globalTradeDocuments = getGlobalTradeDocumentsList(sapShipmentNbr);
        return globalTradeDocuments;
    }

    @Override
    public byte[] getGlobalTradeDocumentPdf(String encodedDocumentUrl, String title) {
        String documentUrl = decodeString(encodedDocumentUrl);
        VelocitydocumentIntegrationPortType velocitydocumentIntegrationPortType = (VelocitydocumentIntegrationPortType) globalTradeDocumentsDownloadFactory.create();
        VelocitydocumentIntegrationRequest velocitydocumentIntegrationRequest = getVelocitydocumentIntegrationRequest(documentUrl, title);

        LOG.warn("Start - Getting Global Trade Download document");
        SharepointDocumentType sharepointDocumentType = velocitydocumentIntegrationPortType.velocityPostdocumentIntegration(velocitydocumentIntegrationRequest);
        String documentbinary = sharepointDocumentType.getDOCUMENTBINARY();
        LOG.warn("End - Getting Global Trade Download document");

        throwExceptionIfDocumentBinaryIsNull(documentbinary, title, documentUrl);
        return Base64.decodeBase64(documentbinary.getBytes());
    }

    private VelocitydocumentIntegrationRequest getVelocitydocumentIntegrationRequest(String documentUrl, String title) {
        VelocitydocumentIntegrationRequest velocitydocumentIntegrationRequest = new VelocitydocumentIntegrationRequest();
        VelocitydocumentIntegrationRequestType velocitydocumentIntegrationRequestType = getVelocitydocumentIntegrationRequestType(documentUrl, title);
        velocitydocumentIntegrationRequest.getVelocitydocumentIntegrationDetails().add(velocitydocumentIntegrationRequestType);
        return velocitydocumentIntegrationRequest;
    }

    private VelocitydocumentIntegrationRequestType getVelocitydocumentIntegrationRequestType(String documentUrl, String title) {
        VelocitydocumentIntegrationRequestType velocitydocumentIntegrationRequestType = new VelocitydocumentIntegrationRequestType();
        velocitydocumentIntegrationRequestType.setFILENAME(title);
        velocitydocumentIntegrationRequestType.setFILEPATH(documentUrl);
        return velocitydocumentIntegrationRequestType;
    }

    private List<GlobalTradeDocuments> getGlobalTradeDocumentsList(String sapShipmentNbr) {
        LOG.warn("Start - Getting Document List with sapShipmentNbr: " + sapShipmentNbr);
        List<GlobalTradeDocuments> globalTradeDocuments = new ArrayList<GlobalTradeDocuments>();
        List<YgtmStVelocityShpmntLink> ygtmStVelocityShpmntLinks = getGlobalTradeDocumentListFromService(sapShipmentNbr);
        for (YgtmStVelocityShpmntLink ygtmStVelocityShpmntLink : ygtmStVelocityShpmntLinks) {
            GlobalTradeDocuments globalTradeDocument = populateGlobalTradeDocument(ygtmStVelocityShpmntLink);
            globalTradeDocuments.add(globalTradeDocument);
        }
        LOG.warn("End - Getting Document List with sapShipmentNbr: " + sapShipmentNbr);
        return globalTradeDocuments;
    }

    private GlobalTradeDocuments populateGlobalTradeDocument(YgtmStVelocityShpmntLink ygtmStVelocityShpmntLink) {
        GlobalTradeDocuments globalTradeDocument = new GlobalTradeDocuments();
        globalTradeDocument.setDocumentStatus(ygtmStVelocityShpmntLink.getYydocStatus());
        globalTradeDocument.setDocumentUrl(ygtmStVelocityShpmntLink.getYypath());
        globalTradeDocument.setEncodedDocumentUrl(encodeString(ygtmStVelocityShpmntLink.getYypath()));
        globalTradeDocument.setTitle(ygtmStVelocityShpmntLink.getYytitle());
        globalTradeDocument.setEncodedTitle(encodeString(ygtmStVelocityShpmntLink.getYytitle()));
        globalTradeDocument.setTimestamp(ygtmStVelocityShpmntLink.getYytime());
        return globalTradeDocument;
    }

    private List<YgtmStVelocityShpmntLink> getGlobalTradeDocumentListFromService(String sapShipmentNbr) {
        List<YgtmStVelocityShpmntLink> documentsList = new ArrayList<YgtmStVelocityShpmntLink>();
        try {
            YESINBGTMSHPMNTDOCLINKS yesinbgtmshpmntdoclinks = (YESINBGTMSHPMNTDOCLINKS) globalTradeDocumentsRetrieveFactory.create();
            YgtmTtVelocityShpmntLink ygtmTtVelocityShpmntLink = yesinbgtmshpmntdoclinks.ygtmWsinbSendVttkDocLink(sapShipmentNbr);
            documentsList = ygtmTtVelocityShpmntLink.getItem();
        } catch (Exception e) {
            LOG.error("Error occurred while getting Global Trade documents for sapShipmentNbr: " + sapShipmentNbr);
            LOG.error(e);
            throw new ShippingWebException(DOCUMENTS_RETRIEVAL_ERROR);
        }
        throwExceptionIfDocsListIsEmpty(documentsList, sapShipmentNbr);
        return documentsList;
    }

    private void throwExceptionIfDocsListIsEmpty(List<YgtmStVelocityShpmntLink> documentsList, String sapShipmentNbr) {
        if (CollectionUtils.isEmpty(documentsList)) {
            LOG.error("Empty list returned while getting Global Trade documents for sapShipmentNbr: " + sapShipmentNbr);
            throw new ShippingWebException(DOCUMENTS_RETRIEVAL_ERROR);
        }
    }

    private void throwExceptionIfDocumentBinaryIsNull(String documentBinary, String title, String documentUrl) {
        if (StringUtils.isBlank(documentBinary)) {
            LOG.error("Global Trade Document download failed for title: " + title + " and document url: " + documentUrl);
            throw new ShippingWebException(DOCUMENTS_DOWNLOAD_ERROR);
        }
    }

    private String decodeString(String encodedValue) {
        byte[] decoded = Base64.decodeBase64(encodedValue);
        String documentUrl;
        try {
            documentUrl = new String(decoded, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOG.error("Unable to decode the global trade document url path/title. [EncodedValue: " + encodedValue + "]");
            throw new ShippingWebException("Unable to decode the global trade document url path/title. [EncodedValue: " + encodedValue + "]", e);
        }
        return documentUrl;
    }

    private String encodeString(String value) {
        String encodedValue;
        byte[] encoded = Base64.encodeBase64(value.getBytes());
        try {
            encodedValue = new String(encoded, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOG.error("Unable to encode the global trade document url path/title. [Value: " + value + "]");
            throw new ShippingWebException("Unable to encode the global trade document url path/title. [Value: " + value + "]", e);
        }
        return encodedValue;
    }

}
