package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.CarrierDao;
import com.monsanto.tps.shipping.domain.CarrierEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
@Service
public class CarrierBusinessImpl implements CarrierBusiness {

    @Autowired
    private CarrierDao carrierDao;

    @Override
    public CarrierEntity findCarrier(Long carrierId) {
        return carrierDao.findCarrier(carrierId);
    }

    @Override
    public List<CarrierEntity> findCarriersByAccountId(Long accountId) {
        List<CarrierEntity> carriers = new ArrayList<CarrierEntity>(carrierDao.findCarriersByAccountId(accountId));
        carriers.addAll(carrierDao.findCarriersByIntegration(false));
        return carriers;
    }

    @Override
    public List<CarrierEntity> findAllCarriers() {
        return carrierDao.findAllCarriers();
    }

    @Override
    public List<CarrierEntity> findIntegratedCarriers() {
        return carrierDao.findCarriersByIntegration(true);
    }

    public List<CarrierEntity> findNonIntegratedCarriers() {
        return carrierDao.findCarriersByIntegration(false);
    }
}
