package com.monsanto.tps.shipping.domain;

import com.google.common.base.Function;
import com.google.common.collect.Lists;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.Collection;
import java.util.List;

/**
 * User: DCENGL
 */
@Entity
@DiscriminatorValue("CASSETTE")
public class CassetteContainerEntity extends ScannedContainerEntity<CassetteEntity> implements MultiContentContainerEntity {

    @Column(name = "BARCODE_NBR")
    private String barcode;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BARCODE_NBR", referencedColumnName = "BARCODE", insertable = false, updatable = false)
    private CassetteEntity cassetteEntity;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "scannedContainer", cascade = {})
    private Collection<RegulatedInventoryMovementEntity> regulatedInventoryMovements;

    @Override
    public void setContent(CassetteEntity contentEntity) {
        cassetteEntity = contentEntity;
        barcode = cassetteEntity.getBarcode(); //TODO need this?
    }

    public String getBarcode() {
        return barcode;
    }

    public CassetteEntity getCassette() {
        return cassetteEntity;
    }

    @Override
    public CassetteEntity getContent() {
        return cassetteEntity;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.CASSETTE;
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return regulatedInventoryMovements;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        RegulatedInventoryMovementEntity regulatedInventoryMovementEntity = newMovement;
        if (regulatedInventoryMovements != null) {
            regulatedInventoryMovements.add(regulatedInventoryMovementEntity);
        } else {
            regulatedInventoryMovements = Lists.newArrayList(regulatedInventoryMovementEntity);
        }
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        this.regulatedInventoryMovements = movements;
    }

    private static final Function<SeedTrayCellEntity, ContentEntity> CONTENT_TRANSFORM = new Function<SeedTrayCellEntity, ContentEntity>() {
        @Override
        public ContentEntity apply(SeedTrayCellEntity input) {
            return input.getInventory();
        }
    };

    @Override
    public List<? extends ContentEntity> getContents() {
        List<ContentEntity> contents = Lists.newArrayList();
        for (SeedTrayCellEntity cell : cassetteEntity.getSeedTrayCells()) {
            ContentEntity content = CONTENT_TRANSFORM.apply(cell);
            if (content != null) {
                contents.add(content);
            }
        }
        return contents;
    }

    @Override
    public CropEntity getCrop() {
        for (SeedTrayCellEntity cell : cassetteEntity.getSeedTrayCells()) {
            ContentEntity content = CONTENT_TRANSFORM.apply(cell);
            if (content != null) {
                return content.getGeneticMaterial().getGermplasm().getCrop();
            }
        }
        return null;
    }
}
