package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.business.ShipmentBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.converter.ShipmentConverter;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Shipment;
import com.monsanto.tps.shipping.service.model.ShipmentAcknowledgement;
import com.monsanto.tps.shipping.service.model.ShipmentType;
import com.monsanto.tps.shipping.util.PlotObservationValueUpdateHelper;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateMidnight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * User: pgadi
 */
@Component("shipmentService")
public class ShipmentServiceImpl implements ShipmentService {

    public static final String MSG_TO_CONTACT_REQUIRED = "\"Ship-To:\" contact was not saved. ";
    private static final Log LOG = LogFactory.getLog(ShipmentServiceImpl.class);

    @Autowired
    private ShipmentBusiness shipmentBusiness;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private ShipmentConverter shipmentConverter;
    @Autowired
    private PlotObservationValueUpdateHelper plotObservationValueUpdateHelper;
    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Trace
    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public Shipment createShipment(Shipment shipment) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(shipment.getPackingListId());
        final ShipmentEntity existingShipment = shipmentBusiness.getShipment(packingList.getBarcode());
        if (existingShipment != null && existingShipment.getShipmentId() != null) {
            updateHarvestWtAndEarWt(existingShipment, packingList);
            return shipmentConverter.buildShipment(existingShipment);
        }
        if (packingList.getSapOrderShipment() == null) {
            ShippingWebException.checkArgument(packingList.getToContactId() != null, MSG_TO_CONTACT_REQUIRED);
        }

        ShipmentEntity shipmentEntity = shipmentBusiness.createShipment(packingList, shipment, getUsername());
        updateHarvestWtAndEarWt(shipmentEntity, packingList);
        return shipmentConverter.buildShipment(shipmentEntity);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<ShipmentType> getShipmentTypes() {
        List<ShipmentTypeEntity> shipmentTypeList = shipmentBusiness.getShipmentTypeList();
        List<ShipmentType> shipmentTypes = Lists.newArrayList();
        for (ShipmentTypeEntity shipmentTypeEntity : shipmentTypeList) {
            shipmentTypes.add(getShipmentType(shipmentTypeEntity.getShipmentTypeId(), shipmentTypeEntity.getName(),
                    shipmentTypeEntity.getDescription(), shipmentTypeEntity.getInactiveDateTime()));
        }
        return shipmentTypes;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void acknowledge(String shBarcode, ShipmentAcknowledgement acknowledgement) {
        ShipmentEntity shipment = shipmentBusiness.getShipment(shBarcode);
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness
                .getShipmentPackingList(acknowledgement.getPackingListId());

        shipmentBusiness.acknowledge(shipment, packingList, acknowledgement);
    }

    @Override
    @Transactional(readOnly = true)
    public ShipmentType getShipmentType(Long shipmentTypeId) {
        ShipmentTypeEntity shipmentTypeEntity = shipmentBusiness.getShipmentType(shipmentTypeId);
        return getShipmentType(shipmentTypeEntity.getShipmentTypeId(), shipmentTypeEntity.getName(),
                shipmentTypeEntity.getDescription(), shipmentTypeEntity.getInactiveDateTime());
    }

    @Override
    @Transactional(readOnly = true)
    public Shipment getShipment(String shBarcode) {
        ShipmentEntity shipmentEntity = shipmentBusiness.getShipment(shBarcode);
        ShippingWebException.checkArgument(shipmentEntity != null, "Shipment not found: " + shBarcode);
        return shipmentConverter.buildShipment(shipmentEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Shipment> getShipments(Long accountId, Long modifiedNumberOfDays, String shipmentDirection) {
        ShippingWebException.checkArgument(accountId != null, "AccountId cannot be null");
        ShippingWebException.checkArgument(modifiedNumberOfDays != null, "Number of days cannot be null");
        ShippingWebException.checkArgument(shipmentDirection != null, "Shipment Direction cannot be null");

        DateMidnight dateTime = new DateMidnight().minusDays(modifiedNumberOfDays.intValue());
        List<ShipmentEntity> shipmentEntities = shipmentBusiness
                .getShipmentsByAccountIdAndShippedDate(accountId, dateTime.toDate(), shipmentDirection);
        return shipmentConverter.buildShipments(shipmentEntities);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Shipment> getInternationalShipments(String countryCode,
                                                    Long modifiedNumberOfDays,
                                                    String shipmentDirection) {
        ShippingWebException.checkArgument(countryCode != null, "CountryCode cannot be null");
        ShippingWebException.checkArgument(modifiedNumberOfDays != null, "Number of days cannot be null");
        ShippingWebException.checkArgument(shipmentDirection != null, "Shipment Direction cannot be null");


        DateMidnight dateTime = new DateMidnight().minusDays(modifiedNumberOfDays.intValue());
        List<ShipmentEntity> shipmentEntities = shipmentBusiness
                .getShipmentsByCountryAndShippedDate(countryCode, dateTime.toDate(), shipmentDirection);
        return shipmentConverter.buildShipments(shipmentEntities);
    }

    @Override
    @Trace
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void cancelShipment(Long shipmentId) {
        shipmentBusiness.cancelShipment(shipmentId);
    }

    @Override
    @Trace
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void updateUndeliveredShipmentStatuses() {
        LOG.warn("Updating undelivered shipment statuses...");
        shipmentBusiness.updateUndeliveredShipmentStatuses();
        LOG.warn("Undelivered shipment status update completed");
    }

    private ShipmentType getShipmentType(Long shipmentTypeId, String name, String description, Date inactiveDate) {
        ShipmentType shipmentType = new ShipmentType();
        shipmentType.setId(shipmentTypeId);
        shipmentType.setName(name);
        shipmentType.setDescription(description);
        shipmentType.setActive(inactiveDate == null);
        return shipmentType;
    }

    private String getUsername() {
        UserDetails userDetails = userDetailsProvider.getUserDetails();
        return userDetails != null ? userDetails.getUsername() : "Could not identify user";
    }

    private void updateHarvestWtAndEarWt(final ShipmentEntity shipmentEntity, ShipmentPackingListEntity packingList) {
        if (isHarvestedPlot(shipmentEntity)) {
            plotObservationValueUpdateHelper.updateHarvestWtAndEarWt(shipmentEntity, packingList);
        }
    }

    private boolean isHarvestedPlot(ShipmentEntity shipmentEntity) {
        return shipmentEntity.getShipmentType().isHarvested();
    }

}
