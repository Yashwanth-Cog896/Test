package com.monsanto.tps.shipping.dao.primarykey;

import com.monsanto.tps.primarykey.midas.BulkKeyGenerator;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;

import javax.annotation.Resource;
import java.io.Serializable;

public class MidasIdGeneratorImpl implements MidasIdGenerator {

    @Resource(name = "bulkKeyGenerator")
    private BulkKeyGenerator bulkKeyGenerator;

    private static MidasIdGenerator instance;

    public static MidasIdGenerator getInstance() {
        if (instance == null) {
            throw new IllegalStateException("Not initialized! Spring should set instance when bean is created!");
        }
        return instance;
    }

    public static void setInstance(MidasIdGenerator midasIdGenerator) {
        instance = midasIdGenerator;
    }

    public MidasIdGeneratorImpl() {
        setInstance(this);
    }

    @Override
    public long getNextId() {
        return bulkKeyGenerator.generate();
    }

    @Override
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        return getNextId();
    }
}
