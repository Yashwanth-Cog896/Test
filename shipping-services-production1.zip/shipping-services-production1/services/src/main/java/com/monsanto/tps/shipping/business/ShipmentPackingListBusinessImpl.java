package com.monsanto.tps.shipping.business;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.monsanto.tps.shipping.dao.*;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;
import com.monsanto.tps.shipping.service.model.enums.DocumentEnum;
import com.monsanto.tps.shipping.service.validation.PackingListContentValidator;
import com.monsanto.tps.shipping.service.validation.PackingListValidator;
import com.monsanto.tps.shipping.util.RegulatedStatusText;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * User: DCENGL
 */
@Service
public class ShipmentPackingListBusinessImpl implements ShipmentPackingListBusiness {

    @Autowired
    private BarcodeGeneratorDao barcodeGeneratorDao;
    @Autowired
    private ShipmentPackingListDao shipmentPackingListDao;
    @Autowired
    private MidasUserDao midasUserDao;
    @Autowired
    private ShipmentContainerBusiness shipmentContainerBusiness;
    @Autowired
    private ShipmentTypeDao shipmentTypeDao;
    @Autowired
    private UnitOfMeasureBusiness unitOfMeasureBusiness;
    @Autowired
    private PackingListValidator packingListValidator;
    @Autowired
    private PackingListContentBusiness packingListContentBusiness;
    @Autowired
    private ProgramBusiness programBusiness;
    @Autowired
    private RepDao repDao;
    @Autowired
    private PackingListContentValidator packingListContentValidator;
    @Autowired
    private SapOrderShipmentBusiness sapOrderShipmentBusiness;
    @Autowired
    private InternationalCompositesBusiness internationalCompositesBusiness;
    @Autowired
    private RegulatedMovementDao regulatedMovementDao;
    @Autowired
    private SapOrderShipmentDao sapOrderShipmentDao;
    @Autowired
    private DocumentBusiness documentBusiness;

    public static final String SHIPMENT_PACKING_LIST_ID_NOT_NULL = "Shipment Packing List Id cannot be null";
    public static final String UOM_NOT_NULL = "Unit of Measure cannot be null";
    public static final String MIDAS_USER_NOT_FOUND = "MidasUser could not be found for: ";
    public static final String SHIPMENT_TYPE_NOT_FOUND = "Shipment type not found with id [%s]";
    public static final String PACKING_LIST_CANNOT_BE_EDITED = "The packing list cannot be edited because a shipment has already been created.";


    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    @Trace
    @Override
    public List<ShipmentPackingListEntity> getShipmentPackingListsByProgramAfterDate(Long accountId, Date date) {
        return shipmentPackingListDao.getPackingListsByProgramAndCreationDate(accountId, date);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    @Trace
    @Override
    public List<ShipmentPackingListEntity> getShipmentPackingListsByCountry(String isoCountryCode, Date date) {
        List<String> contactIds = internationalCompositesBusiness.getStorageLocationIds(isoCountryCode);
        return shipmentPackingListDao.getInternationalPackingListsByCreatedDate(date, contactIds);
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getShipmentPackingList(Long shipmentPackingListId) {
        return shipmentPackingListDao.getPackingListById(shipmentPackingListId);
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getShipmentPackingListForBoxBarcode(String suBarcode) {
        return shipmentPackingListDao.getPackingListByBoxBarcode(suBarcode);
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getShipmentPackingListForShipmentBarcode(String shBarcode) {
        return shipmentPackingListDao.getPackingListByShipmentBarcode(shBarcode);
    }

    @Trace
    @Override
    public ShipmentPackingListEntity getShipmentPackingListForSapOrderShipmentId(Long sapOrderShipmentId) {
        return shipmentPackingListDao.getPackingListBySapOrderShipmentId(sapOrderShipmentId);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Trace
    @Override
    public ShipmentPackingListEntity savePackingList(ShipmentPackingList shipmentPackingList, String username) {
        ShipmentPackingListEntity shipmentPackingListEntity = getBasicPackingList(shipmentPackingList, username);
        Long uomId = shipmentPackingList.getUomId();
        if (uomId == null && StringUtils.isNotBlank(shipmentPackingList.getWeightUOM())) {
            UnitOfMeasureEntity uom = unitOfMeasureBusiness.getUnitOfMeasure(shipmentPackingList.getWeightUOM());
            if (uom != null) {
                uomId = uom.getId();
            }
        }
        updateContents(shipmentPackingListEntity, shipmentPackingList.getPackingListContainers(), shipmentPackingList.getStagingContainer(), uomId, shipmentPackingList.getWeightUOM());
        shipmentPackingListDao.savePackingList(shipmentPackingListEntity);
        return shipmentPackingListEntity;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Trace
    @Override
    public ShipmentPackingListEntity savePackingListWithoutContents(ShipmentPackingList shipmentPackingList,
                                                                    String username) {
        ShipmentPackingListEntity shipmentPackingListEntity = getBasicPackingList(shipmentPackingList, username);
        shipmentPackingListDao.savePackingList(shipmentPackingListEntity);
        return shipmentPackingListEntity;
    }

    private ShipmentPackingListEntity getBasicPackingList(ShipmentPackingList shipmentPackingList, String username) {
        MidasUserEntity midasUserEntity = getMidasUser(username);
        ShipmentPackingListEntity shipmentPackingListEntity = new ShipmentPackingListEntity();
        populateShipmentPackingList(shipmentPackingListEntity, shipmentPackingList, midasUserEntity);
        return shipmentPackingListEntity;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Trace
    @Override
    public ShipmentPackingListEntity editPackingList(ShipmentPackingList shipmentPackingList, String username) {
        checkArgument(shipmentPackingList.getId() != null, SHIPMENT_PACKING_LIST_ID_NOT_NULL);

        ShipmentPackingListEntity shipmentPackingListEntity = getShipmentPackingList(shipmentPackingList.getId());
        if (!packingListValidator.isEditable(shipmentPackingListEntity)) {
            throw new ShippingWebException(PACKING_LIST_CANNOT_BE_EDITED);
        }

        if (shipmentPackingListEntity.getToContactId() != null && shipmentPackingListEntity.getFromContactId() != null) {
            if (!ObjectUtils.equals(shipmentPackingList.getToContactId(), shipmentPackingListEntity.getToContactId().toString())
                    || !ObjectUtils.equals(shipmentPackingList.getFromContactId(), shipmentPackingListEntity.getFromContactId().toString())) {
                if (!RegulatedStatusText.COMPLIANCE_DISABLED.getRegulatedStatusText().equals(shipmentPackingListEntity.getRegulatedStatusText())) {
                    // invalidates compliance
                    shipmentPackingListEntity.setComplianceConfirmedDate(null);
                    shipmentPackingListEntity.setRegulatedStatusText(null);
                }
            }
        }

        populateShipmentPackingList(shipmentPackingListEntity, shipmentPackingList, getMidasUser(username));

        shipmentPackingListDao.updatePackingList(shipmentPackingListEntity);
        return shipmentPackingListEntity;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Trace
    @Override
    public void removeEmptyContainers(ShipmentPackingListEntity shipmentPackingListEntity) {
        if (!CollectionUtils.isEmpty(shipmentPackingListEntity.getShipmentContainers())) {
            for (Iterator<ShipmentContainerEntity> iterator = shipmentPackingListEntity.getShipmentContainers().iterator(); iterator.hasNext(); ) {
                ShipmentContainerEntity shipmentContainerEntity = iterator.next();
                if (CollectionUtils.isEmpty(shipmentContainerEntity.getStorageContainer().getContainers())) {
                    iterator.remove();
                }
            }
        }

        shipmentPackingListDao.savePackingList(shipmentPackingListEntity);
    }

    @Trace
    @Override
    public void deletePackingList(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListDao.getPackingListById(packingListId);
        if (packingList != null) {
            if (packingListValidator.isEditable(packingList)) {
                regulatedMovementDao.deleteRegulatedMovementsForPackingList(packingList);
                sapOrderShipmentDao.delete(packingList.getSapOrderShipment()); // constraint on the SU barcode, so it must be deleted 1st
                shipmentContainerBusiness.delete(packingList.getShipmentContainers());
                shipmentPackingListDao.delete(packingList);
                documentBusiness.deleteAsync(DocumentEnum.PACKING_LIST, packingListId);
            } else {
                throw new ShippingWebException("Warning: Could not delete packing lists with shipment created.");
            }
        }
    }

    @Trace
    @Override
    public void editUom(Long packingListId, String uom) {
        checkArgument(packingListId != null, SHIPMENT_PACKING_LIST_ID_NOT_NULL);
        checkArgument(!StringUtils.isBlank(uom), UOM_NOT_NULL);

        ShipmentPackingListEntity packingListEntity = shipmentPackingListDao.getPackingListById(packingListId);
        if (packingListEntity == null) {
            return;
        }

        if (!CollectionUtils.isEmpty(packingListEntity.getShipmentContainers())) {
            Collection<Long> storageContainerIds = getStorageContainerIds(packingListEntity);
            UnitOfMeasureEntity midasUom = unitOfMeasureBusiness.getUnitOfMeasure(uom);
            Long inventoryMgtUomId = unitOfMeasureBusiness.getInventoryMgtUomIdFromAbbreviation(uom);
            shipmentContainerBusiness.updateUom(packingListId, inventoryMgtUomId);
            packingListContentBusiness.updateUom(storageContainerIds, midasUom.getId());
        }
    }

    @Override
    public Boolean validateShipToMatch(Long packingListId, Long contactId) {

        ProgramEntity program = programBusiness.getProgramByContact(contactId);
        if (program != null) {
            ShipmentPackingListEntity shipmentPackingList = shipmentPackingListDao.getPackingListById(packingListId);
            Collection<RepEntity> reps = repDao.findRepsByShipmentPackingListId(packingListId);
            for (RepEntity rep : reps) {
                if (packingListContentValidator.validateShipToMisMatchForRep(program.getProgramId(), shipmentPackingList.getShipmentType(), rep)) {
                    return false;
                }
            }
        }
        return true;
    }

    @Trace
    @Override
    public void save(ShipmentPackingListEntity packingList) {
        if (packingList.getShipmentPackingListId() != null) {
            shipmentPackingListDao.updatePackingList(packingList);
        } else {
            shipmentPackingListDao.savePackingList(packingList);
        }
    }

    private void updateContents(ShipmentPackingListEntity shipmentPackingListEntity, List<PackingListContainer> packingListContainers, PackingListContainer stagingContainer, Long uomId, String uomAbbreviation) {
        shipmentContainerBusiness.updateContainers(shipmentPackingListEntity, packingListContainers, stagingContainer, uomId, uomAbbreviation);
    }

    private void populateShipmentPackingList(ShipmentPackingListEntity shipmentPackingListEntity, ShipmentPackingList shipmentPackingList, MidasUserEntity midasUserEntity) {

        if (shipmentPackingListEntity.getShipmentPackingListId() == null) {
            shipmentPackingListEntity.setCreatedBy(midasUserEntity);
            shipmentPackingListEntity.setCreationDate(new Date());
            shipmentPackingListEntity.setBarcode(barcodeGeneratorDao.generateNewShipmentBarcode());
        }

        shipmentPackingListEntity.setDescription(shipmentPackingList.getDescription());
        shipmentPackingListEntity.setLastModifiedBy(midasUserEntity);
        shipmentPackingListEntity.setLastModifiedDate(new Date());
        shipmentPackingListEntity.setFromContactId(shipmentPackingList.getFromContactId() == null ? null : Long.valueOf(shipmentPackingList.getFromContactId()));
        if (shipmentPackingList.isInternational()) {
            if (shipmentPackingListEntity.getSapOrderShipment() == null) {
                shipmentPackingListEntity.setSapOrderShipment(sapOrderShipmentBusiness.createSapOrderShipment(shipmentPackingList, midasUserEntity));
            } else {
                shipmentPackingListEntity.getSapOrderShipment().setSoldToCustomerNumber(shipmentPackingList.getSoldToContactId());
                shipmentPackingListEntity.getSapOrderShipment().setShipToCustomerNumber(shipmentPackingList.getToContactId());
                shipmentPackingListEntity.getSapOrderShipment().setSapStorageLocationCode(shipmentPackingList.getFromSapContactId());
                shipmentPackingListEntity.getSapOrderShipment().setModifiedBy(midasUserEntity);
                shipmentPackingListEntity.getSapOrderShipment().setLastModifiedDate(new Date());
            }
        } else {
            shipmentPackingListEntity.setToContactId(shipmentPackingList.getToContactId() == null ? null : Long.valueOf(shipmentPackingList.getToContactId()));
            shipmentPackingListEntity.setShipToAttn(shipmentPackingList.getShipToAttn());
        }
        ShipmentTypeEntity shipmentType = shipmentTypeDao.findById(shipmentPackingList.getShipmentTypeId());
        if (shipmentType == null) {
            throw new ShippingWebException(String.format(SHIPMENT_TYPE_NOT_FOUND, shipmentPackingList.getShipmentTypeId()));
        }
        shipmentPackingListEntity.setShipmentType(shipmentType);
    }

    private MidasUserEntity getMidasUser(String creatorUsername) {
        MidasUserEntity midasUser = midasUserDao.getByUserId(creatorUsername);
        checkArgument(midasUser != null, MIDAS_USER_NOT_FOUND + creatorUsername);
        return midasUser;
    }

    private Collection<Long> getStorageContainerIds(ShipmentPackingListEntity packingListEntity) {
        return Collections2
            .transform(packingListEntity.getShipmentContainers(), new Function<ShipmentContainerEntity, Long>() {
                @Override
                public Long apply(@Nullable ShipmentContainerEntity input) {
                    return input.getStorageContainer().getStorageContainerId();
                }
            });
    }

}
