package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * Created by DCENGL
 */
public interface InternationalComplianceSheetBuilder {

    Sheet buildSheet(Workbook workbook, ShipmentPackingListEntity packingList);

}
