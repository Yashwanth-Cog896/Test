package com.monsanto.tps.shipping.domain;

import java.util.Comparator;

public class ShipmentContainerComparator implements Comparator<ShipmentContainerEntity>{
    @Override
    public int compare(ShipmentContainerEntity input1, ShipmentContainerEntity input2) {
        return input1.getShipmentContainerId().compareTo(input2.getShipmentContainerId());
    }
}
