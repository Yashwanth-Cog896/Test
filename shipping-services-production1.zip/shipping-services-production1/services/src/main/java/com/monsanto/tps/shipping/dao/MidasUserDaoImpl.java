package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.MidasUserEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
public class MidasUserDaoImpl implements MidasUserDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Cacheable("METHOD_CACHE")
    @Override
    public MidasUserEntity getByUserId(String userId) {
        return (MidasUserEntity) sessionFactory.getCurrentSession()
                .createQuery("from MidasUserEntity " +
                        "where upper(loginId) = :userId " +
                        "and refActive = true")
                .setParameter("userId", userId.toUpperCase())
                .uniqueResult();
    }
}
