package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * User: pgadi
 */
@Repository
public class SapOrderItemDaoImpl implements SapOrderItemDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Trace
    @Override
    public void save(SapOrderItemEntity sapOrderItemEntity) {
        sessionFactory.getCurrentSession().saveOrUpdate(sapOrderItemEntity);
    }

    @Override
    public SapOrderItemEntity load(Long sapOrderItemId) {
        return (SapOrderItemEntity) sessionFactory.getCurrentSession().load(SapOrderItemEntity.class, sapOrderItemId);
    }

    @Override
    public void delete(SapOrderItemEntity sapOrderItemEntity) {
        sessionFactory.getCurrentSession().delete(sapOrderItemEntity);
    }

    @Trace
    @Override
    public List<SapOrderItemEntity> findBySapOrderShipmentAndItemNumber(SapOrderShipmentEntity sapOrderShipment,
                                                                        Collection<String> itemNumbers) {
        return (List<SapOrderItemEntity>) sessionFactory.getCurrentSession().createQuery(
            "from SapOrderItemEntity where sapOrderShipment = :sapOrderShipment and  sapOrderItemNumber in :itemNumbers")
            .setParameter("sapOrderShipment", sapOrderShipment).setParameterList("itemNumbers", itemNumbers).list();
    }
}