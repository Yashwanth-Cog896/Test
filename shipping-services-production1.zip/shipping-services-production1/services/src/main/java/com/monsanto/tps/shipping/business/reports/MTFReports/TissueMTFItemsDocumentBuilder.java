package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedSet;

@Service
public class TissueMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);

        for (ScannedContainerEntity contentContainerEntity : contentContainerEntities) {
            if (contentContainerEntity.getContentType() == ContentType.OTHER) {
                OtherContainerEntity otherContainerEntity = (OtherContainerEntity) contentContainerEntity;
                OtherContentEntity otherEntity = otherContainerEntity.getContent();

                appendCellToTable(otherContainerEntity.getScanOrder(), contentsTable, font);
                appendCellToTable(otherEntity.getBarcode(), contentsTable, font);
                appendCellToTable(otherContainerEntity.getStorageContainer().getBarcode(), contentsTable, font);

                appendCellToTable("", contentsTable, font);
                appendCellToTable("", contentsTable, font);
                appendCellToTable("", contentsTable, font);
                appendCellToTable("", contentsTable, font);
                appendCellToTable("", contentsTable, font);
                appendCellToTable("", contentsTable, font);

                contentsTable.completeRow();
                continue;
            }

            TissuePlateContainerEntity tissuePlateContainerEntity = (TissuePlateContainerEntity) contentContainerEntity;
            TissuePlateEntity tissuePlateEntity = tissuePlateContainerEntity.getContent();

            appendCellToTable(tissuePlateContainerEntity.getScanOrder(), contentsTable, font);
            appendCellToTable(tissuePlateEntity.getBarcode(), contentsTable, font);
            appendCellToTable(tissuePlateContainerEntity.getStorageContainer().getBarcode(), contentsTable, font);

            String fieldName = null;
            String testSetName = null;
            String plotBarcode = null;
            PlotEntity plot = tissuePlateEntity.getPlot();
            if (plot != null) {
                FieldEntity field = plot.getField();
                if (field != null) {
                    fieldName = field.getFieldName();
                }
                TestSetEntryEntity testSetEntry = plot.getTestSetEntry();
                if (testSetEntry != null) {
                    TestSetEntity testSet = testSetEntry.getTestSet();
                    if (testSet != null) {
                        testSetName = testSet.getTestSetName();
                    }
                }
                plotBarcode = plot.getBarcode();
            }
            appendCellToTable(fieldName != null ? fieldName : "", contentsTable, font);
            appendCellToTable(testSetName != null ? testSetName : "", contentsTable, font);

            appendCellToTable(tissuePlateEntity.getLimsId(), contentsTable, font);
            appendCellToTable(tissuePlateEntity.getProjectName(), contentsTable, font);
            appendCellToTable(tissuePlateEntity.getWellNumber(), contentsTable, font);
            appendCellToTable(plotBarcode != null ? plotBarcode : "", contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Plate BID", "Box Barcode", "Field", "Set", "LIMS ID", "Rubicon or Project ID", "Well #", "Plot BID","Received"},
                new float[]{15, 45, 30, 30, 35, 30, 25, 15, 60, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return null;
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.TISSUE_PLATE;
    }
}
