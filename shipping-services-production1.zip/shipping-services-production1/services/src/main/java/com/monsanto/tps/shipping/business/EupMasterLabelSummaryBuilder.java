package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.EventWeight;
import com.monsanto.tps.shipping.util.ShippingWebException;

import java.io.ByteArrayOutputStream;
import java.util.Collection;

/**
 * Created with IntelliJ IDEA.
 * User: tbmckay
 * Date: 5/23/14
 * Time: 3:25 PM
 */
public interface EupMasterLabelSummaryBuilder {
    ByteArrayOutputStream concatenateDocuments(Collection<EventWeight> eventsWeights, ByteArrayOutputStream eupMasterLabelStream, String approvalNumber) throws ShippingWebException;
}
