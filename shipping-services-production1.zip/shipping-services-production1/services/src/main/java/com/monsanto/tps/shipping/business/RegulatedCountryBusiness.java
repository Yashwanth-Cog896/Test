package com.monsanto.tps.shipping.business;

/**
 * User: pgadi
 */
public interface RegulatedCountryBusiness {

    boolean isCountryRegulatedByUsdaEpa(String country);

    boolean isCountryAbbrRegulatedByUsdaEpa(String countryAbbr);

    boolean isCountryRegulatedByStewardship(String country);

    boolean isCountryAbbrRegulatedByStewardship(String countryAbbr);

    String lookUpCountryAbbr(String country);
}
