package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ShipmentContainerLabelEntity;

/**
 * User: SDCHIL
 */
public interface ShipmentContainerLabelDao {

    void save(ShipmentContainerLabelEntity shipmentContainerLabelEntity);

    void delete(ShipmentContainerLabelEntity label);
}
