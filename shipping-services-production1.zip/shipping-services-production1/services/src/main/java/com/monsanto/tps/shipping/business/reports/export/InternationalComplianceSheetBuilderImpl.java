package com.monsanto.tps.shipping.business.reports.export;

import com.google.common.base.Function;
import com.google.common.collect.Maps;
import com.monsanto.tps.shipping.business.reports.POISheetBuilder;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.domain.SapOrderItemEntity;
import com.monsanto.tps.shipping.domain.SapOrderShipmentEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.CropDescription;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Map;

/**
 * Created by DCENGL
 */
@Service
public class InternationalComplianceSheetBuilderImpl extends POISheetBuilder implements InternationalComplianceSheetBuilder {

    private static final String[] HEADER = {"Box Barcode", "Region", "Event", "Country of Origin", "Crop Description", "Phytosanitary Comment", "Import Permit Number", "Error Message"};

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Override
    public Sheet buildSheet(Workbook workbook, ShipmentPackingListEntity packingList) {
        Sheet sheet = newSheet(workbook, "International Compliance");
        CellStyle headerCellStyle = buildHeaderStyle(workbook);
        CellStyle defaultCellStyle = buildDefaultStyle(workbook);

        addHeader(sheet, headerCellStyle, HEADER);

        Collection<CropDescription> cropDescriptionList = internationalCompositesDao.getCropDescriptions();
        Map<String, CropDescription> mappedDescriptions = Maps.uniqueIndex(cropDescriptionList, new Function<CropDescription, String>() {
            @Override
            public String apply(CropDescription cropDescription) {
                return cropDescription.getSapCcdVal();
            }
        });

        int currentRowIndex = 1;
        SapOrderShipmentEntity sapOrderShipmentEntity = packingList.getSapOrderShipment();
        if (sapOrderShipmentEntity != null) {
            Collection<SapOrderItemEntity> sapOrderItemEntities = sapOrderShipmentEntity.getOrderItems();
            if (sapOrderItemEntities != null) {
                for (SapOrderItemEntity sapOrderItemEntity : sapOrderItemEntities) {
                    Row row = sheet.createRow(currentRowIndex);
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getStorageContainerBarcode());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getRegionOfOrigin());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getEventStack());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getCountryOfOrigin());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getSapCcdVal() != null ? mappedDescriptions.get(sapOrderItemEntity.getSapCcdVal()).getSapCcdDescription() : null);
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getPhytoNumber());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getImportPermitNumber());
                    appendCell(row, defaultCellStyle, sapOrderItemEntity.getLcErrorMessage());

                    currentRowIndex++;
                }
            }
        }

        autoSizeColumns(sheet, HEADER.length);

        return sheet;
    }
}
