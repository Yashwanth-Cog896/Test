package com.monsanto.tps.shipping.dao;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.IrdContactXref;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;

/**
 * Created by SLAKS on 2/27/14.
 */
@Repository
public class IrdContactXrefDaoImpl implements IrdContactXrefDao{

    private static final Function<Object[],IrdContactXref> IRD_CONTACT_XREF_CONVERTER = new Function<Object[], IrdContactXref>() {
        @Override
        public IrdContactXref apply(@Nullable Object[] object) {
            IrdContactXref irdContactXref = new IrdContactXref((String)object[0],(String)object[1]);
            return irdContactXref;
        }
    };

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;

    @Override
    public List<IrdContactXref> findContactsXrefs(Long contactId) {
        long requestId = tempOcdTableDao.insertLongs(Lists.newArrayList(contactId));

        Collection<Object[]> rawResult = sessionFactory.getCurrentSession()
                .createSQLQuery("select distinct prim.alias_id as alias, sec.alias_id as passedAlias from ird.Contact_Xref prim, ird.Contact_Xref sec " +
                        "where prim.system_type_code = 'SITCON' " +
                        "and sec.system_type_code = 'SITCON' " +
                        "and prim.contact_id = sec.contact_id " +
                        "and prim.active_flag = 'Y' " +
                        "and sec.alias_id in (select NUMBER_1 from midas.temp_session_ocd tempTable where tempTable.request_id = :requestId) ")
                .setParameter("requestId", requestId).list();
        return Lists.newArrayList(Collections2.transform(rawResult,IRD_CONTACT_XREF_CONVERTER));
    }

    @Trace
    @Override
    public List<IrdContactXref> findContactsXrefs(Collection<Long> fcmContactIds) {
        long requestId = tempOcdTableDao.insertLongs(fcmContactIds);

        Collection<Object[]> rawResult = sessionFactory.getCurrentSession()
                .createSQLQuery("select distinct " +
                        "      fcm_contact.alias_id as fcm_contact_id, " +
                        "      ird_contact.alias_id as ird_contact_id " +
                        " from ird.Contact_Xref fcm_contact, " +
                        "      ird.Contact_Xref ird_contact " +
                        "where fcm_contact.system_type_code = 'SITCON' " +
                        "and ird_contact.system_type_code = 'SITCON' " +
                        "and fcm_contact.contact_id = ird_contact.contact_id " +
                        "and fcm_contact.active_flag = 'Y' " +
                        "and fcm_contact.alias_id in (select NUMBER_1 from midas.temp_session_ocd tempTable where tempTable.request_id = :requestId) ")
                .setParameter("requestId", requestId).list();
        return Lists.newArrayList(Collections2.transform(rawResult,IRD_CONTACT_XREF_CONVERTER));
    }

}
