package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.EupEventWeight;
import com.monsanto.tps.shipping.domain.EupMasterLabel;
import com.monsanto.tps.shipping.util.ShippingWebException;

import java.util.Collection;

public interface EupMasterLabelDocumentCollaborator {
    Collection<EupMasterLabel> fetchEupMasterLabels(Collection<EupEventWeight> eupEventWeights) throws ShippingWebException;
}
