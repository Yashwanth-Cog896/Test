package com.monsanto.tps.shipping.business;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.tps.shipping.domain.EventWeight;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Collection;

import static com.itextpdf.text.Font.FontFamily.HELVETICA;

@Service
public class EupMasterLabelWeightSummaryBuilderImpl implements EupMasterLabelWeightSummaryBuilder {

    private static final String EUP_HEADER_TEXT = "Bayer CropScience EUP Shipment Summary Label";
    private static final String EVENT_COLUMN_HEADER = "Event";
    private static final String FEMALE_EVENT_COLUMN_HEADER = "Female Event";
    private static final String MALE_EVENT_COLUMN_HEADER = "Male Event";
    private static final String WEIGHT_COLUMN_HEADER = "Net Contents (wt)";
    private static final String CONTENT_WEIGHT_NOT_PROVIDED = "Content Weight Not Provided";
    private static final Font HEADER_FONT = new Font(HELVETICA ,10, Font.BOLD);
    private static final int TOP_MARGIN = 50;
    private static final int SIDE_MARGIN = 90;

    @Override
    public ByteArrayOutputStream createWeightSummaryPage(String eupNumber, Collection<EventWeight> eventsWeights) throws Exception {
        Document document = new Document();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            PdfWriter writer = PdfWriter.getInstance(document, os);
            document.open();
            addHeader(writer, eupNumber);
            document.add(addEmptyLine(2));
            document.add(addEventWeightTable(eventsWeights));
            return os;
        } finally {
            document.close();
            os.close();
        }
    }

    private void addHeader(PdfWriter writer, String eupNumber) {
        Rectangle rect = writer.getPageSize();

        ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
                new Phrase(EUP_HEADER_TEXT, new Font(HELVETICA ,10, Font.BOLD)), rect.getLeft(SIDE_MARGIN), rect.getTop(TOP_MARGIN), 0);

        ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT,
                new Phrase(eupNumber, HEADER_FONT), rect.getRight(SIDE_MARGIN), rect.getTop(TOP_MARGIN), 0);
    }

    private PdfPTable addEventWeightTable(Collection<EventWeight> eventWeights) {

        PdfPTable table = new PdfPTable(2);
        table.addCell(createHeaderCell(EVENT_COLUMN_HEADER, Element.ALIGN_CENTER, PdfPCell.BOX));
        table.addCell(createHeaderCell(WEIGHT_COLUMN_HEADER, Element.ALIGN_CENTER, PdfPCell.BOX));
        table.setHeaderRows(1);
        for (EventWeight eventWeight : eventWeights) {
            table.addCell(eventWeight.getEvent());
            table.addCell(getWeight(eventWeight));
        }
        return table;
    }

    private PdfPCell createHeaderCell(String columnName, int alignment, int border) {
        PdfPCell cell = new PdfPCell(new Phrase(columnName,  new Font(HELVETICA ,10, Font.BOLD)));
        cell.setHorizontalAlignment(alignment);
        cell.setBorder(border);
        return cell;
    }

    private String getWeight(EventWeight eventWeight) {
        if (eventWeight.getWeight() != null && eventWeight.getWeight() > 0) {
            return eventWeight.getWeight().toString() + " lbs" ;
        } else {
            return CONTENT_WEIGHT_NOT_PROVIDED;
        }
    }

    private Paragraph addEmptyLine(int number) {
        Paragraph paragraph = new Paragraph();
        for (int i = 0; i < number; i++) {
            paragraph.add(Chunk.NEWLINE);
        }

        return paragraph;
    }
}
