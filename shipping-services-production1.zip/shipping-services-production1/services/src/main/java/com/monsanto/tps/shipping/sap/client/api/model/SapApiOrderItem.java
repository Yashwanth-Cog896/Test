package com.monsanto.tps.shipping.sap.client.api.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapApiOrderItem", propOrder = {
    "itemnumber",
    "sapmaterialnumber",
    "sapplant",
    "sapcoo",
    "orderquantity",
    "salesunit",
    "saproute",
    "yyShipfromid",
    "sapstoragelocation",
    "sapregionoforigin",
    "phytosanitaryitemtext",
    "importpermitnumber",
    "registrationnumber",
    "reasonforrejection",
    "customermaterialnumber",
    "materialsalestext"
})
public class SapApiOrderItem {

    @XmlElement(required = true)
    private String itemnumber;
    @XmlElement(required = true)
    private String sapmaterialnumber;
    @XmlElement(required = true)
    private String sapplant;
    @XmlElement(required = true)
    private String sapcoo;
    @XmlElement(required = true)
    private BigDecimal orderquantity;
    @XmlElement(required = true)
    private String salesunit;
    @XmlElement(required = true)
    private String saproute;
    @XmlElement(name = "YyShipfromid", required = true)
    private String yyShipfromid;
    @XmlElement(required = true)
    private String sapstoragelocation;
    @XmlElement(required = true)
    private String sapregionoforigin;
    @XmlElement(required = true)
    private String phytosanitaryitemtext;
    @XmlElement(required = true)
    private String importpermitnumber;
    @XmlElement(required = true)
    private String registrationnumber;
    @XmlElement(required = true)
    private String reasonforrejection;
    @XmlElement(required = true)
    private String customermaterialnumber;
    @XmlElement(required = true)
    private String materialsalestext;
    @XmlTransient
    private Long uomId;
    @XmlTransient
    private BigDecimal boxWeight;

    public String getItemnumber() {
        return itemnumber;
    }

    public void setItemnumber(String itemnumber) {
        this.itemnumber = itemnumber;
    }

    public String getSapmaterialnumber() {
        return sapmaterialnumber;
    }

    public void setSapmaterialnumber(String sapmaterialnumber) {
        this.sapmaterialnumber = sapmaterialnumber;
    }

    public String getSapplant() {
        return sapplant;
    }

    public void setSapplant(String sapplant) {
        this.sapplant = sapplant;
    }

    public String getSapcoo() {
        return sapcoo;
    }

    public void setSapcoo(String sapcoo) {
        this.sapcoo = sapcoo;
    }

    public BigDecimal getOrderquantity() {
        return orderquantity;
    }

    public void setOrderquantity(BigDecimal orderquantity) {
        this.orderquantity = orderquantity;
    }

    public String getSalesunit() {
        return salesunit;
    }

    public void setSalesunit(String salesunit) {
        this.salesunit = salesunit;
    }

    public String getSaproute() {
        return saproute;
    }

    public void setSaproute(String saproute) {
        this.saproute = saproute;
    }

    public String getYyShipfromid() {
        return yyShipfromid;
    }

    public void setYyShipfromid(String yyShipfromid) {
        this.yyShipfromid = yyShipfromid;
    }

    public String getSapstoragelocation() {
        return sapstoragelocation;
    }

    public void setSapstoragelocation(String sapstoragelocation) {
        this.sapstoragelocation = sapstoragelocation;
    }

    public String getSapregionoforigin() {
        return sapregionoforigin;
    }

    public void setSapregionoforigin(String sapregionoforigin) {
        this.sapregionoforigin = sapregionoforigin;
    }

    public String getPhytosanitaryitemtext() {
        return phytosanitaryitemtext;
    }

    public void setPhytosanitaryitemtext(String phytosanitaryitemtext) {
        this.phytosanitaryitemtext = phytosanitaryitemtext;
    }

    public String getImportpermitnumber() {
        return importpermitnumber;
    }

    public void setImportpermitnumber(String importpermitnumber) {
        this.importpermitnumber = importpermitnumber;
    }

    public String getRegistrationnumber() {
        return registrationnumber;
    }

    public void setRegistrationnumber(String registrationnumber) {
        this.registrationnumber = registrationnumber;
    }

    public String getReasonforrejection() {
        return reasonforrejection;
    }

    public void setReasonforrejection(String reasonforrejection) {
        this.reasonforrejection = reasonforrejection;
    }

    public String getCustomermaterialnumber() {
        return customermaterialnumber;
    }

    public void setCustomermaterialnumber(String customermaterialnumber) {
        this.customermaterialnumber = customermaterialnumber;
    }

    public String getMaterialsalestext() {
        return materialsalestext;
    }

    public void setMaterialsalestext(String materialsalestext) {
        this.materialsalestext = materialsalestext;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public BigDecimal getBoxWeight() {
        return boxWeight;
    }

    public void setBoxWeight(BigDecimal boxWeight) {
        this.boxWeight = boxWeight;
    }
}
