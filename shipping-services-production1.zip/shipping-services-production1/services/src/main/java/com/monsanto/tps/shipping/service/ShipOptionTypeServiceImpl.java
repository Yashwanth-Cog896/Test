package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.ShipOptionTypeBusiness;
import com.monsanto.tps.shipping.domain.ShipOptionTypeEntity;
import com.monsanto.tps.shipping.service.model.ShipOptionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component("shipOptionTypeService")
public class ShipOptionTypeServiceImpl implements ShipOptionTypeService {

    @Autowired
    private ShipOptionTypeBusiness shipOptionTypeBusiness;

    @Override
    public void saveShipOptionType(Long shipOptionTypeId) {
        ShipOptionTypeEntity shipOptionTypeEntity = shipOptionTypeBusiness.findShipOptionType(shipOptionTypeId);
        if ( shipOptionTypeEntity != null ) {
            shipOptionTypeBusiness.saveShipOptionType(shipOptionTypeEntity);
        }

    }

    @Override
    public ShipOptionType findShipOptionType(Long shipOptionTypeId) {
        return getShipOptionType(shipOptionTypeBusiness.findShipOptionType(shipOptionTypeId));
    }

    @Override
    @Transactional
    public List<ShipOptionType> findAllShipOptionTypes() {
        List<ShipOptionTypeEntity> shipOptionTypeEntities = shipOptionTypeBusiness.findAllShipOptionTypes();
        List<ShipOptionType> shipOptionTypes = new ArrayList<ShipOptionType>();
        for (ShipOptionTypeEntity shipOptionTypeEntity : shipOptionTypeEntities) {
            shipOptionTypes.add(getShipOptionType(shipOptionTypeEntity));
        }
        return shipOptionTypes;
    }

    private ShipOptionType getShipOptionType(ShipOptionTypeEntity shipOptionTypeEntity) {
        ShipOptionType shipOptionType = new ShipOptionType();
        shipOptionType.setShipOptionTypeId(shipOptionTypeEntity.getShipOptionTypeId());
        shipOptionType.setName(shipOptionTypeEntity.getName());

        return shipOptionType;
    }
}