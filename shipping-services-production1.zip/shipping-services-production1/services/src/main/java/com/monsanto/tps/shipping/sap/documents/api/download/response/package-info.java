@javax.xml.bind.annotation.XmlSchema(namespace = "http://monsanto.com.integrationservices.generic", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.tps.shipping.sap.documents.api.download.response;
