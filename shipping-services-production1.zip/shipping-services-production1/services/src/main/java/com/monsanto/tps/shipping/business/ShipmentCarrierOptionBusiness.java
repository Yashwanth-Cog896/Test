package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipOptionType;
import com.monsanto.tps.shipping.domain.ShipmentCarrierOptionEntity;
import com.monsanto.tps.shipping.domain.ShipmentEntity;
import com.monsanto.tps.shipping.service.model.CarrierShipOption;

import java.util.Collection;

/**
 * User: DCENGL
 */
public interface ShipmentCarrierOptionBusiness {

    Collection<ShipmentCarrierOptionEntity> getCarrierOptionsForShipment(ShipmentEntity shipment, Collection<CarrierShipOption> carrierShipOptionEntities);

    boolean isIntegratedCarrier(Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptions);

    ShipmentCarrierOptionEntity getShipmentCarrierOptionByType(Collection<ShipmentCarrierOptionEntity> shipmentCarrierOptionEntities, ShipOptionType shipOptionType);
}
