
package com.monsanto.tps.shipping.sap.client.api.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SapApiError", propOrder = {
    "yyerror",
    "yyid",
    "yydesc"
})
public class SapApiError {

    @XmlElement(name = "Yyerror", required = true)
    private String yyerror;
    @XmlElement(name = "Yyid", required = true)
    private String yyid;
    @XmlElement(name = "Yydesc", required = true)
    private String yydesc;

    public SapApiError() {
    }

    public SapApiError(String yydesc) {
        this.yydesc = yydesc;
    }

    public String getYyerror() {
        return yyerror;
    }

    public void setYyerror(String yyerror) {
        this.yyerror = yyerror;
    }

    public String getYyid() {
        return yyid;
    }

    public void setYyid(String yyid) {
        this.yyid = yyid;
    }

    public String getYydesc() {
        return yydesc;
    }

    public void setYydesc(String yydesc) {
        this.yydesc = yydesc;
    }
}
