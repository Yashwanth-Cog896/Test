package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.TissuePlateWellEntity;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by DCENGL
 */
@Repository
public class TissuePlateWellDaoImpl implements TissuePlateWellDao {

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<TissuePlateWellEntity> getTissuePlateWells(Collection<ScannedContainerEntity> scannedContainers) {
        List<TissuePlateWellEntity> tissuePlateWellEntities = Lists.newArrayList();

        if (CollectionUtils.isEmpty(scannedContainers)) {
            return tissuePlateWellEntities;
        }

        Map<Long, ScannedContainerEntity> scannedContainerEntityMap = new HashMap<Long, ScannedContainerEntity>();
        List<Long> scannedContainerIdList = Lists.newArrayList();

        for (ScannedContainerEntity scannedContainer : scannedContainers) {
            Long scannedContainerId = scannedContainer.getScannedContainerId();
            scannedContainerIdList.add(scannedContainerId);
            scannedContainerEntityMap.put(scannedContainerId, scannedContainer);
        }

        /**
         * Used Scalar query to avoid complete table/view scan on start up. Its not holding any sql fragments in memory.
         */
        SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery("select storage_container_id, scanned_container_id, " +
                "barcode, plot_bid, sample_nbr, well_nbr, lims_id, project_name, field_name, set_name, plate_type, block_id " +
                "from INVENTORY_MGT.FIELD_PLATE_WELL_VW " +
                "where SCANNED_CONTAINER_ID in (:scannedContainerIds)");

        List<Object[]> tissuePlateWellData = query.setParameterList("scannedContainerIds", scannedContainerIdList).list();

        for (Object[] row : tissuePlateWellData) {
            TissuePlateWellEntity tissuePlateWellEntity = new TissuePlateWellEntity();
            tissuePlateWellEntity.setScannedContainerId(((BigDecimal) row[1]).longValue());
            tissuePlateWellEntity.setBarcode((String) row[2]);
            tissuePlateWellEntity.setPlotBarcode((String) row[3]);
            tissuePlateWellEntity.setSampleNumber(((BigDecimal) row[4]).longValue());
            tissuePlateWellEntity.setWellNumber((String) row[5]);
            tissuePlateWellEntity.setLimsId((String) row[6]);
            tissuePlateWellEntity.setProjectName((String) row[7]);
            tissuePlateWellEntity.setFieldName((String) row[8]);
            tissuePlateWellEntity.setSetName((String) row[9]);
            tissuePlateWellEntity.setPlateType((String) row[10]);
            tissuePlateWellEntity.setBlockId((String) row[11]);

            tissuePlateWellEntities.add(tissuePlateWellEntity);
        }

        for(TissuePlateWellEntity tissuePlateWellEntity : tissuePlateWellEntities) {
            tissuePlateWellEntity.setScannedContainer(scannedContainerEntityMap.get(tissuePlateWellEntity.getScannedContainerId()));
        }

        return tissuePlateWellEntities;
    }
}
