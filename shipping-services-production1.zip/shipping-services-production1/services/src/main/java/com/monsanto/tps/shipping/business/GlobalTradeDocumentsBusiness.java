package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.transfer.GlobalTradeDocuments;

import java.util.List;

public interface GlobalTradeDocumentsBusiness {

    public List<GlobalTradeDocuments> getGlobalTradeDocumentsList(Long sapOrderShipmentId);

    public byte[] getGlobalTradeDocumentPdf(String encodedDocumentUrl, String title);
}
