package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.RepContent;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/rep-content")
public interface RepContentService {

    @GET
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/{barcode}/packing-list/{packing-list-id}/crop/{crop-id}")
    public RepContent getRepContent(@PathParam("packing-list-id") Long packingListId,
                                    @PathParam("barcode") String barcode,
                                    @PathParam("crop-id") Long cropId);

    @GET
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/{barcode}/packing-list/{packing-list-id}")
    public RepContent getRepContent(@PathParam("packing-list-id") Long packingListId,
                                    @PathParam("barcode") String barcode);

    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @Path("/packing-list/{packing-list-id}")
    public List<RepContent> save(@PathParam("packing-list-id") Long packingListId,
                                 @QueryParam("plots-per-box") Integer plotsPerBox,
                                 @QueryParam("use-last-box") Boolean continueLastBox,
                                 @QueryParam("order")String order,
                                 List<RepContent> repContents);

}
