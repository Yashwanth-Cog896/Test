package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@Entity
@Table(name = "temp_session_ocd", schema = "midas")
public class TempOcdTable {

    @Id
    @Column(name = "text_1", nullable = false)
    private String tempOcdId;
    @Column(name ="number_1")
    private Long tempOcdNumber;
    @Column(name = "request_id")
    private long sessionId;

    public String getTempOcdId() {
        return tempOcdId;
    }

    public void setTempOcdId(String tempOcdId) {
        this.tempOcdId = tempOcdId;
    }

    public Long getTempOcdNumber() {
        return tempOcdNumber;
    }

    public void setTempOcdNumber(Long tempOcdNumber) {
        this.tempOcdNumber = tempOcdNumber;
    }

    public long getSessionId() {
        return sessionId;
    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }
}
