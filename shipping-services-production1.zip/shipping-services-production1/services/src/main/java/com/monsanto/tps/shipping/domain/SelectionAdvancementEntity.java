package com.monsanto.tps.shipping.domain;

import javax.persistence.*;

/**
 * User: DCENGL
 */
@Entity
@Table(name = "SELECTION_ADVANCEMENT", schema = "MIDAS")
public class SelectionAdvancementEntity {

    @Id
    @Column(name = "SELECTION_ADVANCEMENT_ID")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "FEMALE_PLOT_ID", insertable = false, updatable = false)
    private PlotEntity femalePlot;
    @Column(name = "ADVANCEMENT_NUMBER")
    private Long advancementNumber;
    @OneToOne(optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "OPERATION_ID", referencedColumnName = "OPERATION_ID", insertable = false, updatable = false)
    private OperationOperationTypeEntity operationOperationType;
    @Column(name = "INACTIVE_DTTM")
    private Long inactiveDttm;
    @OneToOne(fetch = FetchType.EAGER, mappedBy = "selectionAdvancement")
    private SelectionAdvancementMalePlotEntity selectionAdvancementMalePlot;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PlotEntity getFemalePlot() {
        return femalePlot;
    }

    public void setFemalePlot(PlotEntity femalePlot) {
        this.femalePlot = femalePlot;
    }

    public Long getAdvancementNumber() {
        return advancementNumber;
    }

    public void setAdvancementNumber(Long advancementNumber) {
        this.advancementNumber = advancementNumber;
    }

    public OperationOperationTypeEntity getOperationOperationType() {
        return operationOperationType;
    }

    public void setOperationOperationType(OperationOperationTypeEntity operationOperationType) {
        this.operationOperationType = operationOperationType;
    }

    public Long getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Long inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public SelectionAdvancementMalePlotEntity getSelectionAdvancementMalePlot() {
        return selectionAdvancementMalePlot;
    }

    public void setSelectionAdvancementMalePlot(SelectionAdvancementMalePlotEntity selectionAdvancementMalePlot) {
        this.selectionAdvancementMalePlot = selectionAdvancementMalePlot;
    }

    @Override
    public String toString() {
        return "SelectionAdvancementEntity{" +
                "operationOperationType=" + operationOperationType +
                ", id=" + id +
                ", femalePlot=" + femalePlot +
                '}';
    }
}

