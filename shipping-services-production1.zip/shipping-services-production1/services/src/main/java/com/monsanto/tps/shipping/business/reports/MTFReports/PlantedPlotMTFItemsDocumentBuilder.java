package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.SortedSet;

@Service
public class PlantedPlotMTFItemsDocumentBuilder extends AbstractMTFItemsDocumentBuilder {

    @Override
    protected void addItemRows(PdfPTable contentsTable, PdfPTable permitsTable, ShipmentPackingListEntity packingList, Collection<Event> events, Font font) throws DocumentException {
        SortedSet<ScannedContainerEntity> contentContainerEntities = getSortedScannedContainerEntities(packingList);
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        decimalFormat.setRoundingMode(RoundingMode.UP);

        addSelectedPermitsToTable(permitsTable, events, false, font);

        for (ScannedContainerEntity contentContainer : contentContainerEntities) {
            PlotEntity plot = null;
            TestSetEntryEntity entry = null;
            RepEntity rep = null;
            if (contentContainer.getContentType() == ContentType.PLOT) {
                plot = (PlotEntity) contentContainer.getContent();
                entry = plot.getTestSetEntry();
                rep = plot.getRep();
            }

            String eventString = getEventString(contentContainer.getContent());

            appendCellToTable(contentContainer.getScanOrder(), contentsTable, font);
            appendCellToTable(contentContainer.getContent().getBarcode(), contentsTable, font);
            appendCellToTable(eventString, contentsTable, font);
            appendCellToTable(rep != null && rep.getTestSet() != null ? rep.getTestSet().getTestSetName() : "", contentsTable, font);
            appendCellToTable(rep != null && rep.getField() != null ? rep.getField().getFieldName() : "", contentsTable, font);
            appendCellToTable(rep != null && rep.getRepNumber() != null ? rep.getRepNumber().toString() : "", contentsTable, font);
            appendCellToTable(plot != null && plot.getPlotNumber() != null ? plot.getPlotNumber().toString() : "", contentsTable, font);
            appendCellToTable(entry != null && entry.getEntryNumber() != null ? String.valueOf(entry.getEntryNumber().intValue()) : "", contentsTable, font);

            Double weight = contentContainer.getWeight();
            appendCellToTable(weight != null ? decimalFormat.format(weight) : "", contentsTable, font);

            UnitOfMeasureEntity uomEntity = contentContainer.getWeightUOM();
            appendCellToTable(uomEntity != null ? uomEntity.getUomRefId() : "", contentsTable, font);

            Integer quantity = contentContainer.getQuantity();
            appendCellToTable(quantity != null ? quantity.toString() : "", contentsTable, font);

            appendCellToTable(contentContainer.getStorageContainer().getBarcode(), contentsTable, font);

            contentsTable.completeRow();
        }
    }

    @Override
    protected PdfPTable createContentsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Item #", "Item BID", "Event", "Set", "Track ID", "Rep", "Plot #", "Entry #", "Weight", "UOM", "Count", "Box Barcode", "Received"},
                new float[]{15, 55, 65, 20, 20, 15, 15, 15, 15, 15, 15, 25, 20}, font);
    }
    @Override
    protected PdfPTable createPermitsTable(Font font) throws DocumentException {
        return createTableWithHeader(new String[]{"Event", "Permit", "Agency", "Permit Expiration Date"},
                new float[]{120, 50, 30, 50}, font);
    }

    @Override
    public boolean canBuild(ShipmentTypeEntity shipmentType) {
        return shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.PLANTED_PLOT ||
                shipmentType.getShipmentTypeEnum() == ShipmentTypeEnum.PLANTED_PLOT_INV;
    }
}
