package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.ExternalMaterialTypeEntity;

import java.util.Collection;

public interface ExternalMaterialTypeDao {
    ExternalMaterialTypeEntity findById(Long id);

    ExternalMaterialTypeEntity findByDesc(String description);

    Collection<ExternalMaterialTypeEntity> findAllActive();
}
