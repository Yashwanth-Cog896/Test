package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.Collection;

@Entity
@DiscriminatorValue("WHOLE_PLANTS")
public class EventConstructContainerEntity extends ScannedContainerEntity<EventConstructEntity> {

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BARCODE_NBR", referencedColumnName = "BARCODE")
    private EventConstructEntity eventConstructEntity;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SCANNED_CONTAINER_ID", referencedColumnName = "SCANNED_CONTAINER_ID")
    private Collection<RegulatedInventoryMovementEntity> regulatedInventoryMovements;

    @Override
    public EventConstructEntity getContent() {
        return eventConstructEntity;
    }

    @Override
    public Long getIdForRegulatedMovement() {
        return null;
    }

    @Override
    public void setContent(EventConstructEntity contentEntity) {
        this.eventConstructEntity = contentEntity;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.WHOLE_PLANTS;
    }

    @Override
    public Collection<RegulatedInventoryMovementEntity> getRegulatedMovements() {
        return regulatedInventoryMovements;
    }

    @Override
    public void addRegulatedMovement(RegulatedInventoryMovementEntity newMovement) {
        if (regulatedInventoryMovements != null) {
            regulatedInventoryMovements.add(newMovement);
        } else {
            regulatedInventoryMovements = Lists.newArrayList(newMovement);
        }
    }

    @Override
    public void setRegulatedMovements(Collection<RegulatedInventoryMovementEntity> movements) {
        this.regulatedInventoryMovements = movements;
    }
}
