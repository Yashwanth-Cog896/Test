package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierShipOptionEntity;

import java.util.List;

/**
 * Created by KERRA on 5/19/2014.
 */
public interface CarrierShipOptionDao {
    CarrierShipOptionEntity findCarrierShipOption(Long carrierShipOption);
    List<CarrierShipOptionEntity> findAllCarrierShipOptions();
    List<CarrierShipOptionEntity> findCarrierShipOptionByCarrierId(Long carrierId);
}