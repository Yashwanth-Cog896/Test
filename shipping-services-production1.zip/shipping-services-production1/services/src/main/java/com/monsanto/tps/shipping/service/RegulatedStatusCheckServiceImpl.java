package com.monsanto.tps.shipping.service;

import com.google.common.collect.Sets;
import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 * Use this service to health check the Regulated Status API
 */
@Component("regulatedStatusCheckService")
public class RegulatedStatusCheckServiceImpl implements RegulatedStatusCheckService {
    private static final Log LOG = LogFactory.getLog(RegulatedStatusCheckServiceImpl.class);
    @Autowired
    private RegulatedEventStatusService regulatedEventStatusService;

    @Override
    public RegulatedAPIResponse getRegulatedAPIResponses(String eventString) {
        //LOG.info("Inside getRegulatedAPIResponses");
        Set<String> allEventStrings = Sets.newHashSet(eventString);
        List<RegulatedAPIResponse> responseMap = regulatedEventStatusService.getRegulatedAPIResponses(allEventStrings);
        RegulatedAPIResponse response = responseMap.get(0);
        //LOG.info("End getRegulatedAPIResponses response= "+response);
        return response;
    }
}
