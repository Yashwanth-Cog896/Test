package com.monsanto.tps.shipping.business.reports.export;

import com.monsanto.tps.shipping.business.ContactBusiness;
import com.monsanto.tps.shipping.business.reports.POISheetBuilder;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by DCENGL
 */
@Service
public class PackingListDetailsSheetBuilderImpl extends POISheetBuilder implements PackingListDetailsSheetBuilder {

    @Autowired
    private ContactBusiness contactBusiness;

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Override
    public Sheet buildSheet(Workbook workbook, ShipmentPackingListEntity packingList) {
        Sheet sheet = workbook.createSheet("Packing List");

        Row contentTypeRow = sheet.createRow(0);
        appendCell(contentTypeRow, "Content Type");
        appendCell(contentTypeRow, packingList.getShipmentType().getDescription());

        Row barcodeRow = sheet.createRow(1);
        appendCell(barcodeRow, "Shipment");
        appendCell(barcodeRow, packingList.getBarcode());

        AbstractContact fromContact = getFromContact(packingList);
        Row shipFromRow = sheet.createRow(2);
        appendCell(shipFromRow, "Ship From");
        appendCell(shipFromRow, fromContact.getName());

        AbstractContact toContact = getToContact(packingList);
        Row shipToRow = sheet.createRow(3);
        appendCell(shipToRow, "Ship To");
        appendCell(shipToRow, toContact.getName());

        Row shipToAttnRow = sheet.createRow(4);
        appendCell(shipToAttnRow, "Ship To Attn");
        appendCell(shipToAttnRow, packingList.getShipToAttn());

        Row descriptionRow = sheet.createRow(5);
        appendCell(descriptionRow, "Shipment Description");
        appendCell(descriptionRow, packingList.getDescription());

        if (packingList.isInternational()) {
            AbstractContact soldToContact = internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getSoldToCustomerNumber());

            Row soldToRow = sheet.createRow(6);
            appendCell(soldToRow, "Sold To");
            appendCell(soldToRow, soldToContact != null ? soldToContact.getName() : null);
        }


        autoSizeColumns(sheet, 2);

        return sheet;
    }

    private AbstractContact getToContact(ShipmentPackingListEntity packingList) {
        if (packingList.isInternational()) {
            return internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getShipToCustomerNumber());
        }

        return contactBusiness.getContact(packingList.getToContactId());
    }

    private AbstractContact getFromContact(ShipmentPackingListEntity packingList) {
        if (packingList.isInternational()) {
            return internationalCompositesDao.getStorageLocation(packingList.getSapOrderShipment().getSapStorageLocationCode());
        }

        return contactBusiness.getContact(packingList.getFromContactId());
    }
}
