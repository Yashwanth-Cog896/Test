package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.dao.ExternalMaterialTypeDao;
import com.monsanto.tps.shipping.domain.ExternalMaterialTypeEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class ExternalMaterialTypeBusinessImpl implements ExternalMaterialTypeBusiness {

    @Autowired
    private ExternalMaterialTypeDao externalMaterialTypeDao;

    @Trace
    @Override
    public Collection<ExternalMaterialTypeEntity> getAllActive() {
        return externalMaterialTypeDao.findAllActive();
    }
}
