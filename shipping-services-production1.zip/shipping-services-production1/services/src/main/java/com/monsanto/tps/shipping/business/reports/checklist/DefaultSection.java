package com.monsanto.tps.shipping.business.reports.checklist;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import static com.itextpdf.text.Font.FontFamily.HELVETICA;

/**
 * Created by DCENGL
 */
@Service
public class DefaultSection extends AbstractChecklistSection {
    private final static Font CHECKBOX_HEADER_FONT = new Font(HELVETICA, 6);

    private final static String HEADER = "General requirements for movement of all material types (USDA regulated, EPA governed, and/or Bayer stewardship)";

    private final static String SECTION_1 = "Containment";
    private final static String SECTION_1_QUESTION_1 = "Containment layer(s) is/are capable of preventing loss of seed and/or viable plant material.";
    private final static String SECTION_1_QUESTION_2 = "Material is moved within containment layers for USDA notifications and permits per shipping SOP.";
    private final static String SECTION_1_QUESTION_3 = "Containment layers are either new or inspected as being in good condition.";

    private final static String SECTION_2 = "Documentation";
    private final static String SECTION_2_QUESTION_1 = "A completed Material Transfer Form.";
    private final static String SECTION_2_QUESTION_2 = "All documents are placed in Box 1.";

    private final static String SECTION_3 = "Labeling";
    private final static String SECTION_3_QUESTION_1 = "Traceable source and Event is printed on individual material packets or containers.";
    private final static String SECTION_3_QUESTION_2 = "Containment layers have no visible markings that are specifically associated with previous shipments.";

    @Override
    protected String getHeaderText() {
        return HEADER;
    }

    @Override
    protected void onFirstSubSection(PdfWriter writer, float y) throws DocumentException {
        addCheckboxHeader(writer, CHECKBOX_HEADER_FONT, y, 1, "Not", "Applicable");
        addCheckboxHeader(writer, CHECKBOX_HEADER_FONT, y, 2, "Shipper");
        addCheckboxHeader(writer, CHECKBOX_HEADER_FONT, y, 3, "Verifier");
        addCheckboxHeader(writer, CHECKBOX_HEADER_FONT, y, 4, "Receiver");
    }

    @Override
    protected Multimap<String, String> getSectionMap() {
        Multimap<String, String> questionsMap = LinkedListMultimap.create();

        questionsMap.put(SECTION_1, SECTION_1_QUESTION_1);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_2);
        questionsMap.put(SECTION_1, SECTION_1_QUESTION_3);

        questionsMap.put(SECTION_2, SECTION_2_QUESTION_1);
        questionsMap.put(SECTION_2, SECTION_2_QUESTION_2);

        questionsMap.put(SECTION_3, SECTION_3_QUESTION_1);
        questionsMap.put(SECTION_3, SECTION_3_QUESTION_2);

        return questionsMap;
    }

    private void addCheckboxHeader(PdfWriter writer, Font font, float startingPosition, int i, String... headers) throws DocumentException {
        float right = writer.getPageSize().getRight();

        float lowerLeftX = right - (200 - (i * 40));
        float lowerLeftY = startingPosition - 3;

        ColumnText checkboxHeader = new ColumnText(writer.getDirectContent());
        for (String header : headers) {
            Paragraph paragraph = new Paragraph(header, font);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            checkboxHeader.addElement(paragraph);
        }
        checkboxHeader.setSimpleColumn(lowerLeftX - 7, lowerLeftY, lowerLeftX + 25, lowerLeftY + 20, 0, Element.ALIGN_CENTER);
        checkboxHeader.go();
    }

}
