package com.monsanto.tps.shipping.dao;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.domain.TissuePlateEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * User: DCENGL
 */
@Repository
public class TissuePlateDaoImpl implements TissuePlateDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TempOcdTableDao tempOcdTableDao;


    @Trace
    @Override
    public List<TissuePlateEntity> findByBarcode(Set<String> barcodes) {
        long requestId = tempOcdTableDao.insertStrings(Lists.newArrayList(barcodes));

        return sessionFactory.getCurrentSession()
                .createQuery( "select t " +
                        "from TissuePlateEntity t, TempOcdTable tempTable " +
                                "where t.barcode = tempTable.tempOcdId and tempTable.sessionId = :requestId")
                .setParameter("requestId", requestId).list();
    }

    @Trace
    @Override
    public List<TissuePlateEntity> findByBarcode(String barcode) {
        return sessionFactory.getCurrentSession().createQuery("from TissuePlateEntity where barcode = :barcode")
                .setParameter("barcode", barcode)
                .list();
    }
}
