
package com.monsanto.tps.shipping.sap.documents.api.retrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for YgtmStVelocityShpmntLink complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="YgtmStVelocityShpmntLink">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="YydocStatus" type="{urn:sap-com:document:sap:rfc:functions}char1"/>
 *         &lt;element name="Yypath" type="{urn:sap-com:document:sap:rfc:functions}char255"/>
 *         &lt;element name="Yytitle" type="{urn:sap-com:document:sap:rfc:functions}char60"/>
 *         &lt;element name="Yytime" type="{urn:sap-com:document:sap:rfc:functions}char25"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "YgtmStVelocityShpmntLink", propOrder = {
    "yydocStatus",
    "yypath",
    "yytitle",
    "yytime"
})
public class YgtmStVelocityShpmntLink {

    @XmlElement(name = "YydocStatus", required = true)
    protected String yydocStatus;
    @XmlElement(name = "Yypath", required = true)
    protected String yypath;
    @XmlElement(name = "Yytitle", required = true)
    protected String yytitle;
    @XmlElement(name = "Yytime", required = true)
    protected String yytime;

    /**
     * Gets the value of the yydocStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYydocStatus() {
        return yydocStatus;
    }

    /**
     * Sets the value of the yydocStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYydocStatus(String value) {
        this.yydocStatus = value;
    }

    /**
     * Gets the value of the yypath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYypath() {
        return yypath;
    }

    /**
     * Sets the value of the yypath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYypath(String value) {
        this.yypath = value;
    }

    /**
     * Gets the value of the yytitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYytitle() {
        return yytitle;
    }

    /**
     * Sets the value of the yytitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYytitle(String value) {
        this.yytitle = value;
    }

    /**
     * Gets the value of the yytime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYytime() {
        return yytime;
    }

    /**
     * Sets the value of the yytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYytime(String value) {
        this.yytime = value;
    }

}
