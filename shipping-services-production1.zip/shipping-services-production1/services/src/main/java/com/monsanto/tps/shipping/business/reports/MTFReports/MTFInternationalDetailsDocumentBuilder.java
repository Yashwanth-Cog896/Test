package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.tps.shipping.dao.InternationalCompositesDao;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.AbstractContact;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by DCENGL
 */
@Service
public class MTFInternationalDetailsDocumentBuilder extends AbstractMTFDetailsDocumentBuilder {

    @Autowired
    private InternationalCompositesDao internationalCompositesDao;

    @Override
    public void buildDocument(PdfWriter writer, Document document, ShipmentPackingListEntity packingList) throws DocumentException {
        Font boldFont = buildBoldFont(9);
        Font defaultFont = buildDefaultFont(9);
        Font boldUnderlineFont = buildBoldUnderlineFont(9);

        addStringAtCoordinates("Ship From", 20, 50, writer, boldFont);
        addStringAtCoordinates(getShipFromString(packingList), 30, 65, writer, defaultFont);

        addStringAtCoordinates("Ship To", 240, 50, writer, boldFont);
        addStringAtCoordinates(getShipToString(packingList), 250, 65, writer, defaultFont);

        addStringAtCoordinates("Sold To", 560, 50, writer, boldFont);
        addStringAtCoordinates(getSoldToString(packingList), 570, 65, writer, defaultFont);


        addStringAtCoordinates("Shipment Tracking Information", 20, 190, writer, boldFont);
        addBoxesWithTextVerticallyAtCoordinates(new String[]{getCarrierAndTrackingIdString(packingList), getBoxSummaryString(packingList)}, 20, 210, 212, writer, defaultFont);

        addStringAtCoordinates("NOTE: It is the receiver's responsibility to fully check the notification numbers and events prior to release.", 250, 240, writer, defaultFont);

        addStringAtCoordinates("SHIPPER Information", 22, 300, writer, boldUnderlineFont);
        addStringAtCoordinates("RECEIVER Information", 399, 300, writer, boldUnderlineFont);
        addBoxesWithTextCenteredHorizontallyAtY(new String[]{getShipperInformationString(), getReceiverInformationString()}, 300, 250, writer, defaultFont);
    }

    public String getShipFromString(ShipmentPackingListEntity packingList) {
        AbstractContact fromContact = getFromContact(packingList);

        StringBuilder shipFromStringBuilder = new StringBuilder();
        appendContact(fromContact, shipFromStringBuilder);

        return shipFromStringBuilder.toString();
    }

    public String getShipToString(ShipmentPackingListEntity packingList) {
        AbstractContact toContact = getToContact(packingList);

        StringBuilder shipToStringBuilder = new StringBuilder();
        appendContact(toContact, shipToStringBuilder);
        return shipToStringBuilder.toString();
    }

    public String getSoldToString(ShipmentPackingListEntity packingList) {
        AbstractContact toContact = getSoldToContact(packingList);

        StringBuilder soldToStringBUilder = new StringBuilder();
        appendContact(toContact, soldToStringBUilder);
        return soldToStringBUilder.toString();
    }

    protected void appendContact(AbstractContact contact, StringBuilder contactStringBuilder) {

        if (contact == null) {
            return;
        }

        if (contact.getName() != null) {
            contactStringBuilder.append(contact.getName()).append("\n");
        }

        String addressLine1 = contact.getAddressLine1();
        if (!StringUtils.isEmpty(addressLine1)) {
            contactStringBuilder.append(addressLine1).append("\n");
        }
        String addressLine2 = contact.getAddressLine2();
        if (!StringUtils.isEmpty(addressLine2)) {
            contactStringBuilder.append(addressLine2).append("\n");
        }
        String addressLine3 = contact.getAddressLine3();
        if (!StringUtils.isEmpty(addressLine3)) {
            contactStringBuilder.append(addressLine3).append("\n");
        }

        String zipFour = contact.getZipFour();
        contactStringBuilder.append(contact.getCity()).append(", ").append(contact.getState()).append(" ").append(contact.getZip()).append(zipFour != null ? "-" + zipFour : "");
    }

    private AbstractContact getToContact(ShipmentPackingListEntity packingList) {
        return internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getShipToCustomerNumber());
    }

    private AbstractContact getFromContact(ShipmentPackingListEntity packingList) {
        return internationalCompositesDao.getStorageLocation(packingList.getSapOrderShipment().getSapStorageLocationCode());
    }

    private AbstractContact getSoldToContact(ShipmentPackingListEntity packingList) {
        return internationalCompositesDao.getCustomer(packingList.getSapOrderShipment().getSoldToCustomerNumber());
    }
}
