package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

/**
 * User: jdvoll
 * Date: 1/6/14
 * Time: 2:22 PM
 */
@Repository("storageContainerDao")
public class StorageContainerDaoImpl implements StorageContainerDao {

    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;

    @Override
    @Trace
    public StorageContainerEntity getById(long storageContainerId) {
        return (StorageContainerEntity) sessionFactory.getCurrentSession().load(StorageContainerEntity.class, storageContainerId);
    }
}
