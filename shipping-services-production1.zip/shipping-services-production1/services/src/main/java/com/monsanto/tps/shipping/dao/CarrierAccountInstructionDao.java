package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CarrierAccountInstructionEntity;

/**
 * User: SDCHIL
 */
public interface CarrierAccountInstructionDao {

    public CarrierAccountInstructionEntity findByCarrierAcountContact(Long carrierId, Long irdAcctId, Long irdContactId);
}
