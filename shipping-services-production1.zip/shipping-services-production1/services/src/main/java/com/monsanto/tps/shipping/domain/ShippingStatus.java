package com.monsanto.tps.shipping.domain;

import com.google.common.collect.Lists;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.List;

/**
 * User: pgadi
 */
@Entity
@Cacheable
@Table(name = "SHIPPING_STATUS", schema = "INVENTORY_MGT")
public class ShippingStatus implements Comparable<ShippingStatus> {
    public static final String PENDING = "Pending";
    public static final String READY_FOR_PICKUP = "Ready for Pickup";
    public static final String IN_TRANSIT = "In Transit";
    public static final String ACKNOWLEDGED = "Acknowledged";
    public static final String DELIVERED = "Delivered";
    public static final String COMPLETE_VERIFIED = "Complete Verified";
    public static final String COMPLETE_UNVERIFIED = "Complete Unverified";

    public static final List<String> IN_PROGRESS_SHIPMENTS_STATUS = Lists.newArrayList(READY_FOR_PICKUP, IN_TRANSIT, DELIVERED);
    public static final List<String> COMPLETED_SHIPMENTS_STATUS = Lists.newArrayList(COMPLETE_VERIFIED, COMPLETE_UNVERIFIED);

    @Id
    @GeneratedValue(generator = "inventory-mgt-uuid")
    @GenericGenerator(
            name = "inventory-mgt-uuid",
            strategy = "com.monsanto.tps.shipping.dao.primarykey.InventoryMgtIdGenerator"
    )
    @Column(name = "SHIPPING_STATUS_ID")
    private Long shippingStatusId;

    @Column(name = "name")
    private String name;

    @Column(name = "ref_active")
    @Type(type = "true_false")
    private Boolean active;

    @Column(name = "list_rank")
    private Long listRank;

    public ShippingStatus(String name) {
        this.name = name;
    }

    public ShippingStatus() {
    }

    public Long getShippingStatusId() {
        return shippingStatusId;
    }

    public void setShippingStatusId(Long shippingStatusId) {
        this.shippingStatusId = shippingStatusId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Long getListRank() {
        return listRank;
    }

    public void setListRank(Long listRank) {
        this.listRank = listRank;
    }

    @Override
    public int compareTo(ShippingStatus compareToStatus) {
        return this.getListRank().compareTo(compareToStatus.getListRank());
    }
}

