package com.monsanto.tps.shipping.business.reports.MTFReports;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;

public interface MTFDetailsDocumentBuilder {

    void buildDocument(PdfWriter writer, Document document, ShipmentPackingListEntity packingList) throws DocumentException;

}
