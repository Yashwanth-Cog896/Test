package com.monsanto.tps.shipping.service;

import com.google.common.collect.Lists;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.shipping.business.CropBusiness;
import com.monsanto.tps.shipping.business.EpcBusiness;
import com.monsanto.tps.shipping.business.ShipmentPackingListBusiness;
import com.monsanto.tps.shipping.converter.PackingListContainerConversion;
import com.monsanto.tps.shipping.converter.PackingListContentConverter;
import com.monsanto.tps.shipping.dao.ShipmentTypeDao;
import com.monsanto.tps.shipping.domain.*;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.service.model.PackingListContent;
import com.monsanto.tps.shipping.service.model.RegulatedStatus;
import com.monsanto.tps.shipping.service.model.ShipmentPackingList;
import com.monsanto.tps.shipping.service.model.enums.ShipmentTypeEnum;
import com.monsanto.tps.shipping.service.validation.PackingListValidator;
import com.monsanto.tps.shipping.util.ShippingWebException;
import com.monsanto.tps.shipping.util.aspect.DynamicColumnInterceptor;
import com.monsanto.tps.shipping.util.aspect.SolrPackingListIdParam;
import com.monsanto.tps.shipping.util.aspect.Trace;
import com.monsanto.tps.shipping.util.aspect.UpdateSolrIndex;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateMidnight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * @author Supreet Singh (sssing5)
 */
@Component("packingListService")
public class PackingListServiceImpl implements PackingListService {


    @Resource(name = "userDetailsProvider")
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;
    @Autowired
    private PackingListValidator packingListValidator;
    @Autowired
    private PackingListContainerConversion containerConverter;
    @Autowired
    private CropBusiness cropBusiness;
    @Autowired
    private PackingListContentConverter packingListContentConverter;
    @Autowired
    private ShipmentTypeDao shipmentTypeDao;
    @Autowired
    private EpcBusiness epcBusiness;

    @Override
    @Trace
    @Transactional(readOnly = true)
    public List<ShipmentPackingList> getPackingLists(Long accountId, Long modifiedNumberOfDays) {
        ShippingWebException.checkArgument(accountId != null, "AccountId cannot be null");
        ShippingWebException.checkArgument(modifiedNumberOfDays != null, "Number of days cannot be null");

        DateMidnight dateTime = new DateMidnight().minusDays(modifiedNumberOfDays.intValue());
        List<ShipmentPackingListEntity> packingListsByCreatorAndModifiedDate = shipmentPackingListBusiness
            .getShipmentPackingListsByProgramAfterDate(accountId, dateTime.toDate());
        List<ShipmentPackingList> shipmentPackingLists = Lists.newArrayList();
        for (ShipmentPackingListEntity entity : packingListsByCreatorAndModifiedDate) {
            shipmentPackingLists.add(getShipmentPackingListWithoutContainers(entity));
        }
        return shipmentPackingLists;
    }

    //TODO THIS IS TO AID TESTING.  THIS SHOULD BE REMOVED WHEN VERIFY IS WORKED ON
    @Override
    @Trace
    @Transactional
    public ShipmentPackingList verifyPackingList(Long packingListId) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        return createShipmentPackingListWithoutContainers(packingList);
    }

    @Override
    @Trace
    @Transactional
    public Boolean validateShipToMatch(Long packingListId, Long contactId) {
        return shipmentPackingListBusiness.validateShipToMatch(packingListId, contactId);
    }

    @Override
    @Trace
    @Transactional(readOnly = true)
    public ShipmentPackingList getPackingListDetails(Long packingListId) {
        if (packingListId == null) {
            throw new ShippingWebException("PackingListId cannot be null");
        }
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        return createShipmentPackingListWithContainers(packingList);
    }

    @Override
    @Trace
    @Transactional(readOnly = true)
    public ShipmentPackingList getPackingListDetailsForBoxBarcode(String barcode) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness
            .getShipmentPackingListForBoxBarcode(barcode);
        if (packingList == null) {
            throw new ShippingWebException("No shipment packing list found for bar code " + barcode);
        }
        return createShipmentPackingListWithContainers(packingList);
    }

    @Override
    @Trace
    @Transactional(readOnly = true)
    public ShipmentPackingList getPackingListDetailsForShipmentBarcode(String barcode) {
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness
            .getShipmentPackingListForShipmentBarcode(barcode);
        if (packingList == null) {
            throw new ShippingWebException("No shipment packing list found for bar code " + barcode);
        }
        return createShipmentPackingListWithContainers(packingList);
    }

    @Override
    @Trace
    @Transactional
    @UpdateSolrIndex
    public @SolrPackingListIdParam ShipmentPackingList createPackingList(ShipmentPackingList shipmentPackingList) {
        if (shipmentPackingList.getShipmentType() != null){
            ShipmentTypeEnum shipmentType = ShipmentTypeEnum.valueOf(shipmentPackingList.getShipmentType().toUpperCase().trim());
            ShipmentTypeEntity shipmentTypeEntity = shipmentTypeDao.findByName(shipmentType.getTypeName());
            shipmentPackingList.setShipmentTypeId(shipmentTypeEntity.getShipmentTypeId());
        }
        packingListValidator.validate(shipmentPackingList);
        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.savePackingList(shipmentPackingList, getUsername());
        return createShipmentPackingListWithoutContainers(packingList);
    }

    @Override
    @Trace
    @Transactional
    @UpdateSolrIndex
    public @SolrPackingListIdParam ShipmentPackingList createEpcPackingList(ShipmentPackingList shipmentPackingList) {
        if (shipmentPackingList.getShipmentType() != null){
            ShipmentTypeEnum shipmentType = ShipmentTypeEnum.valueOf(shipmentPackingList.getShipmentType().toUpperCase().trim());
            ShipmentTypeEntity shipmentTypeEntity = shipmentTypeDao.findByName(shipmentType.getTypeName());
            shipmentPackingList.setShipmentTypeId(shipmentTypeEntity.getShipmentTypeId());
        }

        epcBusiness.associateBarcodesFromEpc(shipmentPackingList);

        packingListValidator.validate(shipmentPackingList);

        ShipmentPackingListEntity packingList = shipmentPackingListBusiness.savePackingList(shipmentPackingList, getUsername());
        return createShipmentPackingListWithoutContainers(packingList);
    }

    @Override
    @Trace
    @Transactional
    public ShipmentPackingList createPackingListWithoutContents(ShipmentPackingList shipmentPackingList) {
        packingListValidator.validate(shipmentPackingList);
        ShipmentPackingList created = createShipmentPackingListWithoutContainers(shipmentPackingListBusiness.savePackingListWithoutContents(shipmentPackingList, getUsername()));
        if (created.getCropId() == null) {
            created.setCropId(shipmentPackingList.getCropId());
        }
        return created;
    }


    @Override
    @Trace
    @Transactional
    public ShipmentPackingList editPackingList(ShipmentPackingList shipmentPackingList) {
        return createShipmentPackingListWithoutContainers(shipmentPackingListBusiness.editPackingList(shipmentPackingList, getUsername()));
    }

    @Override
    @Trace
    @Transactional
    @UpdateSolrIndex
    public void deletePackingList(@SolrPackingListIdParam Long packingListId) {
        shipmentPackingListBusiness.deletePackingList(packingListId);
    }

    @Override
    @Trace
    @Transactional
    public void editPackingListUom(Long packingListId, String uomRefId) {
        shipmentPackingListBusiness.editUom(packingListId, uomRefId);
    }

    @Override
    @Trace
    @Transactional(readOnly = true)
    public List<ShipmentPackingList> getInternationalPackingLists(String isoCountryCode, Long modifiedNumberOfDays) {
        ShippingWebException.checkArgument(modifiedNumberOfDays != null, "Number of days cannot be null");

        DateMidnight dateTime = new DateMidnight().minusDays(modifiedNumberOfDays.intValue());
        List<ShipmentPackingListEntity> entities = shipmentPackingListBusiness
            .getShipmentPackingListsByCountry(isoCountryCode, dateTime.toDate());
        List<ShipmentPackingList> shipmentPackingLists = Lists.newArrayList();
        for (ShipmentPackingListEntity entity : entities) {
            shipmentPackingLists.add(getShipmentPackingListWithoutContainers(entity));
        }
        return shipmentPackingLists;
    }

    private ShipmentPackingList createShipmentPackingListWithContainers(ShipmentPackingListEntity packingList) {
        ShipmentPackingList shipmentPackingList = createShipmentPackingListWithoutContainers(packingList);
        shipmentPackingList.setPackingListContainers(getPackingListContainers(packingList));
        setUomDetailsOnThePackingList(shipmentPackingList);
        setAllContentsHasUomFlagOnPackingList(shipmentPackingList);
        return shipmentPackingList;
    }

    private void setUomDetailsOnThePackingList(ShipmentPackingList shipmentPackingList) {
        for (PackingListContainer packingListContainer : shipmentPackingList.getPackingListContainers()) {
            if (!StringUtils.isEmpty(packingListContainer.getUom())) {
                shipmentPackingList.setWeightUOM(packingListContainer.getUom());
                return;
            }
            for (PackingListContent packingListContent : packingListContainer.getPackingListContents()) {
                if (!StringUtils.isEmpty(packingListContent.getWeightUOM())) {
                    shipmentPackingList.setWeightUOM(packingListContent.getWeightUOM());
                    return;
                }
            }
        }
    }

    private void setAllContentsHasUomFlagOnPackingList(ShipmentPackingList shipmentPackingList) {
        Boolean allContentsHasUom = true;
        for (PackingListContainer packingListContainer : shipmentPackingList.getPackingListContainers()) {
            for (PackingListContent packingListContent : packingListContainer.getPackingListContents()) {
                if (StringUtils.isEmpty(packingListContent.getWeightUOM())) {
                    allContentsHasUom = false;
                    break;
                }
            }
        }
        shipmentPackingList.setAllContentsHasUom(allContentsHasUom);
    }

    private String getUomFromContents(PackingListContainer packingListContainer) {
        String contentUom = null;
        for (PackingListContent packingListContent : packingListContainer.getPackingListContents()) {
            if (!StringUtils.isEmpty(packingListContent.getWeightUOM())) {
                contentUom = packingListContent.getWeightUOM();
                break;
            }
        }
        return contentUom;
    }

    private List<PackingListContainer> getPackingListContainers(ShipmentPackingListEntity packingList) {
        Collection<ShipmentContainerEntity> shipmentContainersByPackingListId = packingList.getShipmentContainers();
        List<PackingListContainer> packingListContainers = Lists.newArrayList();

        for (ShipmentContainerEntity shipmentContainerEntity : shipmentContainersByPackingListId) {
            PackingListContainer container = containerConverter.toDto(shipmentContainerEntity, new PackingListContainer());
            container.setId(shipmentContainerEntity.getShipmentContainerId());
            container.setPackingListContents(addContainerToPackingListContent(shipmentContainerEntity.getStorageContainer(), packingList.getShipmentType().getName()));
            packingListContainers.add(container);
        }
        return packingListContainers;
    }

    private List<PackingListContent> addContainerToPackingListContent(StorageContainerEntity storageContainer,
                                                                      String shipmentTypeName) {
        Collection<? extends ScannedContainerEntity> containerEntities = storageContainer.getContainers();
        List<PackingListContent> packingListContents = Lists.newArrayList();
        for (ScannedContainerEntity contentContainerEntity : containerEntities) {
            packingListContents.add(createPackingListContent(contentContainerEntity, storageContainer, shipmentTypeName));
        }
        return packingListContents;
    }


    private ShipmentPackingList createShipmentPackingListWithoutContainers(ShipmentPackingListEntity entity) {
        ShipmentPackingList shipmentPackingList = getShipmentPackingListWithoutContainers(entity);
        setCropId(entity, shipmentPackingList);
        shipmentPackingList.setDynamicColumns(DynamicColumnInterceptor.getDynamicColumnsBasedOnType(entity.getShipmentType().getName()));

        return shipmentPackingList;
    }

    private ShipmentPackingList getShipmentPackingListWithoutContainers(ShipmentPackingListEntity entity) {
        String fromContactId = (entity.getFromContactId() != null) ? entity.getFromContactId().toString() : null;
        String toContactId;
        String soldToContactId = null;
        String userString = entity.getCreatedBy().getFirstName() + " " + entity.getCreatedBy().getLastName();
        Long shipmentTypeId = entity.getShipmentType() != null ? entity.getShipmentType().getShipmentTypeId() : -1L;
        SapOrderShipmentEntity sapEntity = entity.getSapOrderShipment();
        boolean international = false;
        if (sapEntity == null) {
            Long toContact = entity.getToContactId();
            toContactId = (toContact != null) ? toContact.toString() : null;
        } else {
            international = true;
            toContactId = sapEntity.getShipToCustomerNumber();
            soldToContactId = sapEntity.getSoldToCustomerNumber();
        }
        SapOrderShipmentEntity sapOrderShipment = entity.getSapOrderShipment();
        Long orderShipmentId = (sapOrderShipment != null) ? sapOrderShipment.getSapOrderShipmentId() : null;
        ShipmentPackingList shipmentPackingList = new ShipmentPackingList(entity.getShipmentPackingListId(),
            entity.getDescription(), userString,
            entity.getCreationDate(), entity.getLastModifiedDate(), fromContactId, toContactId, shipmentTypeId,
            orderShipmentId);
        shipmentPackingList.setInternational(international);
        if (international) {
            shipmentPackingList.setSoldToContactId(soldToContactId);
            SapOrderShipmentEntity sapOrderShipmentEntity = entity.getSapOrderShipment();
            shipmentPackingList.setSapOrderShipmentId(sapOrderShipmentEntity.getSapOrderShipmentId());
            shipmentPackingList.setFromSapContactId(sapOrderShipmentEntity.getSapStorageLocationCode());
            shipmentPackingList.setSapOrderNumber(sapOrderShipmentEntity.getSapOrderNumber());
            shipmentPackingList.setSapShipmentNumber(sapOrderShipmentEntity.getShipmentNumber());
            shipmentPackingList
                .setInternationalHoldStatus(!StringUtils.isEmpty(sapOrderShipmentEntity.getSapErrorMessageText()));
        }

        shipmentPackingList.setHasExternalPermits(entity.hasExternalPermits());
        shipmentPackingList.setEditable(packingListValidator.isEditable(entity));
        if (entity.getRegulatedStatusText() != null) {
            shipmentPackingList.setRegulatedStatus(new RegulatedStatus(entity.getRegulatedStatusText()));
        } else {
            shipmentPackingList.setRegulatedStatus(new RegulatedStatus());
        }
        if (entity.getMaterialStatusText() != null) {
            shipmentPackingList.setMaterialStatus(entity.getMaterialStatusText());
        } else {
            shipmentPackingList.setMaterialStatus(null);
        }

        shipmentPackingList.setShipToAttn(entity.getShipToAttn());
        shipmentPackingList.setComplianceConfirmedDate(entity.getComplianceConfirmedDate());
        shipmentPackingList.setShipmentBarcode(entity.getBarcode());
        return shipmentPackingList;
    }

    private void setCropId(ShipmentPackingListEntity entity, ShipmentPackingList shipmentPackingList) {
        CropEntity cropEntity = cropBusiness.getCropByPackingList(entity);
        if (cropEntity != null) {
            shipmentPackingList.setCropId(cropEntity.getCropId());
        }
    }

    private PackingListContent createPackingListContent(ScannedContainerEntity contentContainerEntity,
                                                        StorageContainerEntity storageContainerEntity,
                                                        String shipmentTypeName) {
        PackingListContent packingListContent = new PackingListContent();
        packingListContentConverter.setPackingListContentValues(packingListContent, contentContainerEntity, shipmentTypeName);
        setValuesFromStorageContainer(storageContainerEntity, packingListContent);
        return packingListContent;
    }

    private void setValuesFromStorageContainer(StorageContainerEntity storageContainerEntity,
                                               PackingListContent packingListContent) {
        packingListContent.setBox(storageContainerEntity.getName());
        packingListContent.setContainerBarcode(storageContainerEntity.getBarcode());
    }


    private String getUsername() {
        UserDetails userDetails = userDetailsProvider.getUserDetails();
        return userDetails != null ? userDetails.getUsername() : "Could not identify user";
    }
}
