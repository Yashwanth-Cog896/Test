/**
 * Created by TMILB on 7/8/14.
 */

package com.monsanto.tps.shipping.dao;

import com.monsanto.tps.shipping.domain.CustomsBrokerEntity;

import java.util.Collection;

public interface CustomsBrokerDao {
    CustomsBrokerEntity findById(long id);
    public CustomsBrokerEntity findBy(Long fromAccountId, String countryCode);
    Collection<CustomsBrokerEntity> loadAll();
}
