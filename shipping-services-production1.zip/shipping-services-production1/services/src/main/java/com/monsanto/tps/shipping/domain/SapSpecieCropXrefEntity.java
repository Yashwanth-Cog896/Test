package com.monsanto.tps.shipping.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * User: pgadi
 */
@Entity
@Table(name = "SAP_SPECIE_CROP_XREF", schema = "COMPLI_PROC")
public class SapSpecieCropXrefEntity {

    @Id
    @Column(name = "SAP_SPECIE_CODE", nullable = false)
    private String sapSpecieCode;

    @Column(name = "CROP_SUB_CLASS_ID", nullable = false)
    private Long cropSubClassId;

    @Column(name = "SPECIE_CROP_NAME")
    private String specieCropName;

    @Column(name = "IS_ACTIVE")
    @Type(type="true_false")
    private boolean isActive;

    public String getSapSpecieCode() { return sapSpecieCode; }

    public void setSapSpecieCode(String sapSpecieCode) { this.sapSpecieCode = sapSpecieCode; }

    public Long getCropSubClassId() { return cropSubClassId; }

    public void setCropSubClassId(Long cropSubClassId) { this.cropSubClassId = cropSubClassId; }

    public String getSpecieCropName() { return specieCropName; }

    public void setSpecieCropName(String specieCropName) { this.specieCropName = specieCropName; }

    public boolean isActive() { return isActive; }

    public void setActive(boolean isActive) { this.isActive = isActive; }
}
