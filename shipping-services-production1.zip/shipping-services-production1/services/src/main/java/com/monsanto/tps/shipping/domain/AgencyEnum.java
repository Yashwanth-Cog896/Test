package com.monsanto.tps.shipping.domain;

/**
 * User: DCENGL
 */
public enum AgencyEnum {

    USDA("USDA", 1),
    EPA("EPA", 2),
    USDA_EPA("USDA_EPA", 0), //TODO This is not an agency.  This strategy will get unmanigable as we add more agencies.
    STEWARDSHIP("STWRDSH", 3),
    PRE_EUP("PRE_EUP", 4);

    private final String abbreviation;
    private final Integer rankOrder;

    AgencyEnum(String abbreviation, Integer rankOrder) {
        this.abbreviation = abbreviation;
        this.rankOrder = rankOrder;
    }

    public Integer getRankOrder() {
        return rankOrder;
    }

    public String getAbbr() {
        return abbreviation;
    }

    public static AgencyEnum fromAbbr(String abbreviation) {
        for (AgencyEnum agencyEnum : values()) {
            if (agencyEnum.getAbbr().equals(abbreviation)) {
                return agencyEnum;
            }
        }
        return null;
    }
}
