package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.business.SapCropDescriptionBusiness;
import com.monsanto.tps.shipping.service.model.CropDescription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * User: pgadi
 */
@Component("sapCropDescriptionService")
public class SapCropDescriptionServiceImpl implements SapCropDescriptionService {

    @Autowired
    private SapCropDescriptionBusiness sapCropDescriptionBusiness;

    @Override
    @Transactional
    public List<CropDescription> getCropDescriptions() {
        return sapCropDescriptionBusiness.getCropDescriptions();
    }
}
