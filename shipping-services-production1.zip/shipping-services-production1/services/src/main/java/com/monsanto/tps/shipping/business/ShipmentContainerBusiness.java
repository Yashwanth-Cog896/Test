package com.monsanto.tps.shipping.business;

import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.service.model.PackingListContainer;

import java.util.Collection;
import java.util.List;

/**
 * User: DCENGL
 */
public interface ShipmentContainerBusiness {

    void updateContainers(ShipmentPackingListEntity shipmentPackingListEntity, List<PackingListContainer> packingListContainers, PackingListContainer stagingContainer, Long uomId, String uom);

    void delete(Collection<ShipmentContainerEntity> shipmentContainers);

    void deleteShipmentContainer(ShipmentContainerEntity shipmentContainer);

    ShipmentContainerEntity createShipmentContainer(Long packingListId);

    ShipmentContainerEntity createStagingContainer(Long packingListId);

    void save(ShipmentContainerEntity container);

    ShipmentContainerEntity getShipmentContainer(Long shipmentContainerId);

    void updateUom(Long packingListId, Long uomId);
}
