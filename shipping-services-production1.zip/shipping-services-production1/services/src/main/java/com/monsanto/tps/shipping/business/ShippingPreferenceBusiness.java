package com.monsanto.tps.shipping.business;

/**
 * User: DCENGL
 */
public interface ShippingPreferenceBusiness {

    String getShippingPreferenceValue(String type, Long accountId);

}
