package com.monsanto.tps.shipping.service;

import com.monsanto.tps.shipping.service.model.RegulatedAPIResponse;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/regulated-status-check")
public interface RegulatedStatusCheckService {

    @GET
    @Path("/event/{event-string}")
    @Produces(APPLICATION_JSON)
    RegulatedAPIResponse getRegulatedAPIResponses(@PathParam("event-string") String eventString);
}
