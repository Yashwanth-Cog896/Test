package com.monsanto.tps.shipping.business;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.converter.PackingListContainerConversion;
import com.monsanto.tps.shipping.dao.BarcodeGeneratorDao;
import com.monsanto.tps.shipping.dao.ShipmentContainerDao;
import com.monsanto.tps.shipping.dao.StorageContainerTypeDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureConversionDao;
import com.monsanto.tps.shipping.dao.UnitOfMeasureDao;
import com.monsanto.tps.shipping.domain.ContentType;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.StorageContainerEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureConversionEntity;
import com.monsanto.tps.shipping.domain.UnitOfMeasureEntity;
import com.monsanto.tps.shipping.service.model.PackingListContainer;
import com.monsanto.tps.shipping.util.ErrorReportingEmailSender;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isEmpty;

/**
 * User: DCENGL
 */
@Service
public class ShipmentContainerBusinessImpl implements ShipmentContainerBusiness {

    public static final String UNBOXED_DESCRIPTION = "Container for Unboxed contents";
    @Autowired
    private ShipmentContainerDao shipmentContainerDao;
    @Autowired
    private BarcodeGeneratorDao barcodeGeneratorDao;
    @Autowired
    private StorageContainerTypeDao storageContainerTypeDao;
    @Autowired
    private PackingListContentBusiness packingListContentBusiness;
    @Autowired
    private UnitOfMeasureDao unitOfMeasureDao;
    @Autowired
    private UnitOfMeasureConversionDao unitOfMeasureConversionDao;
    @Autowired
    private ErrorReportingEmailSender errorReportingEmailSender;
    @Autowired
    private ShipmentPackingListBusiness shipmentPackingListBusiness;

    public static final String BOX = "Box";
    public static final String BOX_0 = "Box-0";

    @Autowired
    private PackingListContainerConversion containerConverter;

    public static final String CONVERSION_FACTOR_NOT_FOUND_MESSAGE = "A conversion factor was not found to convert from UOM Id: [%s] to UOM Id: [%s].  " +
            "Content weights were not converted for (Packing List Id: [%s] & Description: [%s] ).  " +
            "Please work with data management to have the appropriate conversion factor added in MIDAS.UOM_CONVERSION.";
    public static final String PERMIT_UNITS_UOM = "Pounds";
    public static final double CONVERSION_FACTOR_IF_UOMS_MATCH = 1.0;

    @Trace
    @Override
    public void updateContainers(ShipmentPackingListEntity shipmentPackingListEntity, List<PackingListContainer> packingListContainers, PackingListContainer stagingContainer, Long uomId, String uomAbbreviation) {
        Double permitUnitsConversionFactor = uomId == null ? null : getUomConversionFactor(uomId, shipmentPackingListEntity);
        List<ShipmentContainerEntity> shipmentContainers = Lists.newArrayList();

        if (stagingContainer != null) {
            ShipmentContainerEntity unboxedShipmentContainerEntity = updateStagingContainer(shipmentPackingListEntity, stagingContainer, uomId);
            shipmentContainers.add(unboxedShipmentContainerEntity);
        }
        if (CollectionUtils.isNotEmpty(packingListContainers)) {
            for (PackingListContainer packingListContainer : packingListContainers) {
                ShipmentContainerEntity shipmentContainerEntity = newStorageContainer(packingListContainer.getBarcode(), shipmentPackingListEntity.getShipmentType().getContentType(), BOX);

                packingListContentBusiness.updatePackingListContents(shipmentContainerEntity.getStorageContainer(),
                        packingListContainer.getPackingListContents(), shipmentPackingListEntity.getShipmentType(), uomId, permitUnitsConversionFactor);
                shipmentContainerEntity.setShipmentPackingList(shipmentPackingListEntity);

                containerConverter.toEntity(packingListContainer, shipmentContainerEntity);

                shipmentContainers.add(shipmentContainerEntity);
            }
        }
        shipmentPackingListEntity.setShipmentContainers(shipmentContainers);
    }

    public ShipmentContainerEntity updateStagingContainer(ShipmentPackingListEntity shipmentPackingListEntity, PackingListContainer stagingContainer, Long uomId) {
        Double permitUnitsConversionFactor = uomId == null ? null : getUomConversionFactor(uomId, shipmentPackingListEntity);
        ShipmentContainerEntity shipmentContainerEntity = newStorageContainer(stagingContainer.getBarcode(), shipmentPackingListEntity.getShipmentType().getContentType(), BOX_0);

        packingListContentBusiness.updatePackingListContents(shipmentContainerEntity.getStorageContainer(),
                stagingContainer.getPackingListContents(), shipmentPackingListEntity.getShipmentType(), uomId, permitUnitsConversionFactor);
        shipmentContainerEntity.setShipmentPackingList(shipmentPackingListEntity);

        containerConverter.toEntity(stagingContainer, shipmentContainerEntity);

        return shipmentContainerEntity;
    }

    @Trace
    @Override
    public void delete(Collection<ShipmentContainerEntity> shipmentContainers) {
        if (!CollectionUtils.isEmpty(shipmentContainers)) {
            for (ShipmentContainerEntity shipmentContainer : shipmentContainers) {
                deleteShipmentContainer(shipmentContainer);
            }
        }
    }

    @Trace
    @Override
    public void deleteShipmentContainer(ShipmentContainerEntity shipmentContainer) {
        packingListContentBusiness.deleteContent(shipmentContainer.getStorageContainer().getContainers());
        shipmentContainerDao.delete(shipmentContainer);
    }

    @Trace
    @Override
    public ShipmentContainerEntity createShipmentContainer(Long packingListId) {
        ShipmentPackingListEntity shipmentPackingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        return createShipmentContainerEntity(shipmentPackingList, BOX);
    }

    @Override
    public ShipmentContainerEntity createStagingContainer(Long packingListId) {
        ShipmentPackingListEntity shipmentPackingList = shipmentPackingListBusiness.getShipmentPackingList(packingListId);
        ShipmentContainerEntity existingStagingContainer = findExistingStagingContainer(shipmentPackingList.getShipmentContainers());
        return existingStagingContainer == null ?  createShipmentContainerEntity(shipmentPackingList, BOX_0) : existingStagingContainer;
    }

    private ShipmentContainerEntity findExistingStagingContainer(Collection<ShipmentContainerEntity> existingShipmentContainers) {
        return Iterables.find(existingShipmentContainers, new Predicate<ShipmentContainerEntity>() {
            @Override
            public boolean apply(ShipmentContainerEntity input) {
                return BOX_0.equals(input.getStorageContainer().getStorageContainerType().getName());
            }
        }, null);
    }

    private ShipmentContainerEntity createShipmentContainerEntity(ShipmentPackingListEntity shipmentPackingList, String containerType) {
        ShipmentContainerEntity shipmentContainerEntity = newStorageContainer(null, shipmentPackingList.getShipmentType().getContentType(), containerType);
        shipmentContainerEntity.setShipmentPackingList(shipmentPackingList);

        shipmentContainerDao.save(shipmentContainerEntity);
        return shipmentContainerEntity;
    }

    @Trace
    @Override
    public ShipmentContainerEntity getShipmentContainer(Long shipmentContainerId) {
        return shipmentContainerDao.load(shipmentContainerId);
    }

    private Double getUomConversionFactor(Long uomId, ShipmentPackingListEntity packingListEntity) {
        UnitOfMeasureEntity permitUnitsUom = unitOfMeasureDao.findByName(PERMIT_UNITS_UOM);
        UnitOfMeasureConversionEntity conversionEntity = unitOfMeasureConversionDao.getUomConversion(uomId, permitUnitsUom.getId());
        validateUomConversionFactorExists(conversionEntity, uomId, permitUnitsUom.getId(), packingListEntity);
        Double conversionFactor = getConversionFactor(uomId, permitUnitsUom.getId(), conversionEntity);
        return conversionFactor == null ? null: conversionFactor;
    }

    private Double getConversionFactor(Long uomId, Long permitUnitsUomId, UnitOfMeasureConversionEntity conversionEntity) {
        if (conversionEntity == null && permitUnitsUomId.equals(uomId)) {
            return CONVERSION_FACTOR_IF_UOMS_MATCH;
        }
        return conversionEntity == null ? null : conversionEntity.getConversionFactor();
    }

    private void validateUomConversionFactorExists(UnitOfMeasureConversionEntity conversionEntity, Long uomId, Long permitUnitsUomId, ShipmentPackingListEntity packingListEntity) {
        if((conversionEntity == null && uomId != null) && !permitUnitsUomId.equals(uomId)){
            sendConversionFactorNotFoundMessage(uomId, permitUnitsUomId, packingListEntity);
        }
    }

    private void sendConversionFactorNotFoundMessage(Long uomId, Long permitsUnitsUomId, ShipmentPackingListEntity packingListEntity) {
        String message = String.format(CONVERSION_FACTOR_NOT_FOUND_MESSAGE, uomId, permitsUnitsUomId, packingListEntity.getShipmentPackingListId(), packingListEntity.getDescription());
        errorReportingEmailSender.sendMessage(message, "UOM Conversion Factor Not Found");
    }

    public ShipmentContainerEntity newStorageContainer(String barcode, ContentType contentType, String boxName) {
        ShipmentContainerEntity shipmentContainerEntity = new ShipmentContainerEntity();
        StorageContainerEntity storageContainer =  new StorageContainerEntity();
        if (isEmpty(barcode)) {
            barcode = barcodeGeneratorDao.generateNewStorageContainerBarcode();
        }
        storageContainer.setBarcode(barcode);

        storageContainer.setStorageContainerType(storageContainerTypeDao.getByName(boxName));
        storageContainer.setCreationDate(new Date());
        if(boxName.equals(BOX_0)) {
            storageContainer.setName("Staging Container");
            storageContainer.setDescription(UNBOXED_DESCRIPTION);
        } else{
            storageContainer.setName(barcode);
            storageContainer.setDescription(barcode);
        }

        shipmentContainerEntity.setStorageContainer(storageContainer);

        return shipmentContainerEntity;
    }

    @Trace
    @Override
    public void save(ShipmentContainerEntity entity) {
        shipmentContainerDao.save(entity);
    }

    @Trace
    @Override
    public void updateUom(Long packingListId, Long uomId) {
        shipmentContainerDao.updateUom(packingListId, uomId);
    }
}
