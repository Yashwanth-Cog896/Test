package com.monsanto.tps.shipping.service;

import com.monsanto.tps.party.transfer.ContactTO;
import com.monsanto.tps.shipping.business.ContactBusiness;
import com.monsanto.tps.shipping.service.model.ShipmentContact;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * User: DCENGL
 */
@Component("contactService")
public class ContactServiceImpl implements ContactService {

    @Autowired
    private ContactBusiness contactBusiness;

    @Trace
    @Override
    public List<ShipmentContact> getAllForAccount(Long accountId) {
        return contactBusiness.getContactsForAccount(accountId);
    }

    @Trace
    @Override
    public ShipmentContact getContact(Long contactId) {
        return contactBusiness.getContact(contactId);
    }

    @Override
    public ContactTO getContactTOByContactId(Long contactId) {
        return contactBusiness.getPartyContactByContactId(contactId);
    }

    @Override
    public List<ContactTO> getContactTOByAccountId(Long accountId) {
        return contactBusiness.getPartyContactsByAccountId(accountId);
    }

}
