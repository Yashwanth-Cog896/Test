package com.monsanto.tps.shipping.business.compliance;

import com.google.common.collect.Lists;
import com.monsanto.tps.shipping.business.ContentContainerBusiness;
import com.monsanto.tps.shipping.dao.RegulatedMovementDao;
import com.monsanto.tps.shipping.domain.AgencyEntity;
import com.monsanto.tps.shipping.domain.ContentEntity;
import com.monsanto.tps.shipping.domain.RegulatedInventoryMovementEntity;
import com.monsanto.tps.shipping.domain.ScannedContainerEntity;
import com.monsanto.tps.shipping.domain.ShipmentPackingListEntity;
import com.monsanto.tps.shipping.domain.ShipmentTypeEntity;
import com.monsanto.tps.shipping.service.model.Event;
import com.monsanto.tps.shipping.util.aspect.Trace;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by DCENGL
 */
@Service("regulatedScannedContainerMovementUpdater")
public class RegulatedScannedContainerMovementUpdater implements RegulatedMovementUpdater<ContentEntity> {

    @Autowired
    private RegulatedMovementDao regulatedMovementDao;

    @Autowired
    private ContentContainerBusiness contentContainerBusiness;

    @Trace
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RegulatedInventoryMovementEntity> createRegulatedMovements(ShipmentPackingListEntity packingList, Collection<ContentEntity> contents, AgencyEntity agencyEntity, Event event) {
        Collection<RegulatedInventoryMovementEntity> regulatedMovements = Lists.newArrayList();

        if (CollectionUtils.isEmpty(contents)) {
            return regulatedMovements;
        }

        for (ContentEntity content : contents) {
            Collection<ScannedContainerEntity> scannedContainersWithContent = (Collection<ScannedContainerEntity>) contentContainerBusiness.getAllContentContainersWithContent(packingList, content);

            for (ScannedContainerEntity contentContainer : scannedContainersWithContent) {
                RegulatedInventoryMovementEntity movement = newInstance(contentContainer, agencyEntity, event, packingList.getShipmentType());
                contentContainer.addRegulatedMovement(movement);

                regulatedMovementDao.save(movement);

                regulatedMovements.add(movement);
            }
        }

        return regulatedMovements;
    }

    private RegulatedInventoryMovementEntity newInstance(ScannedContainerEntity contentContainer, AgencyEntity agency, Event event, ShipmentTypeEntity type) {
        RegulatedInventoryMovementEntity movement = new RegulatedInventoryMovementEntity();
        movement.setContainer(contentContainer);
        movement.setAgency(agency);
        movement.setScannedContainer(contentContainer);
        movement.setEventString(event.getEventString());
        movement.setHarvested(type.isHarvested());
        movement.setUserOverridden(false);
        return movement;
    }
}

