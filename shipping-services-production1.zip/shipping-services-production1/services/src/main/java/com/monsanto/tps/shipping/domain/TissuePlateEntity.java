package com.monsanto.tps.shipping.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * User: DCENGL
 */
@Entity
@Table(name="FIELD_PLATE_VW", schema="INVENTORY_MGT")
public class TissuePlateEntity implements ContentEntity {

    @Id
    @Column(name = "BLOCK_BARCODE_NBR")
    private String barcode;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "MAB_PROJECT_NAME")
    private String projectName;

    @Column(name = "LIMS_ID")
    private String limsId;

    @Column(name = "WELL_NBR")
    private String wellNumber;

    @Column(name = "PLATE_TYPE_NM")
    private String plateType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MIDAS_PLOT_ID")
    private PlotEntity plot;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLimsId() {
        return limsId;
    }

    public void setLimsId(String limsId) {
        this.limsId = limsId;
    }

    public String getWellNumber() {
        return wellNumber;
    }

    public void setWellNumber(String wellNumber) {
        this.wellNumber = wellNumber;
    }

    public String getPlateType() {
        return plateType;
    }

    public void setPlateType(String plateType) {
        this.plateType = plateType;
    }

    public PlotEntity getPlot() {
        return plot;
    }

    public void setPlot(PlotEntity plot) {
        this.plot = plot;
    }

    @Override
    public Long getContentId() {
        return null;
    }

    @Override
    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    @Override
    public GeneticMaterialEntity getGeneticMaterial() {
        return null;
    }

    @Override
    public InventoryEntity getInventory() {
        return null;
    }

    @Override
    public ContentType getContentType() {
        return ContentType.TISSUE_PLATE;
    }

    @Override
    public String toString() {
        return "TissuePlateEntity{" +
                ", barcode='" + barcode + '\'' +
                '}';
    }
}
