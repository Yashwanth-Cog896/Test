# see http://gitlab.monsanto.com/cloud-foundry/cf-deploy
#
module.exports = (cfDeploy) ->
  {namePostfix, lsi} = cfDeploy.args

  cfBaseName: 'shipping-services'

  finalRoute: () -> [
    "shipping-services"
  ]

  memoryLimit : '3G'

  instances: 4


  startTimeout: 600


  services: [
    "wam-default#{namePostfix}", "shipping-user#{namePostfix}", "tps-appl-user#{namePostfix}", "PartyRESTService#{namePostfix}",
    "ObservationValueServiceRest#{namePostfix}", "FCM_EpaAgencyRequestLookupService#{namePostfix}", "LabelTemplateService#{namePostfix}",
    "PrinterRESTService#{namePostfix}", "FCM_EpaDocumentService#{namePostfix}", "HDFSProxyService#{namePostfix}",
    "Shipping_FedExShipService#{namePostfix}", "Shipping_FedExTrackService#{namePostfix}", "Shipping_UpsTrackingShipService#{namePostfix}",
    "Shipping_UpsSmallPackageShipService#{namePostfix}", "Shipping_UpsAirFreightService#{namePostfix}", "Shipping_UpsSmallPackageVoidService#{namePostfix}",
    "Shipping_SAPIntegrationService#{namePostfix}", "Shipping_SAPAuthorization#{namePostfix}", "SecurityManager_UserRolesService#{namePostfix}",
    "SecurityManager_IDMSearchService#{namePostfix}", "SecurityMgr_GetApplicationADGroupRoleMapping#{namePostfix}", "shipping-solr-services#{namePostfix}",
    "legacy-shipping-client-id",
    "legacy-shipping-client-secret",
    "ping-url",
    "carrier-api-url",
    "epc-services#{namePostfix}", "geocode-services#{namePostfix}"
  ]

  environment:
    JAVA_OPTS: "-Dlsi.function=#{lsi || 'dev'} -DLOGENV=#{lsi || 'dev'} -Dspring.profiles.active=cloud -Djavax.persistence.query.timeout=86400000"

  smokeTest: (options) -> [
    "http://#{options.tempServerInternal}"
  ]

  deployable: 'services/target/shipping-services.war'
